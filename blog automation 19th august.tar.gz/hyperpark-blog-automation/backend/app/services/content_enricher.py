"""Enforce rich blog format: fix images, inject tables/charts mid-body, inline citations."""

from __future__ import annotations

import re

from bs4 import BeautifulSoup, NavigableString, Tag
from loguru import logger

from app.services.blog_structure import (
    enforce_fixed_blog_structure,
    _is_faq_h2,
    _section_nodes_from_h2,
)
from app.services.runtime_config import get_public_base_url
from app.utils.content_format import validate_rich_format
from app.services.product_context import (
    build_cta_block,
    get_brand_palette,
    get_core_brand_colors,
    inject_brand_palette_style,
    internal_links_tuples,
    product_domain as get_product_domain,
)
from app.utils.link_sanitizer import sanitize_backlinks

_SKIP_H2_IDS = frozenset({"faq", "cta", "sources", "contents", "table-of-contents"})
_TOC_SKIP_TITLES = frozenset({"contents", "table of contents", "on this page"})


def _style_hyperlinks(html: str, product=None) -> str:
    """Force all body hyperlinks to branded bold link color from product settings."""
    if not html:
        return html
    palette = get_brand_palette(product)
    link_color = str(palette.get("link") or "#1d4ed8")
    soup = BeautifulSoup(html, "html.parser")
    for a in soup.find_all("a", href=True):
        href = (a.get("href") or "").strip()
        if not href or href.startswith("#"):
            continue
        # Preserve existing non-color styles; always force bold brand color.
        existing = a.get("style") or ""
        parts = [
            p.strip()
            for p in existing.split(";")
            if p.strip()
            and not p.strip().lower().startswith("color:")
            and not p.strip().lower().startswith("font-weight:")
        ]
        parts.extend([f"color: {link_color}", "font-weight: 700", "text-decoration: underline"])
        a["style"] = "; ".join(parts)
        classes = set(a.get("class") or [])
        classes.add("blog-source-link")
        a["class"] = sorted(classes)
    return str(soup)


def _slugify_heading(text: str) -> str:
    slug = re.sub(r"[^\w\s-]", "", text.lower().strip())
    slug = re.sub(r"[\s_]+", "-", slug).strip("-")
    return slug[:60] or "section"


def _ensure_h2_ids(article: Tag) -> None:
    used: set[str] = set()
    for h2 in article.find_all("h2"):
        if h2.find_parent("nav", class_="toc"):
            continue
        if h2.find_parent("section", class_="blog-cta"):
            continue
        hid = (h2.get("id") or "").strip()
        if not hid:
            base = _slugify_heading(h2.get_text(" ", strip=True))
            hid = base
            n = 2
            while hid in used:
                hid = f"{base}-{n}"
                n += 1
            h2["id"] = hid
        used.add(h2["id"])


def _toc_entries(article: Tag) -> list[tuple[str, str]]:
    entries: list[tuple[str, str]] = []
    seen: set[str] = set()

    for h2 in article.find_all("h2"):
        if h2.find_parent("nav", class_="toc"):
            continue

        title = h2.get_text(" ", strip=True)
        if not title or title.lower() in _TOC_SKIP_TITLES:
            continue

        if h2.find_parent("section", class_="blog-cta"):
            continue
        if (h2.get("id") or "").lower() == "cta":
            continue

        anchor = (h2.get("id") or "").strip()
        if not anchor or anchor in seen:
            continue

        seen.add(anchor)
        entries.append((anchor, title))

    return entries


def _build_toc_nav(soup: BeautifulSoup, entries: list[tuple[str, str]]) -> Tag:
    nav = soup.new_tag(
        "nav",
        attrs={"class": "toc", "aria-label": "On this page"},
    )
    heading = soup.new_tag("h2")
    heading.string = "On this page"
    nav.append(heading)

    ol = soup.new_tag("ol", attrs={"class": "toc-list"})
    for idx, (anchor, title) in enumerate(entries, start=1):
        li = soup.new_tag("li")
        link = soup.new_tag("a", href=f"#{anchor}")
        num = soup.new_tag("span", attrs={"class": "toc-num"})
        num.string = f"{idx:02d}"
        label = soup.new_tag("span", attrs={"class": "toc-label"})
        label.string = title
        link.append(num)
        link.append(label)
        li.append(link)
        ol.append(li)
    nav.append(ol)
    return nav


def _find_article_hero(article: Tag) -> Tag | None:
    """Locate the hero <img>, unwrapping a lone <p>/<figure> wrapper if needed."""
    hero = article.find("img", class_=lambda c: c and "blog-hero-image" in c)
    if not hero:
        h1 = article.find("h1")
        if h1:
            for sib in h1.next_siblings:
                if not isinstance(sib, Tag):
                    continue
                if sib.name == "img":
                    hero = sib
                    break
                if sib.name in ("p", "figure", "div"):
                    inner = sib.find("img")
                    if inner and not sib.find(["p", "h1", "h2", "h3", "ul", "ol", "table"]):
                        hero = inner
                        break
                if sib.name in ("h2", "nav", "section"):
                    break
    if not hero:
        hero = article.find("img")
    return hero


def sync_table_of_contents(html: str) -> str:
    """Rebuild the TOC nav and ALWAYS place it after the hero image (never above)."""
    soup = BeautifulSoup(html, "html.parser")
    article = soup.find("article")
    if not article:
        return html

    _ensure_h2_ids(article)
    entries = _toc_entries(article)

    # Remove every existing TOC so we can re-insert in the correct slot
    for old in list(article.find_all("nav", class_="toc")):
        old.decompose()
    for old in list(article.find_all("div", class_="toc")):
        old.decompose()

    if not entries:
        return str(soup)

    new_nav = _build_toc_nav(soup, entries)
    hero = _find_article_hero(article)
    if hero:
        # If hero is nested in a wrapper, insert TOC after the wrapper (not inside it)
        anchor = hero
        parent = hero.parent
        if (
            isinstance(parent, Tag)
            and parent.name in ("p", "figure", "div", "picture")
            and parent.parent is article
        ):
            anchor = parent
        anchor.insert_after(new_nav)
    else:
        h1 = article.find("h1")
        if h1:
            h1.insert_after(new_nav)
        else:
            article.insert(0, new_nav)

    return str(soup)


def hero_image_src(slug: str) -> str:
    base = get_public_base_url()
    return f"{base}/api/images/{slug}.webp"


def _comparison_table(keyword: str) -> str:
    label = (keyword or "modern operations").strip()
    short = label[:48]
    return f"""
<h2 id="roi-comparison">ROI &amp; Impact for {short}</h2>
<table class="blog-table">
<thead>
<tr><th>Metric</th><th>Status quo without focus on {short}</th><th>With a focused {short} program</th></tr>
</thead>
<tbody>
<tr><td>Operational leakage / waste</td><td>High / poorly measured</td><td>Tracked and reduced</td></tr>
<tr><td>Manual process hours / week</td><td>35–50</td><td>8–15</td></tr>
<tr><td>Decision latency</td><td>Days to weeks</td><td>Near real-time</td></tr>
<tr><td>Typical payback window</td><td>Unclear</td><td>12–18 months</td></tr>
</tbody>
</table>
<p>Teams prioritizing <strong>{label}</strong> should keep every row of this table tied to that exact initiative — not a generic product pitch.</p>
"""


def _stat_grid(keyword: str = "", product=None) -> str:
    from app.services.product_context import company_label

    label = (keyword or "this initiative").strip()[:40]
    product_name = (getattr(product, "name", None) or company_label(product)).strip()
    return f"""
<h2 id="key-metrics">Key Indicators for {label}</h2>
<div class="stat-grid" data-charts-opt-in="1">
  <div class="stat-card"><strong>Faster</strong><span>Time-to-insight once {label} data is unified for {product_name}</span></div>
  <div class="stat-card"><strong>Lower</strong><span>Manual rework vs status-quo ops on {label}</span></div>
  <div class="stat-card"><strong>Clearer</strong><span>Audit trail for {label} decisions</span></div>
  <div class="stat-card"><strong>12–18 mo</strong><span>Typical modeled payback window</span></div>
</div>
"""


def _svg_chart(product=None, keyword: str = "", topic: str = "") -> str:
    from app.services.product_context import company_label

    colors = get_core_brand_colors(get_brand_palette(product))
    cta, accent, primary, navy = (
        colors["cta"],
        colors["accent"],
        colors["primary"],
        colors["navy"],
    )
    custom = get_brand_palette(product).get("custom") or []
    fills = [cta, accent, primary, navy]
    for entry in custom:
        hex_val = entry.get("hex") if isinstance(entry, dict) else None
        if isinstance(hex_val, str) and hex_val.startswith("#"):
            fills.append(hex_val)
    while len(fills) < 4:
        fills.append(primary)
    from html import escape

    company = company_label(product)
    product_name = (getattr(product, "name", None) or company).strip()
    subject = (keyword or topic or product_name).strip()[:48] or "this initiative"
    title = escape(f"{subject} outcome trend")
    caption = escape(
        f"Illustrative trend for {product_name} on {subject} — tied to this product and article, "
        "not a generic industry stock graphic."
    )
    return f"""
<figure class="blog-chart" data-charts-opt-in="1" aria-label="{title}">
<svg viewBox="0 0 520 220" width="100%" height="220" role="img">
  <rect x="0" y="0" width="520" height="220" fill="#f8f9fc"/>
  <text x="20" y="28" fill="{navy}" font-size="14" font-weight="600">{title}</text>
  <rect x="60" y="150" width="70" height="50" fill="{fills[0]}"/>
  <rect x="170" y="110" width="70" height="90" fill="{fills[1]}"/>
  <rect x="280" y="70" width="70" height="130" fill="{fills[2]}"/>
  <rect x="390" y="40" width="70" height="160" fill="{fills[3]}"/>
  <text x="72" y="215" fill="#475569" font-size="11">Baseline</text>
  <text x="176" y="215" fill="#475569" font-size="11">Year 1</text>
  <text x="286" y="215" fill="#475569" font-size="11">Year 2</text>
  <text x="396" y="215" fill="#475569" font-size="11">Year 3</text>
</svg>
<figcaption>{caption}</figcaption>
</figure>
"""


def _cta_block(topic: str, product=None) -> str:
    return build_cta_block(product, topic)


def _strip_all_cta_sections(article: Tag) -> None:
    """Remove every CTA block and orphan placeholder headings."""
    for old in list(article.find_all("section", id="cta")):
        old.decompose()
    for old in list(article.select("section.blog-cta")):
        old.decompose()
    for h2 in list(article.find_all("h2", id="cta")):
        h2.decompose()


def _normalize_cta_at_end(html: str, topic_title: str, product=None) -> str:
    """Replace broken/duplicate CTAs with the canonical block at the end of the article."""
    soup = BeautifulSoup(html, "html.parser")
    article = soup.find("article")
    if not article:
        return html

    _strip_all_cta_sections(article)

    fragment = BeautifulSoup(_cta_block(topic_title, product), "html.parser")
    section = fragment.find("section", id="cta") or fragment.find("section", class_="blog-cta")
    if section:
        article.append(section)
    return str(soup)


def feedback_requests_faq(feedback_history: list | None) -> bool:
    """Deprecated: FAQ is Add-FAQ-button only — never from revision prompts."""
    return False


def html_has_opted_in_faq(html: str) -> bool:
    """True only when FAQ was inserted via the Add FAQ button (data-faq-opt-in)."""
    if not html:
        return False
    soup = BeautifulSoup(html, "html.parser")
    h2 = soup.find("h2", id="faq")
    if not isinstance(h2, Tag):
        return False
    flag = h2.get("data-faq-opt-in")
    return flag in ("1", "true", "yes", True) or h2.has_attr("data-faq-opt-in")


def html_has_faq_section(html: str) -> bool:
    if not html:
        return False
    soup = BeautifulSoup(html, "html.parser")
    if soup.find("h2", id="faq"):
        return True
    if soup.find(string=lambda t: isinstance(t, str) and "frequently asked questions" in t.lower()):
        # May match JSON-LD; also check heading text
        for h2 in soup.find_all("h2"):
            if _is_faq_h2(h2):
                return True
    for script in soup.find_all("script", attrs={"type": "application/ld+json"}):
        raw = (script.string or script.get_text() or "").strip()
        if "FAQPage" in raw:
            return True
    return False


def strip_faq_from_html(html: str) -> str:
    """Remove FAQ heading/body and FAQPage JSON-LD so posts stay FAQ-free by default."""
    import json

    soup = BeautifulSoup(html, "html.parser")
    article = soup.find("article")
    if article:
        for h2 in list(article.find_all("h2")):
            if not _is_faq_h2(h2):
                continue
            for node in _section_nodes_from_h2(h2):
                if isinstance(node, Tag):
                    node.decompose()
                elif isinstance(node, NavigableString):
                    try:
                        node.extract()
                    except Exception:
                        pass
        # Catch FAQ containers that aren't standard h2 sections
        for tag in list(article.find_all(id="faq")):
            if isinstance(tag, Tag) and tag.name != "h2":
                tag.decompose()

    for script in list(soup.find_all("script", attrs={"type": "application/ld+json"})):
        raw = (script.string or script.get_text() or "").strip()
        if not raw:
            continue
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            continue
        items = data if isinstance(data, list) else [data]
        if any(
            isinstance(item, dict)
            and (
                item.get("@type") == "FAQPage"
                or (isinstance(item.get("@type"), list) and "FAQPage" in item.get("@type"))
            )
            for item in items
        ):
            script.decompose()

    return str(soup)


def html_has_charts(html: str) -> bool:
    if not html:
        return False
    return bool(
        re.search(r"<svg[\s>]", html, re.I)
        or re.search(r"stat-(grid|card)", html, re.I)
        or re.search(r'class=["\'][^"\']*blog-chart', html, re.I)
    )


def strip_charts_from_html(html: str) -> str:
    """Remove SVG charts, stat-grids, and injected key-metrics headings. Tables stay."""
    if not html:
        return html
    soup = BeautifulSoup(html, "html.parser")
    article = soup.find("article")
    root = article or soup

    for figure in list(root.find_all("figure", class_="blog-chart")):
        figure.decompose()
    for svg in list(root.find_all("svg")):
        svg.decompose()
    for grid in list(root.find_all("div", class_="stat-grid")):
        grid.decompose()
    for h2 in list(root.find_all("h2", id="key-metrics")):
        for node in _section_nodes_from_h2(h2):
            if isinstance(node, Tag):
                node.decompose()
            elif isinstance(node, NavigableString):
                try:
                    node.extract()
                except Exception:
                    pass

    return str(soup)


def add_charts_to_blog(
    html: str,
    topic_title: str,
    primary_keyword: str,
    product=None,
    slug: str | None = None,
) -> str:
    """Opt-in charts after generation — inject topic/product SVG + stat-grid mid-body."""
    html = strip_charts_from_html(html)
    keyword = primary_keyword or topic_title
    blocks = "\n".join(
        [
            _svg_chart(product, keyword=keyword, topic=topic_title),
            _stat_grid(keyword, product=product),
        ]
    )
    html = _inject_in_middle(html, blocks)
    if slug:
        html = lock_hero_before_content(html, slug)
    html = _normalize_cta_at_end(html, topic_title, product)
    html = sync_table_of_contents(html)
    return html


def _build_faq_block(topic: str, keyword: str, product=None) -> str:
    from app.services.product_context import company_label

    company = company_label(product)
    subject = keyword or topic
    return f"""
<h2 id="faq" data-faq-opt-in="1">Frequently Asked Questions</h2>
<p><strong>What is {subject} and why does it matter now?</strong><br/>
{subject} helps operators turn occupancy and access data into clearer forecasting, less revenue leakage, and better day-to-day control across commercial facilities.</p>
<p><strong>Which data should operators track first?</strong><br/>
Start with entry/exit timestamps, peak occupancy windows, dwell time, and no-show or unpaid-exit rates. Those four signals usually surface the biggest demand shifts quickly.</p>
<p><strong>How can {company} help with demand-driven operations?</strong><br/>
{company} combines ANPR validation, occupancy intelligence, and audit-ready reporting so teams can adapt staffing, pricing, and enforcement with measurable ROI.</p>
<p><strong>How long does it take to see results?</strong><br/>
Most enterprise sites see operational clarity within the first deployment cycle, with payback typically modeled over a 14–18 month window depending on facility size and integrations.</p>
"""


def _ensure_faq_json_ld(html: str, topic: str, keyword: str) -> str:
    import json

    soup = BeautifulSoup(html, "html.parser")
    for script in soup.find_all("script", attrs={"type": "application/ld+json"}):
        raw = (script.string or script.get_text() or "").strip()
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            continue
        items = data if isinstance(data, list) else [data]
        if any(isinstance(i, dict) and i.get("@type") == "FAQPage" for i in items):
            return html

    subject = keyword or topic
    faq_schema = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {
                "@type": "Question",
                "name": f"What is {subject} and why does it matter now?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": (
                        f"{subject} helps operators turn occupancy and access data into clearer "
                        "forecasting and lower revenue leakage."
                    ),
                },
            },
            {
                "@type": "Question",
                "name": "Which data should operators track first?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": (
                        "Track entry/exit timestamps, peak occupancy windows, dwell time, "
                        "and unpaid-exit rates first."
                    ),
                },
            },
            {
                "@type": "Question",
                "name": "How long does it take to see results?",
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": (
                        "Most enterprise sites gain operational clarity in the first deployment "
                        "cycle, with typical modeled payback over 14–18 months."
                    ),
                },
            },
        ],
    }
    tag = soup.new_tag("script", type="application/ld+json")
    tag.string = json.dumps(faq_schema)
    article = soup.find("article")
    if article:
        article.insert_before(tag)
    else:
        soup.insert(0, tag)
    return str(soup)


def add_faq_to_blog(
    html: str,
    topic_title: str,
    primary_keyword: str,
    product=None,
    slug: str | None = None,
) -> str:
    """Insert a FAQ section before CTA (does not invent FAQ unless this is called)."""
    html = strip_faq_from_html(html)
    soup = BeautifulSoup(html, "html.parser")
    article = soup.find("article")
    if not article:
        return html

    fragment = BeautifulSoup(
        _build_faq_block(topic_title, primary_keyword, product),
        "html.parser",
    )
    cta = article.find("section", id="cta") or article.find("section", class_="blog-cta")
    nodes = [n for n in fragment.contents if isinstance(n, Tag)]
    if cta:
        for node in nodes:
            cta.insert_before(node)
    else:
        for node in nodes:
            article.append(node)

    html = str(soup)
    html = _ensure_faq_json_ld(html, topic_title, primary_keyword)
    if slug:
        html = lock_hero_before_content(html, slug)
    html = _normalize_cta_at_end(html, topic_title, product)
    return sync_table_of_contents(html)


def fix_blog_cta(html: str, topic_title: str, product=None, slug: str | None = None) -> str:
    """Re-lock layout, then ensure a fresh branded CTA is the last article block."""
    if slug:
        html = lock_hero_before_content(html, slug)
    else:
        soup = BeautifulSoup(html, "html.parser")
        article = soup.find("article")
        from app.services.seo_pipeline import descriptive_hero_alt, public_hero_image_url

        alt = descriptive_hero_alt(topic_title, topic_title)
        hero_src = ""
        if article:
            himg = article.find("img", class_=lambda c: c and "blog-hero-image" in c) or article.find("img")
            if himg:
                hero_src = himg.get("src") or ""
                existing_alt = (himg.get("alt") or "").strip()
                if existing_alt and existing_alt.lower() not in (
                    "blog hero image",
                    "hero image",
                    "image",
                ):
                    alt = existing_alt
        if not hero_src or hero_src.lower().startswith("data:"):
            hero_src = public_hero_image_url(slug or "post", require_file=False)
        html = enforce_fixed_blog_structure(html, slug or "post", alt, hero_src)
        html = sync_table_of_contents(html)

    # CTA last — must run AFTER layout lock or enforce would have dropped a new CTA
    html = _normalize_cta_at_end(html, topic_title, product)
    return sync_table_of_contents(html)


def lock_hero_before_content(html: str, slug: str, alt: str | None = None) -> str:
    """Force H1 → hero → TOC → content on any stored blog HTML."""
    from app.services.seo_pipeline import descriptive_hero_alt, public_hero_image_url

    alt = alt or descriptive_hero_alt(slug.replace("-", " "), None)
    hero_src = public_hero_image_url(slug, require_file=False)
    html = enforce_fixed_blog_structure(html, slug, alt, hero_src)
    html = sync_table_of_contents(html)
    return html


def _fix_images(html: str, slug: str, alt: str) -> str:
    """Insert/replace hero <img> with public storage URL only — NEVER base64."""
    from app.services.seo_pipeline import public_hero_image_url, strip_base64_from_images

    html = strip_base64_from_images(html, slug, alt)
    src = public_hero_image_url(slug, require_file=False)
    if src.lower().startswith("data:"):
        raise ValueError("Hero image src must be a public URL, not a data URI")
    hero_tag = (
        f'<img src="{src}" alt="{alt}" loading="lazy" decoding="async" '
        f'width="1200" height="630" class="blog-hero-image" />'
    )

    if re.search(r"<img\b", html, re.I):
        html = re.sub(
            r"<img[^>]*>",
            hero_tag,
            html,
            count=1,
            flags=re.I,
        )
    else:
        html = re.sub(
            r"(</h1>)",
            r"\1\n" + hero_tag,
            html,
            count=1,
            flags=re.I,
        )
    return html


def _inject_cta_at_end(html: str, block: str) -> str:
    """Append CTA as the last element inside <article> (after FAQ)."""
    soup = BeautifulSoup(html, "html.parser")
    article = soup.find("article")
    if not article:
        if "</article>" in html:
            return html.replace("</article>", block + "\n</article>", 1)
        return html + block

    _strip_all_cta_sections(article)

    fragment = BeautifulSoup(block, "html.parser")
    section = fragment.find("section", id="cta") or fragment.find("section", class_="blog-cta")
    if section:
        article.append(section)
    return str(soup)


def _is_skip_h2(h2: Tag) -> bool:
    hid = (h2.get("id") or "").lower()
    if hid in _SKIP_H2_IDS:
        return True
    if h2.find_parent("nav"):
        return True
    if h2.find_parent("section", class_="blog-cta"):
        return True
    return False


def _content_h2s(article: Tag) -> list[Tag]:
    return [h2 for h2 in article.find_all("h2") if not _is_skip_h2(h2)]


def _middle_insertion_point(article: Tag) -> Tag | None:
    """Return the node before which mid-body blocks (table/chart) should be inserted."""
    h2s = _content_h2s(article)
    if h2s:
        mid = len(h2s) // 2
        return h2s[mid]

    h1 = article.find("h1")
    if h1:
        return h1.find_next_sibling()

    children = [c for c in article.children if isinstance(c, Tag)]
    if children:
        return children[min(len(children) // 2, len(children) - 1)]
    return None


def _inject_in_middle(html: str, block: str) -> str:
    """Insert tables/charts/stat blocks in the middle of the article body."""
    soup = BeautifulSoup(html, "html.parser")
    article = soup.find("article")
    if not article:
        return _inject_cta_at_end(html, block)

    fragment = BeautifulSoup(block, "html.parser")
    anchor = _middle_insertion_point(article)
    if anchor and isinstance(anchor, Tag):
        anchor.insert_before(fragment)
    else:
        article.append(fragment)

    return str(soup)


def _strip_bottom_sources_section(html: str) -> str:
    """Remove dedicated Sources / References sections — citations belong in body copy."""
    soup = BeautifulSoup(html, "html.parser")
    article = soup.find("article")
    if not article:
        return html

    for h2 in list(article.find_all("h2")):
        hid = (h2.get("id") or "").lower()
        title = h2.get_text(" ", strip=True).lower()
        if hid == "sources" or "sources" in title or "references" in title or "further reading" in title:
            _remove_section_from_heading(h2)
    return str(soup)


def _remove_section_from_heading(h2: Tag) -> None:
    """Remove h2 and following siblings until the next h2 or section end."""
    parent = h2.parent
    if not parent:
        h2.decompose()
        return

    node = h2
    while node:
        nxt = node.find_next_sibling()
        node.decompose()
        if nxt is None or (isinstance(nxt, Tag) and nxt.name in ("h2", "section")):
            break
        node = nxt


def _count_external_links(html: str, product_domain: str | None = None) -> int:
    domain = (product_domain or "hyperpark.io").lower().removeprefix("www.")
    domain_re = re.escape(domain)
    return len(
        re.findall(
            rf'<a[^>]+href=["\']https?://(?!(?:www\.)?{domain_re})[^"\']+["\']',
            html,
            re.I,
        )
    )


def _body_paragraphs(article: Tag) -> list[Tag]:
    paragraphs: list[Tag] = []
    for p in article.find_all("p"):
        if p.find_parent(["nav", "section", "table", "figcaption"]):
            continue
        if p.find_parent("section", class_="blog-cta"):
            continue
        if p.find("table"):
            continue
        paragraphs.append(p)
    return paragraphs


def _inject_inline_citations(
    html: str,
    *,
    primary_keyword: str = "",
    product=None,
    citation_targets: list[dict] | None = None,
) -> str:
    """Weave genuine LIVE source links into body paragraphs — never at the bottom.

    Hard rule for all products: never inject a dead URL; prefer topic-matched citations
    from the research pack when available.
    """
    from app.utils.link_sanitizer import filter_live_links, verified_external_sources

    domain = get_product_domain(product)
    if _count_external_links(html, domain) >= 2:
        return html

    soup = BeautifulSoup(html, "html.parser")
    article = soup.find("article")
    if not article:
        return html

    sources: list[tuple[str, str]] = []
    if citation_targets:
        sources = [
            (str(c.get("label") or "Source"), str(c.get("url") or ""))
            for c in citation_targets
            if str(c.get("url") or "").startswith(("http://", "https://"))
        ]
    # Live-check only — NEVER fall back to dead whitelist entries
    live_sources = filter_live_links(sources) if sources else []
    if len(live_sources) < 2:
        for label, url in verified_external_sources():
            if any(u == url for _, u in live_sources):
                continue
            live_sources.append((label, url))
            if len(live_sources) >= 3:
                break

    if not live_sources:
        logger.warning(
            "No live external sources available to inject for keyword '{}'",
            (primary_keyword or "")[:60],
        )
        return html

    topic = (primary_keyword or "this topic").strip()
    phrases = [
        f"shows why operators evaluating {topic} need reliable industry benchmarks",
        f"documents how digital access and mobility programs related to {topic} are scaling",
        f"reinforces the operational case for modernizing systems around {topic}",
    ]

    paragraphs = _body_paragraphs(article)
    needed = max(0, 2 - _count_external_links(html, domain))
    # Prefer injecting up to 3 genuine sources when the body is thin on citations
    inject_n = max(needed, min(3, len(live_sources))) if needed else min(
        1, len(live_sources)
    )
    if needed == 0:
        return html

    for i, source in enumerate(live_sources[:inject_n]):
        label, url = source
        phrase = phrases[i % len(phrases)]
        if paragraphs:
            idx = min((i + 1) * max(1, len(paragraphs) // (inject_n + 1)), len(paragraphs) - 1)
            p = paragraphs[idx]
            p.append(" According to ")
            link = soup.new_tag("a", href=url, target="_blank", rel="noopener noreferrer")
            link.string = label
            p.append(link)
            p.append(f", {phrase}.")
        else:
            h1 = article.find("h1")
            new_p = soup.new_tag("p")
            new_p.append("Industry research from ")
            link = soup.new_tag("a", href=url, target="_blank", rel="noopener noreferrer")
            link.string = label
            new_p.append(link)
            new_p.append(f" {phrase}.")
            if h1:
                h1.insert_after(new_p)
            else:
                article.insert(0, new_p)

    return str(soup)


def _missing_visual_blocks(html: str, keyword: str, product=None, topic: str = "") -> str:
    blocks: list[str] = []
    if not re.search(r"<table[\s>]", html, re.I):
        blocks.append(_comparison_table(keyword))
    if not re.search(r"<svg[\s>]", html, re.I):
        blocks.append(_svg_chart(product, keyword=keyword, topic=topic))
    if not re.search(r"stat-(grid|card)", html, re.I):
        blocks.append(_stat_grid(keyword, product=product))
    return "\n".join(blocks)


def _is_visual_block(tag: Tag) -> bool:
    if tag.name == "table" and "blog-table" in tag.get("class", []):
        return True
    if tag.name == "figure" and "blog-chart" in tag.get("class", []):
        return True
    if tag.name == "div" and "stat-grid" in tag.get("class", []):
        return True
    if tag.name == "h2" and (tag.get("id") or "") in ("roi-comparison", "key-metrics"):
        return True
    return False


def _collect_trailing_visuals(before_node: Tag) -> list[Tag]:
    """Visual blocks sitting immediately before FAQ/CTA (wrong end placement)."""
    nodes: list[Tag] = []
    node = before_node.previous_sibling
    while node:
        if isinstance(node, NavigableString) and not str(node).strip():
            node = node.previous_sibling
            continue
        if isinstance(node, Tag) and _is_visual_block(node):
            nodes.insert(0, node)
            node = node.previous_sibling
            continue
        if isinstance(node, Tag) and node.name == "p" and nodes:
            nodes.insert(0, node)
            node = node.previous_sibling
            continue
        break
    return nodes


def _relocate_end_visuals_to_middle(html: str) -> str:
    """Move table/chart blocks from just before FAQ/CTA into the article middle."""
    soup = BeautifulSoup(html, "html.parser")
    article = soup.find("article")
    if not article:
        return html

    end_anchor = (
        article.find("h2", id="faq")
        or article.find("h2", id="conclusion")
        or article.find("section", id="cta")
    )
    if end_anchor is None:
        return html

    to_move = _collect_trailing_visuals(end_anchor)
    if not to_move:
        return html

    mid_anchor = _middle_insertion_point(article)
    if mid_anchor is None:
        return html

    for tag in to_move:
        mid_anchor.insert_before(tag.extract())

    return str(soup)


def _ensure_conclusion_section(html: str, keyword: str) -> str:
    """Insert a conclusion H2 with summary if missing (required before CTA)."""
    soup = BeautifulSoup(html, "html.parser")
    article = soup.find("article")
    if not article:
        return html

    if article.find("h2", id=re.compile(r"conclusion|key-takeaway|summary", re.I)):
        return str(soup)
    for h2 in article.find_all("h2"):
        title = h2.get_text(" ", strip=True).lower()
        if any(w in title for w in ("conclusion", "key takeaway", "summary", "takeaways")):
            return str(soup)

    anchor = article.find("h2", id="faq") or article.find("section", id="cta")
    heading = soup.new_tag("h2", id="conclusion")
    heading.string = "Key Takeaways"
    summary = soup.new_tag("p")
    summary.append(
        f"In summary, {keyword} gives operators a clearer operating picture for this initiative "
        f"when the program stays tied to measurable outcomes. "
    )
    strong = soup.new_tag("strong")
    strong.string = "The bottom line"
    summary.append(strong)
    summary.append(
        ": teams that pair real-time analytics with structured access control typically achieve payback within 18 months."
    )

    if anchor:
        anchor.insert_before(summary)
        summary.insert_before(heading)
    else:
        article.append(heading)
        article.append(summary)

    return str(soup)


def enrich_blog_html(
    html: str,
    slug: str,
    topic_title: str,
    primary_keyword: str,
    product=None,
    allow_faq: bool | None = None,
    *,
    title_tag: str | None = None,
    meta_description: str | None = None,
    date_published: str | None = None,
    date_modified: str | None = None,
    research_pack: dict | None = None,
    include_charts: bool = True,
) -> str:
    """Guarantee mid-body visuals, inline citations, CTA, and working hero image.

    FAQ is NEVER created here. Existing FAQ is kept only when added via Add FAQ
    (data-faq-opt-in). Pass allow_faq=True only to preserve an already opted-in FAQ.

    After structural enrich, permanently applies SEO pipeline rules (public hero URL,
    descriptive alt, dynamic JSON-LD dates, contextual links, no base64).

    Hard rule (all products): only genuine live backlinks survive; topic-matched
    citation_targets from research_pack are injected inline when needed.
    """
    from app.services.seo_pipeline import (
        descriptive_hero_alt,
        finalize_blog_fragment,
        public_hero_image_url,
    )

    if allow_faq is None:
        allow_faq = html_has_opted_in_faq(html)

    links = internal_links_tuples(product)
    domain = get_product_domain(product)
    title_for_seo = (title_tag or topic_title or primary_keyword or "").strip()
    alt = descriptive_hero_alt(primary_keyword, title_for_seo)

    citation_targets = list((research_pack or {}).get("citation_targets") or [])
    extra_allowed = [
        str(c.get("url") or "")
        for c in citation_targets
        if str(c.get("url") or "").startswith(("http://", "https://"))
    ]

    html = _fix_images(html, slug, alt)
    html, _ = sanitize_backlinks(html, links, domain, extra_allowed=extra_allowed)
    html = _strip_bottom_sources_section(html)

    # FAQ is Add FAQ button only — strip anything the model invents
    if not allow_faq:
        html = strip_faq_from_html(html)

    if include_charts:
        visual_blocks = _missing_visual_blocks(
            html, primary_keyword, product=product, topic=topic_title
        )
        if visual_blocks:
            html = _inject_in_middle(html, visual_blocks)
        html = _relocate_end_visuals_to_middle(html)
    else:
        html = strip_charts_from_html(html)
    html = _inject_inline_citations(
        html,
        primary_keyword=primary_keyword,
        product=product,
        citation_targets=citation_targets,
    )
    html = _ensure_conclusion_section(html, primary_keyword)

    html, removed = sanitize_backlinks(html, links, domain, extra_allowed=extra_allowed)
    if removed:
        logger.info(f"Post {slug}: final backlink sanitization removed {len(removed)} URL(s)")

    # If sanitizer stripped citations, re-inject live ones and sanitize again
    if _count_external_links(html, domain) < 2:
        html = _inject_inline_citations(
            html,
            primary_keyword=primary_keyword,
            product=product,
            citation_targets=citation_targets,
        )
        html, _ = sanitize_backlinks(html, links, domain, extra_allowed=extra_allowed)

    html = _style_hyperlinks(html, product)

    hero_src = public_hero_image_url(slug, require_file=False)
    # Always lock: H1 → hero → TOC → content (no content above hero)
    html = enforce_fixed_blog_structure(html, slug, alt, hero_src)
    html = sync_table_of_contents(html)
    # Final layout pass, then CTA must be last
    html = enforce_fixed_blog_structure(html, slug, alt, hero_src)
    if not allow_faq:
        html = strip_faq_from_html(html)
    html = _normalize_cta_at_end(html, topic_title, product)
    html = sync_table_of_contents(html)
    # Persist product brand colors into the HTML for preview/download
    html = inject_brand_palette_style(html, product)

    missing = validate_rich_format(html, include_charts=include_charts)
    if missing:
        logger.warning(f"Post {slug} still missing after enrich: {', '.join(missing)}")

    # Standing SEO rules for every future post
    html = finalize_blog_fragment(
        html,
        slug=slug,
        title=title_for_seo,
        description=(meta_description or "")[:300],
        primary_keyword=primary_keyword,
        product=product,
        date_published=date_published,
        date_modified=date_modified,
    )
    return html
