import { BrandPalette } from "./brandPalette";
import { buildBlogProseCss } from "./blogProseCss";
import { absoluteApiUrl, apiUrl } from "./apiBase";

/**
 * Normalize blog HTML so preview/download share one left edge:
 * - pull JSON-LD scripts out
 * - unwrap nested <article> (preview/download already provide the shell)
 */
export function sanitizeBlogHtml(html: string): {
  bodyHtml: string;
  scripts: string[];
} {
  const scripts: string[] = [];
  let body = html || "";

  body = body.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, (tag) => {
    scripts.push(tag);
    return "";
  });

  body = body.trim();

  const articleMatch = body.match(/^<article\b[^>]*>([\s\S]*)<\/article>\s*$/i);
  if (articleMatch) {
    body = articleMatch[1].trim();
  }

  return { bodyHtml: body, scripts };
}

/** Replace the first hero <img> src (does not alter surrounding structure). */
export function replaceHeroSrc(html: string, src: string): string {
  if (!src || /^data:/i.test(src)) {
    throw new Error("Hero image src must be a public URL — base64 data URIs are forbidden");
  }
  const cleanSrc = unwrapMarkdownUrl(src);
  let replaced = false;
  return html.replace(/<img\b[^>]*>/i, (tag) => {
    if (replaced) return tag;
    replaced = true;
    if (/src=["'][^"']*["']/i.test(tag)) {
      return tag.replace(/src=["'][^"']*["']/i, `src="${cleanSrc}"`);
    }
    return tag.replace(/<img/i, `<img src="${cleanSrc}"`);
  });
}

/** Strip Markdown [label](url) wrappers from attribute values (LLM artifact). */
export function unwrapMarkdownUrl(value: string): string {
  let raw = (value || "").trim();
  const re = /^\s*\[([^\]]*)\]\(\s*(https?:\/\/[^)\s]+)\s*\)\s*$/i;
  for (let i = 0; i < 4; i++) {
    const m = raw.match(re);
    if (m) {
      raw = (m[2] || "").trim();
      continue;
    }
    if (raw.startsWith("[") && raw.includes("](") && /https?:\/\//i.test(raw)) {
      const urls = [...raw.matchAll(/\(\s*(https?:\/\/[^)\s]+)\s*\)/gi)].map((x) => x[1]);
      if (urls.length) {
        raw = urls[urls.length - 1].trim();
        continue;
      }
    }
    break;
  }
  return raw;
}

/** Fix href/src/content attributes that contain Markdown link syntax. */
export function sanitizeMarkdownUrlsInHtml(html: string): string {
  if (!html || !html.includes("[") || !html.includes("](")) return html || "";
  return html.replace(
    /((?:src|href|content|data-src|poster|action)\s*=\s*)(["'])([^"']*)\2/gi,
    (_full, prefix: string, quote: string, value: string) =>
      `${prefix}${quote}${unwrapMarkdownUrl(value)}${quote}`
  );
}

/** Public hero URL for in-app preview — same-origin relative is fine. Never base64. */
export function publicHeroImageUrl(slug: string, imageVersion = 0): string {
  const v = imageVersion ? `?v=${imageVersion}` : "";
  return apiUrl(`/api/images/${slug}.webp${v}`);
}

/**
 * Absolute public hero URL for downloaded HTML.
 * Relative `/api/images/...` breaks when the file is opened outside the app.
 */
export function downloadHeroImageUrl(slug: string, imageVersion = 0): string {
  const v = imageVersion ? `?v=${imageVersion}` : "";
  return absoluteApiUrl(`/api/images/${slug}.webp${v}`);
}

/** Replace the first hero <img> src with a cache-busted public URL (preview). */
export function preparePreviewHtml(
  html: string,
  slug: string,
  imageVersion: number
): string {
  const { bodyHtml } = sanitizeBlogHtml(html);
  return replaceHeroSrc(bodyHtml, publicHeroImageUrl(slug, imageVersion));
}

/**
 * @deprecated Base64 embeds are forbidden. Use publicHeroImageUrl + replaceHeroSrc.
 */
export function embedHeroDataUri(_html: string, _dataUri: string): string {
  throw new Error(
    "Base64 hero embeds are disabled. Use the public /api/images/{slug}.webp URL instead."
  );
}

/** @deprecated Prefer public URLs; kept only so old imports don't crash silently wrongly */
export async function fetchImageAsDataUri(_imageUrl: string): Promise<string | null> {
  return null;
}

function escapeAttr(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

/**
 * Standing SEO download document — canonical, OG, Twitter, public hero URL only.
 * Mirrors backend assemble_full_html_document rules.
 */
export function buildDownloadHtmlDoc(opts: {
  title: string;
  description?: string;
  bodyHtml: string;
  brandPalette?: BrandPalette | null;
  canonicalUrl: string;
  imageUrl: string;
  siteName?: string;
}): string {
  const title = escapeAttr(opts.title || "");
  const description = escapeAttr(opts.description || "");
  const canonical = (opts.canonicalUrl || "").trim();
  const imageUrl = (opts.imageUrl || "").trim();
  const siteName = escapeAttr(opts.siteName || "Hyperthings.ai");

  if (!canonical) {
    throw new Error("Download HTML blocked: canonical URL is required");
  }
  if (!imageUrl || /^data:/i.test(imageUrl)) {
    throw new Error("Download HTML blocked: hero image must be a public URL (not base64)");
  }
  if (!/^https?:\/\//i.test(imageUrl)) {
    throw new Error(
      "Download HTML blocked: hero image must be an absolute http(s) URL (relative /api paths break offline)"
    );
  }
  if (/HERO_IMAGE_SRC|\{\{|\{%/.test(opts.bodyHtml || "")) {
    throw new Error("Download HTML blocked: unreplaced placeholders in body");
  }

  let working = opts.bodyHtml || "";
  working = sanitizeMarkdownUrlsInHtml(working);
  // Strip any accidental base64 from body before packaging
  working = working.replace(
    /(<img\b[^>]*\bsrc\s*=\s*["'])data:image\/[^"']+(["'][^>]*>)/gi,
    `$1${imageUrl}$2`
  );
  working = replaceHeroSrc(working, imageUrl);

  const { bodyHtml, scripts } = sanitizeBlogHtml(working);
  const headScripts = scripts.join("\n");
  const proseCss = buildBlogProseCss(opts.brandPalette);
  const c = escapeAttr(canonical);
  const img = escapeAttr(imageUrl);

  const doc = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
<title>${title}</title>
<meta name="description" content="${description}" />
<link rel="canonical" href="${c}" />
<meta property="og:type" content="article" />
<meta property="og:title" content="${title}" />
<meta property="og:description" content="${description}" />
<meta property="og:image" content="${img}" />
<meta property="og:url" content="${c}" />
<meta property="og:site_name" content="${siteName}" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="${title}" />
<meta name="twitter:description" content="${description}" />
<meta name="twitter:image" content="${img}" />
<meta name="color-scheme" content="light" />
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />
<style>
${proseCss}
</style>
${headScripts}
</head>
<body>
<main class="blog-page">
  <article class="prose-blog">
${bodyHtml}
  </article>
</main>
</body>
</html>`;

  // Fail loud if still broken
  if (/data:image\//i.test(doc)) {
    throw new Error("Download HTML blocked: base64 image still present after assemble");
  }
  if (!doc.includes('rel="canonical"') || !doc.includes("og:title") || !doc.includes("twitter:card")) {
    throw new Error("Download HTML blocked: missing canonical/OG/Twitter tags");
  }
  return doc;
}
