"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  Box,
  Clock,
  FileText,
  Globe,
  Hash,
  Layers,
  Loader2,
  Palette,
  Plus,
  Rss,
  Save,
  Sheet,
  ToggleLeft,
  ToggleRight,
  Trash2,
  Upload,
} from "lucide-react";
import {
  api,
  DiscoverySchedule,
  Product,
  ProductInternalLink,
  ScraperSetting,
  TopicSelectionMode,
} from "@/lib/api";
import BrandPaletteEditor from "@/components/BrandPaletteEditor";
import SchedulerPicker from "@/components/SchedulerPicker";
import TopicModeSelector from "@/components/TopicModeSelector";
import {
  allPaletteSwatches,
  DEFAULT_BRAND_PALETTE,
  normalizeBrandPalette,
} from "@/lib/brandPalette";
import Button from "@/components/ui/Button";
import { Input, Textarea } from "@/components/ui/Input";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Skeleton } from "@/components/ui/Skeleton";
import { cn } from "@/lib/cn";
import { useToast } from "@/contexts/ToastContext";
import { useNotifications } from "@/contexts/NotificationContext";

const EMPTY_LINK: ProductInternalLink = { label: "", url: "" };

function defaultSchedules(product?: Product | null): DiscoverySchedule[] {
  if (product?.discovery_schedules?.length) return product.discovery_schedules;
  return [
    {
      id: "default",
      day_of_week: product?.cron_day_of_week || "mon",
      hour: product?.cron_hour ?? 9,
      minute: product?.cron_minute ?? 0,
    },
  ];
}

function hydrateFormFromProduct(product: Product) {
  const schedules = defaultSchedules(product);
  const mode = (product.topic_selection_mode || "manual") as TopicSelectionMode;
  return {
    name: product.name,
    company_name: product.company_name,
    website_url: product.website_url,
    description: product.description || "",
    brand_context: product.brand_context || "",
    brand_palette: normalizeBrandPalette(product.brand_palette),
    internal_links:
      product.internal_links?.length > 0
        ? product.internal_links
        : [{ ...EMPTY_LINK }],
    google_sheet_url: product.google_sheet_url || "",
    cron_day_of_week: schedules[0]?.day_of_week || "mon",
    cron_hour: schedules[0]?.hour ?? 9,
    cron_minute: schedules[0]?.minute ?? 0,
    cron_timezone: product.cron_timezone || "Asia/Kolkata",
    schedule_enabled: mode === "manual" ? false : (product.schedule_enabled ?? true),
    discovery_schedules: schedules,
    topic_selection_mode: mode,
  };
}

export default function ProductsPanel() {
  const toast = useToast();
  const { notifySaved } = useNotifications();
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [dirty, setDirty] = useState(false);

  const [form, setForm] = useState({
    name: "",
    company_name: "HyperPark",
    website_url: "",
    description: "",
    brand_context: "",
    brand_palette: { ...DEFAULT_BRAND_PALETTE },
    internal_links: [{ ...EMPTY_LINK }] as ProductInternalLink[],
    google_sheet_url: "",
    cron_day_of_week: "mon",
    cron_hour: 9,
    cron_minute: 0,
    cron_timezone: "Asia/Kolkata",
    schedule_enabled: false,
    discovery_schedules: [
      { id: "default", day_of_week: "mon", hour: 9, minute: 0 },
    ] as DiscoverySchedule[],
    topic_selection_mode: "manual" as TopicSelectionMode,
  });

  const [keywords, setKeywords] = useState<ScraperSetting[]>([]);
  const [urls, setUrls] = useState<ScraperSetting[]>([]);
  const [rssFeeds, setRssFeeds] = useState<ScraperSetting[]>([]);
  const [newKeyword, setNewKeyword] = useState("");
  const [newUrl, setNewUrl] = useState("");
  const [newRssFeed, setNewRssFeed] = useState("");

  const lastHydratedId = useRef<number | "new" | null>(null);

  const selected = products.find((p) => p.id === selectedId) ?? null;

  const loadProducts = useCallback(async () => {
    const list = await api.getProducts();
    setProducts(list);
    return list;
  }, []);

  const loadScraperTargets = useCallback(async (productId: number) => {
    const settings = await api.getSettings(undefined, productId);
    setKeywords(settings.filter((s) => s.category === "INDUSTRY_KEYWORD"));
    setUrls(settings.filter((s) => s.category === "COMPETITOR_URL"));
    setRssFeeds(settings.filter((s) => s.category === "RSS_FEED"));
  }, []);

  useEffect(() => {
    loadProducts()
      .then((list) => {
        if (list.length > 0) {
          setSelectedId(list[0].id);
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [loadProducts]);

  useEffect(() => {
    if (selectedId === null) {
      if (lastHydratedId.current !== "new") {
        lastHydratedId.current = "new";
        setForm({
          name: "",
          company_name: "HyperPark",
          website_url: "",
          description: "",
          brand_context: "",
          brand_palette: { ...DEFAULT_BRAND_PALETTE },
          internal_links: [{ ...EMPTY_LINK }],
          google_sheet_url: "",
          cron_day_of_week: "mon",
          cron_hour: 9,
          cron_minute: 0,
          cron_timezone: "Asia/Kolkata",
          schedule_enabled: false,
          discovery_schedules: [
            { id: "default", day_of_week: "mon", hour: 9, minute: 0 },
          ],
          topic_selection_mode: "manual",
        });
        setKeywords([]);
        setUrls([]);
        setRssFeeds([]);
        setDirty(false);
      }
      return;
    }

    const product = products.find((p) => p.id === selectedId);
    if (!product) return;

    if (lastHydratedId.current !== selectedId) {
      lastHydratedId.current = selectedId;
      setForm(hydrateFormFromProduct(product));
      setDirty(false);
      loadScraperTargets(product.id).catch(console.error);
    }
  }, [selectedId, products, loadScraperTargets]);

  function updateForm(patch: Partial<typeof form>) {
    setForm((prev) => ({ ...prev, ...patch }));
    setDirty(true);
  }

  function resetNewForm() {
    setSelectedId(null);
    setMessage(null);
  }

  function buildPayload() {
    const links = form.internal_links.filter((l) => l.label.trim() && l.url.trim());
    let website = form.website_url.trim().replace(/\/$/, "");
    if (website && !/^https?:\/\//i.test(website)) {
      website = `https://${website}`;
    }
    const schedules =
      form.discovery_schedules?.length > 0
        ? form.discovery_schedules
        : [
            {
              id: "default",
              day_of_week: form.cron_day_of_week,
              hour: form.cron_hour,
              minute: form.cron_minute,
            },
          ];
    return {
      name: form.name.trim(),
      company_name: form.company_name.trim() || "HyperPark",
      website_url: website,
      description: form.description.trim(),
      brand_context: form.brand_context.trim(),
      brand_palette: normalizeBrandPalette(form.brand_palette),
      internal_links: links,
      google_sheet_url: form.google_sheet_url.trim(),
      cron_day_of_week: schedules[0].day_of_week,
      cron_hour: schedules[0].hour,
      cron_minute: schedules[0].minute,
      cron_timezone: form.cron_timezone || "Asia/Kolkata",
      schedule_enabled:
        form.topic_selection_mode === "manual" ? false : form.schedule_enabled,
      discovery_schedules: schedules,
      topic_selection_mode: form.topic_selection_mode,
    };
  }

  async function handleSaveProduct() {
    const payload = buildPayload();
    if (!payload.name || !payload.website_url) {
      const text = "Product name and website URL are required.";
      setMessage({ type: "error", text });
      toast.error("Save failed", text);
      return;
    }
    setSaving(true);
    setMessage(null);
    try {
      if (selectedId) {
        const updated = await api.updateProduct(selectedId, payload);
        setProducts((prev) =>
          prev.map((p) => (p.id === updated.id ? updated : p))
        );
        setForm(hydrateFormFromProduct(updated));
        setDirty(false);
        const text = `"${updated.name}" saved successfully.`;
        setMessage({ type: "success", text });
        toast.success("Saved", text);
        notifySaved("Product saved", text);
      } else {
        const created = await api.createProduct(payload);
        const list = await api.getProducts();
        setProducts(list);
        lastHydratedId.current = null;
        setSelectedId(created.id);
        setDirty(false);
        const text = `"${created.name}" created successfully.`;
        setMessage({ type: "success", text });
        toast.success("Created", text);
        notifySaved("Product created", text);
      }
    } catch (e) {
      const text = e instanceof Error ? e.message : String(e);
      setMessage({ type: "error", text });
      toast.error("Save failed", text);
    } finally {
      setSaving(false);
    }
  }

  async function handleDeleteProduct() {
    if (!selectedId || !selected) return;
    if (
      !confirm(
        `Delete "${selected.name}"?\n\nThis hides the product from the board and settings. Existing blog posts are kept.`
      )
    ) {
      return;
    }
    setDeleting(true);
    setMessage(null);
    try {
      await api.deleteProduct(selectedId);
      const list = await api.getProducts();
      setProducts(list);
      lastHydratedId.current = null;
      setSelectedId(list[0]?.id ?? null);
      setMessage({ type: "success", text: `"${selected.name}" deleted.` });
      notifySaved("Product deleted", `"${selected.name}" was removed.`);
    } catch (e) {
      setMessage({
        type: "error",
        text: e instanceof Error ? e.message : String(e),
      });
    } finally {
      setDeleting(false);
    }
  }

  async function handlePdfUpload(files: FileList | File[]) {
    if (!selectedId) return;
    const list = Array.from(files);
    if (!list.length) return;
    setUploading(true);
    setMessage(null);
    try {
      let updated: Product | null = null;
      for (const file of list) {
        updated = await api.uploadProductPdf(selectedId, file);
      }
      if (updated) {
        setProducts((prev) =>
          prev.map((p) => (p.id === updated!.id ? updated! : p))
        );
      }
      const text =
        list.length === 1
          ? `"${list[0].name}" uploaded and indexed.`
          : `${list.length} PDFs uploaded and indexed.`;
      setMessage({ type: "success", text });
      toast.success("PDF saved", text);
      notifySaved("PDF saved", text);
    } catch (e) {
      const text = e instanceof Error ? e.message : String(e);
      setMessage({ type: "error", text });
      toast.error("PDF upload failed", text);
    } finally {
      setUploading(false);
    }
  }

  async function handleDeletePdf(pdfId?: string) {
    if (!selectedId || !selected?.has_pdf) return;
    if (
      !confirm(
        pdfId
          ? "Remove this PDF from the product?"
          : "Remove all uploaded PDFs from this product?"
      )
    ) {
      return;
    }
    try {
      const updated = await api.deleteProductPdf(selectedId, pdfId);
      setProducts((prev) =>
        prev.map((p) => (p.id === updated.id ? updated : p))
      );
      const text = "PDF removed.";
      setMessage({ type: "success", text });
      toast.success("Saved", text);
      notifySaved("PDF removed", text);
    } catch (e) {
      const text = e instanceof Error ? e.message : String(e);
      setMessage({ type: "error", text });
      toast.error("Delete failed", text);
    }
  }

  async function handleAddKeyword() {
    if (!selectedId || !newKeyword.trim()) return;
    const value = newKeyword.trim();
    try {
      await api.createSetting({
        category: "INDUSTRY_KEYWORD",
        value,
        product_id: selectedId,
      });
      setNewKeyword("");
      await loadScraperTargets(selectedId);
      toast.success("Saved", "Keyword added");
      notifySaved("Scraper target saved", `Keyword added: ${value}`);
    } catch (e) {
      const text = e instanceof Error ? e.message : String(e);
      setMessage({ type: "error", text });
      toast.error("Failed", text);
    }
  }

  async function handleAddRssFeed() {
    if (!selectedId || !newRssFeed.trim()) return;
    try {
      const value = newRssFeed.trim();
      await api.createSetting({
        category: "RSS_FEED",
        value,
        product_id: selectedId,
      });
      setNewRssFeed("");
      await loadScraperTargets(selectedId);
      toast.success("Saved", "RSS feed added");
      notifySaved("Scraper target saved", `RSS feed added: ${value}`);
    } catch (e) {
      const text = e instanceof Error ? e.message : String(e);
      setMessage({ type: "error", text });
      toast.error("Failed", text);
    }
  }

  async function handleAddUrl() {
    if (!selectedId || !newUrl.trim()) return;
    try {
      const value = newUrl.trim();
      await api.createSetting({
        category: "COMPETITOR_URL",
        value,
        product_id: selectedId,
      });
      setNewUrl("");
      await loadScraperTargets(selectedId);
      toast.success("Saved", "Competitor URL added");
      notifySaved("Scraper target saved", `Competitor URL added: ${value}`);
    } catch (e) {
      const text = e instanceof Error ? e.message : String(e);
      setMessage({ type: "error", text });
      toast.error("Failed", text);
    }
  }

  if (loading) {
    return (
      <div className="space-y-5">
        <Skeleton className="h-20 w-full rounded-2xl" />
        <div className="grid gap-3 sm:grid-cols-2">
          <Skeleton className="h-24 rounded-2xl" />
          <Skeleton className="h-24 rounded-2xl" />
        </div>
        <Skeleton className="h-96 w-full rounded-2xl" />
      </div>
    );
  }

  return (
    <div className="products-panel space-y-7">
      <div className="products-guide animate-fade-up p-5 md:p-6">
        <div className="relative space-y-5 pl-2">
          <div className="max-w-2xl">
            <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-hyper-orange">
              Product workspace
            </p>
            <h3 className="mt-1 font-display text-xl font-semibold tracking-tight text-hyper-navy md:text-2xl">
              How products <span className="text-highlight">work</span>
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-slate-600 md:text-[15px]">
              Each product keeps its own{" "}
              <span className="font-semibold text-hyper-navy">automation mode</span>, brand
              colors, schedule, scrapers, and Google Sheet ledger. Configure one profile at a
              time, then <span className="font-semibold text-hyper-orange">save</span> before
              switching.
            </p>
          </div>
          <ol className="products-guide-steps">
            {[
              {
                n: "1",
                title: "Select a product",
                body: "Open a card below or create a new product profile.",
              },
              {
                n: "2",
                title: "Configure settings",
                body: "Set mode, brand colors, links, sheet, schedule, and scrapers.",
              },
              {
                n: "3",
                title: "Save product",
                body: "Use Save product — the Content Board runs on the active profile.",
              },
            ].map((step) => (
              <li key={step.n} className="products-guide-step">
                <span className="products-guide-num" aria-hidden="true">
                  {step.n}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-hyper-navy">{step.title}</p>
                  <p className="mt-0.5 text-xs leading-relaxed text-slate-600">{step.body}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </div>

      {message && (
        <div
          className={cn(
            "flex animate-fade-in items-center gap-3 rounded-xl border px-4 py-3 text-sm shadow-soft",
            message.type === "success"
              ? "border-emerald-200 bg-emerald-50 text-emerald-800"
              : "border-red-200 bg-red-50 text-red-800"
          )}
        >
          <span
            className={cn(
              "h-2 w-2 shrink-0 rounded-full",
              message.type === "success" ? "bg-emerald-500" : "bg-hyper-red"
            )}
          />
          {message.text}
        </div>
      )}

      <div className="animate-fade-up" style={{ animationDelay: "80ms" }}>
        <div className="mb-3 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
          <div className="min-w-0">
            <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-hyper-primary">
              Select product
            </p>
            <p className="mt-1 text-sm text-slate-600">
              Open a card to edit{" "}
              <span className="font-semibold text-hyper-navy">automation</span>,{" "}
              <span className="text-highlight">brand colors</span>, and discovery setup
            </p>
          </div>
        </div>
        <div className="products-stagger grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {products.map((p) => {
            const active = selectedId === p.id;
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => {
                  if (dirty && !confirm("Discard unsaved changes?")) return;
                  setSelectedId(p.id);
                  setMessage(null);
                }}
                className={cn(
                  "product-pick-card group rounded-2xl border p-4 text-left active:scale-[0.99]",
                  active
                    ? "is-active border-hyper-navy/25 bg-white shadow-elevated ring-1 ring-hyper-navy/10"
                    : "border-hyper-border/80 bg-[#f8f9fc] hover:border-hyper-primary/30 hover:bg-white hover:shadow-card"
                )}
              >
                {active && (
                  <span className="absolute left-0 top-3.5 h-9 w-1 rounded-r-full bg-hyper-orange" />
                )}
                <div className="flex items-start justify-between gap-2">
                  <span
                    className={cn(
                      "flex h-10 w-10 items-center justify-center rounded-xl transition-all duration-200",
                      active
                        ? "bg-hyper-navy text-white shadow-sm"
                        : "bg-white text-hyper-primary ring-1 ring-hyper-border group-hover:scale-105 group-hover:bg-hyper-primary/10"
                    )}
                  >
                    <Box className="h-4 w-4" />
                  </span>
                  <div className="flex flex-wrap items-center justify-end gap-1.5">
                    <span className="inline-flex items-center rounded-md bg-hyper-navy/5 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-hyper-navy">
                      {p.topic_selection_mode === "hybrid"
                        ? "Both"
                        : p.topic_selection_mode || "Manual"}
                    </span>
                    {p.schedule_enabled && p.topic_selection_mode !== "manual" && (
                      <span className="inline-flex items-center gap-1 rounded-md bg-hyper-orange/10 px-2 py-0.5 text-[10px] font-semibold text-hyper-orange">
                        <Clock className="h-3 w-3" />
                        Scheduled
                      </span>
                    )}
                  </div>
                </div>
                <p className="mt-3 text-[15px] font-semibold tracking-tight text-hyper-navy">
                  {p.name}
                </p>
                {p.slug ? (
                  <p className="mt-0.5 truncate font-mono text-[11px] text-slate-500">/{p.slug}</p>
                ) : null}
                <p className="mt-0.5 truncate text-xs text-slate-500">{p.company_name}</p>
                <div className="mt-3.5 flex h-1.5 overflow-hidden rounded-full ring-1 ring-black/5">
                  {allPaletteSwatches(normalizeBrandPalette(p.brand_palette)).map((swatch) => (
                    <span
                      key={`${p.id}-${swatch.label}-${swatch.hex}`}
                      className="flex-1"
                      style={{ backgroundColor: swatch.hex }}
                      title={`${swatch.label}: ${swatch.hex}`}
                    />
                  ))}
                </div>
              </button>
            );
          })}
          <button
            type="button"
            onClick={() => {
              if (dirty && !confirm("Discard unsaved changes?")) return;
              resetNewForm();
            }}
            className="product-pick-card flex min-h-[140px] flex-col items-center justify-center gap-2.5 rounded-2xl border border-dashed border-hyper-border/90 bg-white/70 text-slate-600 transition hover:border-hyper-orange/50 hover:bg-hyper-orange/[0.04] hover:text-hyper-orange"
          >
            <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-hyper-border bg-white shadow-sm transition group-hover:scale-105">
              <Plus className="h-5 w-5" />
            </span>
            <span className="text-sm font-semibold">New product</span>
            <span className="px-4 text-center text-[11px] text-slate-500">
              Start a blank profile for another product line
            </span>
          </button>
        </div>
      </div>

      <Card
        variant="elevated"
        className="animate-fade-up overflow-hidden rounded-2xl border-hyper-border/80 shadow-elevated"
        style={{ animationDelay: "140ms" } as React.CSSProperties}
      >
        <div className="settings-accent-bar h-1" />
        <CardHeader className="flex flex-col gap-4 border-b border-hyper-border/80 bg-[linear-gradient(180deg,#fbfbfd_0%,#ffffff_100%)] sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-hyper-primary">
              {selectedId ? "Editing product" : "Create product"}
            </p>
            <h2 className="mt-1 font-display text-xl font-semibold tracking-tight text-hyper-navy md:text-2xl">
              {selectedId ? selected?.name ?? "Edit product" : "Add product"}
            </h2>
            <p className="mt-1.5 max-w-xl text-sm leading-relaxed text-slate-600">
              {selectedId
                ? (
                  <>
                    Update{" "}
                    <span className="font-semibold text-hyper-navy">automation</span>, brand
                    identity, publishing sheet, and discovery scrapers for this product line.
                  </>
                )
                : (
                  <>
                    Fill in identity details first, then{" "}
                    <span className="text-highlight">save</span> to unlock schedules, scrapers,
                    and uploads.
                  </>
                )}
            </p>
            {dirty && (
              <p className="mt-2 inline-flex items-center gap-1.5 rounded-lg bg-hyper-orange/10 px-2.5 py-1 text-xs font-semibold text-hyper-orange">
                <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-hyper-orange" />
                Unsaved changes — click <span className="underline decoration-hyper-orange/50">Save product</span> before leaving
              </p>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {selectedId && (
              <Button
                type="button"
                variant="danger"
                size="sm"
                onClick={handleDeleteProduct}
                loading={deleting}
                disabled={deleting || saving}
              >
                <Trash2 className="h-4 w-4" />
                Delete
              </Button>
            )}
            <Button
              type="button"
              variant="orange"
              size="sm"
              onClick={handleSaveProduct}
              loading={saving}
              disabled={saving || deleting}
              className="btn-sheen relative overflow-hidden"
            >
              <Save className="h-4 w-4" />
              {selectedId ? "Save product" : "Create product"}
            </Button>
          </div>
        </CardHeader>
        <CardBody className="products-stagger space-y-5 p-4 md:space-y-6 md:p-6">
          <SettingsBlock
            icon={Layers}
            title="Automation mode"
            description="Choose how this product runs discovery — Manual, Auto, or Both. This is saved with the product and used on the Content Board."
          >
            <TopicModeSelector
              value={form.topic_selection_mode}
              onChange={(mode) =>
                updateForm({
                  topic_selection_mode: mode,
                  schedule_enabled: mode === "manual" ? false : form.schedule_enabled,
                })
              }
            />
          </SettingsBlock>

          <SettingsBlock
            icon={Box}
            title="Identity & brand"
            description="Product name, company, website, and brand context injected into AI prompts for every generated blog."
          >
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Product name">
                <Input
                  value={form.name}
                  onChange={(e) => updateForm({ name: e.target.value })}
                  placeholder="e.g. Smart Parking"
                />
              </Field>
              <Field label="Company name">
                <Input
                  value={form.company_name}
                  onChange={(e) => updateForm({ company_name: e.target.value })}
                  placeholder="HyperPark"
                />
              </Field>
            </div>
            {selected?.slug ? (
              <Field label="Product slug (fixed)">
                <Input value={selected.slug} disabled readOnly className="font-mono text-sm" />
                <p className="mt-1.5 text-xs leading-relaxed text-slate-600">
                  Unique permanent id for this product. Blog URLs use{" "}
                  <code className="rounded bg-slate-100 px-1.5 py-0.5 font-mono text-[11px] text-hyper-navy">
                    {selected.slug}-…
                  </code>
                </p>
              </Field>
            ) : null}
            <Field label="Website URL">
              <Input
                value={form.website_url}
                onChange={(e) => updateForm({ website_url: e.target.value })}
                placeholder="https://hyperpark.io"
              />
            </Field>
            <Field label="Short description (for AI prompts)">
              <Textarea
                value={form.description}
                onChange={(e) => updateForm({ description: e.target.value })}
                rows={2}
                placeholder="Enterprise smart parking and urban mobility SaaS platform"
              />
            </Field>
            <Field label="Brand context (value props, audience, positioning)">
              <Textarea
                value={form.brand_context}
                onChange={(e) => updateForm({ brand_context: e.target.value })}
                rows={4}
                placeholder="Target audience, differentiators, tone..."
              />
            </Field>
          </SettingsBlock>

          <SettingsBlock
            icon={Palette}
            title="Brand color palette"
            description="Set exact hex colors for this product. Generated HTML blogs use these colors for headings, charts, CTAs, and links — click Save product after editing."
          >
            <BrandPaletteEditor
              value={form.brand_palette}
              onChange={(brand_palette) => updateForm({ brand_palette })}
              productName={selected?.name || form.name || undefined}
            />
          </SettingsBlock>

          <SettingsBlock
            icon={Globe}
            title="CTA & internal links"
            description="These links are woven into generated blog CTAs and related sections. Use clear labels and full https:// URLs."
          >
            <div className="space-y-2">
              {form.internal_links.map((link, i) => (
                <div key={i} className="flex gap-2">
                  <Input
                    value={link.label}
                    onChange={(e) => {
                      const next = [...form.internal_links];
                      next[i] = { ...next[i], label: e.target.value };
                      updateForm({ internal_links: next });
                    }}
                    placeholder="Label"
                    className="flex-1"
                  />
                  <Input
                    value={link.url}
                    onChange={(e) => {
                      const next = [...form.internal_links];
                      next[i] = { ...next[i], url: e.target.value };
                      updateForm({ internal_links: next });
                    }}
                    placeholder="https://..."
                    className="flex-[2]"
                  />
                  {form.internal_links.length > 1 && (
                    <button
                      type="button"
                      className="rounded-xl p-2 text-text-muted transition hover:bg-red-50 hover:text-hyper-red"
                      onClick={() => {
                        const next = form.internal_links.filter((_, idx) => idx !== i);
                        updateForm({ internal_links: next });
                      }}
                      aria-label="Remove link"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="mt-3"
              onClick={() =>
                updateForm({
                  internal_links: [...form.internal_links, { ...EMPTY_LINK }],
                })
              }
            >
              <Plus className="h-3.5 w-3.5" />
              Add link
            </Button>
          </SettingsBlock>

          <SettingsBlock
            icon={Sheet}
            title="Published blogs Google Sheet"
            description="On every Approve & Publish, a new ledger row is written here with the public image and MinIO HTML links."
          >
            <Field label="Google Sheet link">
              <Input
                value={form.google_sheet_url}
                onChange={(e) => updateForm({ google_sheet_url: e.target.value })}
                placeholder="https://script.google.com/macros/s/…/exec  or  docs.google.com/spreadsheets/d/…"
                className="font-mono text-sm"
              />
            </Field>
            <div className="products-hint mt-3 space-y-3 px-4 py-4 text-sm leading-relaxed">
              <div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-hyper-primary">
                  Setup checklist
                </p>
                <p className="mt-1 font-medium text-hyper-navy">
                  Row 1 headers must match exactly
                </p>
                <p className="mt-1 rounded-lg bg-white px-3 py-2 font-mono text-xs text-slate-700 ring-1 ring-hyper-border">
                  Serial No | Slug | Blog Title | Image URL | HTML Page Path
                </p>
              </div>
              <ol className="list-decimal space-y-2 pl-5 text-slate-600">
                <li>
                  Create a Google Sheet tab named{" "}
                  <strong className="font-semibold text-hyper-navy">Blogs</strong> with those 5
                  headers.
                </li>
                <li>
                  Prefer pasting your{" "}
                  <strong className="font-semibold text-hyper-navy">Apps Script web-app URL</strong>{" "}
                  (<code className="rounded bg-white px-1.5 py-0.5 text-[11px] ring-1 ring-hyper-border">
                    script.google.com/macros/s/…/exec
                  </code>
                  ) — no service account needed.
                </li>
                <li>
                  Or paste a{" "}
                  <strong className="font-semibold text-hyper-navy">docs.google.com</strong> sheet URL
                  and add service-account JSON under Integrations → Google Sheets Ledger (share the
                  sheet with that <code className="rounded bg-white px-1 text-[11px]">client_email</code>{" "}
                  as Editor).
                </li>
                <li>
                  On every approve/publish, a new row is added:{" "}
                  <strong className="font-semibold text-hyper-navy">Image URL</strong> = public banner,{" "}
                  <strong className="font-semibold text-hyper-navy">HTML Page Path</strong> = public
                  MinIO / live blog link.
                </li>
              </ol>
            </div>
          </SettingsBlock>

          {selectedId && (
            <SettingsBlock
              icon={Clock}
              title="Discovery schedule"
              description={
                form.topic_selection_mode === "manual"
                  ? "Disabled in Manual mode — use Run discovery on the Board"
                  : "Per-product weekly auto-discovery (Auto / Both modes only)"
              }
            >
              {form.topic_selection_mode === "manual" ? (
                <p className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
                  This product is in <strong>Manual</strong> mode. Scheduled runs are off.
                  Start each step yourself from the Content Board (discovery → topic → review → publish).
                </p>
              ) : (
                <div className="rounded-2xl border border-hyper-border bg-surface-1/50 p-4 md:p-5">
                  <SchedulerPicker
                    productName={selected?.name}
                    values={{
                      discovery_schedules: form.discovery_schedules,
                      cron_day_of_week: form.cron_day_of_week,
                      cron_hour: form.cron_hour,
                      cron_minute: form.cron_minute,
                      cron_timezone: form.cron_timezone,
                      schedule_enabled: form.schedule_enabled,
                    }}
                    onChange={(patch) => {
                      updateForm(patch);
                    }}
                  />
                </div>
              )}
            </SettingsBlock>
          )}

          {selectedId && (
            <SettingsBlock
              icon={FileText}
              title="Product PDFs"
              description="Upload multiple brochures or datasheets used as AI context when generating blogs for this product."
            >
              <div className="rounded-2xl border border-dashed border-hyper-primary/20 bg-hyper-primary/[0.03] p-5">
                {(selected?.pdfs?.length || 0) > 0 ? (
                  <ul className="mb-4 space-y-2">
                    {selected!.pdfs!.map((pdf) => (
                      <li
                        key={pdf.id}
                        className="flex flex-wrap items-center gap-3 rounded-lg bg-surface-0 px-3 py-2 ring-1 ring-hyper-border"
                      >
                        <span className="inline-flex min-w-0 flex-1 items-center gap-2 font-mono text-xs text-text-secondary">
                          <FileText className="h-3.5 w-3.5 shrink-0 text-hyper-primary" />
                          <span className="truncate">
                            {pdf.original_name || pdf.filename}
                          </span>
                        </span>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeletePdf(pdf.id)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                          Remove
                        </Button>
                      </li>
                    ))}
                  </ul>
                ) : selected?.has_pdf && selected.pdf_filename ? (
                  <div className="mb-4 flex flex-wrap items-center gap-3">
                    <span className="inline-flex items-center gap-2 rounded-lg bg-surface-0 px-3 py-2 font-mono text-xs text-text-secondary ring-1 ring-hyper-border">
                      <FileText className="h-3.5 w-3.5 text-hyper-primary" />
                      {selected.pdf_filename}
                    </span>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeletePdf()}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      Remove
                    </Button>
                  </div>
                ) : (
                  <p className="mb-4 text-sm text-text-muted">No PDFs uploaded yet</p>
                )}
                <label className="inline-flex cursor-pointer">
                  <input
                    type="file"
                    accept=".pdf,application/pdf"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      const files = e.target.files;
                      if (files?.length) handlePdfUpload(files);
                      e.target.value = "";
                    }}
                  />
                  <span className="inline-flex items-center gap-2 rounded-xl border border-hyper-border bg-surface-0 px-4 py-2.5 text-sm font-medium text-hyper-navy shadow-sm transition hover:border-hyper-primary/30 hover:bg-surface-1">
                    {uploading ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Upload className="h-4 w-4 text-hyper-primary" />
                    )}
                    {uploading ? "Uploading..." : "Upload PDF(s)"}
                  </span>
                </label>
              </div>
            </SettingsBlock>
          )}

          {selectedId && (
            <SettingsBlock
              icon={Hash}
              title="Scraper targets"
              description="Keywords, competitor URLs, and RSS feeds used for topic discovery on this product only. Add entries below, then keep them enabled."
            >
              <div className="flex flex-col gap-4">
                <ScraperCard
                  title="Industry keywords"
                  subtitle="Tavily API search queries"
                  icon={Hash}
                  items={keywords}
                  inputValue={newKeyword}
                  onInputChange={setNewKeyword}
                  onAdd={handleAddKeyword}
                  placeholder="e.g. smart parking automation trends"
                  onReload={() => loadScraperTargets(selectedId)}
                />
                <ScraperCard
                  title="Competitor URLs"
                  subtitle="Playwright HTML blog scraper"
                  icon={Globe}
                  items={urls}
                  inputValue={newUrl}
                  onInputChange={setNewUrl}
                  onAdd={handleAddUrl}
                  placeholder="https://competitor.com/blog/"
                  onReload={() => loadScraperTargets(selectedId)}
                />
                <ScraperCard
                  title="RSS feeds"
                  subtitle="Free XML feed parser — no API cost"
                  icon={Rss}
                  items={rssFeeds}
                  inputValue={newRssFeed}
                  onInputChange={setNewRssFeed}
                  onAdd={handleAddRssFeed}
                  placeholder="https://blog.com/feed/"
                  onReload={() => loadScraperTargets(selectedId)}
                  emptyHint="Add a feed URL or blog homepage — common /feed paths are auto-detected."
                />
              </div>
            </SettingsBlock>
          )}
        </CardBody>
      </Card>

      <div className="settings-action-bar">
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold text-hyper-navy">
            {selectedId ? selected?.name || "Edit product" : "New product"}
          </p>
          <p className={cn("text-xs", dirty ? "font-medium text-hyper-orange" : "text-slate-500")}>
            {dirty ? "Unsaved changes — save before switching products" : "All changes saved"}
          </p>
        </div>
        <Button
          type="button"
          variant="orange"
          size="sm"
          onClick={handleSaveProduct}
          loading={saving}
          disabled={saving || deleting}
          className="settings-btn-row-primary btn-sheen relative w-full overflow-hidden sm:w-auto"
        >
          <Save className="h-4 w-4" />
          {selectedId ? "Save product" : "Create product"}
        </Button>
      </div>
    </div>
  );
}

function SettingsBlock({
  icon: Icon,
  title,
  description,
  children,
}: {
  icon: React.ElementType;
  title: string;
  description: string;
  children: React.ReactNode;
}) {
  return (
    <section className="products-section">
      <div className="products-section-head">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-hyper-navy text-white shadow-sm">
          <Icon className="h-4 w-4" />
        </span>
        <div className="min-w-0 pt-0.5">
          <h3 className="text-base font-semibold tracking-tight text-hyper-navy">{title}</h3>
          <p className="mt-1 text-sm leading-relaxed text-slate-600">{description}</p>
        </div>
      </div>
      <div className="space-y-4 p-4 md:p-5">{children}</div>
    </section>
  );
}

function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: React.ReactNode;
  hint?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.12em] text-hyper-primary">
        {label}
      </span>
      {children}
      {hint ? <p className="mt-1.5 text-xs leading-relaxed text-slate-500">{hint}</p> : null}
    </label>
  );
}

function ScraperCard({
  title,
  subtitle,
  icon: Icon,
  items,
  inputValue,
  onInputChange,
  onAdd,
  placeholder,
  onReload,
  emptyHint,
}: {
  title: string;
  subtitle: string;
  icon: React.ElementType;
  items: ScraperSetting[];
  inputValue: string;
  onInputChange: (v: string) => void;
  onAdd: () => void;
  placeholder: string;
  onReload: () => void;
  emptyHint?: string;
}) {
  async function handleToggle(id: number, isActive: boolean) {
    await api.updateSetting(id, { is_active: !isActive });
    onReload();
  }

  async function handleDelete(id: number) {
    if (!confirm("Delete this entry?")) return;
    await api.deleteSetting(id);
    onReload();
  }

  return (
    <div className="flex min-w-0 flex-col overflow-hidden rounded-2xl border border-hyper-border/80 bg-surface-0 shadow-soft">
      <div className="shrink-0 border-b border-hyper-border/70 bg-surface-1/60 px-4 py-3">
        <div className="flex items-center gap-2.5">
          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-hyper-primary/10">
            <Icon className="h-4 w-4 text-hyper-primary" />
          </span>
          <div className="min-w-0">
            <h3 className="text-sm font-semibold text-hyper-navy">{title}</h3>
            <p className="mt-0.5 text-xs leading-snug text-slate-600">{subtitle}</p>
          </div>
        </div>
      </div>

      <div className="min-h-0 max-h-[min(20rem,50vh)] min-w-0 divide-y divide-hyper-border/70 overflow-y-auto">
        {items.length === 0 ? (
          <div className="flex min-h-[6rem] items-center justify-center px-4 py-5">
            <p className="max-w-md text-center text-sm leading-relaxed text-slate-600">
              {emptyHint || "No targets yet. Add one below."}
            </p>
          </div>
        ) : (
          items.map((item) => (
            <div
              key={item.id}
              className="flex min-w-0 items-start gap-3 px-4 py-3 sm:items-center"
            >
              <div className="min-w-0 flex-1">
                <p
                  className={cn(
                    "break-all text-sm leading-snug sm:break-words",
                    item.is_active ? "text-text-primary" : "text-text-muted line-through"
                  )}
                  title={item.value}
                >
                  {item.value}
                </p>
                <p className="mt-0.5 text-[11px] text-text-muted">by {item.added_by}</p>
              </div>
              <div className="flex shrink-0 items-center gap-1">
                <button
                  type="button"
                  onClick={() => handleToggle(item.id, item.is_active)}
                  className="rounded-lg p-2 text-hyper-primary hover:bg-surface-1"
                  aria-label={item.is_active ? "Disable target" : "Enable target"}
                >
                  {item.is_active ? (
                    <ToggleRight className="h-5 w-5" />
                  ) : (
                    <ToggleLeft className="h-5 w-5 text-text-muted" />
                  )}
                </button>
                <button
                  type="button"
                  className="rounded-lg p-2 text-text-muted hover:bg-red-50 hover:text-hyper-red"
                  onClick={() => handleDelete(item.id)}
                  aria-label="Delete target"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      <div className="flex shrink-0 flex-col gap-2 border-t border-hyper-border/70 bg-surface-1/50 p-3 sm:flex-row sm:items-center">
        <Input
          value={inputValue}
          onChange={(e) => onInputChange(e.target.value)}
          placeholder={placeholder}
          onKeyDown={(e) => e.key === "Enter" && onAdd()}
          className="h-10 w-full min-w-0 flex-1 py-2"
        />
        <Button
          type="button"
          size="md"
          variant="primary"
          onClick={onAdd}
          className="h-10 w-full shrink-0 px-4 sm:w-auto"
        >
          <Plus className="h-4 w-4" />
          Add
        </Button>
      </div>
    </div>
  );
}
