from __future__ import annotations

from typing import List

from fastapi import APIRouter, BackgroundTasks, Body, Depends, File, HTTPException, UploadFile
from loguru import logger
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.database import get_db
from app.config import settings
from app.models import BlogPost, BlogStatus
from app.schemas import (
    BlogPostDetail,
    BlogPostEditRequest,
    BlogPostSummary,
    RedoRequest,
    ReviewResponse,
)
from app.services.blog_editor import calc_reading_time, save_hero_upload, sync_hero_img_in_html
from app.services.blog_text_editor import apply_editable_text, extract_editable_text
from app.services.content_enricher import (
    add_faq_to_blog,
    enrich_blog_html,
    fix_blog_cta,
    html_has_faq_section,
    html_has_opted_in_faq,
    lock_hero_before_content,
    strip_faq_from_html,
    sync_table_of_contents,
)
from app.services.blog_structure import layout_needs_hero_lock
from app.services.notification_service import emit_notification
from app.services.product_context import get_product
from app.services.seo_pipeline import BlogSeoValidationError, bump_json_ld_date_modified, public_hero_image_url
from app.services.workflow import abort_post, approve_post, redo_post
from app.utils.seo import compute_seo_metrics

router = APIRouter(prefix="/api/review", tags=["review"])


class RegenerateImageRequest(BaseModel):
    prompt: str = Field(default="", max_length=600)


def _public_image_url(slug: str) -> str:
    return public_hero_image_url(slug, require_file=False)


def _sync_hero_with_alt(post: BlogPost) -> None:
    if not post.html_content or not post.slug:
        return
    alt_hint = post.title_tag or post.selected_topic_title or post.slug.replace("-", " ")
    post.html_content = sync_hero_img_in_html(post.html_content, post.slug, alt=alt_hint)
    post.html_content = lock_hero_before_content(post.html_content, post.slug, alt=alt_hint)


def _ensure_hero_first_layout(post: BlogPost, db: Session) -> None:
    """Persist H1 → hero → TOC → content when stored HTML has content above the hero."""
    if not post.html_content or not post.slug:
        return
    if not layout_needs_hero_lock(post.html_content):
        return
    post.html_content = lock_hero_before_content(post.html_content, post.slug)
    db.commit()
    db.refresh(post)


def _ensure_no_unsolicited_faq(post: BlogPost, db: Session) -> None:
    """Strip FAQ that was not added via the Add FAQ button."""
    if not post.html_content:
        return
    if html_has_opted_in_faq(post.html_content):
        return
    if not html_has_faq_section(post.html_content):
        return
    cleaned = strip_faq_from_html(post.html_content)
    cleaned = sync_table_of_contents(cleaned)
    post.html_content = cleaned
    db.commit()
    db.refresh(post)


def _review_response(post: BlogPost) -> ReviewResponse:
    detail = BlogPostDetail.model_validate(post)
    updates: dict = {}
    if post.html_content:
        updates["body_text"] = extract_editable_text(post.html_content)
    minio_object = None
    for entry in reversed(list(post.feedback_history or [])):
        if isinstance(entry, dict) and entry.get("type") == "published":
            mini = entry.get("minio")
            if isinstance(mini, dict):
                minio_object = mini.get("object_name")
            break
    if minio_object:
        updates["minio_object"] = minio_object
    if updates:
        detail = detail.model_copy(update=updates)
    metrics = compute_seo_metrics(
        post.title_tag,
        post.meta_description,
        post.slug,
        post.reading_time,
        post.html_content,
        post.content_archetype,
    )
    return ReviewResponse(post=detail, seo_metrics=metrics)


@router.get("/pending", response_model=List[BlogPostSummary])
def list_pending_reviews(db: Session = Depends(get_db)):
    return (
        db.query(BlogPost)
        .filter(BlogPost.status == BlogStatus.PENDING_REVIEW)
        .order_by(BlogPost.created_at.desc())
        .all()
    )


@router.get("/{post_id}", response_model=ReviewResponse)
def get_review_post(post_id: int, db: Session = Depends(get_db)):
    post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    _ensure_hero_first_layout(post, db)
    _ensure_no_unsolicited_faq(post, db)
    return _review_response(post)


@router.post("/{post_id}/repair-cta")
def repair_blog_cta(post_id: int, db: Session = Depends(get_db)):
    """Fix CTA only — replaces broken/placeholder CTAs without changing images or body content."""
    post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    if not post.html_content:
        raise HTTPException(status_code=400, detail="Post has no content to repair")

    topic = post.selected_topic_title or post.title_tag or post.slug.replace("-", " ")
    product = get_product(db, post.product_id)
    post.html_content = fix_blog_cta(post.html_content, topic, product, slug=post.slug)
    db.commit()
    db.refresh(post)
    title = post.title_tag or post.selected_topic_title or post.slug or f"Post #{post.id}"
    emit_notification(
        db,
        type="published",
        title="CTA fixed — ready",
        message=f'"{title}" closing call-to-action was updated and is ready to review.',
        severity="success",
        post_id=post.id,
    )
    return _review_response(post)


@router.post("/{post_id}/add-faq")
def add_blog_faq(post_id: int, db: Session = Depends(get_db)):
    """Opt-in FAQ section — blogs stay FAQ-free until this button is clicked."""
    post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    if not post.html_content:
        raise HTTPException(status_code=400, detail="Post has no content")

    topic = post.selected_topic_title or post.title_tag or (post.slug or "topic").replace("-", " ")
    keyword = post.slug.replace("-", " ") if post.slug else topic
    product = get_product(db, post.product_id)
    post.html_content = add_faq_to_blog(
        post.html_content,
        topic,
        keyword,
        product=product,
        slug=post.slug,
    )
    db.commit()
    db.refresh(post)
    title = post.title_tag or post.selected_topic_title or post.slug or f"Post #{post.id}"
    emit_notification(
        db,
        type="published",
        title="FAQ added — ready",
        message=f'"{title}" FAQ section was added and is ready to review.',
        severity="success",
        post_id=post.id,
    )
    return _review_response(post)


@router.post("/{post_id}/repair-format")
def repair_blog_format(post_id: int, db: Session = Depends(get_db)):
    """Re-apply mid-body tables/charts, inline citations, CTA, TOC, and fix hero image URLs."""
    from pathlib import Path

    from app.services.image_generator import generate_hero_image

    post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    if not post.slug or not post.html_content:
        raise HTTPException(status_code=400, detail="Post has no content to repair")

    keyword = post.selected_topic_title or post.slug.replace("-", " ")
    product = get_product(db, post.product_id)
    # Preserve FAQ only if Add FAQ button already opted in
    allow_faq = html_has_opted_in_faq(post.html_content)
    post.html_content = enrich_blog_html(
        post.html_content,
        post.slug,
        post.selected_topic_title or post.title_tag or post.slug,
        keyword,
        product=product,
        allow_faq=allow_faq,
        title_tag=post.title_tag,
        meta_description=post.meta_description or "",
        research_pack=post.research_pack_json if isinstance(post.research_pack_json, dict) else None,
    )
    # Preserve existing hero quality — only generate if the file is missing
    hero_path = Path(settings.blog_images_dir) / f"{post.slug}.webp"
    if not hero_path.is_file():
        generate_hero_image(
            post.title_tag or post.selected_topic_title or post.slug,
            post.slug,
            post.feedback_history,
            product,
            primary_keyword=post.selected_topic_title or post.slug.replace("-", " "),
            meta_description=post.meta_description,
            html_content=post.html_content,
        )
    post.image_url = _public_image_url(post.slug)
    db.commit()
    db.refresh(post)
    title = post.title_tag or post.selected_topic_title or post.slug or f"Post #{post.id}"
    emit_notification(
        db,
        type="published",
        title="Format repaired — ready",
        message=f'"{title}" layout and format repair finished and is ready to review.',
        severity="success",
        post_id=post.id,
    )
    return _review_response(post)


@router.patch("/{post_id}", response_model=ReviewResponse)
def update_review_post(
    post_id: int,
    payload: BlogPostEditRequest,
    db: Session = Depends(get_db),
):
    """Manually edit blog metadata and HTML content."""
    post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    if post.status not in (BlogStatus.PENDING_REVIEW, BlogStatus.APPROVED, BlogStatus.GENERATING):
        raise HTTPException(status_code=400, detail=f"Cannot edit post in status {post.status}")

    data = payload.model_dump(exclude_unset=True)
    if "slug" in data and data["slug"]:
        from app.services.slugs import allocate_blog_slug, slugify
        from app.services.product_context import get_product

        product = get_product(db, post.product_id)
        requested = slugify(data["slug"], max_len=200)
        # Keep edits unique + product-scoped fixed form when possible
        conflict = (
            db.query(BlogPost)
            .filter(BlogPost.slug == requested, BlogPost.id != post_id)
            .first()
        )
        if conflict:
            data["slug"] = allocate_blog_slug(
                db,
                product=product,
                primary_keyword=requested,
                topic_title=post.selected_topic_title or "",
                post_id=post_id,
                lock_slug=None,
            )
        else:
            data["slug"] = requested

    body_text = data.pop("body_text", None)
    for key, value in data.items():
        setattr(post, key, value)

    if body_text is not None and post.html_content:
        post.html_content = apply_editable_text(post.html_content, body_text)
        post.html_content = bump_json_ld_date_modified(post.html_content)

    if post.html_content:
        post.reading_time = calc_reading_time(post.html_content)
        if post.slug:
            _sync_hero_with_alt(post)

    if post.slug:
        post.image_url = _public_image_url(post.slug)

    db.commit()
    db.refresh(post)
    return _review_response(post)


@router.post("/{post_id}/hero-image", response_model=ReviewResponse)
async def upload_hero_image(
    post_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """Replace hero image with a manual upload (converted to 1200×630 WebP)."""
    post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    if not post.slug:
        raise HTTPException(status_code=400, detail="Post has no slug yet")

    save_hero_upload(post.slug, file)
    post.image_url = _public_image_url(post.slug)
    if post.html_content:
        _sync_hero_with_alt(post)
        post.html_content = bump_json_ld_date_modified(post.html_content)
    db.commit()
    db.refresh(post)
    return _review_response(post)


@router.post("/{post_id}/regenerate-image")
def regenerate_hero_image(
    post_id: int,
    db: Session = Depends(get_db),
    payload: RegenerateImageRequest = Body(default_factory=RegenerateImageRequest),
):
    """Regenerate hero image with Fal.ai — pass prompt to override the default topic prompt."""
    from app.services.image_generator import generate_hero_image

    post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    if not post.slug:
        raise HTTPException(status_code=400, detail="Post has no slug yet")

    title = post.title_tag or post.selected_topic_title or post.slug
    product = get_product(db, post.product_id)
    custom_prompt = (payload.prompt or "").strip() or None
    generate_hero_image(
        title,
        post.slug,
        post.feedback_history,
        product,
        custom_prompt=custom_prompt,
        primary_keyword=post.selected_topic_title or post.slug.replace("-", " "),
        meta_description=post.meta_description,
        html_content=post.html_content,
    )
    post.image_url = _public_image_url(post.slug)
    if post.html_content:
        _sync_hero_with_alt(post)
        post.html_content = bump_json_ld_date_modified(post.html_content)
    db.commit()
    db.refresh(post)
    return {"message": "Hero image regenerated", "post_id": post_id}


class ApproveRequest(BaseModel):
    """Optional manual override when word count is outside the archetype filter."""

    override_word_count: bool = Field(
        False,
        description=(
            "If true, publish even when word count is outside the archetype min/max. "
            "UI must warn the editor first; same rule for every product."
        ),
    )


@router.post("/{post_id}/approve")
def approve_review(
    post_id: int,
    body: ApproveRequest = Body(default_factory=ApproveRequest),
    db: Session = Depends(get_db),
):
    post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    if post.status != BlogStatus.PENDING_REVIEW:
        raise HTTPException(status_code=400, detail=f"Post is in status {post.status}")
    if not post.html_content or not post.slug:
        raise HTTPException(status_code=400, detail="Content is still generating")

    override_word_count = bool(body.override_word_count)

    def _notify_fail(title: str, message: str) -> None:
        try:
            emit_notification(
                db,
                type="error",
                title=title,
                message=message[:2000],
                severity="error",
                post_id=post_id,
            )
        except Exception as notify_exc:
            logger.warning("Failed to emit approve error notification: {}", notify_exc)

    try:
        result = approve_post(post_id, override_word_count=override_word_count)
    except BlogSeoValidationError as exc:
        # publisher.py already emits a bell notification for SEO failures
        raise HTTPException(
            status_code=422,
            detail={
                "message": "Publish blocked — SEO validation failed",
                "failures": exc.failures,
            },
        ) from exc
    except Exception as exc:
        from app.services.content_generator import WordCountValidationError

        if isinstance(exc, WordCountValidationError):
            # publisher.py already emits a bell notification for word-count blocks
            raise HTTPException(
                status_code=422,
                detail={
                    "message": (
                        f"Publish blocked — word count {exc.word_count} is outside the "
                        f"chosen archetype limit ({exc.min_words}–{exc.max_words}). "
                        "Use Revision prompt to fix length, or confirm a manual override."
                    ),
                    "failures": [str(exc)],
                    "word_count": exc.word_count,
                    "min_words": exc.min_words,
                    "max_words": exc.max_words,
                    "override_allowed": True,
                },
            ) from exc
        _notify_fail(
            f"Publish failed · Post #{post_id}",
            f"{type(exc).__name__}: {exc}",
        )
        raise
    if not result:
        raise HTTPException(status_code=404, detail="Post not found")

    minio_info = None
    minio_error = None
    wordpress_info = None
    wordpress_error = None
    google_info = None
    google_error = None
    history = list(result.feedback_history or [])
    if history and isinstance(history[-1], dict):
        minio_info = history[-1].get("minio")
        minio_error = history[-1].get("minio_error")
        wordpress_info = history[-1].get("wordpress")
        wordpress_error = history[-1].get("wordpress_error")
        google_info = history[-1].get("google")
        google_error = history[-1].get("google_error")

    parts = ["Blog published successfully"]
    if minio_info:
        parts.append(
            f"MinIO: {minio_info.get('bucket')}/{minio_info.get('object_name')}"
        )
    elif minio_error:
        parts.append(f"MinIO failed: {minio_error}")
    if wordpress_info:
        parts.append(f"WordPress: {wordpress_info.get('link') or wordpress_info.get('id')}")
    elif wordpress_error:
        parts.append(f"WordPress failed: {wordpress_error}")
    if google_info:
        parts.append(f"Google: {google_info.get('url') or google_info.get('id')}")
    elif google_error:
        parts.append(f"Google failed: {google_error}")

    return {
        "message": " · ".join(parts),
        "post_id": post_id,
        "slug": result.slug,
        "minio": minio_info,
        "minio_error": minio_error,
        "wordpress": wordpress_info,
        "wordpress_error": wordpress_error,
        "google": google_info,
        "google_error": google_error,
    }


@router.post("/{post_id}/redo", status_code=202)
def redo_review(
    post_id: int,
    payload: RedoRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    if post.status != BlogStatus.PENDING_REVIEW:
        raise HTTPException(status_code=400, detail=f"Post is in status {post.status}")

    background_tasks.add_task(redo_post, post_id, payload.feedback)
    return {"message": "Redo requested. Regenerating content.", "post_id": post_id}


@router.post("/{post_id}/abort")
def abort_review(post_id: int, db: Session = Depends(get_db)):
    post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")

    title = post.title_tag or post.selected_topic_title or post.slug or f"Post #{post.id}"
    # Persist before delete so the bell still shows after the tab is closed
    emit_notification(
        db,
        type="published",
        title="Abort finished",
        message=f'"{title}" was aborted and removed. You can start a fresh run with Run discovery.',
        severity="success",
        post_id=None,
    )
    abort_post(post_id)
    return {"message": "Post aborted and removed. Run discovery to start fresh.", "post_id": post_id}
