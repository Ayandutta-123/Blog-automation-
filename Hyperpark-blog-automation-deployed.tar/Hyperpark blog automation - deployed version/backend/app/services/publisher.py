from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from loguru import logger
from openpyxl import Workbook, load_workbook
from sqlalchemy.orm import Session

from app.config import settings
from app.models import BlogPost, BlogStatus


def _ensure_excel_exists() -> None:
    path = Path(settings.metadata_excel_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    headers = ["Serial No", "Slug", "Blog Title", "Image URL", "HTML Page Path"]
    if not path.exists():
        wb = Workbook()
        ws = wb.active
        ws.title = "Blogs"
        ws.append(headers)
        wb.save(path)
        logger.info(f"Created metadata Excel: {path}")
        return

    # Align legacy header (Description → Slug) if needed
    try:
        wb = load_workbook(path)
        ws = wb.active
        first = [str(c.value or "").strip() for c in next(ws.iter_rows(min_row=1, max_row=1, max_col=5))]
        if first != headers:
            for col, value in enumerate(headers, start=1):
                ws.cell(1, col, value)
            if ws.title in ("Blog Metadata", "Sheet"):
                ws.title = "Blogs"
            wb.save(path)
            logger.info("Updated metadata Excel headers to Slug format")
    except Exception as exc:
        logger.warning("Could not normalize Excel headers: {}", exc)


def publish_blog_post(
    db: Session,
    post: BlogPost,
    *,
    override_word_count: bool = False,
) -> BlogPost:
    """Write a full SEO HTML document (canonical + OG/Twitter + public hero URL) and update indexes.

    When ``override_word_count`` is True (manual dashboard confirm), word-count
    archetype limits are logged but do not block publish — same for every product.
    """
    from app.services.blog_prose_css import blog_prose_css_for_product
    from app.services.notification_service import emit_notification
    from app.services.product_context import get_product
    from app.services.related_posts import register_published_post
    from app.services.seo_pipeline import (
        BlogSeoValidationError,
        assemble_full_html_document,
        canonical_url_for,
        finalize_blog_fragment,
        iso_date_today,
        public_hero_image_url,
        validate_seo_document,
    )

    _ensure_excel_exists()

    html_dir = Path(settings.blog_html_dir)
    html_dir.mkdir(parents=True, exist_ok=True)
    html_path = html_dir / f"{post.slug}.html"

    product = get_product(db, post.product_id)
    slug = post.slug or ""
    title = post.title_tag or post.selected_topic_title or slug
    description = post.meta_description or ""
    keyword = post.selected_topic_title or slug.replace("-", " ")
    published = iso_date_today()

    try:
        # Re-finalize with file present; fail loudly if SEO broken
        fragment = finalize_blog_fragment(
            post.html_content or "",
            slug=slug,
            title=title,
            description=description,
            primary_keyword=keyword,
            product=product,
            date_published=published,
            date_modified=published,
        )
        image_url = public_hero_image_url(slug, require_file=True)
        canonical = canonical_url_for(product, slug)
        css = blog_prose_css_for_product(product)
        full_doc = assemble_full_html_document(
            title=title,
            description=description,
            body_html=fragment,
            canonical=canonical,
            image_url=image_url,
            css=css,
        )
        validate_seo_document(full_doc, require_full_document=True)
    except BlogSeoValidationError as exc:
        logger.error(f"Publish blocked for '{slug}': {exc}")
        try:
            emit_notification(
                db,
                type="error",
                title=f"Publish failed · Post #{post.id}",
                message=str(exc)[:500],
                severity="error",
                post_id=post.id,
            )
        except Exception as notify_exc:
            logger.warning("Failed to emit publish SEO error notification: {}", notify_exc)
        raise

    from app.utils.content_format import validate_word_count

    wc_issues = validate_word_count(fragment, post.content_archetype)
    if wc_issues:
        from app.services.content_archetypes import get_archetype
        from app.services.content_generator import WordCountValidationError
        from app.utils.word_count import count_blog_words

        arch = get_archetype(post.content_archetype)
        wc = count_blog_words(fragment)
        if override_word_count:
            logger.warning(
                "Word-count override for '{}': {} words outside {}–{} ({})",
                slug,
                wc,
                arch.min_words,
                arch.max_words,
                arch.label,
            )
            try:
                emit_notification(
                    db,
                    type="warning",
                    title=f"Published with word-count override · Post #{post.id}",
                    message=(
                        f"Manual override: {wc} words outside {arch.label} limit "
                        f"({arch.min_words}–{arch.max_words}). {wc_issues[0]}"
                    )[:2000],
                    severity="warning",
                    post_id=post.id,
                )
            except Exception as notify_exc:
                logger.warning("Failed to emit word-count override notification: {}", notify_exc)
        else:
            logger.error("Publish blocked for '{}': {}", slug, wc_issues[0])
            try:
                emit_notification(
                    db,
                    type="error",
                    title=f"Publish blocked · word count · Post #{post.id}",
                    message=(
                        f"{wc_issues[0]}. Fix with Revision prompt, then Approve again — "
                        "or confirm a manual override from the review screen."
                    ),
                    severity="error",
                    post_id=post.id,
                )
            except Exception as notify_exc:
                logger.warning("Failed to emit word-count error notification: {}", notify_exc)
            raise WordCountValidationError(
                wc_issues[0],
                word_count=wc,
                min_words=arch.min_words,
                max_words=arch.max_words,
            )

    html_path.write_text(full_doc, encoding="utf-8")
    logger.info(f"SEO HTML written: {html_path}")

    # Keep DB fragment in sync (public URL + JSON-LD), not the full document
    post.html_content = fragment

    published_at = datetime.now(timezone.utc)
    # Per-product serial: next number after highest existing publish_serial
    from sqlalchemy import func

    serial_q = db.query(func.max(BlogPost.publish_serial)).filter(
        BlogPost.status == BlogStatus.PUBLISHED
    )
    if post.product_id is not None:
        serial_q = serial_q.filter(BlogPost.product_id == post.product_id)
    else:
        serial_q = serial_q.filter(BlogPost.product_id.is_(None))
    max_serial = serial_q.scalar() or 0
    publish_serial = int(max_serial) + 1

    hero_path: Optional[Path] = None
    images_dir = Path(settings.blog_images_dir)
    for ext in (".webp", ".jpg", ".jpeg", ".png"):
        candidate = images_dir / f"{slug}{ext}"
        if candidate.is_file():
            hero_path = candidate
            break

    minio_meta = None
    minio_hero_meta = None
    minio_error: Optional[str] = None
    try:
        from app.services.minio_storage import (
            MinioUploadError,
            minio_configured,
            resolve_public_url,
            upload_hero_image,
            upload_published_html,
        )

        if minio_configured():
            # Host the hero on MinIO too, otherwise the page depends on public_base_url
            # being internet-reachable and the image renders broken.
            minio_doc = full_doc
            if hero_path:
                minio_hero_meta = upload_hero_image(
                    slug=slug,
                    image_path=hero_path,
                    published_at=published_at,
                )
                hero_public = resolve_public_url(
                    (minio_hero_meta or {}).get("object_name") or "",
                    existing_url=(minio_hero_meta or {}).get("url") or "",
                    bucket=(minio_hero_meta or {}).get("bucket"),
                )
                if hero_public and minio_hero_meta is not None:
                    minio_hero_meta["url"] = hero_public
                    minio_doc = full_doc.replace(image_url, hero_public)
                    logger.info("MinIO hero image hosted at {}", hero_public)

            from app.utils.link_sanitizer import sanitize_markdown_urls_in_html

            minio_doc = sanitize_markdown_urls_in_html(minio_doc)

            minio_meta = upload_published_html(
                slug=slug,
                html_path=html_path,
                html_content=minio_doc,
                published_at=published_at,
            )
            if minio_meta:
                html_public = resolve_public_url(
                    minio_meta.get("object_name") or "",
                    existing_url=minio_meta.get("url") or "",
                    bucket=minio_meta.get("bucket"),
                )
                if html_public:
                    minio_meta["url"] = html_public
                if minio_hero_meta and minio_hero_meta.get("url"):
                    minio_meta["hero_url"] = minio_hero_meta["url"]
                    minio_meta["hero_object_name"] = minio_hero_meta.get("object_name") or ""
                logger.info(
                    "Published HTML uploaded to MinIO: {}",
                    minio_meta.get("url") or minio_meta.get("object_name"),
                )
            else:
                minio_error = "MinIO configured but upload returned no result"
        else:
            minio_error = "MinIO is not configured — HTML saved locally only"
    except MinioUploadError as exc:
        minio_error = str(exc)
        logger.error("MinIO upload failed for '{}': {}", slug, exc)
    except Exception as exc:
        minio_error = str(exc)
        logger.error("MinIO upload unexpected error for '{}': {}", slug, exc)

    if minio_error:
        try:
            emit_notification(
                db,
                type="error",
                title=f"MinIO upload failed · Post #{post.id}",
                message=(
                    f"Blog published locally, but HTML was not uploaded to MinIO: {minio_error}"
                )[:2000],
                severity="error",
                post_id=post.id,
            )
        except Exception as notify_exc:
            logger.warning("Failed to emit MinIO error notification: {}", notify_exc)

    wordpress_meta = None
    wordpress_error: Optional[str] = None
    try:
        from app.services.wordpress_publisher import (
            WordPressError,
            publish_post_to_wordpress,
            wordpress_configured,
        )

        if wordpress_configured(product):
            from app.services.wordpress_publisher import build_wordpress_excerpt

            wp_excerpt = build_wordpress_excerpt(
                title=title,
                meta_description=description,
                html_fragment=fragment,
            )
            wordpress_meta = publish_post_to_wordpress(
                product=product,
                title=title,
                content_html=fragment,
                slug=slug,
                excerpt=wp_excerpt,
                meta_description=description,
                featured_image_path=hero_path,
                hero_source_url=image_url,
            )
            logger.info(
                "Published to WordPress: {}",
                wordpress_meta.get("link") or wordpress_meta.get("id"),
            )
            if wordpress_meta.get("styles_kept") is False:
                try:
                    emit_notification(
                        db,
                        type="error",
                        title=f"WordPress stripped blog styles · Post #{post.id}",
                        message=(
                            "The post was published, but WordPress removed the embedded "
                            "stylesheet, so it will not match the downloaded HTML. Give the "
                            "connected WordPress account the 'unfiltered_html' capability "
                            "(Administrator on a single site) and republish."
                        ),
                        severity="error",
                        post_id=post.id,
                    )
                except Exception as notify_exc:
                    logger.warning("Failed to emit WordPress style notification: {}", notify_exc)
        else:
            wordpress_error = None  # not connected — skip silently
    except WordPressError as exc:
        wordpress_error = str(exc)
        logger.error("WordPress publish failed for '{}': {}", slug, exc)
    except Exception as exc:
        wordpress_error = str(exc)
        logger.error("WordPress publish unexpected error for '{}': {}", slug, exc)

    if wordpress_error:
        try:
            emit_notification(
                db,
                type="error",
                title=f"WordPress publish failed · Post #{post.id}",
                message=(
                    f"Blog published locally, but WordPress upload failed: {wordpress_error}"
                )[:2000],
                severity="error",
                post_id=post.id,
            )
        except Exception as notify_exc:
            logger.warning("Failed to emit WordPress error notification: {}", notify_exc)

    google_meta = None
    google_error: Optional[str] = None
    try:
        from app.services.google_blogger_publisher import (
            GoogleBloggerError,
            google_configured,
            publish_post_to_google,
        )

        if google_configured(product):
            google_meta = publish_post_to_google(
                product=product,
                title=title,
                content_html=fragment,
                db=db,
            )
            logger.info(
                "Published to Google Blogger: {}",
                google_meta.get("url") or google_meta.get("id"),
            )
    except GoogleBloggerError as exc:
        google_error = str(exc)
        logger.error("Google Blogger publish failed for '{}': {}", slug, exc)
    except Exception as exc:
        google_error = str(exc)
        logger.error("Google Blogger publish unexpected error for '{}': {}", slug, exc)

    if google_error:
        try:
            emit_notification(
                db,
                type="error",
                title=f"Google Blogger publish failed · Post #{post.id}",
                message=(
                    f"Blog published locally, but Google Blogger upload failed: {google_error}"
                )[:2000],
                severity="error",
                post_id=post.id,
            )
        except Exception as notify_exc:
            logger.warning("Failed to emit Google error notification: {}", notify_exc)

    register_published_post(
        title=title,
        url=canonical,
        primary_keyword=keyword,
        slug=slug,
    )

    wb = load_workbook(settings.metadata_excel_path)
    ws = wb.active

    last_serial = 0
    for row in ws.iter_rows(min_row=2, max_col=1, values_only=True):
        if row[0] is not None:
            try:
                last_serial = max(last_serial, int(row[0]))
            except (ValueError, TypeError):
                pass

    new_serial = publish_serial if publish_serial else last_serial + 1

    # Google Sheet / Excel must store clickable public MinIO URLs for every product —
    # not local /api/images paths, filesystem paths, or private app URLs.
    minio_html_url = ((minio_meta or {}).get("url") or "").strip()
    minio_image_url = (
        ((minio_meta or {}).get("hero_url") or "").strip()
        or ((minio_hero_meta or {}).get("url") or "").strip()
    )
    image_public = minio_image_url or (image_url or "").strip()
    public_post_url = (
        minio_html_url
        or (canonical or "").strip()
        or str(html_path.resolve())
    )
    logger.info(
        "Ledger URLs for '{}': html={} image={}",
        slug,
        public_post_url,
        image_public,
    )

    ws.append(
        [
            new_serial,
            slug,
            title,
            image_public,
            public_post_url,
        ]
    )
    wb.save(settings.metadata_excel_path)
    logger.info(f"Excel ledger updated: row {new_serial}")

    sheet_meta = None
    sheet_error = None
    try:
        from app.services.google_sheets_ledger import (
            GoogleSheetsLedgerError,
            append_blog_ledger_row,
            sheet_configured,
        )

        if sheet_configured(product):
            sheet_meta = append_blog_ledger_row(
                product,
                serial_no=new_serial,
                slug=slug,
                blog_title=title,
                image_url=image_public or "",
                html_page_path=public_post_url,
                db=db,
            )
    except GoogleSheetsLedgerError as exc:
        sheet_error = str(exc)
        logger.error("Google Sheet ledger failed for '{}': {}", slug, exc)
    except Exception as exc:
        sheet_error = str(exc)
        logger.error("Google Sheet ledger unexpected error for '{}': {}", slug, exc)

    if sheet_error:
        try:
            emit_notification(
                db,
                type="error",
                title=f"Google Sheet ledger failed · Post #{post.id}",
                message=(
                    f"Blog published locally, but the product Google Sheet was not updated: "
                    f"{sheet_error}"
                )[:2000],
                severity="error",
                post_id=post.id,
            )
        except Exception as notify_exc:
            logger.warning("Failed to emit Google Sheet error notification: {}", notify_exc)

    post.status = BlogStatus.PUBLISHED
    post.published_at = published_at
    post.publish_serial = publish_serial
    post.final_html_path = str(html_path)
    post.image_url = image_public

    history = list(post.feedback_history or [])
    history.append(
        {
            "type": "published",
            "feedback": f"Published: {post.title_tag or post.slug}",
            "timestamp": published_at.isoformat(),
            "publish_serial": publish_serial,
            **({"minio": minio_meta} if minio_meta else {}),
            **({"minio_error": minio_error} if minio_error else {}),
            **({"wordpress": wordpress_meta} if wordpress_meta else {}),
            **({"wordpress_error": wordpress_error} if wordpress_error else {}),
            **({"google": google_meta} if google_meta else {}),
            **({"google_error": google_error} if google_error else {}),
            **({"google_sheet": sheet_meta} if sheet_meta else {}),
            **({"google_sheet_error": sheet_error} if sheet_error else {}),
        }
    )
    post.feedback_history = history

    db.commit()
    db.refresh(post)

    try:
        parts = [f"“{title}” is live."]
        if minio_meta:
            parts.append(
                f"MinIO: {minio_meta.get('bucket')}/{minio_meta.get('object_name')}"
            )
        if wordpress_meta:
            parts.append(f"WordPress: {wordpress_meta.get('link') or wordpress_meta.get('id')}")
        if google_meta:
            parts.append(f"Google: {google_meta.get('url') or google_meta.get('id')}")
        if sheet_meta:
            parts.append(f"Sheet row #{sheet_meta.get('serial_no')}")
        if not minio_meta and minio_error:
            parts.append("(MinIO upload failed — see error notification)")
        if wordpress_error:
            parts.append("(WordPress upload failed — see error notification)")
        if google_error:
            parts.append("(Google Blogger upload failed — see error notification)")
        if sheet_error:
            parts.append("(Google Sheet ledger failed — see error notification)")
        emit_notification(
            db,
            type="published",
            title=f"Published · Post #{post.id}",
            message=" ".join(parts)[:2000],
            severity="success",
            post_id=post.id,
        )
    except Exception as notify_exc:
        logger.warning("Failed to emit publish success notification: {}", notify_exc)

    from app.services.teams_notifier import notify_published

    product_name = getattr(product, "name", None) if product else None
    notify_published(
        post.title_tag or "",
        post.slug or "",
        live_url=(minio_meta or {}).get("url") if minio_meta else None,
        product_name=product_name,
        minio_object=(minio_meta or {}).get("object_name") if minio_meta else None,
        wordpress_url=(wordpress_meta or {}).get("link") if wordpress_meta else None,
        google_url=(google_meta or {}).get("url") if google_meta else None,
        post_id=post.id,
    )
    return post
