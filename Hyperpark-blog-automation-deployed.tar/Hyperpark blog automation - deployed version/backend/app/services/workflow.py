from __future__ import annotations

from pathlib import Path

from loguru import logger
from sqlalchemy.orm import Session

from app.config import settings

from app.database import SessionLocal
from app.models import BlogPost, BlogStatus, Product, ScraperCategory, ScraperSettings
from app.services.content_generator import generate_blog_content
from app.services.image_generator import generate_hero_image
from app.services.product_context import get_product
from app.services.runtime_config import get_config_value
from app.services.scraper import run_discovery
from app.services.teams_notifier import notify_review_required, notify_topic_selection
from app.services.topic_synthesis import synthesize_topics
from app.services.publisher import publish_blog_post

from datetime import datetime, timezone
from typing import Any

from app.utils.word_count import count_blog_words

DEFAULT_KEYWORDS = [
    "smart parking automation trends",
    "ANPR access control IoT",
    "EV charging mobility hubs",
]

DEFAULT_COMPETITOR_URLS = [
    "https://www.parkopedia.com/blog/",
    "https://www.skidata.com/news/",
    "https://www.flowbird.group/en/news/",
]


def _default_product_id(db: Session) -> int | None:
    product = db.query(Product).filter(Product.is_default.is_(True)).first()
    if product:
        return product.id
    fallback = db.query(Product).first()
    return fallback.id if fallback else None


def migrate_global_scraper_settings(db: Session) -> None:
    """Assign legacy global scraper rows to the default product."""
    product_id = _default_product_id(db)
    if not product_id:
        return
    updated = (
        db.query(ScraperSettings)
        .filter(ScraperSettings.product_id.is_(None))
        .update({ScraperSettings.product_id: product_id}, synchronize_session=False)
    )
    if updated:
        db.commit()
        logger.info(f"Migrated {updated} global scraper settings to product #{product_id}")


def seed_scraper_settings(db: Session) -> None:
    migrate_global_scraper_settings(db)

    existing = db.query(ScraperSettings).count()
    if existing > 0:
        return

    product_id = _default_product_id(db)

    for kw in DEFAULT_KEYWORDS:
        db.add(
            ScraperSettings(
                category=ScraperCategory.INDUSTRY_KEYWORD,
                value=kw,
                is_active=True,
                added_by="System",
                product_id=product_id,
            )
        )
    for url in DEFAULT_COMPETITOR_URLS:
        db.add(
            ScraperSettings(
                category=ScraperCategory.COMPETITOR_URL,
                value=url,
                is_active=True,
                added_by="System",
                product_id=product_id,
            )
        )
    db.commit()
    logger.info("Seeded default scraper settings")


def normalize_topic_selection_mode(raw: str | None) -> str:
    mode = (raw or "manual").strip().lower()
    if mode == "both":
        return "hybrid"
    if mode not in ("manual", "auto", "hybrid"):
        return "manual"
    return mode


def get_topic_selection_mode(product_id: int | None = None) -> str:
    """Resolve topic mode for a product (preferred) or fall back to legacy global config."""
    if product_id:
        db = SessionLocal()
        try:
            product = db.query(Product).filter(Product.id == product_id).first()
            if product and getattr(product, "topic_selection_mode", None):
                return normalize_topic_selection_mode(product.topic_selection_mode)
        finally:
            db.close()

    # Legacy global fallback (Integrations / env) — default manual so nothing auto-runs
    # until the user picks a mode under the product.
    mode = (get_config_value("topic_selection_mode") or "manual").strip().lower()
    return normalize_topic_selection_mode(mode)


def get_default_content_archetype(product_id: int | None = None) -> str:
    from app.services.content_archetypes import DEFAULT_ARCHETYPE, normalize_archetype

    if product_id:
        db = SessionLocal()
        try:
            product = db.query(Product).filter(Product.id == product_id).first()
            if product and product.content_archetype:
                return normalize_archetype(product.content_archetype)
        finally:
            db.close()
    return normalize_archetype(get_config_value("content_archetype") or DEFAULT_ARCHETYPE)


def get_active_product_id(db: Session) -> int | None:
    raw = get_config_value("active_product_id", db)
    if raw and str(raw).isdigit():
        return int(raw)
    product = get_product(db, None)
    return product.id if product else None


def start_discovery_run(product_id: int | None = None) -> int:
    """Create a SCRAPING post and return its id immediately."""
    db = SessionLocal()
    try:
        resolved_id = product_id or get_active_product_id(db)
        post = BlogPost(
            status=BlogStatus.SCRAPING,
            content_archetype=get_default_content_archetype(resolved_id),
            product_id=resolved_id,
        )
        db.add(post)
        db.commit()
        db.refresh(post)
        logger.info(f"Discovery started for BlogPost #{post.id}")
        return post.id
    finally:
        db.close()


def _mark_discovery_failed(post_id: int, error: str) -> None:
    """Keep post in Discovery (SCRAPING) so Retry reworks the same stage — never jump back to a fresh run."""
    db = SessionLocal()
    try:
        post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
        if not post:
            return
        history: list[dict[str, Any]] = list(post.feedback_history or [])
        history.append(
            {
                "feedback": f"Discovery failed: {error}",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "type": "error",
                "stage": "discovery",
                "needs_retry": True,
            }
        )
        post.feedback_history = history
        post.status = BlogStatus.SCRAPING
        db.commit()
        try:
            from app.services.notification_service import emit_notification

            emit_notification(
                db,
                type="error",
                title=f"Discovery failed · Post #{post_id}",
                message=str(error)[:2000],
                severity="error",
                post_id=post_id,
            )
        except Exception as notify_exc:
            logger.warning(f"Failed to emit discovery error notification: {notify_exc}")
        logger.error(f"BlogPost #{post_id} discovery failed: {error}")
    finally:
        db.close()


def _mark_generation_failed(post_id: int, error: str) -> None:
    """Keep post in Generation (GENERATING) so Retry stays on the same workflow stage."""
    db = SessionLocal()
    try:
        post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
        if not post:
            return
        history: list[dict[str, Any]] = list(post.feedback_history or [])
        history.append(
            {
                "feedback": f"Content generation failed: {error}",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "type": "error",
                "stage": "generation",
                "needs_retry": True,
            }
        )
        post.feedback_history = history
        post.status = BlogStatus.GENERATING
        db.commit()
        try:
            from app.services.notification_service import emit_notification

            emit_notification(
                db,
                type="error",
                title=f"Generation failed · Post #{post_id}",
                message=str(error)[:2000],
                severity="error",
                post_id=post_id,
            )
        except Exception as notify_exc:
            logger.warning(f"Failed to emit generation error notification: {notify_exc}")
        logger.error(f"BlogPost #{post_id} content generation failed: {error}")
    finally:
        db.close()


def _content_is_ready(post: BlogPost) -> bool:
    return bool(post.html_content and post.slug and post.title_tag)


def _pick_best_topic(topics) -> dict:
    """Auto-select the best topic by SEO score; fall back to first topic."""
    from app.services.topic_seo_analyzer import rank_topics_for_auto_pick

    ranked = rank_topics_for_auto_pick(topics)
    return ranked[0] if ranked else {}


def complete_discovery_run(post_id: int) -> None:
    """Background job: scrape, synthesize topics, apply selection mode."""
    from app.utils.playwright_setup import configure_playwright_browsers_path

    configure_playwright_browsers_path()
    db = SessionLocal()
    try:
        post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
        if not post:
            logger.error(f"BlogPost #{post_id} not found for discovery")
            return

        logger.info(f"Running discovery pipeline for BlogPost #{post_id}")
        product = get_product(db, post.product_id)
        discovery_data = run_discovery(db, post.product_id)
        topics = synthesize_topics(discovery_data, product)

        from app.services.topic_seo_analyzer import (
            compact_discovery_snapshot,
            enrich_topics_with_seo_analysis,
        )

        topics = enrich_topics_with_seo_analysis(topics, discovery_data, db)
        from app.services.topic_synthesis import attach_source_links_to_topics

        topics = attach_source_links_to_topics(topics, discovery_data)
        snapshot = compact_discovery_snapshot(discovery_data)

        # Fresh discovery must not retain prior generation artifacts
        post.scraped_topics_json = topics
        post.discovery_snapshot_json = snapshot
        post.research_pack_json = None
        post.selected_topic_title = None
        post.title_tag = None
        post.meta_description = None
        post.slug = None
        post.reading_time = None
        post.image_url = None
        post.html_content = None
        post.final_html_path = None
        post.feedback_history = []
        post.status = BlogStatus.PENDING_TOPIC
        db.commit()
        db.refresh(post)

        try:
            from app.services.notification_service import emit_notification

            emit_notification(
                db,
                type="topic_selection",
                title=f"Topics ready · Post #{post.id}",
                message="Discovery finished — choose a topic to continue.",
                severity="action",
                post_id=post.id,
            )
        except Exception as exc:
            logger.warning(f"Notification emit failed (non-fatal): {exc}")

        mode = get_topic_selection_mode(post.product_id)
        logger.info(f"Topic selection mode for product #{post.product_id}: {mode}")

        from app.services.topic_synthesis import flatten_topics

        flat = flatten_topics(topics)

        if mode == "auto" and flat:
            # Fully automated: pick best SEO-scored topic → generate → Teams review ping
            best = _pick_best_topic(topics)
            logger.info(
                f"Auto-picked topic (SEO score {best.get('seo_score')}): {best.get('title')}"
            )
            db.close()
            select_topic_and_generate(
                post_id,
                best.get("title", ""),
                best.get("primary_keyword"),
            )
            return

        # hybrid ("Both") and manual: pause at topic selection.
        # hybrid also notifies Teams so reviewers can pick; cron only fires for auto/hybrid.
        try:
            notify_topic_selection(post.id, flat)
        except Exception as exc:
            logger.warning(f"Teams notification failed (non-fatal): {exc}")
        logger.info(f"BlogPost #{post_id} ready for topic selection ({mode} mode)")
    except Exception as exc:
        logger.error(f"Discovery failed for #{post_id}: {exc}")
        db.rollback()
        _mark_discovery_failed(post_id, str(exc))
    finally:
        db.close()


def run_scheduled_discovery(product_id: int) -> None:
    """Cron entrypoint for a single product."""
    post_id = start_discovery_run(product_id)
    complete_discovery_run(post_id)


# Backwards-compatible alias (unused by scheduler after per-product migration)
def run_weekly_discovery() -> None:
    db = SessionLocal()
    try:
        product_id = get_active_product_id(db)
    finally:
        db.close()
    if product_id:
        run_scheduled_discovery(product_id)


def auto_select_topic(post_id: int) -> None:
    """Manually trigger auto topic pick (hybrid/manual modes)."""
    db = SessionLocal()
    try:
        post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
        if not post or post.status != BlogStatus.PENDING_TOPIC:
            return
        topics = post.scraped_topics_json or []
        if not topics:
            raise ValueError("No topics available to auto-select")
        best = _pick_best_topic(topics)
    finally:
        db.close()

    select_topic_and_generate(
        post_id,
        best.get("title", ""),
        best.get("primary_keyword"),
    )


def select_topic_and_generate(
    post_id: int,
    topic_title: str,
    primary_keyword: str | None = None,
    content_archetype: str | None = None,
) -> None:
    db = SessionLocal()
    try:
        post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
        if not post:
            logger.error(f"BlogPost #{post_id} not found")
            return

        incomplete_review = (
            post.status == BlogStatus.PENDING_REVIEW and not _content_is_ready(post)
        )
        if post.status not in (
            BlogStatus.PENDING_TOPIC,
            BlogStatus.GENERATING,
        ) and not incomplete_review:
            logger.warning(f"BlogPost #{post_id} status is {post.status}, skipping generation")
            return

        post.selected_topic_title = topic_title
        if content_archetype:
            post.content_archetype = content_archetype
        elif not post.content_archetype:
            post.content_archetype = get_default_content_archetype(post.product_id)
        if not primary_keyword and post.scraped_topics_json:
            from app.services.topic_synthesis import flatten_topics

            for t in flatten_topics(post.scraped_topics_json):
                if t.get("title") == topic_title:
                    primary_keyword = t.get("primary_keyword", topic_title)
                    break
        primary_keyword = primary_keyword or topic_title

        from app.services.keyword_research import build_research_pack

        discovery_data = post.discovery_snapshot_json or {}
        research_pack = build_research_pack(
            db,
            topic_title=topic_title,
            primary_keyword=primary_keyword,
            discovery_data=discovery_data,
        )
        post.research_pack_json = research_pack

        post.status = BlogStatus.GENERATING
        db.commit()
    finally:
        db.close()

    _generate_content_and_image(post_id, topic_title, primary_keyword)


def _generate_content_and_image(
    post_id: int,
    topic_title: str,
    primary_keyword: str,
    regenerate_image: bool = True,
    lock_slug: str | None = None,
) -> None:
    """Generate/regenerate blog content, optionally regenerating the hero image too.

    regenerate_image=False (used for revision-prompt redos) guarantees the image on disk is
    left completely untouched — only content, tables, and charts may change from a prompt.
    Images only ever change via the dedicated "AI Generate" / "Upload Image" buttons.
    """
    db = SessionLocal()
    try:
        post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
        if not post:
            return

        feedback = list(post.feedback_history or [])
        archetype = post.content_archetype or get_default_content_archetype(post.product_id)
        from app.services.content_archetypes import get_archetype

        arch = get_archetype(archetype)
        if post.html_content:
            wc = count_blog_words(post.html_content)
            if wc:
                feedback.append(
                    {
                        "type": "system",
                        "feedback": (
                            f"INTERNAL REFERENCE ONLY (do not publish): previous draft is {wc} words. "
                            f"Target for {arch.label} is {arch.min_words}–{arch.max_words} words. "
                            "Honor reviewer redo requests about length."
                        ),
                    }
                )

        slug_guess = lock_slug or primary_keyword.lower().replace(" ", "-")[:60]
        product = get_product(db, post.product_id)
        from app.services.slugs import allocate_blog_slug, ensure_product_slug

        if product:
            ensure_product_slug(db, product)
            db.commit()
        # Fixed unique slug per product — ignore model-invented variants
        fixed_slug = allocate_blog_slug(
            db,
            product=product,
            primary_keyword=primary_keyword,
            topic_title=topic_title,
            post_id=post_id,
            lock_slug=lock_slug or post.slug,
        )
        research_pack = post.research_pack_json
        if not research_pack:
            from app.services.keyword_research import build_research_pack

            research_pack = build_research_pack(
                db,
                topic_title=topic_title,
                primary_keyword=primary_keyword,
                discovery_data=post.discovery_snapshot_json or {},
            )
            post.research_pack_json = research_pack
            db.commit()
        # Content first, then hero — image must match the final clickbait title + article angle
        content = generate_blog_content(
            topic_title,
            primary_keyword,
            feedback,
            archetype,
            product,
            fixed_slug,
            research_pack=research_pack,
        )
        slug = content.get("slug") or fixed_slug or slug_guess
        image_title = content.get("title_tag") or topic_title
        image_keyword = content.get("primary_keyword") or primary_keyword
        image_meta = content.get("meta_description") or ""
        article_html = content.get("html_content") or ""

        if regenerate_image:
            generate_hero_image(
                image_title,
                slug,
                feedback,
                product,
                primary_keyword=image_keyword,
                meta_description=image_meta,
                html_content=article_html,
            )
        elif not (Path(settings.blog_images_dir) / f"{slug}.webp").is_file():
            # Safety net only — a revision prompt should never need this because slug is
            # locked, but never ship a post with a missing hero image.
            logger.warning(f"BlogPost #{post_id}: hero image missing for locked slug '{slug}'; generating once")
            generate_hero_image(
                image_title,
                slug,
                feedback,
                product,
                primary_keyword=image_keyword,
                meta_description=image_meta,
                html_content=article_html,
            )

        # Standing SEO finalize AFTER hero exists on disk (public URL, JSON-LD dates, no base64)
        from app.services.seo_pipeline import (
            BlogSeoValidationError,
            finalize_blog_fragment,
            iso_date_today,
        )

        published = iso_date_today()
        try:
            html = finalize_blog_fragment(
                content.get("html_content") or "",
                slug=slug,
                title=content.get("title_tag") or topic_title,
                description=content.get("meta_description") or "",
                primary_keyword=image_keyword,
                product=product,
                date_published=published,
                date_modified=published,
                image_prompt=image_meta or image_title,
            )
        except BlogSeoValidationError as exc:
            logger.error(f"SEO validation failed for BlogPost #{post_id}: {exc}")
            raise

        from app.services.seo_pipeline import public_hero_image_url as _public_hero

        post.slug = content.get("slug") or slug
        post.title_tag = content.get("title_tag")
        post.meta_description = content.get("meta_description")
        post.reading_time = content.get("reading_time")
        post.html_content = html
        post.image_url = _public_hero(post.slug, require_file=False)
        post.status = BlogStatus.PENDING_REVIEW
        history = list(post.feedback_history or [])
        post.feedback_history = [h for h in history if h.get("type") != "error"]
        db.commit()
        db.refresh(post)

        try:
            from app.services.notification_service import emit_notification

            emit_notification(
                db,
                type="review_required",
                title=post.title_tag or f"Post #{post.id}",
                message="Content is ready for your review",
                severity="action",
                post_id=post.id,
            )
        except Exception as exc:
            logger.warning(f"Notification emit failed (non-fatal): {exc}")

        try:
            notify_review_required(post)
        except Exception as exc:
            logger.warning(f"Teams notification failed (non-fatal): {exc}")
        logger.info(f"Content generated for BlogPost #{post_id}, awaiting review")
    except Exception as exc:
        logger.error(f"Content generation failed for #{post_id}: {exc}")
        db.rollback()
        _mark_generation_failed(post_id, str(exc))
        raise
    finally:
        db.close()


def approve_post(post_id: int, *, override_word_count: bool = False) -> BlogPost | None:
    db = SessionLocal()
    try:
        post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
        if not post:
            return None
        if post.status != BlogStatus.PENDING_REVIEW:
            logger.warning(f"Cannot approve post #{post_id} in status {post.status}")
            return post
        # Publish first; only mark APPROVED/PUBLISHED after SEO validation succeeds
        return publish_blog_post(db, post, override_word_count=override_word_count)
    finally:
        db.close()


def redo_post(post_id: int, feedback: str) -> None:
    """Revision prompt — regenerates content/tables/charts only. The hero image is never
    touched here; it only changes via the dedicated AI Generate / Upload Image buttons."""
    db = SessionLocal()
    try:
        post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
        if not post:
            return

        original_slug = post.slug

        history: list[dict[str, Any]] = list(post.feedback_history or [])
        history.append(
            {
                "feedback": feedback,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        )
        post.feedback_history = history
        post.status = BlogStatus.GENERATING
        db.commit()

        primary_keyword = post.slug or post.selected_topic_title or ""
        from app.services.topic_synthesis import flatten_topics

        for t in flatten_topics(post.scraped_topics_json):
            if t.get("title") == post.selected_topic_title:
                primary_keyword = t.get("primary_keyword", primary_keyword)
                break

        _generate_content_and_image(
            post_id,
            post.selected_topic_title or "",
            primary_keyword,
            regenerate_image=False,
            lock_slug=original_slug,
        )
    finally:
        db.close()


def retry_generation(post_id: int) -> None:
    """Retry a failed generation without leaving the Review column / stage."""
    db = SessionLocal()
    topic = ""
    primary_keyword = ""
    try:
        post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
        if not post:
            raise ValueError("Post not found")
        if post.status not in (BlogStatus.GENERATING, BlogStatus.PENDING_REVIEW):
            raise ValueError(f"Cannot retry generation in status {post.status.value}")
        if not post.selected_topic_title:
            raise ValueError("No selected topic to regenerate")

        history = list(post.feedback_history or [])
        post.feedback_history = [h for h in history if h.get("type") != "error"]
        post.status = BlogStatus.GENERATING
        db.commit()

        primary_keyword = post.slug or post.selected_topic_title or ""
        from app.services.topic_synthesis import flatten_topics

        for t in flatten_topics(post.scraped_topics_json):
            if t.get("title") == post.selected_topic_title:
                primary_keyword = t.get("primary_keyword", primary_keyword)
                break

        topic = post.selected_topic_title
    finally:
        db.close()

    if not topic:
        raise ValueError("No selected topic to regenerate")
    _generate_content_and_image(post_id, topic, primary_keyword)


def abort_post(post_id: int) -> None:
    """Abort means wipe the run entirely — no leftover topics/content on the board."""
    db = SessionLocal()
    try:
        post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
        if not post:
            return
        db.delete(post)
        db.commit()
        logger.info(f"BlogPost #{post_id} aborted and deleted")
    finally:
        db.close()
