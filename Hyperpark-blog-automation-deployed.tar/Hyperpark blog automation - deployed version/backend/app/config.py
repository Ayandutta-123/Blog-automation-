from __future__ import annotations

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    tavily_api_key: str = ""
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-4-5"
    fal_key: str = ""
    teams_webhook_url: str = ""

    storage_root: str = "../storage"
    blog_images_dir: str = "../storage/blog_images"
    blog_html_dir: str = "../storage/blogs/html"
    metadata_excel_path: str = "../storage/blogs/metadata.xlsx"
    database_url: str = "sqlite:///../storage/hyperpark_blog.db"

    api_host: str = "0.0.0.0"
    api_port: int = 8000
    frontend_url: str = "http://localhost:3000"
    public_base_url: str = "http://localhost:8000"

    cron_day_of_week: str = "mon"
    cron_hour: int = 9
    cron_minute: int = 0
    cron_timezone: str = "Asia/Kolkata"
    dashboard_username: str = ""
    dashboard_password: str = ""
    topic_selection_mode: str = "hybrid"
    content_archetype: str = "tutorial"
    blog_content_instructions: str = (
        "Always use rich format: data tables, inline SVG or stat-grid graphics, "
        "genuine authoritative backlinks, and a strong demo CTA ending. "
        "Photorealistic hero image context."
    )
    blog_structure_rules: str = ""

    # MinIO / S3-compatible storage for published HTML
    minio_endpoint: str = ""
    minio_access_key: str = ""
    minio_secret_key: str = ""
    minio_bucket: str = ""
    minio_prefix: str = "blogs/html"
    minio_secure: str = "true"
    minio_region: str = ""
    minio_public_base_url: str = ""

    def ensure_dirs(self) -> None:
        for path in [
            self.storage_root,
            self.blog_images_dir,
            self.blog_html_dir,
            Path(self.metadata_excel_path).parent,
        ]:
            Path(path).mkdir(parents=True, exist_ok=True)


settings = Settings()
