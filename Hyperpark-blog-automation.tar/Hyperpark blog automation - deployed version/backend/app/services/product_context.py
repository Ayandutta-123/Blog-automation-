from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from bs4 import BeautifulSoup
from loguru import logger
from sqlalchemy.orm import Session

from app.config import settings
from app.models import Product

DEFAULT_INTERNAL_LINKS = [
    {"label": "Book a live demo", "url": "https://calendly.com/vijayrhts/htssales"},
    {"label": "Smart parking platform", "url": "https://hyperpark.io/smart-parking"},
    {"label": "Access management solutions", "url": "https://hyperpark.io/access-management"},
    {"label": "HyperPark platform", "url": "https://hyperpark.io/"},
]

DEFAULT_BRAND_CONTEXT = """Target audience: B2B enterprise decision-makers, smart city planners, hospital/mall facility managers, parking operators.

Core value props: Smart parking automation, ANPR, ticketless QR access, HyperValet digital valet, EV mobility hubs, zero revenue leakage, hardware-agnostic IoT."""

DEFAULT_BRAND_PALETTE = {
    "primary": "#252a61",
    "navy": "#1b1f4a",
    "accent": "#ff6002",
    "cta": "#c1262a",
    "link": "#1d4ed8",
}

BRAND_PALETTE_KEYS = ("primary", "navy", "accent", "cta", "link")
_HEX_COLOR_RE = re.compile(r"^#[0-9A-Fa-f]{6}$")


def product_storage_dir(product_id: int) -> Path:
    root = Path(settings.storage_root) / "products" / str(product_id)
    root.mkdir(parents=True, exist_ok=True)
    return root


def _normalize_custom_colors(raw: Any) -> list[dict[str, str]]:
    if not isinstance(raw, list):
        return []
    colors: list[dict[str, str]] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        hex_value = item.get("hex")
        if not isinstance(hex_value, str):
            continue
        cleaned = hex_value.strip()
        if not _HEX_COLOR_RE.match(cleaned):
            continue
        label = str(item.get("label") or "Custom").strip()[:64] or "Custom"
        entry_id = str(item.get("id") or "").strip()[:32]
        if not entry_id:
            entry_id = f"custom-{len(colors) + 1}"
        colors.append({"id": entry_id, "label": label, "hex": cleaned.lower()})
    return colors


def normalize_brand_palette(raw: Any) -> dict[str, Any]:
    palette: dict[str, Any] = {**DEFAULT_BRAND_PALETTE, "custom": []}
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except json.JSONDecodeError:
            return palette
    if isinstance(raw, dict):
        for key in BRAND_PALETTE_KEYS:
            value = raw.get(key)
            if isinstance(value, str):
                cleaned = value.strip()
                if _HEX_COLOR_RE.match(cleaned):
                    palette[key] = cleaned.lower()
        palette["custom"] = _normalize_custom_colors(raw.get("custom"))
    return palette


def get_core_brand_colors(palette: dict[str, Any]) -> dict[str, str]:
    return {key: str(palette.get(key, DEFAULT_BRAND_PALETTE[key])) for key in BRAND_PALETTE_KEYS}


def get_brand_palette(product: Product | None) -> dict[str, Any]:
    if not product:
        return normalize_brand_palette(None)
    return normalize_brand_palette(product.brand_palette_json)


def format_brand_palette_prompt(product: Product | None) -> str:
    palette = get_brand_palette(product)
    lines = [
        "BRAND COLOR PALETTE — HARD LOCK (use ONLY these exact hex values; never invent or substitute other colors):",
        f"- Primary: {palette['primary']} (headings, table accents)",
        f"- Navy: {palette['navy']} (dark backgrounds, table headers)",
        f"- Accent / charts: {palette['accent']} (stat numbers, chart bars, highlights)",
        f"- CTA button: {palette['cta']} (primary CTA button fill)",
        f"- Hyperlink / source: {palette['link']} (bold, this exact color on every <a>)",
    ]
    for entry in palette.get("custom") or []:
        lines.append(f"- {entry['label']}: {entry['hex']}")
    lines.append(
        "Do NOT use HyperPark default navy/orange unless those are the palette values above. "
        "Do NOT pick random theme colors. Inline SVG fills, chart bars, CTA backgrounds, and "
        "link colors MUST match the hex list above exactly."
    )
    return "\n".join(lines)


def brand_palette_css_block(product: Product | None = None, palette: dict[str, Any] | None = None) -> str:
    """CSS variable block so blog HTML (preview/download) uses this product's colors."""
    full = palette or get_brand_palette(product)
    colors = get_core_brand_colors(full)
    lines = [
        ":root, .prose-blog, article {",
        f"  --hyper-primary: {colors['primary']};",
        f"  --hyper-navy: {colors['navy']};",
        f"  --hyper-orange: {colors['accent']};",
        f"  --hyper-accent: {colors['accent']};",
        f"  --hyper-red: {colors['cta']};",
        f"  --hyper-cta: {colors['cta']};",
        f"  --hyper-link: {colors['link']};",
    ]
    for index, entry in enumerate(full.get("custom") or [], start=1):
        hex_val = entry.get("hex") if isinstance(entry, dict) else None
        if isinstance(hex_val, str) and hex_val.startswith("#"):
            lines.append(f"  --brand-custom-{index}: {hex_val.lower()};")
    lines.append("}")
    lines.append("")
    return "\n".join(lines) + "\n"


def inject_brand_palette_style(html: str, product: Product | None = None) -> str:
    """Embed product brand CSS vars into stored HTML (idempotent)."""
    css = brand_palette_css_block(product)
    style_html = f'<style id="product-brand-palette" type="text/css">\n{css}</style>'
    soup = BeautifulSoup(html or "", "html.parser")
    for old in list(soup.find_all("style", id="product-brand-palette")):
        old.decompose()
    fragment = BeautifulSoup(style_html, "html.parser")
    tag = fragment.find("style")
    if tag is None:
        return str(soup)
    # Prefer before <article>; otherwise prepend to document
    article = soup.find("article")
    if article is not None:
        article.insert_before(tag)
    elif soup.contents:
        soup.insert(0, tag)
    else:
        soup.append(tag)
    return str(soup)


def _parse_internal_links(raw: Any) -> list[dict[str, str]]:
    if not raw:
        return list(DEFAULT_INTERNAL_LINKS)
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except json.JSONDecodeError:
            return list(DEFAULT_INTERNAL_LINKS)
    if isinstance(raw, list):
        out: list[dict[str, str]] = []
        for item in raw:
            if isinstance(item, dict) and item.get("url"):
                out.append(
                    {
                        "label": str(item.get("label") or item["url"]),
                        "url": str(item["url"]),
                    }
                )
        return out or list(DEFAULT_INTERNAL_LINKS)
    return list(DEFAULT_INTERNAL_LINKS)


def internal_links_tuples(product: Product | None) -> list[tuple[str, str]]:
    links = _parse_internal_links(product.internal_links_json if product else None)
    return [(l["label"], l["url"]) for l in links]


def product_domain(product: Product | None) -> str:
    if not product or not product.website_url:
        return "hyperpark.io"
    host = urlparse(product.website_url).netloc.lower()
    return host.removeprefix("www.")


def blog_base_url(product: Product | None) -> str:
    base = (
        (product.website_url if product else None) or "https://hyperthings.ai"
    ).rstrip("/")
    return f"{base}/blog"


def company_label(product: Product | None) -> str:
    if not product:
        return "HyperPark"
    return product.company_name or product.name


def product_display_name(product: Product | None) -> str:
    if not product:
        return "Smart Parking"
    return product.name


def get_product(db: Session, product_id: int | None) -> Product | None:
    if product_id:
        return db.query(Product).filter(Product.id == product_id, Product.is_active.is_(True)).first()
    return (
        db.query(Product)
        .filter(Product.is_default.is_(True), Product.is_active.is_(True))
        .first()
        or db.query(Product).filter(Product.is_active.is_(True)).order_by(Product.id).first()
    )


def get_product_by_id(db: Session, product_id: int) -> Product | None:
    return db.query(Product).filter(Product.id == product_id).first()


def extract_pdf_text(pdf_path: Path) -> str:
    if not pdf_path.exists():
        return ""
    try:
        from pypdf import PdfReader

        reader = PdfReader(str(pdf_path))
        chunks: list[str] = []
        for page in reader.pages[:40]:
            text = page.extract_text() or ""
            if text.strip():
                chunks.append(text.strip())
        return "\n\n".join(chunks)[:12000]
    except Exception as exc:
        logger.warning(f"PDF text extraction failed for {pdf_path}: {exc}")
        return ""


def get_pdf_knowledge(product: Product | None) -> str:
    if not product:
        return ""
    from app.services.product_assets import pdfs_from_product

    chunks: list[str] = []
    for entry in pdfs_from_product(product):
        text = (entry.get("extracted_text") or "").strip()
        if not text and entry.get("filename"):
            path = product_storage_dir(product.id) / entry["filename"]
            text = extract_pdf_text(path)
        if text:
            name = entry.get("original_name") or entry.get("filename") or "PDF"
            chunks.append(f"[Document: {name}]\n{text}")
    if chunks:
        return "\n\n---\n\n".join(chunks)[:16000]
    if product.pdf_extracted_text:
        return product.pdf_extracted_text.strip()
    if product.pdf_filename:
        path = product_storage_dir(product.id) / product.pdf_filename
        return extract_pdf_text(path)
    return ""


def build_cmo_system_prompt(product: Product | None) -> str:
    company = company_label(product)
    website = (
        (product.website_url if product else None) or "https://hyperpark.io"
    ).rstrip("/")
    description = (
        (product.description if product else None)
        or "an enterprise smart parking and urban mobility SaaS platform"
    ).strip()
    brand = (
        (product.brand_context if product else None) or DEFAULT_BRAND_CONTEXT
    ).strip()
    pdf_block = ""
    pdf_text = get_pdf_knowledge(product)
    if pdf_text:
        pdf_block = f"\n\nPRODUCT KNOWLEDGE BASE (from uploaded PDF — use for accuracy):\n{pdf_text[:8000]}"

    return f"""You are the Chief Marketing Officer for {company} ({website}),
{description}.

{brand}
{pdf_block}

Generate SEO-driven blog topics tailored to this product's enterprise pain points.
Topics must be actionable, data-driven, and differentiated from generic industry content.
When asked for grouped topics, follow the user's JSON schema exactly (industry_keywords, competitor_urls, rss_feeds).

Return ONLY valid JSON (no markdown fences) matching the schema requested in the user message."""


def build_seo_system_prompt(product: Product | None) -> str:
    from app.services.blog_format import build_blog_format_rules

    company = company_label(product)
    website = (
        (product.website_url if product else None) or "https://hyperpark.io"
    ).rstrip("/")
    blog_url = blog_base_url(product)
    palette_block = format_brand_palette_prompt(product)
    format_rules = build_blog_format_rules(get_core_brand_colors(get_brand_palette(product)))

    return f"""You are {company}'s senior SEO content strategist. Generate enterprise-grade blog content 
for {website}.

STRICT TECHNICAL SEO RULES (MUST FOLLOW):
1. URL Slug: lowercase, hyphenated, primary keyword included, NO dates
2. Title Tag: HARDCODED clickbait style — 55–60 chars, curiosity + stakes + primary keyword,
   content-true (never bland "X Guide 2024"); og_title must match
3. Meta Description: 140–160 characters, CTA verb + primary keyword + curiosity hook
4. H1: exactly ONE, mirrors the clickbait title_tag, keyword near the start
5. Article order: JSON-LD scripts → <article> → H1 → hero img → TOC → intro (100–150 words) →
   body H2/H3 → mid-body table+chart → conclusion H2 → CTA section (ALWAYS last)
6. Image alt: describes the specific article visual metaphor (not generic parking). Hero attrs required.
7. Schema: Article JSON-LD in <script type="application/ld+json"> at the VERY TOP of html_content
   (NEVER include FAQPage JSON-LD — FAQ is added only via the dashboard Add FAQ button)
8. Reading time: word count ÷ 200 WPM, format "X min read"
9. Semantic HTML only — no markdown fences in output
10. Return ONLY valid JSON
11. NEVER place intro, TOC, or body content above the hero image — hero is always immediately under H1
12. NEVER include an FAQ section, <h2 id="faq">, or FAQPage schema — even if feedback mentions FAQ
13. Hero scene and title MUST match THIS article's topic every time (dynamic per post)
14. TOPIC LOCK (ALL PRODUCTS): write ONLY the locked topic/command for the entire article —
    never pivot mid-post into generic product fluff or a different subject

{palette_block}

{format_rules}

Return ONLY valid JSON (no markdown fences):
{{
  "slug": "...",
  "title_tag": "...",
  "meta_description": "...",
  "reading_time": "X min read",
  "primary_keyword": "...",
  "hero_image_alt": "...",
  "canonical_url": "{blog_url}/{{slug}}",
  "og_title": "...",
  "og_description": "...",
  "html_content": "<script type=\\"application/ld+json\\">...</script><article>...</article>"
}}"""


def build_external_sources_block(product: Product | None) -> str:
    from app.utils.link_sanitizer import verified_external_sources, verified_internal_links

    from app.services.blog_format import AUTHORITATIVE_EXTERNAL_SOURCES, BACKLINK_HARD_RULES

    company = company_label(product)
    # HARD RULE: only offer LIVE sources to the model — never dead whitelist entries.
    live_external = verified_external_sources(list(AUTHORITATIVE_EXTERNAL_SOURCES))
    live_internal = verified_internal_links(internal_links_tuples(product))
    # Internal CTAs must still appear even if some product pages fail the probe
    if not live_internal:
        live_internal = internal_links_tuples(product)

    lines = [
        BACKLINK_HARD_RULES.strip(),
        "",
        "APPROVED EXTERNAL SOURCES (LIVE only — use 2+ INLINE next to related claims):",
    ]
    if live_external:
        for label, url in live_external:
            lines.append(f"- {label}: {url}")
    else:
        lines.append(
            "- (No live external sources available right now — do NOT invent URLs; "
            "write claims without hyperlinks until sources are restored.)"
        )
    lines.append(f"\nAPPROVED {company.upper()} INTERNAL LINKS:")
    for label, url in live_internal:
        lines.append(f"- {label}: {url}")
    return "\n".join(lines)


def build_cta_block(product: Product | None, topic: str) -> str:
    company = company_label(product)
    links = internal_links_tuples(product)
    demo = links[0] if links else ("Book a Live Demo", "https://hyperpark.io/demo")
    secondary = links[1] if len(links) > 1 else ("Learn more", (product.website_url if product else "https://hyperpark.io"))
    colors = get_core_brand_colors(get_brand_palette(product))
    band = f"background:linear-gradient(135deg,{colors['navy']},{colors['primary']});"
    button = (
        f"display:inline-block;margin-top:0.65rem;border-radius:0.5rem;"
        f"background:{colors['cta']};color:#fff;padding:0.6rem 1.1rem;"
        f"font-weight:600;text-decoration:none;"
    )
    return f"""<section id="cta" class="blog-cta" style="{band}color:#fff;">
  <h2>Ready to get started?</h2>
  <p>See how {company} helps organizations deploy {topic} with measurable ROI.</p>
  <ul>
    <li>Enterprise-grade deployment and integration</li>
    <li>Measurable outcomes and audit-ready reporting</li>
    <li>Faster time-to-value with proven playbooks</li>
  </ul>
  <p>
    <a href="{demo[1]}" class="cta-button" style="{button}">{demo[0]}</a>
    <span aria-hidden="true"> · </span>
    <a href="{secondary[1]}" style="color:#fff;">{secondary[0]}</a>
  </p>
</section>"""


def product_to_dict(product: Product) -> dict[str, Any]:
    from app.services.product_assets import (
        pdfs_from_product,
        schedules_from_product,
    )

    schedules = schedules_from_product(product)
    pdfs = pdfs_from_product(product)
    return {
        "id": product.id,
        "name": product.name,
        "slug": getattr(product, "slug", None) or None,
        "company_name": product.company_name,
        "website_url": product.website_url,
        "description": product.description,
        "brand_context": product.brand_context,
        "brand_palette": get_brand_palette(product),
        "internal_links": _parse_internal_links(product.internal_links_json),
        "google_sheet_url": getattr(product, "google_sheet_url", None) or "",
        "pdf_filename": product.pdf_filename,
        "has_pdf": bool(pdfs),
        "pdfs": [
            {
                "id": p["id"],
                "filename": p["filename"],
                "original_name": p.get("original_name") or p["filename"],
            }
            for p in pdfs
        ],
        "is_default": product.is_default,
        "is_active": product.is_active,
        "cron_day_of_week": product.cron_day_of_week or "mon",
        "cron_hour": int(product.cron_hour if product.cron_hour is not None else 9),
        "cron_minute": int(product.cron_minute if product.cron_minute is not None else 0),
        "cron_timezone": product.cron_timezone or "Asia/Kolkata",
        "schedule_enabled": bool(product.schedule_enabled),
        "discovery_schedules": schedules,
        "content_archetype": _product_content_archetype(product),
        "topic_selection_mode": _product_topic_mode(product),
        "created_at": product.created_at.isoformat() if product.created_at else None,
    }


def _product_topic_mode(product: Product) -> str:
    mode = (getattr(product, "topic_selection_mode", None) or "manual").strip().lower()
    return mode if mode in ("manual", "auto", "hybrid") else "manual"


def _product_content_archetype(product: Product) -> str:
    from app.services.content_archetypes import normalize_archetype

    return normalize_archetype(getattr(product, "content_archetype", None))
