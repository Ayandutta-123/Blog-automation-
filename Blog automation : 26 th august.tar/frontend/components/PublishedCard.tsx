"use client";

import { useState } from "react";
import {
  CalendarClock,
  Download,
  Eye,
  Hash,
  ImageIcon,
  RefreshCw,
} from "lucide-react";
import { api, BlogPostSummary } from "@/lib/api";
import { downloadPublishedHtml, downloadPublishedImage } from "@/lib/blogDownload";
import { formatDateTime, getPostTitle } from "@/lib/status";
import Button from "@/components/ui/Button";
import { cn } from "@/lib/cn";
import { useToast } from "@/contexts/ToastContext";

export default function PublishedCard({
  post,
  onOpen,
  onRepublished,
}: {
  post: BlogPostSummary;
  onOpen: () => void;
  onRepublished?: () => void;
}) {
  const title = getPostTitle(post);
  const when = post.published_at || post.created_at;
  const [downloading, setDownloading] = useState<"html" | "image" | null>(null);
  const [republishing, setRepublishing] = useState(false);
  const [imgFailed, setImgFailed] = useState(false);
  const { success, error: toastError } = useToast();

  async function handleDownloadHtml(e: React.MouseEvent) {
    e.stopPropagation();
    setDownloading("html");
    try {
      const res = await api.getReviewPost(post.id);
      await downloadPublishedHtml({ post: res.post });
    } catch (err) {
      alert(String(err));
    } finally {
      setDownloading(null);
    }
  }

  async function handleDownloadImage(e: React.MouseEvent) {
    e.stopPropagation();
    if (!post.slug) {
      alert("No hero image for this post.");
      return;
    }
    setDownloading("image");
    try {
      await downloadPublishedImage(post.slug);
    } catch (err) {
      alert(String(err));
    } finally {
      setDownloading(null);
    }
  }

  async function handleRepublish(e: React.MouseEvent) {
    e.stopPropagation();
    if (republishing) return;
    const ok = window.confirm(
      `Republish “${title}”?\n\nThis re-uploads to every destination set for this product (MinIO and/or WordPress). If a WordPress post was deleted, clicking Republish creates it again. Serial stays the same.`
    );
    if (!ok) return;
    setRepublishing(true);
    try {
      const res = await api.republishPost(post.id);
      success("Republished", res.message || "Blog was pushed live again.");
      onRepublished?.();
    } catch (err) {
      const msg = String(err);
      if (/override_allowed|word count/i.test(msg)) {
        const force = window.confirm(
          `${msg}\n\nForce republish with word-count override?`
        );
        if (force) {
          try {
            const res = await api.republishPost(post.id, {
              override_word_count: true,
            });
            success("Republished", res.message || "Blog was pushed live again.");
            onRepublished?.();
            return;
          } catch (err2) {
            toastError("Republish failed", String(err2));
            return;
          }
        }
      }
      toastError("Republish failed", msg);
    } finally {
      setRepublishing(false);
    }
  }

  return (
    <article
      className={cn(
        "group w-full overflow-hidden rounded-2xl border border-emerald-200/80 bg-white text-left shadow-soft",
        "transition-all duration-200 hover:-translate-y-0.5 hover:border-emerald-300 hover:shadow-elevated"
      )}
    >
      <button type="button" onClick={onOpen} className="w-full p-3 text-left">
        <div className="mb-2.5 flex items-start justify-between gap-2">
          <span className="inline-flex items-center gap-1 rounded-lg bg-emerald-50 px-2 py-1 font-mono text-[11px] font-bold text-emerald-800 ring-1 ring-emerald-100">
            <Hash className="h-3 w-3" />
            {post.publish_serial != null ? post.publish_serial : "—"}
          </span>
          <span className="rounded-md bg-emerald-50 px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-emerald-700">
            Live
          </span>
        </div>

        <h3 className="line-clamp-3 font-display text-[15px] font-bold leading-snug tracking-tight text-hyper-navy">
          {title}
        </h3>

        <p className="mt-2 flex items-start gap-1.5 text-xs font-medium text-slate-600">
          <CalendarClock className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" />
          <span>{formatDateTime(when)}</span>
        </p>

        {post.reading_time ? (
          <p className="mt-1 text-[11px] text-text-muted">{post.reading_time}</p>
        ) : null}

        {post.slug && !imgFailed ? (
          <div className="relative mt-3 overflow-hidden rounded-xl bg-hyper-navy/5 ring-1 ring-black/[0.04]">
            <img
              src={api.imageUrl(post.slug)}
              alt=""
              className="aspect-[16/9] w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
              onError={() => setImgFailed(true)}
            />
          </div>
        ) : (
          <div className="mt-3 flex aspect-[16/9] items-center justify-center rounded-xl bg-surface-2 text-text-muted">
            <ImageIcon className="h-6 w-6" />
          </div>
        )}

        <span className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-hyper-primary group-hover:text-hyper-orange">
          <Eye className="h-3.5 w-3.5" />
          View full blog
        </span>
      </button>

      <div className="flex flex-wrap gap-1.5 border-t border-hyper-border/70 bg-surface-1/50 px-2.5 py-2">
        <Button
          type="button"
          variant="orange"
          size="sm"
          className="h-8 flex-1 px-2 text-[11px]"
          disabled={!!downloading || republishing}
          loading={republishing}
          onClick={handleRepublish}
          title="Re-upload to MinIO / WordPress if the remote copy was deleted"
        >
          {republishing ? null : <RefreshCw className="h-3 w-3" />}
          Republish
        </Button>
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="h-8 flex-1 px-2 text-[11px]"
          disabled={!!downloading || republishing}
          loading={downloading === "html"}
          onClick={handleDownloadHtml}
        >
          {downloading !== "html" && <Download className="h-3 w-3" />}
          HTML
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="h-8 flex-1 px-2 text-[11px]"
          disabled={!post.slug || !!downloading || republishing}
          loading={downloading === "image"}
          onClick={handleDownloadImage}
        >
          {downloading !== "image" && <ImageIcon className="h-3 w-3" />}
          Image
        </Button>
      </div>
    </article>
  );
}
