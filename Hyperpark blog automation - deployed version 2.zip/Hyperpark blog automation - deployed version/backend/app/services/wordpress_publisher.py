"""WordPress REST API publisher — per-product credentials.

Many hosts (nginx/CGI) strip the Authorization header, so Application Password
Basic-auth never reaches WordPress (always `rest_not_logged_in`). This module:

1. Tries REST Basic auth (Application Password) first
2. Falls back to cookie login (normal WordPress password) + REST nonce
"""

from __future__ import annotations

import base64
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urljoin, urlparse

import httpx
from loguru import logger
from sqlalchemy.orm import Session

from app.models import Product


class WordPressError(Exception):
    pass


def _normalize_site_url(raw: str) -> str:
    value = (raw or "").strip()
    if not value:
        raise WordPressError("WordPress site URL is required")
    if not value.startswith(("http://", "https://")):
        value = f"https://{value}"
    value = re.sub(r"/wp-admin/?.*$", "", value, flags=re.I)
    value = re.sub(r"/wp-login\.php.*$", "", value, flags=re.I)
    value = value.rstrip("/")
    parsed = urlparse(value)
    if not parsed.netloc:
        raise WordPressError(f"Invalid WordPress site URL: {raw}")
    return f"{parsed.scheme}://{parsed.netloc}"


def get_wordpress_config(product: Product) -> dict[str, Any]:
    raw = getattr(product, "wordpress_json", None) or {}
    return dict(raw) if isinstance(raw, dict) else {}


def wordpress_configured(product: Product) -> bool:
    cfg = get_wordpress_config(product)
    return bool(
        cfg.get("site_url")
        and cfg.get("username")
        and cfg.get("app_password")
        and cfg.get("connected")
    )


def wordpress_public_status(product: Product) -> dict[str, Any]:
    cfg = get_wordpress_config(product)
    connected = wordpress_configured(product)
    return {
        "product_id": product.id,
        "product_name": product.name,
        "connected": connected,
        "site_url": cfg.get("site_url") or None,
        "username": cfg.get("username") or None,
        "display_name": cfg.get("display_name") or None,
        "user_id": cfg.get("user_id"),
        "connected_at": cfg.get("connected_at"),
        "auto_publish": bool(cfg.get("auto_publish", True)),
        "post_status": cfg.get("post_status")
        or ("publish" if cfg.get("auto_publish", True) else "draft"),
        "has_password": bool(cfg.get("app_password")),
        "auth_mode": cfg.get("auth_mode") or None,
    }


def _clean_password(password: str) -> str:
    # Application passwords are often shown with spaces — strip for Basic auth
    return re.sub(r"\s+", "", password or "")


def _basic_auth_header(username: str, password: str) -> dict[str, str]:
    token = base64.b64encode(
        f"{username}:{_clean_password(password)}".encode("utf-8")
    ).decode("ascii")
    return {"Authorization": f"Basic {token}"}


def _api_base(site_url: str) -> str:
    return f"{_normalize_site_url(site_url)}/wp-json/wp/v2/"


def _parse_login_error(html: str) -> str:
    m = re.search(
        r'id=["\']login_error["\'][^>]*>([\s\S]*?)</div>',
        html or "",
        flags=re.I,
    )
    if not m:
        return ""
    text = re.sub(r"<[^>]+>", " ", m.group(1))
    text = re.sub(r"\s+", " ", text).strip()
    return text[:300]


def _extract_rest_nonce(html: str) -> Optional[str]:
    patterns = [
        r'wpApiSettings\s*=\s*\{[^}]*"nonce"\s*:\s*"([a-zA-Z0-9]+)"',
        r'"nonce"\s*:\s*"([a-zA-Z0-9]+)"[^}]*"root"\s*:\s*"[^"]*wp-json',
        r'createNonce\([\'"]wp_rest[\'"]\)\s*,\s*[\'"]([a-zA-Z0-9]+)[\'"]',
        r'wp\.apiFetch\.createNonceMiddleware\(\s*[\'"]([a-zA-Z0-9]+)[\'"]\s*\)',
        r'restNonce["\']?\s*[:=]\s*["\']([a-zA-Z0-9]+)["\']',
        r'X-WP-Nonce["\']?\s*[:=]\s*["\']([a-zA-Z0-9]+)["\']',
    ]
    for pat in patterns:
        m = re.search(pat, html or "", flags=re.I)
        if m:
            return m.group(1)
    return None


def _cookie_login(client: httpx.Client, site_url: str, username: str, password: str) -> str:
    """Log in via wp-login.php. Returns wp_rest nonce for authenticated REST calls."""
    login_url = f"{site_url}/wp-login.php"
    client.cookies.set("wordpress_test_cookie", "WP Cookie check")
    client.get(login_url, headers={"Accept": "text/html"})

    # Try raw password first (normal login), then spaced-stripped (app password pasted)
    candidates = []
    raw = (password or "").strip()
    cleaned = _clean_password(password)
    if raw:
        candidates.append(raw)
    if cleaned and cleaned != raw:
        candidates.append(cleaned)

    last_error = ""
    for pwd in candidates:
        resp = client.post(
            login_url,
            data={
                "log": username,
                "pwd": pwd,
                "rememberme": "forever",
                "wp-submit": "Log In",
                "redirect_to": f"{site_url}/wp-admin/",
                "testcookie": "1",
            },
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Referer": login_url,
                "Accept": "text/html,application/xhtml+xml",
            },
        )
        cookie_names = [k.lower() for k in client.cookies.keys()]
        logged_in = any(
            n.startswith("wordpress_logged_in") or n.startswith("wordpress_sec")
            for n in cookie_names
        )
        if logged_in or ("/wp-admin" in str(resp.url) and resp.status_code < 400):
            # Fetch nonce from wp-admin (or profile)
            admin = client.get(
                f"{site_url}/wp-admin/",
                headers={"Accept": "text/html"},
            )
            nonce = _extract_rest_nonce(admin.text)
            if not nonce:
                # Some installs expose it on the post editor bootstrap page
                alt = client.get(
                    f"{site_url}/wp-admin/post-new.php",
                    headers={"Accept": "text/html"},
                )
                nonce = _extract_rest_nonce(alt.text)
            if not nonce:
                # Last resort: users/me with cookies alone (GET often works)
                me = client.get(
                    f"{site_url}/wp-json/wp/v2/users/me",
                    params={"context": "edit"},
                    headers={"Accept": "application/json"},
                )
                if me.status_code < 400:
                    return ""
                raise WordPressError(
                    "Logged into WordPress, but could not obtain a REST API nonce. "
                    "Open wp-admin once in a browser, or ask hosting to pass through "
                    "the Authorization header for Application Passwords."
                )
            return nonce

        last_error = _parse_login_error(resp.text) or last_error

    raise WordPressError(
        last_error
        or (
            "WordPress cookie login failed. Use your normal wp-admin username/password "
            "(or an Application Password if your host supports API Basic auth)."
        )
    )


def _try_basic_auth_me(
    client: httpx.Client, site_url: str, username: str, password: str
) -> Optional[dict[str, Any]]:
    headers = {
        **_basic_auth_header(username, password),
        "Accept": "application/json",
    }
    # Also try with spaces kept (some hosts expect the displayed form)
    variants = [
        headers,
        {
            "Authorization": "Basic "
            + base64.b64encode(f"{username}:{password.strip()}".encode()).decode(),
            "Accept": "application/json",
        },
    ]
    for hdr in variants:
        me = client.get(
            f"{site_url}/wp-json/wp/v2/users/me",
            headers=hdr,
            params={"context": "edit"},
        )
        if me.status_code < 400:
            return {"user": me.json(), "headers": hdr, "mode": "basic"}
        try:
            code = me.json().get("code")
        except Exception:
            code = None
        # rest_not_logged_in ⇒ Authorization never reached PHP
        if code and code not in ("rest_not_logged_in",):
            # Wrong password / disabled — stop and report
            msg = me.json().get("message") or code
            raise WordPressError(f"WordPress Basic auth rejected: {msg}")
    return None


def _try_cookie_auth_me(
    client: httpx.Client, site_url: str, username: str, password: str
) -> dict[str, Any]:
    nonce = _cookie_login(client, site_url, username, password)
    headers: dict[str, str] = {"Accept": "application/json"}
    if nonce:
        headers["X-WP-Nonce"] = nonce
    me = client.get(
        f"{site_url}/wp-json/wp/v2/users/me",
        headers=headers,
        params={"context": "edit"},
    )
    if me.status_code >= 400:
        raise WordPressError(
            f"WordPress cookie session could not call the REST API "
            f"(HTTP {me.status_code}): {(me.text or '')[:240]}"
        )
    return {"user": me.json(), "headers": headers, "mode": "cookie", "nonce": nonce}


def authenticate_wordpress(
    *,
    site_url: str,
    username: str,
    password: str,
    client: Optional[httpx.Client] = None,
) -> dict[str, Any]:
    """
    Authenticate and return {site_url, username, user, mode, headers, client_owned}.
    Caller must close client if client_owned is True / if we created it.
    """
    site = _normalize_site_url(site_url)
    user = (username or "").strip()
    if not user or not (password or "").strip():
        raise WordPressError("Username and password are required")

    owns_client = client is None
    client = client or httpx.Client(
        timeout=httpx.Timeout(30.0, connect=12.0),
        follow_redirects=True,
    )
    try:
        # 1) Application Password / Basic auth
        basic = _try_basic_auth_me(client, site, user, password)
        if basic:
            return {
                "site_url": site,
                "username": user,
                "user": basic["user"],
                "mode": "basic",
                "headers": basic["headers"],
                "client": client,
                "owns_client": owns_client,
            }

        # 2) Cookie login fallback (host strips Authorization header)
        logger.warning(
            "WordPress Basic auth ignored at {} (Authorization likely stripped) — "
            "trying cookie login",
            site,
        )
        cookie = _try_cookie_auth_me(client, site, user, password)
        return {
            "site_url": site,
            "username": user,
            "user": cookie["user"],
            "mode": "cookie",
            "headers": cookie["headers"],
            "client": client,
            "owns_client": owns_client,
        }
    except Exception:
        if owns_client:
            client.close()
        raise


def test_wordpress_connection(
    *,
    site_url: str,
    username: str,
    app_password: str,
) -> dict[str, Any]:
    """Verify credentials (Basic auth, then cookie login fallback)."""
    auth = None
    try:
        auth = authenticate_wordpress(
            site_url=site_url,
            username=username,
            password=app_password,
        )
        data = auth["user"]
        return {
            "ok": True,
            "site_url": auth["site_url"],
            "username": username.strip(),
            "user_id": data.get("id"),
            "display_name": data.get("name") or data.get("slug") or username,
            "roles": data.get("roles") or [],
            "auth_mode": auth["mode"],
        }
    except WordPressError:
        raise
    except httpx.HTTPError as exc:
        raise WordPressError(f"Could not reach WordPress site: {exc}") from exc
    finally:
        if auth and auth.get("owns_client") and auth.get("client"):
            auth["client"].close()


def save_wordpress_credentials(
    db: Session,
    product: Product,
    *,
    site_url: str,
    username: str,
    app_password: str,
    auto_publish: bool = True,
    post_status: Optional[str] = None,
) -> dict[str, Any]:
    """Validate credentials, then store on the product (password never returned to clients)."""
    from sqlalchemy.orm.attributes import flag_modified

    probe = test_wordpress_connection(
        site_url=site_url,
        username=username,
        app_password=app_password,
    )
    status = (post_status or ("publish" if auto_publish else "draft")).strip().lower()
    if status not in ("publish", "draft", "pending", "private"):
        status = "publish" if auto_publish else "draft"

    product.wordpress_json = {
        "site_url": probe["site_url"],
        "username": username.strip(),
        "app_password": app_password.strip(),
        "connected": True,
        "connected_at": datetime.now(timezone.utc).isoformat(),
        "user_id": probe.get("user_id"),
        "display_name": probe.get("display_name"),
        "auto_publish": bool(auto_publish),
        "post_status": status,
        "auth_mode": probe.get("auth_mode"),
    }
    flag_modified(product, "wordpress_json")
    db.commit()
    db.refresh(product)
    logger.info(
        "WordPress connected for product #{} ({}) → {} via {}",
        product.id,
        product.name,
        probe["site_url"],
        probe.get("auth_mode"),
    )
    return wordpress_public_status(product)


def disconnect_wordpress(db: Session, product: Product) -> dict[str, Any]:
    from sqlalchemy.orm.attributes import flag_modified

    product.wordpress_json = None
    flag_modified(product, "wordpress_json")
    db.commit()
    db.refresh(product)
    logger.info("WordPress disconnected for product #{}", product.id)
    return wordpress_public_status(product)


def _extract_body_html(html: str) -> str:
    text = html or ""
    m = re.search(r"<body[^>]*>([\s\S]*)</body>", text, flags=re.I)
    if m:
        text = m.group(1)
    return text.strip()


def _upload_featured_image(
    client: httpx.Client,
    *,
    base: str,
    headers: dict[str, str],
    image_path: Path,
    title: str,
) -> Optional[int]:
    if not image_path.is_file():
        return None
    data = image_path.read_bytes()
    if not data:
        return None
    suffix = image_path.suffix.lower() or ".webp"
    mime = {
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
        ".webp": "image/webp",
        ".gif": "image/gif",
    }.get(suffix, "application/octet-stream")
    filename = image_path.name
    media_headers = {
        **headers,
        "Content-Disposition": f'attachment; filename="{filename}"',
        "Content-Type": mime,
    }
    resp = client.post(
        urljoin(base, "media"),
        headers=media_headers,
        content=data,
        params={"title": title[:120]},
    )
    if resp.status_code >= 400:
        logger.warning(
            "WordPress media upload failed: {} {}", resp.status_code, resp.text[:200]
        )
        return None
    media = resp.json()
    mid = media.get("id")
    return int(mid) if mid else None


def publish_post_to_wordpress(
    *,
    product: Product,
    title: str,
    content_html: str,
    slug: str,
    excerpt: str = "",
    status: Optional[str] = None,
    featured_image_path: Optional[Path] = None,
) -> dict[str, Any]:
    """Create a WordPress post via REST API (Basic or cookie session)."""
    if not wordpress_configured(product):
        raise WordPressError("WordPress is not connected for this product")

    cfg = get_wordpress_config(product)
    site_url = cfg["site_url"]
    username = cfg["username"]
    password = cfg["app_password"]
    post_status = (status or cfg.get("post_status") or "publish").strip().lower()
    if post_status not in ("publish", "draft", "pending", "private"):
        post_status = "publish"

    base = _api_base(site_url)
    body = {
        "title": title or slug,
        "content": _extract_body_html(content_html),
        "status": post_status,
        "slug": slug,
        "excerpt": excerpt or "",
    }

    auth = None
    try:
        auth = authenticate_wordpress(
            site_url=site_url,
            username=username,
            password=password,
        )
        client: httpx.Client = auth["client"]
        headers = {
            **auth["headers"],
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

        if featured_image_path:
            media_id = _upload_featured_image(
                client,
                base=base,
                headers={k: v for k, v in headers.items() if k != "Content-Type"},
                image_path=Path(featured_image_path),
                title=title or slug,
            )
            if media_id:
                body["featured_media"] = media_id

        resp = client.post(urljoin(base, "posts"), headers=headers, json=body)
        if resp.status_code in (401, 403):
            raise WordPressError(
                "WordPress rejected credentials while publishing. "
                "Reconnect under Settings → Integrations → WordPress."
            )
        if resp.status_code >= 400:
            raise WordPressError(
                f"WordPress publish failed (HTTP {resp.status_code}): {(resp.text or '')[:400]}"
            )
        data = resp.json()
    except WordPressError:
        raise
    except httpx.HTTPError as exc:
        raise WordPressError(f"WordPress publish request failed: {exc}") from exc
    finally:
        if auth and auth.get("owns_client") and auth.get("client"):
            auth["client"].close()

    link = data.get("link") or data.get("guid", {}).get("rendered")
    result = {
        "id": data.get("id"),
        "link": link,
        "status": data.get("status") or post_status,
        "slug": data.get("slug") or slug,
        "site_url": site_url,
        "auth_mode": auth.get("mode") if auth else None,
    }
    logger.info(
        "Published to WordPress for product #{}: {} → {} ({})",
        product.id,
        result.get("id"),
        link,
        result.get("auth_mode"),
    )
    return result
