"""Minimal brand+layout CSS for published HTML documents (Python-side)."""

from __future__ import annotations

from typing import Any

from app.services.product_context import brand_palette_css_block


def blog_prose_css_for_product(product: Any = None) -> str:
    brand = brand_palette_css_block(product)
    return f"""
{brand}
*, *::before, *::after {{ box-sizing: border-box; }}
html {{ -webkit-text-size-adjust: 100%; }}
body {{ margin: 0; font-family: system-ui, -apple-system, sans-serif; color: #0f172a; background: #fff; }}
.blog-page {{ width: 100%; min-height: 100vh; }}
.prose-blog {{
  width: 100%;
  max-width: min(80rem, 100%);
  margin: 0 auto;
  padding: clamp(1.5rem, 4vw, 3.25rem) clamp(1rem, 5vw, 4rem);
}}
.prose-blog .blog-hero-image {{
  width: 100%;
  height: clamp(200px, 30vw, 360px);
  max-height: 360px;
  object-fit: cover;
  border-radius: 0.75rem;
  display: block;
}}
.prose-blog a {{ color: var(--hyper-link, #1d4ed8); font-weight: 600; }}
""".strip()
