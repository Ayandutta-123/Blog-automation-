# HyperPark Autonomous Blog & HITL Automation Engine

Enterprise SEO blog automation system for [HyperPark](https://hyperpark.io/) with dual-channel Human-in-the-Loop review gates (dashboard + MS Teams).

## Architecture

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
│  Next.js UI     │────▶│  FastAPI Backend │────▶│  SQLite DB      │
│  (localhost:3000)│     │  (localhost:8000)│     │  scraper_settings│
└─────────────────┘     └────────┬─────────┘     │  blog_posts      │
                                 │                └─────────────────┘
                    ┌────────────┼────────────┐
                    ▼            ▼            ▼
              Tavily API    Claude 3.5    Fal.ai Flux
              Playwright    Sonnet        (WebP images)
                    │            │            │
                    └────────────┼────────────┘
                                 ▼
                    ┌────────────────────────┐
                    │  MS Teams Webhooks     │
                    │  Excel Ledger (xlsx)   │
                    │  HTML + WebP Storage   │
                    └────────────────────────┘
```

## Workflow Phases

1. **Discovery** — Weekly cron (Mon 09:00) or manual trigger scrapes Tavily + competitor blogs, synthesizes 4 topics via Claude
2. **HITL Gate 1** — Select topic via `/topics` dashboard or Teams Adaptive Card
3. **Generation** — Parallel Claude content + Fal.ai hero image (WebP 1200×630)
4. **HITL Gate 2** — Review preview at `/review` with SEO metrics sidebar; approve/redo/abort
5. **Publish** — Write HTML, append Excel ledger, notify Teams

## Quick Start

### Backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
playwright install chromium
cp .env.example .env        # Add your API keys
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Frontend

```bash
cd frontend
npm install
cp .env.local.example .env.local
npm run dev
```

Open http://localhost:3000

## Docker Compose (Postgres)

Postgres data and uploaded files survive container rebuilds via named volumes (`postgres_data`, `uploads_data`).

```bash
cp .env.docker.example .env   # set DASHBOARD_PASSWORD and POSTGRES_PASSWORD
docker compose up -d --build
```

Open http://localhost:8080

Local `uvicorn` / `npm run dev` still use SQLite. Compose always points the app at Postgres:

`postgresql://hyperpark:…@postgres:5432/hyperpark`

## Environment Variables

| Variable | Description |
|----------|-------------|
| `TAVILY_API_KEY` | Tavily search API key |
| `ANTHROPIC_API_KEY` | Anthropic Claude API key |
| `FAL_KEY` | Fal.ai API key for image generation |
| `TEAMS_WEBHOOK_URL` | MS Teams Incoming Webhook URL |
| `STORAGE_ROOT` | Local storage root (default: `./storage`) |
| `FRONTEND_URL` | Dashboard URL for Teams card links |
| `PUBLIC_BASE_URL` | Public API URL for image serving |

## Storage Layout

```
storage/
├── blog_images/{slug}.webp
├── blogs/
│   ├── html/{slug}.html
│   └── metadata.xlsx
├── hyperpark_blog.db
└── logs/hyperpark_blog.log
```

For production, set paths to `/mnt/storage/...` in `.env`.

## Teams Integration (Cloudflare Tunnel)

Route Teams webhook button clicks to your local FastAPI:

```bash
cloudflared tunnel --url http://localhost:8000
```

Configure Adaptive Card `Action.Submit` to POST to:
- `/api/teams/webhook` — unified handler
- `/api/teams/topic-select` — topic selection
- `/api/teams/approve` — approve/redo actions

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/settings` | List scraper settings |
| POST | `/api/settings` | Add keyword/URL |
| GET | `/api/topics/pending` | Posts awaiting topic selection |
| POST | `/api/topics/{id}/select` | Select topic |
| GET | `/api/review/{id}` | Full review with SEO metrics |
| POST | `/api/review/{id}/approve` | Publish to ledger |
| POST | `/api/review/{id}/redo` | Regenerate with feedback |
| POST | `/api/discovery/trigger` | Manual discovery run |

## Brand Colors

- Primary Blue: `#252a61`
- Navy: `#1b1f4a` / `#0a0349`
- Red: `#c1262a`
- Orange: `#ff6002`
