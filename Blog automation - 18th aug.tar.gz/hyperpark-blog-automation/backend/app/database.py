from collections.abc import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.config import settings


def _is_sqlite() -> bool:
    return (settings.database_url or "").startswith("sqlite")


def _engine_kwargs() -> dict:
    kwargs: dict = {"pool_pre_ping": True}
    if _is_sqlite():
        kwargs["connect_args"] = {"check_same_thread": False}
    return kwargs


engine = create_engine(settings.database_url, **_engine_kwargs())
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    pass


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def run_sqlite_migrations() -> None:
    """Lightweight column migrations for existing SQLite databases."""
    from sqlalchemy import text

    with engine.connect() as conn:
        rows = conn.execute(text("PRAGMA table_info(blog_posts)")).fetchall()
        columns = {row[1] for row in rows}
        if "content_archetype" not in columns:
            conn.execute(
                text(
                    "ALTER TABLE blog_posts ADD COLUMN content_archetype VARCHAR(32) DEFAULT 'tutorial'"
                )
            )
            conn.commit()

        rows = conn.execute(text("PRAGMA table_info(blog_posts)")).fetchall()
        columns = {row[1] for row in rows}
        if "product_id" not in columns:
            conn.execute(text("ALTER TABLE blog_posts ADD COLUMN product_id INTEGER"))
            conn.commit()

        rows = conn.execute(text("PRAGMA table_info(blog_posts)")).fetchall()
        columns = {row[1] for row in rows}
        for col in ("discovery_snapshot_json", "research_pack_json"):
            if col not in columns:
                conn.execute(text(f"ALTER TABLE blog_posts ADD COLUMN {col} JSON"))
                conn.commit()

        rows = conn.execute(text("PRAGMA table_info(scraper_settings)")).fetchall()
        columns = {row[1] for row in rows}
        if "product_id" not in columns:
            conn.execute(text("ALTER TABLE scraper_settings ADD COLUMN product_id INTEGER"))
            conn.commit()

        rows = conn.execute(text("PRAGMA table_info(products)")).fetchall()
        columns = {row[1] for row in rows}
        product_schedule_columns = {
            "cron_day_of_week": "VARCHAR(8) DEFAULT 'mon'",
            "cron_hour": "INTEGER DEFAULT 9",
            "cron_minute": "INTEGER DEFAULT 0",
            "cron_timezone": "VARCHAR(64) DEFAULT 'Asia/Kolkata'",
            "schedule_enabled": "BOOLEAN DEFAULT 1",
        }
        for col, col_type in product_schedule_columns.items():
            if col not in columns:
                conn.execute(text(f"ALTER TABLE products ADD COLUMN {col} {col_type}"))
                conn.commit()

        rows = conn.execute(text("PRAGMA table_info(products)")).fetchall()
        columns = {row[1] for row in rows}
        if "brand_palette_json" not in columns:
            conn.execute(text("ALTER TABLE products ADD COLUMN brand_palette_json JSON"))
            conn.commit()

        rows = conn.execute(text("PRAGMA table_info(products)")).fetchall()
        columns = {row[1] for row in rows}
        if "content_archetype" not in columns:
            conn.execute(
                text("ALTER TABLE products ADD COLUMN content_archetype VARCHAR(32) DEFAULT 'tutorial'")
            )
            conn.commit()

        rows = conn.execute(text("PRAGMA table_info(products)")).fetchall()
        columns = {row[1] for row in rows}
        if "discovery_schedules_json" not in columns:
            conn.execute(text("ALTER TABLE products ADD COLUMN discovery_schedules_json JSON"))
            conn.commit()

        rows = conn.execute(text("PRAGMA table_info(products)")).fetchall()
        columns = {row[1] for row in rows}
        if "pdfs_json" not in columns:
            conn.execute(text("ALTER TABLE products ADD COLUMN pdfs_json JSON"))
            conn.commit()

        rows = conn.execute(text("PRAGMA table_info(products)")).fetchall()
        columns = {row[1] for row in rows}
        if "topic_selection_mode" not in columns:
            conn.execute(
                text(
                    "ALTER TABLE products ADD COLUMN topic_selection_mode "
                    "VARCHAR(16) DEFAULT 'manual'"
                )
            )
            conn.commit()

        rows = conn.execute(text("PRAGMA table_info(products)")).fetchall()
        columns = {row[1] for row in rows}
        if "wordpress_json" not in columns:
            conn.execute(text("ALTER TABLE products ADD COLUMN wordpress_json JSON"))
            conn.commit()

        rows = conn.execute(text("PRAGMA table_info(products)")).fetchall()
        columns = {row[1] for row in rows}
        if "google_json" not in columns:
            conn.execute(text("ALTER TABLE products ADD COLUMN google_json JSON"))
            conn.commit()

        rows = conn.execute(text("PRAGMA table_info(products)")).fetchall()
        columns = {row[1] for row in rows}
        if "slug" not in columns:
            conn.execute(text("ALTER TABLE products ADD COLUMN slug VARCHAR(128)"))
            conn.commit()

        rows = conn.execute(text("PRAGMA table_info(products)")).fetchall()
        columns = {row[1] for row in rows}
        if "google_sheet_url" not in columns:
            conn.execute(text("ALTER TABLE products ADD COLUMN google_sheet_url VARCHAR(1024)"))
            conn.commit()

        rows = conn.execute(text("PRAGMA table_info(products)")).fetchall()
        columns = {row[1] for row in rows}
        if "auto_include_charts" not in columns:
            conn.execute(
                text(
                    "ALTER TABLE products ADD COLUMN auto_include_charts BOOLEAN DEFAULT 1"
                )
            )
            conn.commit()

        rows = conn.execute(text("PRAGMA table_info(products)")).fetchall()
        columns = {row[1] for row in rows}
        if "publish_destination" not in columns:
            conn.execute(
                text(
                    "ALTER TABLE products ADD COLUMN publish_destination "
                    "VARCHAR(16) DEFAULT 'both'"
                )
            )
            conn.commit()

        rows = conn.execute(text("PRAGMA table_info(blog_posts)")).fetchall()
        columns = {row[1] for row in rows}
        if "published_at" not in columns:
            conn.execute(text("ALTER TABLE blog_posts ADD COLUMN published_at DATETIME"))
            conn.commit()
        if "publish_serial" not in columns:
            conn.execute(text("ALTER TABLE blog_posts ADD COLUMN publish_serial INTEGER"))
            conn.commit()

        rows = conn.execute(text("PRAGMA table_info(blog_posts)")).fetchall()
        columns = {row[1] for row in rows}
        if "include_charts" not in columns:
            conn.execute(text("ALTER TABLE blog_posts ADD COLUMN include_charts BOOLEAN"))
            conn.commit()

        # Persistent notifications table (create_all also covers new DBs)
        conn.execute(
            text(
                """
                CREATE TABLE IF NOT EXISTS app_notifications (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    type VARCHAR(64) NOT NULL,
                    title VARCHAR(256) NOT NULL,
                    message TEXT NOT NULL DEFAULT '',
                    severity VARCHAR(32) DEFAULT 'action',
                    post_id INTEGER,
                    created_at DATETIME
                )
                """
            )
        )
        conn.commit()

        _backfill_publish_metadata(conn)


def run_schema_migrations() -> None:
    """Apply additive schema updates. SQLite needs PRAGMA; Postgres uses create_all + ALTER."""
    if _is_sqlite():
        run_sqlite_migrations()
        return
    _run_postgres_migrations()


def _run_postgres_migrations() -> None:
    from sqlalchemy import text

    with engine.connect() as conn:
        def columns(table: str) -> set[str]:
            rows = conn.execute(
                text(
                    """
                    SELECT column_name
                    FROM information_schema.columns
                    WHERE table_schema = 'public' AND table_name = :table
                    """
                ),
                {"table": table},
            )
            return {row[0] for row in rows}

        def add_column(table: str, col: str, col_type: str) -> None:
            if col not in columns(table):
                conn.execute(text(f'ALTER TABLE {table} ADD COLUMN {col} {col_type}'))
                conn.commit()

        add_column("blog_posts", "content_archetype", "VARCHAR(32) DEFAULT 'tutorial'")
        add_column("blog_posts", "product_id", "INTEGER")
        add_column("blog_posts", "discovery_snapshot_json", "JSON")
        add_column("blog_posts", "research_pack_json", "JSON")
        add_column("blog_posts", "published_at", "TIMESTAMP")
        add_column("blog_posts", "publish_serial", "INTEGER")
        add_column("blog_posts", "include_charts", "BOOLEAN")
        add_column("scraper_settings", "product_id", "INTEGER")
        add_column("products", "cron_day_of_week", "VARCHAR(8) DEFAULT 'mon'")
        add_column("products", "cron_hour", "INTEGER DEFAULT 9")
        add_column("products", "cron_minute", "INTEGER DEFAULT 0")
        add_column("products", "cron_timezone", "VARCHAR(64) DEFAULT 'Asia/Kolkata'")
        add_column("products", "schedule_enabled", "BOOLEAN DEFAULT TRUE")
        add_column("products", "brand_palette_json", "JSON")
        add_column("products", "content_archetype", "VARCHAR(32) DEFAULT 'tutorial'")
        add_column("products", "discovery_schedules_json", "JSON")
        add_column("products", "pdfs_json", "JSON")
        add_column("products", "topic_selection_mode", "VARCHAR(16) DEFAULT 'manual'")
        add_column("products", "wordpress_json", "JSON")
        add_column("products", "google_json", "JSON")
        add_column("products", "slug", "VARCHAR(128)")
        add_column("products", "google_sheet_url", "VARCHAR(1024)")
        add_column("products", "auto_include_charts", "BOOLEAN DEFAULT TRUE")
        add_column("products", "publish_destination", "VARCHAR(16) DEFAULT 'both'")
        _backfill_publish_metadata(conn)


def _backfill_publish_metadata(conn) -> None:
    """Fill published_at / publish_serial for existing PUBLISHED rows."""
    from datetime import datetime
    from sqlalchemy import text

    rows = conn.execute(
        text(
            """
            SELECT id, product_id, created_at, feedback_history, published_at, publish_serial
            FROM blog_posts
            WHERE status = 'PUBLISHED'
            ORDER BY id ASC
            """
        )
    ).fetchall()
    if not rows:
        return

    # Group by product for serial assignment
    by_product: dict = {}
    updates = []
    for row in rows:
        post_id, product_id, created_at, feedback_history, published_at, publish_serial = row
        ts = published_at
        if not ts and feedback_history:
            try:
                import json

                history = (
                    json.loads(feedback_history)
                    if isinstance(feedback_history, str)
                    else feedback_history
                )
                for entry in reversed(history or []):
                    if isinstance(entry, dict) and entry.get("type") == "published":
                        raw = entry.get("timestamp")
                        if raw:
                            ts = datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
                            break
            except Exception:
                ts = None
        if not ts:
            ts = created_at
        updates.append((post_id, product_id, ts, publish_serial))

    for post_id, product_id, ts, existing_serial in updates:
        key = product_id if product_id is not None else 0
        by_product.setdefault(key, []).append((post_id, ts, existing_serial))

    for _pid, items in by_product.items():
        items.sort(key=lambda x: (str(x[1] or ""), x[0]))
        for idx, (post_id, ts, existing_serial) in enumerate(items, start=1):
            conn.execute(
                text(
                    """
                    UPDATE blog_posts
                    SET published_at = COALESCE(published_at, :ts),
                        publish_serial = COALESCE(publish_serial, :serial)
                    WHERE id = :id
                    """
                ),
                {"ts": ts, "serial": existing_serial or idx, "id": post_id},
            )
    conn.commit()
