from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Product
from app.services.content_archetypes import list_archetypes_for_api, normalize_archetype
from app.services.product_context import (
    DEFAULT_BRAND_CONTEXT,
    DEFAULT_BRAND_PALETTE,
    DEFAULT_INTERNAL_LINKS,
    extract_pdf_text,
    get_product,
    normalize_brand_palette,
    product_storage_dir,
    product_to_dict,
)
from app.services.product_assets import (
    normalize_schedules,
    pdfs_from_product,
    sync_legacy_cron_fields,
    sync_legacy_pdf_fields,
)
from app.services.notification_service import emit_notification
from app.services.runtime_config import get_config_value, set_config_value
from app.services.scheduler import reschedule_all_discovery_jobs
import uuid

router = APIRouter(prefix="/api/products", tags=["products"])


class InternalLink(BaseModel):
    label: str
    url: str


class BrandColorEntry(BaseModel):
    id: str = Field(..., min_length=1, max_length=32)
    label: str = Field(default="Custom", max_length=64)
    hex: str = Field(..., pattern=r"^#[0-9A-Fa-f]{6}$")


class BrandPalette(BaseModel):
    primary: str = Field(default="#252a61", pattern=r"^#[0-9A-Fa-f]{6}$")
    navy: str = Field(default="#1b1f4a", pattern=r"^#[0-9A-Fa-f]{6}$")
    accent: str = Field(default="#ff6002", pattern=r"^#[0-9A-Fa-f]{6}$")
    cta: str = Field(default="#c1262a", pattern=r"^#[0-9A-Fa-f]{6}$")
    link: str = Field(default="#1d4ed8", pattern=r"^#[0-9A-Fa-f]{6}$")
    custom: List[BrandColorEntry] = Field(default_factory=list)


class ScheduleSlot(BaseModel):
    id: Optional[str] = None
    day_of_week: str = "mon"
    hour: int = Field(default=9, ge=0, le=23)
    minute: int = Field(default=0, ge=0, le=59)


class ProductPdfInfo(BaseModel):
    id: str
    filename: str
    original_name: str


class ProductCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=128)
    company_name: str = Field(default="HyperPark", max_length=128)
    website_url: str = Field(..., min_length=4, max_length=512)
    description: str = ""
    brand_context: str = ""
    brand_palette: BrandPalette = Field(default_factory=BrandPalette)
    internal_links: List[InternalLink] = Field(default_factory=list)
    is_default: bool = False
    cron_day_of_week: str = "mon"
    cron_hour: int = Field(default=9, ge=0, le=23)
    cron_minute: int = Field(default=0, ge=0, le=59)
    cron_timezone: str = "Asia/Kolkata"
    schedule_enabled: bool = True
    discovery_schedules: Optional[List[ScheduleSlot]] = None
    topic_selection_mode: str = Field(default="manual", pattern="^(manual|auto|hybrid)$")
    auto_include_charts: bool = True
    publish_destination: str = Field(default="both", pattern="^(wordpress|minio|both)$")
    google_sheet_url: str = ""


class ProductUpdate(BaseModel):
    name: Optional[str] = None
    company_name: Optional[str] = None
    website_url: Optional[str] = None
    description: Optional[str] = None
    brand_context: Optional[str] = None
    brand_palette: Optional[BrandPalette] = None
    internal_links: Optional[List[InternalLink]] = None
    is_default: Optional[bool] = None
    is_active: Optional[bool] = None
    cron_day_of_week: Optional[str] = None
    cron_hour: Optional[int] = Field(default=None, ge=0, le=23)
    cron_minute: Optional[int] = Field(default=None, ge=0, le=59)
    cron_timezone: Optional[str] = None
    schedule_enabled: Optional[bool] = None
    discovery_schedules: Optional[List[ScheduleSlot]] = None
    content_archetype: Optional[str] = None
    topic_selection_mode: Optional[str] = Field(default=None, pattern="^(manual|auto|hybrid)$")
    auto_include_charts: Optional[bool] = None
    publish_destination: Optional[str] = Field(
        default=None, pattern="^(wordpress|minio|both)$"
    )
    google_sheet_url: Optional[str] = None


class ProductResponse(BaseModel):
    id: int
    name: str
    slug: Optional[str] = None
    company_name: str
    website_url: str
    description: Optional[str] = None
    brand_context: Optional[str] = None
    brand_palette: BrandPalette = Field(default_factory=BrandPalette)
    internal_links: List[InternalLink] = Field(default_factory=list)
    publish_destination: str = "both"
    google_sheet_url: str = ""
    pdf_filename: Optional[str] = None
    has_pdf: bool = False
    pdfs: List[ProductPdfInfo] = Field(default_factory=list)
    is_default: bool = False
    is_active: bool = True
    cron_day_of_week: str = "mon"
    cron_hour: int = 9
    cron_minute: int = 0
    cron_timezone: str = "Asia/Kolkata"
    schedule_enabled: bool = True
    discovery_schedules: List[ScheduleSlot] = Field(default_factory=list)
    content_archetype: str = "tutorial"
    topic_selection_mode: str = "manual"
    auto_include_charts: bool = True
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class ActiveProductResponse(BaseModel):
    product_id: int
    product: ProductResponse


class ProductContentArchetypeUpdate(BaseModel):
    archetype: str = Field(..., min_length=1, max_length=32)


class ProductContentArchetypeResponse(BaseModel):
    archetype: str
    archetypes: list[dict]


def _to_response(product: Product) -> ProductResponse:
    data = product_to_dict(product)
    return ProductResponse(**data)


@router.get("", response_model=List[ProductResponse])
def list_products(db: Session = Depends(get_db)):
    products = (
        db.query(Product)
        .filter(Product.is_active.is_(True))
        .order_by(Product.is_default.desc(), Product.name)
        .all()
    )
    return [_to_response(p) for p in products]


@router.get("/active", response_model=ActiveProductResponse)
def get_active_product(db: Session = Depends(get_db)):
    raw = get_config_value("active_product_id")
    product_id = int(raw) if raw and str(raw).isdigit() else None
    product = get_product(db, product_id)
    if not product:
        raise HTTPException(status_code=404, detail="No active product configured")
    return ActiveProductResponse(product_id=product.id, product=_to_response(product))


@router.put("/active", response_model=ActiveProductResponse)
def set_active_product(product_id: int, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id, Product.is_active.is_(True)).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    set_config_value("active_product_id", str(product_id), db)
    return ActiveProductResponse(product_id=product.id, product=_to_response(product))


@router.get("/{product_id}/content-archetype", response_model=ProductContentArchetypeResponse)
def read_product_content_archetype(product_id: int, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id, Product.is_active.is_(True)).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return ProductContentArchetypeResponse(
        archetype=normalize_archetype(product.content_archetype),
        archetypes=list_archetypes_for_api(),
    )


@router.put("/{product_id}/content-archetype", response_model=ProductContentArchetypeResponse)
def write_product_content_archetype(
    product_id: int,
    payload: ProductContentArchetypeUpdate,
    db: Session = Depends(get_db),
):
    product = db.query(Product).filter(Product.id == product_id, Product.is_active.is_(True)).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    product.content_archetype = normalize_archetype(payload.archetype)
    db.commit()
    db.refresh(product)
    return ProductContentArchetypeResponse(
        archetype=normalize_archetype(product.content_archetype),
        archetypes=list_archetypes_for_api(),
    )


@router.post("", response_model=ProductResponse, status_code=201)
def create_product(payload: ProductCreate, db: Session = Depends(get_db)):
    if payload.is_default:
        db.query(Product).update({Product.is_default: False})

    links = [l.model_dump() for l in payload.internal_links] if payload.internal_links else []
    schedules = normalize_schedules(
        [s.model_dump() for s in payload.discovery_schedules]
        if payload.discovery_schedules is not None
        else None,
        fallback_day=payload.cron_day_of_week,
        fallback_hour=payload.cron_hour,
        fallback_minute=payload.cron_minute,
    )
    mode = (payload.topic_selection_mode or "manual").strip().lower()
    if mode not in ("manual", "auto", "hybrid"):
        mode = "manual"
    # Manual products never auto-run on a schedule
    schedule_enabled = False if mode == "manual" else payload.schedule_enabled

    sheet_url = (payload.google_sheet_url or "").strip() or None
    dest = (payload.publish_destination or "both").strip().lower()
    if dest not in ("wordpress", "minio", "both"):
        dest = "both"
    product = Product(
        name=payload.name.strip(),
        company_name=payload.company_name.strip() or "HyperPark",
        website_url=payload.website_url.strip().rstrip("/"),
        description=payload.description.strip() or None,
        brand_context=payload.brand_context.strip() or None,
        brand_palette_json=normalize_brand_palette(payload.brand_palette.model_dump()),
        internal_links_json=links or None,
        publish_destination=dest,
        google_sheet_url=sheet_url,
        is_default=payload.is_default,
        is_active=True,
        cron_timezone=(payload.cron_timezone or "Asia/Kolkata").strip(),
        schedule_enabled=schedule_enabled,
        discovery_schedules_json=schedules,
        topic_selection_mode=mode,
        auto_include_charts=bool(payload.auto_include_charts),
    )
    sync_legacy_cron_fields(product, schedules)
    db.add(product)
    db.flush()
    from app.services.slugs import allocate_product_slug

    product.slug = allocate_product_slug(db, product.name, exclude_product_id=product.id)
    db.commit()
    db.refresh(product)
    product_storage_dir(product.id)
    reschedule_all_discovery_jobs()
    emit_notification(
        db,
        type="published",
        title=f'Product "{product.name}" created',
        message="Product line is ready. Schedule and scrapers can be configured next.",
        severity="success",
    )
    return _to_response(product)


@router.patch("/{product_id}", response_model=ProductResponse)
def update_product(
    product_id: int,
    payload: ProductUpdate,
    db: Session = Depends(get_db),
):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    if payload.is_default is True:
        db.query(Product).filter(Product.id != product_id).update({Product.is_default: False})
        product.is_default = True
    elif payload.is_default is False:
        product.is_default = False

    if payload.name is not None:
        product.name = payload.name.strip()
    if payload.company_name is not None:
        product.company_name = payload.company_name.strip()
    if payload.website_url is not None:
        product.website_url = payload.website_url.strip().rstrip("/")
    if payload.description is not None:
        product.description = payload.description.strip() or None
    if payload.brand_context is not None:
        product.brand_context = payload.brand_context.strip() or None
    if payload.brand_palette is not None:
        product.brand_palette_json = normalize_brand_palette(payload.brand_palette.model_dump())
    if payload.internal_links is not None:
        product.internal_links_json = [l.model_dump() for l in payload.internal_links]
    if payload.google_sheet_url is not None:
        product.google_sheet_url = payload.google_sheet_url.strip() or None
    if payload.publish_destination is not None:
        dest = payload.publish_destination.strip().lower()
        if dest in ("wordpress", "minio", "both"):
            product.publish_destination = dest
    if payload.is_active is not None:
        product.is_active = payload.is_active

    schedule_changed = False
    if payload.discovery_schedules is not None:
        schedules = normalize_schedules(
            [s.model_dump() for s in payload.discovery_schedules],
            fallback_day=payload.cron_day_of_week or product.cron_day_of_week or "mon",
            fallback_hour=payload.cron_hour
            if payload.cron_hour is not None
            else (product.cron_hour if product.cron_hour is not None else 9),
            fallback_minute=payload.cron_minute
            if payload.cron_minute is not None
            else (product.cron_minute if product.cron_minute is not None else 0),
        )
        product.discovery_schedules_json = schedules
        sync_legacy_cron_fields(product, schedules)
        schedule_changed = True
    else:
        if payload.cron_day_of_week is not None:
            product.cron_day_of_week = payload.cron_day_of_week.strip().lower()[:3]
            schedule_changed = True
        if payload.cron_hour is not None:
            product.cron_hour = payload.cron_hour
            schedule_changed = True
        if payload.cron_minute is not None:
            product.cron_minute = payload.cron_minute
            schedule_changed = True
        if schedule_changed:
            schedules = normalize_schedules(
                product.discovery_schedules_json,
                fallback_day=product.cron_day_of_week or "mon",
                fallback_hour=product.cron_hour if product.cron_hour is not None else 9,
                fallback_minute=product.cron_minute if product.cron_minute is not None else 0,
            )
            # keep first slot in sync with legacy edits when schedules weren't sent
            if schedules:
                schedules[0] = {
                    **schedules[0],
                    "day_of_week": product.cron_day_of_week or "mon",
                    "hour": int(product.cron_hour if product.cron_hour is not None else 9),
                    "minute": int(product.cron_minute if product.cron_minute is not None else 0),
                }
                product.discovery_schedules_json = schedules

    if payload.cron_timezone is not None:
        product.cron_timezone = payload.cron_timezone.strip() or "Asia/Kolkata"
        schedule_changed = True
    if payload.schedule_enabled is not None:
        product.schedule_enabled = payload.schedule_enabled
        schedule_changed = True
    if payload.content_archetype is not None:
        product.content_archetype = normalize_archetype(payload.content_archetype)
    if payload.topic_selection_mode is not None:
        mode = payload.topic_selection_mode.strip().lower()
        if mode not in ("manual", "auto", "hybrid"):
            raise HTTPException(status_code=400, detail="Invalid topic_selection_mode")
        product.topic_selection_mode = mode
        if mode == "manual":
            # Entirely manual — never fire cron for this product
            product.schedule_enabled = False
        schedule_changed = True
    if payload.auto_include_charts is not None:
        product.auto_include_charts = bool(payload.auto_include_charts)

    # Manual always wins over any schedule toggle
    if (product.topic_selection_mode or "manual") == "manual" and product.schedule_enabled:
        product.schedule_enabled = False
        schedule_changed = True

    db.commit()
    db.refresh(product)
    if schedule_changed or payload.is_active is not None or payload.topic_selection_mode is not None:
        reschedule_all_discovery_jobs()
    emit_notification(
        db,
        type="published",
        title=f'"{product.name}" saved',
        message="Product settings and schedule were updated.",
        severity="success",
    )
    return _to_response(product)


@router.delete("/{product_id}", status_code=204)
def delete_product(product_id: int, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    product.is_active = False
    db.commit()
    reschedule_all_discovery_jobs()


@router.post("/{product_id}/pdf", response_model=ProductResponse)
async def upload_product_pdf(
    product_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    original = (file.filename or "product.pdf").replace("/", "_").replace("\\", "_")
    if not original.lower().endswith(".pdf"):
        original = f"{original}.pdf"
    doc_id = uuid.uuid4().hex[:12]
    stored_name = f"{doc_id}_{original}"

    dest_dir = product_storage_dir(product_id)
    dest_path = dest_dir / stored_name
    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="Empty file")
    dest_path.write_bytes(content)

    extracted = extract_pdf_text(dest_path)
    pdfs = pdfs_from_product(product)
    pdfs.append(
        {
            "id": doc_id,
            "filename": stored_name,
            "original_name": original,
            "extracted_text": extracted or "",
        }
    )
    product.pdfs_json = pdfs
    sync_legacy_pdf_fields(product, pdfs)
    db.commit()
    db.refresh(product)
    emit_notification(
        db,
        type="published",
        title=f'PDF added to "{product.name}"',
        message=original,
        severity="success",
    )
    return _to_response(product)


@router.delete("/{product_id}/pdf", response_model=ProductResponse)
def delete_product_pdf(
    product_id: int,
    pdf_id: Optional[str] = None,
    db: Session = Depends(get_db),
):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    pdfs = pdfs_from_product(product)
    if not pdfs:
        product.pdf_filename = None
        product.pdf_extracted_text = None
        product.pdfs_json = []
        db.commit()
        db.refresh(product)
        return _to_response(product)

    if pdf_id:
        keep: list[dict] = []
        removed = None
        for entry in pdfs:
            if entry["id"] == pdf_id:
                removed = entry
            else:
                keep.append(entry)
        if removed:
            path = product_storage_dir(product_id) / removed["filename"]
            if path.exists():
                path.unlink(missing_ok=True)
        pdfs = keep
    else:
        # Delete all (legacy behavior)
        for entry in pdfs:
            path = product_storage_dir(product_id) / entry["filename"]
            if path.exists():
                path.unlink(missing_ok=True)
        pdfs = []

    product.pdfs_json = pdfs
    sync_legacy_pdf_fields(product, pdfs)
    db.commit()
    db.refresh(product)
    emit_notification(
        db,
        type="published",
        title=f'PDF removed from "{product.name}"',
        message="Product knowledge base updated.",
        severity="success",
    )
    return _to_response(product)


def seed_default_product(db: Session) -> Product:
    existing = db.query(Product).first()
    if existing:
        return existing

    product = Product(
        name="Smart Parking",
        company_name="HyperPark",
        website_url="https://hyperpark.io",
        description="Enterprise smart parking and urban mobility SaaS platform",
        brand_context=DEFAULT_BRAND_CONTEXT,
        brand_palette_json=normalize_brand_palette({**DEFAULT_BRAND_PALETTE, "custom": []}),
        internal_links_json=DEFAULT_INTERNAL_LINKS,
        is_default=True,
        is_active=True,
        topic_selection_mode="manual",
        auto_include_charts=True,
        schedule_enabled=False,
    )
    db.add(product)
    db.flush()
    from app.services.slugs import allocate_product_slug

    product.slug = allocate_product_slug(db, product.name, exclude_product_id=product.id)
    db.commit()
    db.refresh(product)
    product_storage_dir(product.id)
    set_config_value("active_product_id", str(product.id), db)
    return product
