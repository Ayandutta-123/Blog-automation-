import { apiBase } from "@/lib/apiBase";

const API_BASE = apiBase();

function authHeaders(): Record<string, string> {
  if (typeof window === "undefined") return {};
  const token = localStorage.getItem("blog_automation_token");
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function fetchApi<T>(path: string, options?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...authHeaders(),
        ...options?.headers,
      },
    });
  } catch (e) {
    const why = e instanceof Error ? e.message : String(e);
    throw new Error(
      `Cannot reach API at ${API_BASE} (${why}). Is the backend running on port 8000?`
    );
  }
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    const detail = err.detail;
    let message: string;
    if (typeof detail === "string") {
      message = detail;
    } else if (detail && typeof detail === "object" && "message" in detail) {
      message = String((detail as { message: string }).message);
      const failures = (detail as { failures?: string[] }).failures;
      if (failures?.length) message += `: ${failures.join("; ")}`;
    } else if (Array.isArray(detail)) {
      message = detail.map((d: { msg?: string }) => d.msg).filter(Boolean).join(", ");
    } else {
      message = `API error ${res.status}`;
    }
    throw new Error(message || `API error ${res.status}`);
  }
  if (res.status === 204) return undefined as T;
  return res.json();
}

async function fetchFormApi<T>(path: string, formData: FormData): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    body: formData,
    headers: {
      ...authHeaders(),
    },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    const detail = err.detail;
    const message =
      typeof detail === "string"
        ? detail
        : Array.isArray(detail)
          ? detail.map((d: { msg?: string }) => d.msg).filter(Boolean).join(", ")
          : `API error ${res.status}`;
    throw new Error(message || `API error ${res.status}`);
  }
  return res.json();
}

export interface ScraperSetting {
  id: number;
  category: "INDUSTRY_KEYWORD" | "COMPETITOR_URL" | "RSS_FEED";
  value: string;
  is_active: boolean;
  added_by: string;
  product_id?: number | null;
}

export interface WordPressAccountStatus {
  product_id: number;
  product_name: string;
  connected: boolean;
  site_url?: string | null;
  username?: string | null;
  display_name?: string | null;
  user_id?: number | null;
  connected_at?: string | null;
  auto_publish?: boolean;
  post_status?: string;
  has_password?: boolean;
  auth_mode?: string | null;
}

export interface WordPressConnectPayload {
  site_url: string;
  username: string;
  app_password: string;
  auto_publish?: boolean;
  post_status?: "publish" | "draft" | "pending" | "private";
}

export interface GoogleAccountStatus {
  product_id: number;
  product_name: string;
  connected: boolean;
  blog_id?: string | null;
  blog_name?: string | null;
  blog_url?: string | null;
  connected_at?: string | null;
  is_draft?: boolean;
  has_token?: boolean;
  has_refresh_token?: boolean;
}

export interface GoogleConnectPayload {
  blog_id: string;
  access_token: string;
  refresh_token?: string;
  client_id?: string;
  client_secret?: string;
  is_draft?: boolean;
}

export interface ProductInternalLink {
  label: string;
  url: string;
}

export interface BrandColorEntry {
  id: string;
  label: string;
  hex: string;
}

export interface BrandPalette {
  primary: string;
  navy: string;
  accent: string;
  cta: string;
  link: string;
  custom: BrandColorEntry[];
}

export interface BrandPaletteBatch {
  id: string;
  name: string;
  builtin: boolean;
  colors: {
    primary: string;
    navy: string;
    accent: string;
    cta: string;
    link: string;
  };
}

export interface ProductPdf {
  id: string;
  filename: string;
  original_name: string;
}

export interface DiscoverySchedule {
  id: string;
  day_of_week: string;
  hour: number;
  minute: number;
}

export interface Product {
  id: number;
  name: string;
  slug?: string | null;
  company_name: string;
  website_url: string;
  description?: string;
  brand_context?: string;
  brand_palette: BrandPalette;
  internal_links: ProductInternalLink[];
  google_sheet_url?: string;
  publish_destination?: PublishDestination;
  pdf_filename?: string | null;
  has_pdf: boolean;
  pdfs?: ProductPdf[];
  is_default: boolean;
  is_active: boolean;
  cron_day_of_week: string;
  cron_hour: number;
  cron_minute: number;
  cron_timezone: string;
  schedule_enabled: boolean;
  discovery_schedules?: DiscoverySchedule[];
  content_archetype?: ContentArchetypeId;
  topic_selection_mode?: TopicSelectionMode;
  auto_include_charts?: boolean;
  created_at?: string;
}

export interface BlogPostSummary {
  id: number;
  created_at: string;
  published_at?: string | null;
  publish_serial?: number | null;
  status: string;
  selected_topic_title?: string;
  slug?: string;
  title_tag?: string;
  meta_description?: string;
  reading_time?: string;
  image_url?: string;
  topics_count?: number;
  comment_count?: number;
  last_error?: string;
  content_archetype?: ContentArchetypeId;
  include_charts?: boolean | null;
  product_id?: number | null;
  product_name?: string | null;
  minio_object?: string | null;
}

export type NotificationType =
  | "topic_selection"
  | "review_required"
  | "error"
  | "published";

export interface NotificationItem {
  id: string;
  type: NotificationType;
  post_id: number;
  title: string;
  message: string;
  timestamp: string;
  severity: "action" | "error" | "success";
}

export interface NotificationsResponse {
  items: NotificationItem[];
  counts: {
    total: number;
    action: number;
    error: number;
    success: number;
  };
}

export type ContentArchetypeId =
  | "quick_faq"
  | "news_update"
  | "tutorial"
  | "listicle"
  | "pillar";

export interface ContentArchetypeInfo {
  id: ContentArchetypeId;
  label: string;
  min_words: number;
  max_words: number;
  intent: string;
}

export type TopicSelectionMode = "manual" | "auto" | "hybrid";
export type PublishDestination = "wordpress" | "minio" | "both";

export interface BlogTopicItem {
  title: string;
  description: string;
  primary_keyword: string;
  source?: "industry_keywords" | "competitor_urls" | "rss_feeds";
  seo_score?: number;
  recommendation?: "strong_pick" | "good" | "moderate" | "weak";
  recommended?: boolean;
  seo_rank?: number;
  seo_signals?: {
    search_volume?: number | null;
    seo_difficulty?: number | null;
    cpc?: number | null;
    competitor_matches?: number;
    competitor_gap_score?: number;
    ubersuggest_connected?: boolean;
    source_tool?: string | null;
  };
  seo_why?: string[];
  source_links?: Array<{
    label: string;
    url: string;
    source_type?: string;
  }>;
}

export interface TopicGroupsPayload {
  version?: number;
  groups?: {
    industry_keywords?: BlogTopicItem[];
    competitor_urls?: BlogTopicItem[];
    rss_feeds?: BlogTopicItem[];
  };
  top_picks?: Array<{
    title: string;
    primary_keyword?: string;
    seo_score?: number;
    recommendation?: string;
    source?: string;
    source_links?: Array<{
      label: string;
      url: string;
      source_type?: string;
    }>;
  }>;
}

export interface BlogPostDetail extends BlogPostSummary {
  scraped_topics_json?: BlogTopicItem[] | TopicGroupsPayload | null;
  discovery_snapshot_json?: Record<string, unknown> | null;
  research_pack_json?: Record<string, unknown> | null;
  html_content?: string;
  body_text?: string;
  final_html_path?: string;
  feedback_history?: Array<{
    feedback: string;
    timestamp: string;
    type?: string;
    stage?: string;
    needs_retry?: boolean;
  }>;
}

export interface SEOMetrics {
  title_tag_length: number;
  title_tag_valid: boolean;
  meta_description_length: number;
  meta_description_valid: boolean;
  slug: string | null;
  reading_time: string | null;
  word_count: number;
  word_count_min: number;
  word_count_max: number;
  word_count_valid: boolean;
  content_archetype: ContentArchetypeId;
  content_archetype_label: string;
  has_json_ld: boolean;
  internal_links_count: number;
  external_links_count: number;
}

export interface ReviewResponse {
  post: BlogPostDetail;
  seo_metrics: SEOMetrics;
}

export interface IntegrationField {
  key: string;
  label: string;
  description: string;
  group: string;
  secret: boolean;
  is_set: boolean;
  source: string;
  is_placeholder?: boolean;
  value?: string | null;
  masked_value?: string | null;
}

export interface IntegrationsConfig {
  fields: IntegrationField[];
  groups: string[];
}

export interface UbersuggestStatus {
  connected: boolean;
  connected_at?: string | null;
  keyword_tool?: string | null;
  backlinks_tool?: string | null;
}

export interface UbersuggestTool {
  name: string;
  description?: string | null;
  input_schema?: Record<string, unknown> | null;
}

export interface KeywordVolumeMetrics {
  ok: boolean;
  keyword: string;
  search_volume?: number | null;
  cpc?: number | null;
  seo_difficulty?: number | null;
  paid_difficulty?: number | null;
  competition?: number | null;
  source_tool?: string | null;
}

export const api = {
  getSettings: (category?: string, productId?: number) =>
    fetchApi<ScraperSetting[]>(
      `/api/settings${category || productId != null ? "?" : ""}${
        category ? `category=${category}` : ""
      }${category && productId != null ? "&" : ""}${
        productId != null ? `product_id=${productId}` : ""
      }`
    ),

  createSetting: (data: {
    category: string;
    value: string;
    added_by?: string;
    product_id?: number;
  }) =>
    fetchApi<ScraperSetting>("/api/settings", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  createSettingsBulk: (data: {
    category: string;
    value: string;
    added_by?: string;
    product_id?: number;
  }) =>
    fetchApi<{
      added: ScraperSetting[];
      added_count: number;
      skipped_count: number;
      total_parsed: number;
    }>("/api/settings/bulk", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  uploadSettingsSpreadsheet: (
    file: File,
    category: string,
    productId?: number
  ) => {
    const form = new FormData();
    form.append("file", file);
    form.append("category", category);
    if (productId != null) form.append("product_id", String(productId));
    return fetchFormApi<{
      added: ScraperSetting[];
      added_count: number;
      skipped_count: number;
      total_parsed: number;
    }>("/api/settings/upload", form);
  },

  updateSetting: (
    id: number,
    data: { value?: string; is_active?: boolean }
  ) =>
    fetchApi<ScraperSetting>(`/api/settings/${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),

  deleteSetting: (id: number) =>
    fetchApi<void>(`/api/settings/${id}`, { method: "DELETE" }),

  getBrandPaletteBatches: () =>
    fetchApi<{ batches: BrandPaletteBatch[] }>("/api/brand-palettes"),

  createBrandPaletteBatch: (data: {
    name: string;
    colors: {
      primary: string;
      navy: string;
      accent: string;
      cta: string;
      link: string;
    };
  }) =>
    fetchApi<BrandPaletteBatch>("/api/brand-palettes", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  deleteBrandPaletteBatch: (id: string) =>
    fetchApi<{ batches: BrandPaletteBatch[] }>(`/api/brand-palettes/${id}`, {
      method: "DELETE",
    }),

  getIntegrations: () =>
    fetchApi<IntegrationsConfig>("/api/integrations"),

  updateIntegrations: (data: Record<string, string>) =>
    fetchApi<IntegrationsConfig>("/api/integrations", {
      method: "PUT",
      body: JSON.stringify(data),
    }),

  saveIntegrationKey: (key: string, value: string) =>
    fetchApi<IntegrationField>(`/api/integrations/${key}`, {
      method: "PUT",
      body: JSON.stringify({ value }),
    }),

  deleteIntegrationKey: (key: string) =>
    fetchApi<IntegrationField>(`/api/integrations/${key}`, {
      method: "DELETE",
    }),

  getUbersuggestStatus: () =>
    fetchApi<UbersuggestStatus>("/api/integrations/ubersuggest/status"),

  connectUbersuggest: () =>
    fetchApi<{ authorize_url: string }>("/api/integrations/ubersuggest/connect", {
      method: "POST",
    }),

  disconnectUbersuggest: () =>
    fetchApi<{ ok: boolean }>("/api/integrations/ubersuggest/disconnect", {
      method: "POST",
    }),

  getUbersuggestTools: () =>
    fetchApi<{ tools: UbersuggestTool[] }>("/api/integrations/ubersuggest/tools"),

  callUbersuggestTool: (name: string, argumentsJson: Record<string, unknown>) =>
    fetchApi<{ result: unknown }>("/api/integrations/ubersuggest/call", {
      method: "POST",
      body: JSON.stringify({ name, arguments: argumentsJson }),
    }),

  setUbersuggestMapping: (data: { keyword_tool?: string | null; backlinks_tool?: string | null }) =>
    fetchApi<UbersuggestStatus>("/api/integrations/ubersuggest/mapping", {
      method: "PUT",
      body: JSON.stringify(data),
    }),

  checkUbersuggestKeyword: (keyword: string, opts?: { language?: string; loc_id?: number }) =>
    fetchApi<KeywordVolumeMetrics>("/api/integrations/ubersuggest/keyword-check", {
      method: "POST",
      body: JSON.stringify({
        keyword,
        language: opts?.language || "en",
        loc_id: opts?.loc_id ?? 2840,
      }),
    }),

  testTeamsWebhook: (data?: { webhook_url?: string; channel_name?: string }) =>
    fetchApi<{ success: boolean; message: string }>("/api/teams/test", {
      method: "POST",
      body: JSON.stringify(data ?? {}),
    }),

  notifyReviewTeams: (postId: number) =>
    fetchApi<{ success: boolean; message: string }>(
      `/api/teams/notify-review/${postId}`,
      { method: "POST" }
    ),

  getPendingTopics: () => fetchApi<BlogPostSummary[]>("/api/topics/pending"),

  getTopicPost: (id: number) => fetchApi<BlogPostDetail>(`/api/topics/${id}`),

  selectTopic: (
    id: number,
    topicTitle: string,
    custom = false,
    contentArchetype?: ContentArchetypeId,
    includeCharts?: boolean
  ) =>
    fetchApi<{ message: string }>(`/api/topics/${id}/select`, {
      method: "POST",
      body: JSON.stringify({
        topic_title: topicTitle,
        custom,
        content_archetype: contentArchetype,
        include_charts: includeCharts,
      }),
    }),

  autoSelectTopic: (
    id: number,
    includeCharts?: boolean,
    contentArchetype?: ContentArchetypeId
  ) =>
    fetchApi<{ message: string }>(`/api/topics/${id}/auto-select`, {
      method: "POST",
      body: JSON.stringify({
        include_charts: includeCharts,
        content_archetype: contentArchetype,
      }),
    }),

  getPendingReviews: () => fetchApi<BlogPostSummary[]>("/api/review/pending"),

  getNotifications: () => fetchApi<NotificationsResponse>("/api/notifications"),

  getReviewPost: (id: number) => fetchApi<ReviewResponse>(`/api/review/${id}`),

  repairBlogFormat: (id: number) =>
    fetchApi<ReviewResponse>(`/api/review/${id}/repair-format`, {
      method: "POST",
    }),

  repairBlogCta: (id: number) =>
    fetchApi<ReviewResponse>(`/api/review/${id}/repair-cta`, {
      method: "POST",
    }),

  addBlogFaq: (id: number) =>
    fetchApi<ReviewResponse>(`/api/review/${id}/add-faq`, {
      method: "POST",
    }),

  setBlogCharts: (id: number, enabled: boolean) =>
    fetchApi<ReviewResponse>(`/api/review/${id}/charts`, {
      method: "POST",
      body: JSON.stringify({ enabled }),
    }),

  updateReviewPost: (
    id: number,
    data: {
      title_tag?: string;
      meta_description?: string;
      slug?: string;
      selected_topic_title?: string;
      body_text?: string;
    }
  ) =>
    fetchApi<ReviewResponse>(`/api/review/${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),

  uploadHeroImage: (id: number, file: File) => {
    const form = new FormData();
    form.append("file", file);
    return fetchFormApi<ReviewResponse>(`/api/review/${id}/hero-image`, form);
  },

  regenerateHeroImage: (id: number, prompt?: string) =>
    fetchApi<{ message: string }>(`/api/review/${id}/regenerate-image`, {
      method: "POST",
      body: JSON.stringify({ prompt: prompt || "" }),
    }),

  approvePost: (id: number, opts?: { override_word_count?: boolean }) =>
    fetchApi<{
      message: string;
      post_id: number;
      slug?: string;
      minio?: {
        bucket?: string;
        object_name?: string;
        url?: string;
        etag?: string;
      } | null;
      minio_error?: string | null;
      wordpress?: {
        id?: number;
        link?: string;
        status?: string;
        slug?: string;
        site_url?: string;
      } | null;
      wordpress_error?: string | null;
      google?: {
        id?: string;
        url?: string;
        status?: string;
      } | null;
      google_error?: string | null;
    }>(`/api/review/${id}/approve`, {
      method: "POST",
      body: JSON.stringify({
        override_word_count: Boolean(opts?.override_word_count),
      }),
    }),

  getWordPressAccounts: () =>
    fetchApi<WordPressAccountStatus[]>("/api/wordpress/accounts"),

  getWordPressStatus: (productId: number) =>
    fetchApi<WordPressAccountStatus>(`/api/wordpress/products/${productId}/status`),

  connectWordPress: (productId: number, data: WordPressConnectPayload) =>
    fetchApi<WordPressAccountStatus>(`/api/wordpress/products/${productId}/connect`, {
      method: "POST",
      body: JSON.stringify(data),
    }),

  testWordPress: (productId: number, data: WordPressConnectPayload) =>
    fetchApi<{
      ok: boolean;
      product_id: number;
      site_url: string;
      username: string;
      display_name?: string;
      user_id?: number;
    }>(`/api/wordpress/products/${productId}/test`, {
      method: "POST",
      body: JSON.stringify({
        site_url: data.site_url,
        username: data.username,
        app_password: data.app_password,
      }),
    }),

  logoutWordPress: (productId: number) =>
    fetchApi<WordPressAccountStatus>(`/api/wordpress/products/${productId}/logout`, {
      method: "POST",
    }),

  getGoogleAccounts: () =>
    fetchApi<GoogleAccountStatus[]>("/api/google/accounts"),

  connectGoogle: (productId: number, data: GoogleConnectPayload) =>
    fetchApi<GoogleAccountStatus>(`/api/google/products/${productId}/connect`, {
      method: "POST",
      body: JSON.stringify(data),
    }),

  testGoogle: (productId: number, data: GoogleConnectPayload) =>
    fetchApi<{
      ok: boolean;
      product_id: number;
      blog_id?: string;
      blog_name?: string;
      blog_url?: string;
    }>(`/api/google/products/${productId}/test`, {
      method: "POST",
      body: JSON.stringify({
        blog_id: data.blog_id,
        access_token: data.access_token,
        refresh_token: data.refresh_token || "",
        client_id: data.client_id || "",
        client_secret: data.client_secret || "",
      }),
    }),

  logoutGoogle: (productId: number) =>
    fetchApi<GoogleAccountStatus>(`/api/google/products/${productId}/logout`, {
      method: "POST",
    }),

  redoPost: (id: number, feedback: string) =>
    fetchApi<{ message: string }>(`/api/review/${id}/redo`, {
      method: "POST",
      body: JSON.stringify({ feedback }),
    }),

  abortPost: (id: number) =>
    fetchApi<{ message: string }>(`/api/review/${id}/abort`, {
      method: "POST",
    }),

  triggerDiscovery: (productId?: number) =>
    fetchApi<{ message: string; post_id: number }>("/api/discovery/trigger", {
      method: "POST",
      body: JSON.stringify({ product_id: productId ?? null }),
    }),

  retryDiscovery: (postId: number) =>
    fetchApi<{ message: string; post_id: number }>(
      `/api/discovery/${postId}/retry`,
      { method: "POST" }
    ),

  retryGeneration: (postId: number) =>
    fetchApi<{ message: string; post_id: number }>(
      `/api/generation/${postId}/retry`,
      { method: "POST" }
    ),

  getTopicMode: (productId?: number) =>
    fetchApi<{ mode: TopicSelectionMode; product_id?: number | null }>(
      productId
        ? `/api/workflow/topic-mode?product_id=${productId}`
        : "/api/workflow/topic-mode"
    ),

  setTopicMode: (mode: TopicSelectionMode, productId?: number) =>
    fetchApi<{ mode: TopicSelectionMode; product_id?: number | null }>(
      "/api/workflow/topic-mode",
      {
        method: "PUT",
        body: JSON.stringify({ mode, product_id: productId ?? null }),
      }
    ),

  getContentArchetype: () =>
    fetchApi<{ archetype: ContentArchetypeId; archetypes: ContentArchetypeInfo[] }>(
      "/api/workflow/content-archetype"
    ),

  setContentArchetype: (archetype: ContentArchetypeId) =>
    fetchApi<{ archetype: ContentArchetypeId; archetypes: ContentArchetypeInfo[] }>(
      "/api/workflow/content-archetype",
      { method: "PUT", body: JSON.stringify({ archetype }) }
    ),

  getProductContentArchetype: (productId: number) =>
    fetchApi<{ archetype: ContentArchetypeId; archetypes: ContentArchetypeInfo[] }>(
      `/api/products/${productId}/content-archetype`
    ),

  setProductContentArchetype: (productId: number, archetype: ContentArchetypeId) =>
    fetchApi<{ archetype: ContentArchetypeId; archetypes: ContentArchetypeInfo[] }>(
      `/api/products/${productId}/content-archetype`,
      { method: "PUT", body: JSON.stringify({ archetype }) }
    ),

  getPosts: (productId?: number, status?: string) => {
    const params = new URLSearchParams();
    if (productId != null) params.set("product_id", String(productId));
    if (status) params.set("status", status);
    const q = params.toString();
    return fetchApi<BlogPostSummary[]>(q ? `/api/posts?${q}` : "/api/posts");
  },

  getProducts: () => fetchApi<Product[]>("/api/products"),

  getActiveProduct: () =>
    fetchApi<{ product_id: number; product: Product }>("/api/products/active"),

  setActiveProduct: (productId: number) =>
    fetchApi<{ product_id: number; product: Product }>(
      `/api/products/active?product_id=${productId}`,
      { method: "PUT" }
    ),

  createProduct: (data: {
    name: string;
    company_name?: string;
    website_url: string;
    description?: string;
    brand_context?: string;
    brand_palette?: BrandPalette;
    internal_links?: ProductInternalLink[];
    google_sheet_url?: string;
    publish_destination?: PublishDestination;
    is_default?: boolean;
    cron_day_of_week?: string;
    cron_hour?: number;
    cron_minute?: number;
    cron_timezone?: string;
    schedule_enabled?: boolean;
    discovery_schedules?: DiscoverySchedule[];
    topic_selection_mode?: TopicSelectionMode;
    auto_include_charts?: boolean;
  }) =>
    fetchApi<Product>("/api/products", {
      method: "POST",
      body: JSON.stringify(data),
    }),

  updateProduct: (
    id: number,
    data: Partial<{
      name: string;
      company_name: string;
      website_url: string;
      description: string;
      brand_context: string;
      brand_palette: BrandPalette;
      internal_links: ProductInternalLink[];
      google_sheet_url: string;
      publish_destination: PublishDestination;
      is_default: boolean;
      is_active: boolean;
      cron_day_of_week: string;
      cron_hour: number;
      cron_minute: number;
      cron_timezone: string;
      schedule_enabled: boolean;
      discovery_schedules: DiscoverySchedule[];
      topic_selection_mode: TopicSelectionMode;
      auto_include_charts: boolean;
    }>
  ) =>
    fetchApi<Product>(`/api/products/${id}`, {
      method: "PATCH",
      body: JSON.stringify(data),
    }),

  deleteProduct: (id: number) =>
    fetchApi<void>(`/api/products/${id}`, { method: "DELETE" }),

  uploadProductPdf: (id: number, file: File) => {
    const form = new FormData();
    form.append("file", file);
    return fetchFormApi<Product>(`/api/products/${id}/pdf`, form);
  },

  deleteProductPdf: (id: number, pdfId?: string) =>
    fetchApi<Product>(
      `/api/products/${id}/pdf${pdfId ? `?pdf_id=${encodeURIComponent(pdfId)}` : ""}`,
      { method: "DELETE" }
    ),

  imageUrl: (slug: string, version?: number) =>
    `${API_BASE}/api/images/${slug}.webp${version ? `?v=${version}` : ""}`,

  login: (username: string, password: string) =>
    fetchApi<{ token: string; message: string }>("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ username, password }),
    }),

  logout: () =>
    fetchApi<{ message: string }>("/api/auth/logout", { method: "POST" }),

  getSession: () =>
    fetchApi<{ authenticated: boolean; username?: string | null; role?: string | null }>(
      "/api/auth/session"
    ),

  changePassword: (current_password: string, new_password: string) =>
    fetchApi<{ message: string }>("/api/auth/change-password", {
      method: "POST",
      body: JSON.stringify({ current_password, new_password }),
    }),

  createUser: (data: { username: string; password: string; role?: "admin" | "user" }) =>
    fetchApi<{ id: number; username: string; role: string; is_active: boolean }>(
      "/api/auth/users/create",
      {
        method: "POST",
        body: JSON.stringify(data),
      }
    ),
};
