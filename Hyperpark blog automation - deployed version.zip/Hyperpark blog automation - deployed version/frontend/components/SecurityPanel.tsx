"use client";

import { useState } from "react";
import { Eye, EyeOff, LogOut, Save, Shield } from "lucide-react";
import { api } from "@/lib/api";
import { useAuth } from "@/contexts/AuthContext";
import { useNotifications } from "@/contexts/NotificationContext";
import Button from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { cn } from "@/lib/cn";

function PasswordField({
  label,
  value,
  onChange,
  show,
  onToggleShow,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  show: boolean;
  onToggleShow: () => void;
  placeholder: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-text-muted">
        {label}
      </span>
      <div className="relative">
        <Input
          type={show ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="pr-10"
          autoComplete="off"
        />
        <button
          type="button"
          onClick={onToggleShow}
          className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-text-muted hover:bg-surface-1 hover:text-hyper-primary"
          aria-label={show ? "Hide password" : "Show password"}
        >
          {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </button>
      </div>
    </label>
  );
}

export default function SecurityPanel() {
  const { logout } = useAuth();
  const { notifySaved } = useNotifications();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNext, setShowNext] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(
    null
  );

  async function handleChangePassword() {
    if (next.length < 8) {
      setMessage({ type: "error", text: "New password must be at least 8 characters." });
      return;
    }
    if (next !== confirm) {
      setMessage({ type: "error", text: "New passwords do not match." });
      return;
    }
    setSaving(true);
    setMessage(null);
    try {
      const res = await api.changePassword(current, next);
      setMessage({ type: "success", text: res.message });
      setCurrent("");
      setNext("");
      setConfirm("");
      notifySaved("Password updated", res.message || "Dashboard password was changed.");
    } catch (e) {
      setMessage({
        type: "error",
        text: e instanceof Error ? e.message : "Failed to update password",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="relative overflow-hidden rounded-2xl border border-hyper-border/70 bg-[linear-gradient(135deg,#f8f9fd_0%,#ffffff_55%,#fff7f1_100%)] p-4 md:p-5">
        <div className="flex items-start gap-3.5">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-hyper-navy text-white shadow-sm">
            <Shield className="h-4 w-4" />
          </span>
          <div>
            <p className="text-sm font-semibold text-hyper-navy">Dashboard security</p>
            <p className="mt-1 max-w-2xl text-xs leading-relaxed text-text-secondary md:text-sm">
              Sign-in requires a username and password. Credentials are stored server-side only.
              Failed attempts are rate-limited. Change your password below when needed.
            </p>
          </div>
        </div>
      </div>

      {message && (
        <div
          className={cn(
            "rounded-xl border px-4 py-3 text-sm",
            message.type === "success"
              ? "border-emerald-200 bg-emerald-50 text-emerald-800"
              : "border-red-200 bg-red-50 text-red-800"
          )}
        >
          {message.text}
        </div>
      )}

      <div className="space-y-4 rounded-2xl border border-hyper-border/70 bg-[#fbfbfd] p-4 md:p-5">
        <div>
          <h3 className="text-sm font-semibold text-hyper-navy md:text-base">Change password</h3>
          <p className="mt-0.5 text-xs text-text-secondary">
            Use at least 8 characters. Username is managed by your server admin.
          </p>
        </div>
        <PasswordField
          label="Current password"
          value={current}
          onChange={setCurrent}
          show={showCurrent}
          onToggleShow={() => setShowCurrent((v) => !v)}
          placeholder="Enter current password"
        />
        <PasswordField
          label="New password"
          value={next}
          onChange={setNext}
          show={showNext}
          onToggleShow={() => setShowNext((v) => !v)}
          placeholder="At least 8 characters"
        />
        <PasswordField
          label="Confirm new password"
          value={confirm}
          onChange={setConfirm}
          show={showConfirm}
          onToggleShow={() => setShowConfirm((v) => !v)}
          placeholder="Repeat new password"
        />
        <div className="flex flex-wrap gap-2 pt-2">
          <Button
            type="button"
            variant="orange"
            onClick={handleChangePassword}
            loading={saving}
            disabled={saving || !current || !next || !confirm}
          >
            <Save className="h-4 w-4" />
            Update password
          </Button>
          <Button
            type="button"
            variant="secondary"
            onClick={() => logout().then(() => window.location.assign("/login"))}
          >
            <LogOut className="h-4 w-4" />
            Sign out
          </Button>
        </div>
      </div>
    </div>
  );
}
