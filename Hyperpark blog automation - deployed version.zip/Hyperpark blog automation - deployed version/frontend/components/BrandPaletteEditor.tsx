"use client";

import { useMemo, useState } from "react";
import {
  Check,
  Copy,
  Info,
  Palette,
  Plus,
  RotateCcw,
  Sparkles,
  Trash2,
} from "lucide-react";
import {
  BRAND_PALETTE_PRESETS,
  BRAND_PALETTE_SLOTS,
  BrandColorEntry,
  BrandPalette,
  BrandPaletteKey,
  allPaletteSwatches,
  createCustomColor,
  normalizeBrandPalette,
  normalizeHex,
} from "@/lib/brandPalette";
import Button from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { cn } from "@/lib/cn";

type Props = {
  value: BrandPalette;
  onChange: (palette: BrandPalette) => void;
  productName?: string;
};

function findMatchingPreset(palette: BrandPalette) {
  return BRAND_PALETTE_PRESETS.find((preset) =>
    BRAND_PALETTE_SLOTS.every((slot) => palette[slot.key] === preset.colors[slot.key])
  );
}

function ColorRow({
  label,
  hint,
  color,
  onChange,
  onCopy,
}: {
  label: string;
  hint: string;
  color: string;
  onChange: (hex: string) => void;
  onCopy: (hex: string) => void;
}) {
  const safeColor = normalizeHex(color) ?? "#252a61";
  const valid = Boolean(normalizeHex(color));

  return (
    <div className="group flex items-center gap-3 rounded-xl border border-transparent px-2 py-2 transition hover:border-hyper-border hover:bg-surface-1/80">
      <label
        className="relative h-10 w-10 shrink-0 cursor-pointer overflow-hidden rounded-xl shadow-sm ring-1 ring-black/10 transition group-hover:ring-hyper-primary/30"
        title={`Pick ${label.toLowerCase()} color`}
      >
        <span className="absolute inset-0" style={{ backgroundColor: safeColor }} aria-hidden />
        <input
          type="color"
          value={safeColor}
          onChange={(e) => {
            const next = normalizeHex(e.target.value);
            if (next) onChange(next);
          }}
          className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
          aria-label={`${label} color picker`}
        />
      </label>

      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium text-hyper-navy">{label}</p>
        <p className="text-[11px] text-text-muted">{hint}</p>
      </div>

      <div className="flex items-center gap-1.5">
        <Input
          value={color}
          onChange={(e) => onChange(e.target.value)}
          onBlur={(e) => {
            const next = normalizeHex(e.target.value);
            if (next) onChange(next);
          }}
          placeholder="#252a61"
          className={cn(
            "w-[108px] font-mono text-xs uppercase",
            !valid && color.trim() && "border-red-300 focus:border-red-400"
          )}
          spellCheck={false}
          aria-label={`${label} hex code`}
        />
        <button
          type="button"
          onClick={() => onCopy(safeColor)}
          className="rounded-lg p-2 text-text-muted opacity-0 transition hover:bg-surface-2 hover:text-hyper-primary group-hover:opacity-100"
          title="Copy hex"
          aria-label={`Copy ${label} hex`}
        >
          <Copy className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
}

export default function BrandPaletteEditor({ value, onChange, productName }: Props) {
  const palette = normalizeBrandPalette(value);
  const swatches = allPaletteSwatches(palette);
  const matchedPreset = useMemo(() => findMatchingPreset(palette), [palette]);
  const [copied, setCopied] = useState<string | null>(null);

  function updatePalette(next: BrandPalette) {
    onChange(normalizeBrandPalette(next));
  }

  function updateSlot(key: BrandPaletteKey, hex: string) {
    const normalized = normalizeHex(hex);
    updatePalette({
      ...palette,
      [key]: normalized ?? palette[key],
    });
  }

  function applyPreset(colors: Omit<BrandPalette, "custom">) {
    updatePalette({
      ...colors,
      custom: palette.custom,
    });
  }

  function resetToDefault() {
    applyPreset(BRAND_PALETTE_PRESETS[0].colors);
  }

  function addCustomColor() {
    updatePalette({
      ...palette,
      custom: [...palette.custom, createCustomColor(`Accent ${palette.custom.length + 1}`)],
    });
  }

  function updateCustomColor(id: string, patch: Partial<BrandColorEntry>) {
    updatePalette({
      ...palette,
      custom: palette.custom.map((entry) =>
        entry.id === id ? { ...entry, ...patch } : entry
      ),
    });
  }

  function deleteCustomColor(id: string) {
    updatePalette({
      ...palette,
      custom: palette.custom.filter((entry) => entry.id !== id),
    });
  }

  async function copyHex(hex: string) {
    try {
      await navigator.clipboard.writeText(hex);
      setCopied(hex);
      window.setTimeout(() => setCopied(null), 1500);
    } catch {
      /* ignore */
    }
  }

  return (
    <div className="space-y-6">
      {/* Live preview */}
      <div className="overflow-hidden rounded-2xl border border-hyper-primary/15 bg-gradient-to-br from-surface-0 via-surface-1 to-hyper-primary/5">
        <div className="flex h-16 sm:h-20">
          {BRAND_PALETTE_SLOTS.map((slot) => (
            <div
              key={slot.key}
              className="relative flex-1 transition-all"
              style={{ backgroundColor: palette[slot.key] }}
              title={`${slot.label}: ${palette[slot.key]}`}
            />
          ))}
          {palette.custom.map((entry) => (
            <div
              key={entry.id}
              className="flex-1 border-l border-white/20"
              style={{ backgroundColor: entry.hex }}
              title={`${entry.label}: ${entry.hex}`}
            />
          ))}
        </div>

        <div className="border-t border-hyper-border/60 bg-surface-0/80 px-4 py-4 backdrop-blur-sm sm:px-5">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="mb-1 flex flex-wrap items-center gap-2">
                <span className="inline-flex items-center gap-1.5 rounded-full bg-hyper-primary/10 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-hyper-primary">
                  <Sparkles className="h-3 w-3" />
                  Live preview
                </span>
                {matchedPreset && (
                  <span className="rounded-full bg-emerald-50 px-2.5 py-0.5 text-[10px] font-medium text-emerald-700">
                    {matchedPreset.name} palette
                  </span>
                )}
              </div>
              <p className="text-sm text-text-secondary">
                {productName
                  ? `Brand colors for ${productName} — used in AI charts, tables, CTAs, and hero images.`
                  : "Used in AI-generated charts, tables, CTAs, and hero placeholder images."}
              </p>
            </div>
          </div>

          <div className="mt-3 flex flex-wrap gap-2">
            {swatches.map((swatch) => (
              <button
                key={`${swatch.label}-${swatch.hex}`}
                type="button"
                onClick={() => copyHex(swatch.hex)}
                className="inline-flex items-center gap-2 rounded-lg border border-hyper-border bg-surface-0 px-2.5 py-1.5 text-left transition hover:border-hyper-primary/30 hover:shadow-sm"
                title="Click to copy hex"
              >
                <span
                  className="h-4 w-4 shrink-0 rounded-md ring-1 ring-black/10"
                  style={{ backgroundColor: swatch.hex }}
                />
                <span className="text-[11px] font-medium text-hyper-navy">{swatch.label}</span>
                <span className="font-mono text-[10px] uppercase text-text-muted">
                  {copied === swatch.hex ? "Copied!" : swatch.hex}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Starter palettes */}
      <section>
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h4 className="text-sm font-semibold text-hyper-navy">Starter palettes</h4>
            <p className="text-xs text-text-muted">
              One default (Navy &amp; Orange). Pick any starter, then edit every color below and save the product.
            </p>
          </div>
          <Button type="button" variant="ghost" size="sm" onClick={resetToDefault}>
            <RotateCcw className="h-3.5 w-3.5" />
            Reset to default
          </Button>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-thin">
          {BRAND_PALETTE_PRESETS.map((preset) => {
            const isActive = BRAND_PALETTE_SLOTS.every(
              (slot) => palette[slot.key] === preset.colors[slot.key]
            );
            return (
              <button
                key={preset.id}
                type="button"
                onClick={() => applyPreset(preset.colors)}
                className={cn(
                  "flex min-w-[148px] shrink-0 flex-col rounded-2xl border p-3 text-left transition-all",
                  isActive
                    ? "border-hyper-primary bg-hyper-primary/5 shadow-sm ring-2 ring-hyper-primary/20"
                    : "border-hyper-border bg-surface-0 hover:border-hyper-primary/25 hover:shadow-sm"
                )}
              >
                <div className="mb-2 flex h-7 overflow-hidden rounded-lg ring-1 ring-black/5">
                  {BRAND_PALETTE_SLOTS.map((slot) => (
                    <span
                      key={slot.key}
                      className="flex-1"
                      style={{ backgroundColor: preset.colors[slot.key] }}
                    />
                  ))}
                </div>
                <span className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-hyper-navy">
                    {preset.id === "hyperpark" ? "Default" : preset.name}
                  </span>
                  {isActive && <Check className="h-3.5 w-3.5 text-hyper-primary" />}
                </span>
                {preset.id === "hyperpark" && (
                  <span className="mt-0.5 text-[10px] text-text-muted">Navy &amp; Orange</span>
                )}
              </button>
            );
          })}
        </div>
      </section>

      {/* Fine-tune */}
      <section className="rounded-2xl border border-hyper-border bg-surface-1/30 p-3 sm:p-4">
        <div className="mb-2 flex items-center gap-2 px-2">
          <Palette className="h-4 w-4 text-hyper-primary" />
          <div>
            <h4 className="text-sm font-semibold text-hyper-navy">Fine-tune colors</h4>
            <p className="text-xs text-text-muted">
              Edit Primary, Charts, CTA, Links — saved colors apply to this product&apos;s blogs only.
            </p>
          </div>
        </div>
        <div className="divide-y divide-hyper-border/60">
          {BRAND_PALETTE_SLOTS.map((slot) => (
            <ColorRow
              key={slot.key}
              label={slot.label}
              hint={slot.description}
              color={palette[slot.key]}
              onChange={(hex) => updateSlot(slot.key, hex)}
              onCopy={copyHex}
            />
          ))}
        </div>
      </section>

      {/* Extra colors */}
      <section>
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h4 className="text-sm font-semibold text-hyper-navy">Extra colors</h4>
            <p className="text-xs text-text-muted">Optional — for charts, highlights, or accents.</p>
          </div>
          <Button type="button" variant="outline" size="sm" onClick={addCustomColor}>
            <Plus className="h-3.5 w-3.5" />
            Add color
          </Button>
        </div>

        {palette.custom.length === 0 ? (
          <button
            type="button"
            onClick={addCustomColor}
            className="flex w-full flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-hyper-border bg-surface-0/50 px-4 py-8 text-center transition hover:border-hyper-primary/40 hover:bg-hyper-primary/[0.03]"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-hyper-primary/10 text-hyper-primary">
              <Plus className="h-5 w-5" />
            </span>
            <span className="text-sm font-medium text-hyper-navy">Add an extra brand color</span>
            <span className="max-w-xs text-xs text-text-muted">
              Useful for secondary highlights in generated blog graphics.
            </span>
          </button>
        ) : (
          <div className="space-y-2">
            {palette.custom.map((entry, index) => {
              const safeColor = normalizeHex(entry.hex) ?? "#64748b";
              return (
                <div
                  key={entry.id}
                  className="flex flex-wrap items-center gap-2 rounded-xl border border-hyper-border bg-surface-0 p-3 sm:flex-nowrap"
                >
                  <span className="hidden w-6 shrink-0 text-center text-[10px] font-mono text-text-muted sm:inline">
                    {index + 1}
                  </span>
                  <label
                    className="relative h-10 w-10 shrink-0 cursor-pointer overflow-hidden rounded-xl ring-1 ring-black/10"
                    title="Pick color"
                  >
                    <span
                      className="absolute inset-0"
                      style={{ backgroundColor: safeColor }}
                      aria-hidden
                    />
                    <input
                      type="color"
                      value={safeColor}
                      onChange={(e) => {
                        const next = normalizeHex(e.target.value);
                        if (next) updateCustomColor(entry.id, { hex: next });
                      }}
                      className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
                    />
                  </label>
                  <Input
                    value={entry.label}
                    onChange={(e) => updateCustomColor(entry.id, { label: e.target.value })}
                    placeholder="Label"
                    className="min-w-[100px] flex-1"
                  />
                  <Input
                    value={entry.hex}
                    onChange={(e) => updateCustomColor(entry.id, { hex: e.target.value })}
                    onBlur={(e) => {
                      const next = normalizeHex(e.target.value);
                      if (next) updateCustomColor(entry.id, { hex: next });
                    }}
                    placeholder="#64748b"
                    className="w-[108px] shrink-0 font-mono text-xs uppercase"
                    spellCheck={false}
                  />
                  <button
                    type="button"
                    onClick={() => deleteCustomColor(entry.id)}
                    className="rounded-lg p-2.5 text-text-muted transition hover:bg-red-50 hover:text-hyper-red"
                    aria-label={`Remove ${entry.label}`}
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </section>

      <div className="flex items-start gap-2 rounded-xl border border-hyper-primary/10 bg-hyper-primary/[0.04] px-3.5 py-3 text-xs text-text-secondary">
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-hyper-primary" />
        <p>
          Palette changes apply after you click <strong className="text-hyper-navy">Save product</strong>{" "}
          at the top of this panel. Each product line keeps its own colors.
        </p>
      </div>
    </div>
  );
}
