"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { Inbox, Loader2, Play, Plus, Search, Settings } from "lucide-react";
import Link from "next/link";
import {
  api,
  BlogPostDetail,
  BlogPostSummary,
  ReviewResponse,
} from "@/lib/api";
import { KANBAN_COLUMNS } from "@/lib/status";
import TaskCard from "./TaskCard";
import PublishedCard from "./PublishedCard";
import PublishedBlogReader from "./PublishedBlogReader";
import PublishedListModal from "./PublishedListModal";
import TaskDetailModal from "./TaskDetailModal";
import ContentArchetypeSelector from "./ContentArchetypeSelector";
import ProductSelector, { getStoredActiveProductId } from "./ProductSelector";
import NotificationBell from "./NotificationBell";
import Button from "./ui/Button";
import EmptyState from "./ui/EmptyState";
import { TaskCardSkeleton } from "./ui/Skeleton";
import { cn } from "@/lib/cn";

const POLL_MS = 3000;

const EMPTY_COPY: Record<string, { title: string; description: string }> = {
  discovery: {
    title: "No discovery runs",
    description: "Start scraping industry sources to find blog topics",
  },
  topics: {
    title: "No topics waiting",
    description: "Topics appear here after discovery completes",
  },
  review: {
    title: "Nothing in review",
    description: "Generated posts land here for editorial review",
  },
  published: {
    title: "No published posts",
    description: "Approved posts appear here with title, date, and downloads",
  },
};

export default function KanbanBoard() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [posts, setPosts] = useState<BlogPostSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [triggering, setTriggering] = useState(false);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [detail, setDetail] = useState<BlogPostDetail | ReviewResponse | null>(
    null
  );
  const [publishedReaderId, setPublishedReaderId] = useState<number | null>(null);
  const [publishedSummary, setPublishedSummary] = useState<BlogPostSummary | null>(
    null
  );
  const [publishedListOpen, setPublishedListOpen] = useState(false);
  const [activeProductId, setActiveProductId] = useState<number | null>(null);
  const [activeProductName, setActiveProductName] = useState<string | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const columnRefs = useRef<Partial<Record<string, HTMLDivElement | null>>>({});
  /** Prevents URL ?post= from immediately re-opening the reader after Close */
  const suppressPostDeepLinkRef = useRef(false);
  const highlightColumn = searchParams.get("column");

  const loadPosts = useCallback((silent = false, productId?: number | null) => {
    if (!silent) setLoading(true);
    const pid = productId ?? activeProductId;
    return api
      .getPosts(pid ?? undefined)
      .then(setPosts)
      .catch(console.error)
      .finally(() => {
        if (!silent) setLoading(false);
      });
  }, [activeProductId]);

  useEffect(() => {
    if (activeProductId == null) return;
    loadPosts(false, activeProductId);
  }, [activeProductId, loadPosts]);

  useEffect(() => {
    api
      .getActiveProduct()
      .then((r) => {
        setActiveProductId(r.product_id);
        setActiveProductName(r.product?.name || null);
      })
      .catch(() => setActiveProductId(getStoredActiveProductId()));
  }, []);

  const handleProductChange = useCallback((id: number, product?: { name?: string } | null) => {
    setActiveProductId((prev) => {
      if (prev === id) return prev;
      if (prev != null) {
        setSelectedId(null);
        setDetail(null);
        setPublishedReaderId(null);
        setPublishedSummary(null);
        setPublishedListOpen(false);
      }
      return id;
    });
    if (product?.name) setActiveProductName(product.name);
  }, []);

  const hasActiveWork = posts.some(
    (p) =>
      (p.status === "SCRAPING" ||
        p.status === "PENDING_TOPIC" ||
        p.status === "GENERATING") &&
      !p.last_error
  );

  useEffect(() => {
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
    if (hasActiveWork || triggering) {
      pollRef.current = setInterval(() => loadPosts(true), POLL_MS);
    }
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [hasActiveWork, triggering, loadPosts]);

  async function openDetail(post: BlogPostSummary) {
    // Published → full-page reader for every product
    if (post.status === "PUBLISHED") {
      suppressPostDeepLinkRef.current = false;
      setSelectedId(null);
      setDetail(null);
      setPublishedSummary(post);
      setPublishedReaderId(post.id);
      const next = new URLSearchParams(searchParams.toString());
      next.set("post", String(post.id));
      next.set("column", "published");
      router.replace(`${pathname}?${next.toString()}`, { scroll: false });
      return;
    }

    suppressPostDeepLinkRef.current = false;
    setPublishedReaderId(null);
    setPublishedSummary(null);
    setSelectedId(post.id);
    try {
      if (post.status === "PENDING_TOPIC" || post.status === "SCRAPING") {
        const d = await api.getTopicPost(post.id);
        setDetail(d);
      } else if (
        post.status === "GENERATING" ||
        post.status === "PENDING_REVIEW" ||
        post.status === "APPROVED" ||
        post.status === "REJECTED"
      ) {
        const d = await api.getReviewPost(post.id);
        setDetail(d);
      } else {
        const d = await api.getTopicPost(post.id);
        setDetail(d);
      }
    } catch (e) {
      console.error(e);
      setSelectedId(null);
      setDetail(null);
    }
  }

  useEffect(() => {
    const postId = Number(searchParams.get("post"));
    if (!postId || posts.length === 0) return;
    if (suppressPostDeepLinkRef.current) return;
    if (publishedReaderId === postId || selectedId === postId) return;
    const post = posts.find((p) => p.id === postId);
    if (post) void openDetail(post);
  }, [searchParams, posts, selectedId, publishedReaderId]);

  useEffect(() => {
    if (loading || !highlightColumn) return;
    const el = columnRefs.current[highlightColumn];
    if (!el) return;
    const timer = window.setTimeout(() => {
      el.scrollIntoView({ behavior: "smooth", inline: "center", block: "nearest" });
    }, 150);
    return () => window.clearTimeout(timer);
  }, [highlightColumn, loading, posts.length]);

  function closeDetail() {
    suppressPostDeepLinkRef.current = true;
    setSelectedId(null);
    setDetail(null);
    loadPosts(true);

    if (searchParams.get("post")) {
      const next = new URLSearchParams(searchParams.toString());
      next.delete("post");
      const query = next.toString();
      router.replace(query ? `${pathname}?${query}` : pathname, { scroll: false });
    }
  }

  function closePublishedReader() {
    suppressPostDeepLinkRef.current = true;
    setPublishedReaderId(null);
    setPublishedSummary(null);
    if (searchParams.get("post") || searchParams.get("column")) {
      const next = new URLSearchParams(searchParams.toString());
      next.delete("post");
      next.delete("column");
      const query = next.toString();
      router.replace(query ? `${pathname}?${query}` : pathname, { scroll: false });
    }
  }

  async function handleTrigger() {
    setTriggering(true);
    try {
      const res = await api.triggerDiscovery(activeProductId ?? undefined);
      await loadPosts(true);
      if (res.post_id) {
        setPosts((prev) => {
          if (prev.some((p) => p.id === res.post_id)) return prev;
          return [
            {
              id: res.post_id,
              status: "SCRAPING",
              created_at: new Date().toISOString(),
            },
            ...prev,
          ];
        });
      }
    } catch (e) {
      alert(`Failed: ${e}`);
    } finally {
      setTriggering(false);
    }
  }

  async function handleRetry(postId: number, stage: "discovery" | "generation" = "discovery") {
    try {
      if (stage === "generation") {
        await api.retryGeneration(postId);
      } else {
        await api.retryDiscovery(postId);
      }
      await loadPosts(true);
    } catch (e) {
      alert(`Retry failed: ${e}`);
    }
  }

  const scrapingCount = posts.filter((p) => p.status === "SCRAPING").length;
  const generatingCount = posts.filter((p) => p.status === "GENERATING").length;

  return (
    <div className="flex h-full min-w-0 flex-col px-3 py-4 sm:px-4 sm:py-5 md:px-6">
      {/* Page header */}
      <div className="page-hero mb-4 animate-fade-up overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-hyper-navy via-[#252a61] to-[#1b1f4a] px-4 py-5 text-white shadow-elevated sm:mb-5 sm:rounded-3xl sm:px-5 sm:py-6 md:px-7">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <p className="text-micro uppercase tracking-[0.2em] text-white/55">
              Pipeline
            </p>
            <h1 className="mt-1.5 font-display text-xl font-bold tracking-tight sm:text-2xl md:text-3xl">
              Content Board
            </h1>
            <p className="mt-1.5 max-w-xl text-sm leading-relaxed text-white/75">
              Discovery → topic → generation → publish for the active product line
            </p>
            {(generatingCount > 0 || scrapingCount > 0) && (
              <div className="mt-3.5 flex flex-wrap gap-2">
                {scrapingCount > 0 && (
                  <span className="inline-flex items-center gap-1.5 rounded-xl bg-white/10 px-2.5 py-1.5 text-xs font-medium text-orange-100 ring-1 ring-white/15 backdrop-blur-sm">
                    <Loader2 className="h-3 w-3 animate-spin" />
                    {scrapingCount} discovering
                  </span>
                )}
                {generatingCount > 0 && (
                  <span className="inline-flex items-center gap-1.5 rounded-xl bg-white/10 px-2.5 py-1.5 text-xs font-medium text-sky-100 ring-1 ring-white/15 backdrop-blur-sm">
                    <Loader2 className="h-3 w-3 animate-spin" />
                    {generatingCount} generating
                  </span>
                )}
              </div>
            )}
          </div>
          <div className="flex flex-col items-end gap-2.5 self-start lg:self-center">
            <div className="flex items-center gap-1.5">
              <Link
                href="/settings"
                className="inline-flex h-9 w-9 items-center justify-center rounded-xl text-white/80 transition-all duration-200 hover:bg-white/12 hover:text-white hover:shadow-soft active:scale-95"
                aria-label="Settings"
              >
                <Settings className="h-4 w-4" />
              </Link>
              <div className="[&_.icon-btn]:text-white/80 [&_.icon-btn]:hover:bg-white/12 [&_.icon-btn]:hover:text-white [&_.icon-btn]:hover:shadow-soft">
                <NotificationBell align="end" />
              </div>
            </div>
            <Button
              variant="orange"
              size="lg"
              onClick={handleTrigger}
              disabled={triggering}
              loading={triggering}
              className="min-w-[178px]"
            >
              {!triggering && <Play className="h-4 w-4 fill-current" />}
              {triggering ? "Starting…" : "Run discovery"}
            </Button>
          </div>
        </div>
      </div>

      {/* Controls shelf */}
      <div className="panel-shelf mb-5 animate-fade-up space-y-4 p-4 md:p-5" style={{ animationDelay: "60ms" }}>
        <ProductSelector variant="dropdown" onChange={handleProductChange} />
        <div className="border-t border-hyper-border/60 pt-4">
          <div className="mb-2.5 flex items-end justify-between gap-3">
            <div>
              <p className="text-micro uppercase tracking-[0.14em] text-text-muted">
                Content archetype
              </p>
              <p className="mt-0.5 text-xs text-text-secondary">
                Word-count target saved for this product line
              </p>
            </div>
          </div>
          <ContentArchetypeSelector variant="chips" productId={activeProductId} />
        </div>
      </div>

      {/* Kanban columns */}
      {loading ? (
        <div className="kanban-scroll flex flex-1 gap-3 overflow-x-auto pb-4 [-webkit-overflow-scrolling:touch] sm:gap-4">
          {KANBAN_COLUMNS.map((col) => (
            <div
              key={col.id}
              className="flex w-[min(300px,85vw)] shrink-0 flex-col rounded-2xl border border-hyper-border/70 bg-white/70 shadow-soft backdrop-blur-sm"
            >
              <div className={cn("rounded-t-2xl border-l-4 px-4 py-3", col.headerBg, col.accentBorder)}>
                <div className="loading-shimmer h-4 w-24 rounded-lg" />
              </div>
              <div className="flex flex-col gap-2.5 p-3">
                <TaskCardSkeleton />
                <TaskCardSkeleton />
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="kanban-scroll stagger-in relative flex flex-1 gap-3 overflow-x-auto pb-4 [-webkit-overflow-scrolling:touch] sm:gap-4">
          {KANBAN_COLUMNS.map((col) => {
            const columnPosts = posts
              .filter((p) => col.statuses.includes(p.status))
              .sort((a, b) => {
                if (col.id !== "published") return 0;
                const sa = a.publish_serial ?? Number.MAX_SAFE_INTEGER;
                const sb = b.publish_serial ?? Number.MAX_SAFE_INTEGER;
                if (sa !== sb) return sa - sb;
                const ta = new Date(a.published_at || a.created_at).getTime();
                const tb = new Date(b.published_at || b.created_at).getTime();
                return ta - tb;
              });
            const empty = EMPTY_COPY[col.id];
            return (
              <div
                key={col.id}
                ref={(el) => {
                  columnRefs.current[col.id] = el;
                }}
                className={cn(
                  "flex w-[min(300px,85vw)] shrink-0 flex-col rounded-2xl border bg-white/85 shadow-soft backdrop-blur-sm transition-all duration-300",
                  highlightColumn === col.id
                    ? "border-hyper-orange shadow-glow ring-2 ring-hyper-orange/25"
                    : "border-hyper-border/70 hover:-translate-y-0.5 hover:shadow-card"
                )}
              >
                <div
                  className={cn(
                    "sticky top-0 z-10 rounded-t-2xl border-l-4 px-4 py-3.5",
                    col.headerBg,
                    col.accentBorder,
                    col.id === "published" &&
                      "cursor-pointer transition hover:brightness-[0.98] active:scale-[0.99]"
                  )}
                  onClick={
                    col.id === "published"
                      ? () => setPublishedListOpen(true)
                      : undefined
                  }
                  role={col.id === "published" ? "button" : undefined}
                  tabIndex={col.id === "published" ? 0 : undefined}
                  onKeyDown={
                    col.id === "published"
                      ? (e) => {
                          if (e.key === "Enter" || e.key === " ") {
                            e.preventDefault();
                            setPublishedListOpen(true);
                          }
                        }
                      : undefined
                  }
                  aria-label={
                    col.id === "published"
                      ? "Open published blogs list"
                      : undefined
                  }
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h2 className="font-display text-sm font-bold tracking-tight text-hyper-navy">
                        {col.title}
                      </h2>
                      <p className="mt-0.5 text-xs text-text-secondary">
                        {col.id === "published"
                          ? "Click to view all published blogs"
                          : col.subtitle}
                      </p>
                    </div>
                    <span className="inline-flex h-7 min-w-7 items-center justify-center rounded-xl bg-white/90 px-2 font-mono text-[11px] font-bold text-hyper-navy shadow-soft ring-1 ring-black/[0.04]">
                      {columnPosts.length}
                    </span>
                  </div>
                </div>
                <div className="flex flex-1 flex-col gap-2.5 overflow-y-auto p-3">
                  {columnPosts.length === 0 ? (
                    <EmptyState
                      icon={col.id === "discovery" ? Search : Inbox}
                      title={empty.title}
                      description={empty.description}
                      action={
                        col.id === "discovery" ? (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={handleTrigger}
                            disabled={triggering}
                            loading={triggering}
                          >
                            {!triggering && <Plus className="h-3.5 w-3.5" />}
                            {triggering ? "Starting…" : "Add discovery run"}
                          </Button>
                        ) : undefined
                      }
                    />
                  ) : (
                    columnPosts.map((post) =>
                      col.id === "published" || post.status === "PUBLISHED" ? (
                        <PublishedCard
                          key={post.id}
                          post={post}
                          onOpen={() => openDetail(post)}
                        />
                      ) : (
                        <TaskCard
                          key={post.id}
                          post={post}
                          onClick={() => openDetail(post)}
                          onRetry={
                            (post.status === "REJECTED" ||
                              (post.status === "SCRAPING" && !!post.last_error))
                              ? () => handleRetry(post.id, "discovery")
                              : post.status === "GENERATING" && post.last_error
                                ? () => handleRetry(post.id, "generation")
                                : undefined
                          }
                        />
                      )
                    )
                  )}
                  {col.id === "discovery" && columnPosts.length > 0 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={handleTrigger}
                      disabled={triggering}
                      loading={triggering}
                      className="h-10 w-full border border-dashed border-hyper-border/80 text-text-muted hover:border-hyper-primary/40 hover:bg-hyper-primary/[0.04] hover:text-hyper-primary"
                    >
                      {!triggering && <Plus className="h-3.5 w-3.5" />}
                      {triggering ? "Starting…" : "Add discovery run"}
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {selectedId && detail && (
        <TaskDetailModal
          postId={selectedId}
          detail={detail}
          onClose={closeDetail}
        />
      )}

      {publishedListOpen && (
        <PublishedListModal
          productId={activeProductId}
          productName={activeProductName}
          onClose={() => setPublishedListOpen(false)}
          onOpenPost={(post) => {
            setPublishedListOpen(false);
            void openDetail(post);
          }}
        />
      )}

      {publishedReaderId != null && (
        <PublishedBlogReader
          postId={publishedReaderId}
          summary={publishedSummary}
          onClose={closePublishedReader}
        />
      )}
    </div>
  );
}
