"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowRight,
  BarChart3,
  CheckCircle2,
  ChevronDown,
  ExternalLink,
  FileText,
  Zap,
} from "lucide-react";
import { api, BlogPostSummary } from "@/lib/api";
import {
  getColumnForStatus,
  getColumnMeta,
  getPostTitle,
  KANBAN_COLUMNS,
  REPORT_STATUSES,
  STATUS_LABELS,
} from "@/lib/status";
import StatusBadge from "@/components/StatusBadge";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import { Skeleton } from "@/components/ui/Skeleton";
import { cn } from "@/lib/cn";

const STATUS_COLORS: Record<string, string> = {
  SCRAPING: "bg-slate-400",
  PENDING_TOPIC: "bg-amber-400",
  GENERATING: "bg-indigo-500",
  PENDING_REVIEW: "bg-blue-500",
  APPROVED: "bg-violet-500",
  PUBLISHED: "bg-emerald-500",
  REJECTED: "bg-hyper-red",
};

export default function ReportPage() {
  const router = useRouter();
  const [posts, setPosts] = useState<BlogPostSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedStatus, setExpandedStatus] = useState<string | null>(null);

  useEffect(() => {
    api
      .getPosts()
      .then(setPosts)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const published = posts.filter((p) => p.status === "PUBLISHED").length;
  const inPipeline = posts.filter(
    (p) => !["PUBLISHED", "REJECTED"].includes(p.status)
  ).length;
  const pendingReview = posts.filter(
    (p) => p.status === "PENDING_REVIEW"
  ).length;

  function handleStatusClick(status: string, statusPosts: BlogPostSummary[]) {
    if (statusPosts.length === 0) {
      const column = getColumnForStatus(status);
      router.push(`/?column=${column}`);
      return;
    }
    if (statusPosts.length === 1) {
      router.push(`/?post=${statusPosts[0].id}`);
      return;
    }
    setExpandedStatus((prev) => (prev === status ? null : status));
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-6 md:px-6">
      <div className="animate-fade-up">
        <p className="text-micro uppercase tracking-[0.16em] text-text-muted">Analytics</p>
        <h1 className="mt-1 font-display text-display tracking-tight text-hyper-navy">Report</h1>
        <p className="mt-1.5 text-sm font-medium text-text-secondary">
          SEO content pipeline analytics — click counts to drill into the board
        </p>
      </div>

      {loading ? (
        <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
          <Skeleton className="h-28 rounded-2xl" />
          <Skeleton className="h-28 rounded-2xl" />
          <Skeleton className="h-28 rounded-2xl" />
        </div>
      ) : (
        <>
          <div className="stagger-in mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
            <StatCard
              icon={FileText}
              label="In Pipeline"
              value={inPipeline}
              href="/"
              accent="from-hyper-orange/20 to-hyper-orange/5 text-hyper-orange"
            />
            <StatCard
              icon={Zap}
              label="Pending Review"
              value={pendingReview}
              href="/?column=review"
              accent="from-hyper-primary/20 to-hyper-primary/5 text-hyper-primary"
            />
            <StatCard
              icon={CheckCircle2}
              label="Published"
              value={published}
              href="/?column=published"
              accent="from-emerald-500/20 to-emerald-500/5 text-emerald-600"
            />
          </div>

          <Card variant="elevated" className="mt-6">
            <CardHeader className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-hyper-primary" />
                <div>
                  <h2 className="font-display text-h2 text-hyper-navy">
                    Status breakdown
                  </h2>
                  <p className="text-xs text-text-muted">
                    Click a count to view items or open the board column
                  </p>
                </div>
              </div>
              <Link
                href="/"
                className="inline-flex items-center gap-1.5 text-xs font-medium text-hyper-primary hover:underline"
              >
                Open content board
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </CardHeader>
            <CardBody className="space-y-3">
              {REPORT_STATUSES.map((status) => {
                const statusPosts = posts.filter((p) => p.status === status);
                const count = statusPosts.length;
                const pct = posts.length ? (count / posts.length) * 100 : 0;
                const expanded = expandedStatus === status;
                const column = getColumnMeta(status);

                return (
                  <div
                    key={status}
                    className={cn(
                      "rounded-xl border transition-colors",
                      expanded
                        ? "border-hyper-primary/20 bg-surface-1/50"
                        : "border-transparent"
                    )}
                  >
                    <div className="px-1 py-1">
                      <div className="mb-1.5 flex items-center justify-between gap-3">
                        <button
                          type="button"
                          onClick={() => handleStatusClick(status, statusPosts)}
                          className="group flex min-w-0 flex-1 items-center gap-2 text-left"
                        >
                          <StatusBadge status={status} size="xs" />
                          <span className="truncate text-sm text-text-secondary">
                            {column?.title ?? STATUS_LABELS[status]}
                          </span>
                          {count > 1 && (
                            <ChevronDown
                              className={cn(
                                "h-4 w-4 shrink-0 text-text-muted transition-transform",
                                expanded && "rotate-180"
                              )}
                            />
                          )}
                        </button>
                        <div className="flex shrink-0 items-center gap-2">
                          <Link
                            href={`/?column=${getColumnForStatus(status)}`}
                            className="hidden text-[11px] font-medium text-hyper-primary hover:underline sm:inline"
                            title={`Open ${column?.title ?? "board"} column`}
                          >
                            Board
                          </Link>
                          <button
                            type="button"
                            onClick={() => handleStatusClick(status, statusPosts)}
                            className={cn(
                              "min-w-[2rem] rounded-lg px-2 py-1 font-mono text-sm font-semibold tabular-nums transition",
                              count > 0
                                ? "bg-hyper-primary/10 text-hyper-navy hover:bg-hyper-primary hover:text-white"
                                : "bg-surface-2 text-text-muted hover:bg-surface-2"
                            )}
                          >
                            {count}
                          </button>
                        </div>
                      </div>
                      <div className="h-2 overflow-hidden rounded-full bg-surface-2">
                        <div
                          className={cn(
                            "h-full rounded-full transition-all duration-300",
                            STATUS_COLORS[status] || "bg-hyper-primary"
                          )}
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>

                    {expanded && count > 0 && (
                      <ul className="mx-1 mb-2 divide-y divide-hyper-border overflow-hidden rounded-lg border border-hyper-border bg-surface-0">
                        {statusPosts.map((post) => (
                          <li key={post.id}>
                            <Link
                              href={`/?post=${post.id}`}
                              className="flex items-center justify-between gap-3 px-3 py-2.5 transition hover:bg-hyper-primary/5"
                            >
                              <div className="min-w-0">
                                <p className="truncate text-sm font-medium text-hyper-navy">
                                  {getPostTitle(post)}
                                </p>
                                <p className="mt-0.5 text-[11px] text-text-muted">
                                  #{post.id}
                                  {post.product_name ? ` · ${post.product_name}` : ""}
                                  {post.created_at
                                    ? ` · ${new Date(post.created_at).toLocaleDateString()}`
                                    : ""}
                                </p>
                              </div>
                              <ExternalLink className="h-3.5 w-3.5 shrink-0 text-hyper-primary" />
                            </Link>
                          </li>
                        ))}
                      </ul>
                    )}

                    {count === 1 && !expanded && (
                      <div className="mx-1 mb-1">
                        <Link
                          href={`/?post=${statusPosts[0].id}`}
                          className="flex items-center justify-between gap-2 rounded-lg border border-hyper-border bg-surface-0 px-3 py-2 text-sm transition hover:border-hyper-primary/30 hover:bg-hyper-primary/5"
                        >
                          <span className="truncate font-medium text-hyper-navy">
                            {getPostTitle(statusPosts[0])}
                          </span>
                          <span className="shrink-0 text-xs text-hyper-primary">
                            View on board →
                          </span>
                        </Link>
                      </div>
                    )}
                  </div>
                );
              })}
            </CardBody>
          </Card>

          <div className="mt-4 rounded-xl border border-hyper-border bg-surface-1 px-4 py-3">
            <p className="text-xs text-text-secondary">
              <strong className="text-hyper-navy">Board columns:</strong>{" "}
              {KANBAN_COLUMNS.map((col, i) => (
                <span key={col.id}>
                  {i > 0 && " · "}
                  <Link
                    href={`/?column=${col.id}`}
                    className="font-medium text-hyper-primary hover:underline"
                  >
                    {col.title}
                  </Link>
                </span>
              ))}
            </p>
          </div>
        </>
      )}
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  href,
  accent,
}: {
  icon: React.ElementType;
  label: string;
  value: number;
  href: string;
  accent: string;
}) {
  return (
    <Link
      href={href}
      className={cn(
        "group block rounded-2xl border border-hyper-border/70 bg-gradient-to-br p-5 shadow-soft transition-all duration-200 hover:-translate-y-1 hover:shadow-elevated",
        accent
      )}
    >
      <div className="mb-3 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Icon className="h-5 w-5 transition-transform duration-200 group-hover:scale-110" />
          <span className="text-sm font-semibold tracking-tight">{label}</span>
        </div>
        <ArrowRight className="h-4 w-4 -translate-x-1 opacity-0 transition-all duration-200 group-hover:translate-x-0 group-hover:opacity-100" />
      </div>
      <p className="font-display text-3xl font-bold tracking-tight text-hyper-navy tabular-nums">
        {value}
      </p>
    </Link>
  );
}
