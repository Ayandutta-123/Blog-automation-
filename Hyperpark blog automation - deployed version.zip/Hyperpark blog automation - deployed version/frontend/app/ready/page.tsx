"use client";

import { useCallback, useEffect, useState } from "react";
import { Box, CheckCircle2, ChevronDown, ChevronRight } from "lucide-react";
import { api, BlogPostSummary, Product } from "@/lib/api";
import PublishedBlogReader from "@/components/PublishedBlogReader";
import { formatDateTime, getPostTitle } from "@/lib/status";
import { Card, CardBody } from "@/components/ui/Card";
import EmptyState from "@/components/ui/EmptyState";
import { Skeleton } from "@/components/ui/Skeleton";
import { cn } from "@/lib/cn";

const STORAGE_KEY = "hyperpark_active_product_id";

export default function ReadyToUsePage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [productId, setProductId] = useState<number | null>(null);
  const [posts, setPosts] = useState<BlogPostSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingPosts, setLoadingPosts] = useState(false);
  const [selectedId, setSelectedId] = useState<number | null>(null);

  const selectedSummary = posts.find((p) => p.id === selectedId) ?? null;

  const loadProducts = useCallback(async () => {
    setLoading(true);
    try {
      const list = await api.getProducts();
      setProducts(list);
      const stored = localStorage.getItem(STORAGE_KEY);
      const preferred =
        stored && /^\d+$/.test(stored) && list.some((p) => p.id === Number(stored))
          ? Number(stored)
          : list[0]?.id ?? null;
      setProductId(preferred);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  const loadPublished = useCallback(async (pid: number) => {
    setLoadingPosts(true);
    setSelectedId(null);
    try {
      const list = await api.getPosts(pid, "PUBLISHED");
      setPosts(list);
    } catch (e) {
      console.error(e);
      setPosts([]);
    } finally {
      setLoadingPosts(false);
    }
  }, []);

  useEffect(() => {
    loadProducts();
  }, [loadProducts]);

  useEffect(() => {
    if (productId == null) return;
    localStorage.setItem(STORAGE_KEY, String(productId));
    loadPublished(productId);
  }, [productId, loadPublished]);

  function openPost(id: number) {
    setSelectedId(id);
  }

  function closeReader() {
    setSelectedId(null);
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-6 md:px-6">
      <div className="animate-fade-up">
        <p className="text-micro uppercase tracking-[0.16em] text-text-muted">
          Library
        </p>
        <h1 className="mt-1 font-display text-display tracking-tight text-hyper-navy">
          Ready to use
        </h1>
        <p className="mt-1.5 max-w-xl text-sm font-medium text-text-secondary">
          Published blogs per product in serial order. Click a row to open the
          full article with HTML and image download.
        </p>
      </div>

      <Card variant="elevated" className="mt-6 animate-fade-up overflow-hidden rounded-2xl">
        <CardBody className="flex flex-col gap-4 p-4 sm:flex-row sm:items-end sm:justify-between md:p-5">
          <label className="block min-w-0 flex-1">
            <span className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-slate-500">
              <Box className="h-3.5 w-3.5" />
              Product
            </span>
            <div className="relative">
              <select
                value={productId ?? ""}
                disabled={loading || products.length === 0}
                onChange={(e) => setProductId(Number(e.target.value))}
                className="h-11 w-full appearance-none rounded-xl border border-hyper-border/80 bg-white py-2.5 pl-3.5 pr-10 text-sm font-semibold text-hyper-navy shadow-soft focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/15"
              >
                {products.length === 0 ? (
                  <option value="">No products yet</option>
                ) : (
                  products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                      {p.company_name ? ` · ${p.company_name}` : ""}
                    </option>
                  ))
                )}
              </select>
              <ChevronDown className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
            </div>
          </label>
          <p className="text-sm font-medium text-slate-600 sm:pb-3">
            {loadingPosts
              ? "Loading published blogs…"
              : `${posts.length} ready blog${posts.length === 1 ? "" : "s"}`}
          </p>
        </CardBody>
      </Card>

      {loading || loadingPosts ? (
        <div className="mt-6 space-y-2">
          <Skeleton className="h-14 w-full rounded-xl" />
          <Skeleton className="h-14 w-full rounded-xl" />
          <Skeleton className="h-14 w-full rounded-xl" />
        </div>
      ) : posts.length === 0 ? (
        <div className="mt-8">
          <EmptyState
            icon={CheckCircle2}
            title="No ready blogs yet"
            description="Approve & publish a post from the Board — it will show up here for this product."
          />
        </div>
      ) : (
        <div className="stagger-in mt-6 overflow-hidden rounded-2xl border border-hyper-border/80 bg-white shadow-soft">
          <div className="hidden grid-cols-[4.5rem_1fr_11rem_7rem_2rem] gap-3 border-b border-hyper-border/70 bg-slate-50 px-4 py-2.5 text-[11px] font-bold uppercase tracking-wide text-slate-600 sm:grid sm:px-5">
            <span>Serial</span>
            <span>Title</span>
            <span>Published</span>
            <span>Read time</span>
            <span className="sr-only">Open</span>
          </div>
          <ul className="divide-y divide-hyper-border/70">
            {posts.map((post) => {
              const when = post.published_at || post.created_at;
              const active = selectedId === post.id;
              return (
                <li key={post.id}>
                  <button
                    type="button"
                    onClick={() => openPost(post.id)}
                    className={cn(
                      "grid w-full grid-cols-[3.25rem_1fr_auto] items-center gap-3 px-4 py-3.5 text-left transition sm:grid-cols-[4.5rem_1fr_11rem_7rem_2rem] sm:px-5",
                      active
                        ? "bg-hyper-primary/[0.06]"
                        : "hover:bg-slate-50"
                    )}
                  >
                    <span className="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-50 font-mono text-sm font-bold text-emerald-800 ring-1 ring-emerald-100">
                      {post.publish_serial ?? "—"}
                    </span>
                    <span className="min-w-0">
                      <span className="block truncate font-display text-sm font-bold text-hyper-navy sm:text-[15px]">
                        {getPostTitle(post)}
                      </span>
                      <span className="mt-0.5 block truncate text-xs font-medium text-slate-600 sm:hidden">
                        {formatDateTime(when)}
                        {post.reading_time ? ` · ${post.reading_time}` : ""}
                      </span>
                      {post.slug ? (
                        <span className="mt-0.5 hidden truncate font-mono text-[11px] font-medium text-slate-500 sm:block">
                          /{post.slug}
                        </span>
                      ) : null}
                    </span>
                    <span className="hidden text-sm font-semibold text-slate-700 sm:block">
                      {formatDateTime(when)}
                    </span>
                    <span className="hidden text-sm font-medium text-slate-600 sm:block">
                      {post.reading_time || "—"}
                    </span>
                    <ChevronRight className="h-4 w-4 shrink-0 text-slate-500" />
                  </button>
                </li>
              );
            })}
          </ul>
        </div>
      )}

      {selectedId != null && (
        <PublishedBlogReader
          postId={selectedId}
          summary={selectedSummary}
          onClose={closeReader}
        />
      )}
    </div>
  );
}
