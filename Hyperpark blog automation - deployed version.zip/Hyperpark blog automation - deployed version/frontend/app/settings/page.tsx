"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Box, KeyRound, Settings2, Shield } from "lucide-react";
import IntegrationsPanel from "@/components/IntegrationsPanel";
import ProductsPanel from "@/components/ProductsPanel";
import SecurityPanel from "@/components/SecurityPanel";
import UbersuggestPanel from "@/components/UbersuggestPanel";
import WordPressPanel from "@/components/WordPressPanel";
import GoogleBloggerPanel from "@/components/GoogleBloggerPanel";
import { Tab } from "@/components/ui/Tabs";
import { cn } from "@/lib/cn";

type TabId = "products" | "integrations" | "security";

const NAV_ITEMS: {
  id: TabId;
  label: string;
  description: string;
  icon: React.ElementType;
}[] = [
  {
    id: "products",
    label: "Products",
    description: "Profiles, automation & scrapers",
    icon: Box,
  },
  {
    id: "integrations",
    label: "Integrations",
    description: "API keys & content rules",
    icon: KeyRound,
  },
  {
    id: "security",
    label: "Security",
    description: "Password & sign out",
    icon: Shield,
  },
];

const TAB_META: Record<
  TabId,
  { eyebrow: string; title: string; blurb: string }
> = {
  products: {
    eyebrow: "Product workspace",
    title: "Product lines",
    blurb: "Configure automation mode, brand palette, schedules, and discovery targets per product.",
  },
  integrations: {
    eyebrow: "Connections",
    title: "Integrations",
    blurb: "Connect search, AI content, image generation, WordPress, Teams, and editorial rules that power every run.",
  },
  security: {
    eyebrow: "Access control",
    title: "Security",
    blurb: "Update your dashboard password and end the current session securely.",
  },
};

function parseTab(raw: string | null): TabId {
  if (raw === "integrations" || raw === "security" || raw === "products") return raw;
  return "products";
}

export default function SettingsPage() {
  return (
    <Suspense fallback={<div className="p-6 text-slate-400">Loading settings…</div>}>
      <SettingsPageInner />
    </Suspense>
  );
}

function SettingsPageInner() {
  const searchParams = useSearchParams();
  const [tab, setTab] = useState<TabId>(() => parseTab(searchParams.get("tab")));
  const meta = TAB_META[tab];

  useEffect(() => {
    setTab(parseTab(searchParams.get("tab")));
  }, [searchParams]);

  function selectTab(next: TabId) {
    setTab(next);
    const url = new URL(window.location.href);
    url.searchParams.set("tab", next);
    window.history.replaceState({}, "", url.toString());
  }

  return (
    <div className="min-h-full bg-[linear-gradient(180deg,#f4f6fb_0%,#eef1f8_45%,#f7f8fc_100%)]">
      {/* Hero */}
      <div className="settings-hero relative overflow-hidden border-b border-white/10">
        <div className="settings-glow pointer-events-none absolute inset-0" />
        <div className="pointer-events-none absolute -right-20 top-0 h-56 w-56 rounded-full bg-hyper-orange/25 blur-3xl" />
        <div className="pointer-events-none absolute left-1/3 top-0 h-40 w-40 rounded-full bg-white/10 blur-3xl" />
        <div className="pointer-events-none absolute -left-10 bottom-0 h-36 w-36 rounded-full bg-white/5 blur-2xl" />

        <div className="relative mx-auto max-w-6xl px-4 py-8 md:px-8 md:py-10">
          <div className="flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
            <div className="max-w-2xl">
              <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-3 py-1 backdrop-blur-sm">
                <Settings2 className="h-3.5 w-3.5 text-hyper-orange" />
                <span className="text-micro font-semibold uppercase tracking-[0.16em] text-white/90">
                  Workspace settings
                </span>
              </div>
              <h1 className="font-display text-3xl font-bold tracking-tight text-white md:text-4xl">
                Settings
              </h1>
              <p className="settings-hero-lead mt-2 max-w-xl text-sm leading-relaxed">
                Enterprise controls for product lines, integrations, and access — tuned for a
                clean, predictable content pipeline.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-2 rounded-2xl border border-white/15 bg-white/10 p-1.5 backdrop-blur-sm md:min-w-[280px]">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const active = tab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => selectTab(item.id)}
                    className={cn(
                      "flex flex-col items-center gap-1 rounded-xl px-2 py-2.5 text-center transition-all duration-200 ease-out",
                      active
                        ? "bg-white text-hyper-navy shadow-soft scale-[1.02]"
                        : "text-white/70 hover:bg-white/10 hover:text-white hover:scale-[1.01]"
                    )}
                  >
                    <Icon className={cn("h-4 w-4", active ? "text-hyper-orange" : "")} />
                    <span className="text-[11px] font-semibold">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Body */}
      <div className="mx-auto max-w-6xl px-4 py-7 md:px-8 md:py-9">
        <div className="flex flex-col gap-6 lg:flex-row lg:gap-8">
          {/* Side nav */}
          <aside className="lg:sticky lg:top-4 lg:w-[250px] lg:shrink-0 lg:self-start">
            <p className="mb-2.5 px-1 text-micro uppercase tracking-wider text-text-muted">
              Sections
            </p>
            <div
              role="tablist"
              aria-label="Settings sections"
              className="flex gap-2 overflow-x-auto rounded-2xl border border-hyper-border/80 bg-white/80 p-1.5 shadow-sm backdrop-blur-sm lg:flex-col lg:gap-1.5 lg:overflow-visible"
            >
              {NAV_ITEMS.map((item) => (
                <Tab
                  key={item.id}
                  id={`tab-${item.id}`}
                  label={item.label}
                  description={item.description}
                  icon={item.icon}
                  active={tab === item.id}
                  variant="settings"
                  onClick={() => selectTab(item.id)}
                />
              ))}
            </div>
            <p className="mt-3 hidden px-1 text-[11px] leading-relaxed text-text-muted lg:block">
              Changes apply per product unless noted. Save each product profile before leaving.
            </p>
          </aside>

          {/* Content */}
          <div className="min-w-0 flex-1">
            <div className="mb-4">
              <p className="text-micro uppercase tracking-wider text-text-muted">
                {meta.eyebrow}
              </p>
              <h2 className="mt-1 font-display text-xl font-semibold tracking-tight text-hyper-navy md:text-2xl">
                {meta.title}
              </h2>
              <p className="mt-1 max-w-2xl text-sm text-text-secondary">{meta.blurb}</p>
            </div>

            <div className="overflow-hidden rounded-2xl border border-hyper-border/80 bg-white shadow-[0_18px_40px_-28px_rgba(27,31,74,0.35)]">
              <div className="settings-accent-bar h-1" />
              <div className="p-4 md:p-6 lg:p-7">
                {tab === "products" ? (
                  <ProductsPanel />
                ) : tab === "integrations" ? (
                  <div className="space-y-6">
                    <Suspense fallback={null}>
                      <UbersuggestPanel />
                    </Suspense>
                    <WordPressPanel />
                    <GoogleBloggerPanel />
                    <IntegrationsPanel />
                  </div>
                ) : (
                  <SecurityPanel />
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
