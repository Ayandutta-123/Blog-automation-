from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.database import get_db
from app.services.auth import (
    authenticate,
    change_password,
    check_rate_limit,
    clear_login_failures,
    create_session,
    get_expected_username,
    get_stored_password_hash,
    record_login_failure,
    revoke_session,
    validate_session,
)

router = APIRouter(prefix="/api/auth", tags=["auth"])


class LoginRequest(BaseModel):
    username: str = Field(..., min_length=1, max_length=128)
    password: str = Field(..., min_length=1, max_length=256)


class LoginResponse(BaseModel):
    token: str
    message: str = "Signed in"


class SessionResponse(BaseModel):
    authenticated: bool


class ChangePasswordRequest(BaseModel):
    current_password: str = Field(..., min_length=1, max_length=256)
    new_password: str = Field(..., min_length=8, max_length=256)


def _client_key(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()[:128]
    if request.client and request.client.host:
        return request.client.host
    return "unknown"


def _extract_token(authorization: Optional[str]) -> Optional[str]:
    if not authorization:
        return None
    if authorization.lower().startswith("bearer "):
        return authorization[7:].strip()
    return None


def require_session(
    authorization: Optional[str] = Header(default=None),
    db: Session = Depends(get_db),
) -> str:
    token = _extract_token(authorization)
    if not validate_session(token, db):
        raise HTTPException(status_code=401, detail="Not authenticated")
    return token  # type: ignore[return-value]


@router.post("/login", response_model=LoginResponse)
def login(payload: LoginRequest, request: Request, db: Session = Depends(get_db)):
    key = _client_key(request)
    locked = check_rate_limit(key)
    if locked:
        raise HTTPException(status_code=429, detail=locked)

    if not get_expected_username() or not get_stored_password_hash(db):
        # Misconfigured server — do not leak details to the client
        raise HTTPException(status_code=503, detail="Sign-in is temporarily unavailable")

    if not authenticate(payload.username, payload.password, db):
        record_login_failure(key)
        raise HTTPException(status_code=401, detail="Invalid credentials")

    clear_login_failures(key)
    token = create_session(db)
    return LoginResponse(token=token)


@router.post("/logout")
def logout(
    authorization: Optional[str] = Header(default=None),
    db: Session = Depends(get_db),
):
    token = _extract_token(authorization)
    revoke_session(token, db)
    return {"message": "Signed out"}


@router.get("/session", response_model=SessionResponse)
def session_status(
    authorization: Optional[str] = Header(default=None),
    db: Session = Depends(get_db),
):
    token = _extract_token(authorization)
    return SessionResponse(authenticated=validate_session(token, db))


@router.post("/change-password")
def update_password(
    payload: ChangePasswordRequest,
    db: Session = Depends(get_db),
    _token: str = Depends(require_session),
):
    try:
        change_password(payload.current_password, payload.new_password, db)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"message": "Password updated successfully"}
