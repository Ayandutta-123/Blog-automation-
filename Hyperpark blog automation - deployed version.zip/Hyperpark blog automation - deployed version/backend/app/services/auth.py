from __future__ import annotations

import hashlib
import json
import secrets
import time
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Optional

from sqlalchemy.orm import Session

from app.config import settings as env_settings
from app.database import SessionLocal
from app.services.runtime_config import get_config_value, set_config_value

PASSWORD_HASH_KEY = "dashboard_password_hash"
SESSIONS_KEY = "dashboard_sessions"
_PBKDF_SALT = b"blog-automation-dashboard-v1"
_SESSION_TTL_DAYS = 14
_MIN_PASSWORD_LEN = 8

# Brute-force protection (in-memory; per process)
_MAX_FAILURES = 5
_WINDOW_SECONDS = 15 * 60
_LOCKOUT_SECONDS = 15 * 60
_failures: dict[str, list[float]] = defaultdict(list)
_lockouts: dict[str, float] = {}


def hash_password(password: str) -> str:
    digest = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        _PBKDF_SALT,
        120_000,
    )
    return digest.hex()


def verify_password(password: str, stored_hash: str) -> bool:
    if not password or not stored_hash:
        return False
    return secrets.compare_digest(hash_password(password), stored_hash)


def get_expected_username() -> str:
    return (env_settings.dashboard_username or "").strip()


def get_stored_password_hash(db: Session) -> str:
    stored = get_config_value(PASSWORD_HASH_KEY, db)
    if stored:
        return stored
    plain = (env_settings.dashboard_password or "").strip()
    if not plain:
        # No bootstrap password configured — leave unset (login will fail).
        return ""
    hashed = hash_password(plain)
    set_config_value(PASSWORD_HASH_KEY, hashed, db, is_secret=True)
    return hashed


def _dummy_hash() -> str:
    return hash_password("__unused_dummy_password__")


def authenticate(username: str, password: str, db: Session) -> bool:
    """Constant-time-ish check of username + password. Never reveals which failed."""
    expected_user = get_expected_username()
    stored = get_stored_password_hash(db) or _dummy_hash()

    provided_user = (username or "").strip()
    # Pad lengths before compare_digest to reduce trivial length leaks
    max_len = max(len(provided_user), len(expected_user), 1)
    user_ok = bool(expected_user) and secrets.compare_digest(
        provided_user.ljust(max_len),
        expected_user.ljust(max_len),
    )
    pass_ok = verify_password(password or "", stored)
    return user_ok and pass_ok


def change_password(current: str, new_password: str, db: Session) -> None:
    cleaned = (new_password or "").strip()
    if len(cleaned) < _MIN_PASSWORD_LEN:
        raise ValueError(f"New password must be at least {_MIN_PASSWORD_LEN} characters")
    stored = get_stored_password_hash(db)
    if not stored or not verify_password(current, stored):
        raise ValueError("Current password is incorrect")
    set_config_value(PASSWORD_HASH_KEY, hash_password(cleaned), db, is_secret=True)


def check_rate_limit(client_key: str) -> Optional[str]:
    """Return an error message if locked out, else None."""
    now = time.monotonic()
    until = _lockouts.get(client_key)
    if until and until > now:
        secs = int(until - now) + 1
        return f"Too many failed attempts. Try again in {secs}s."
    if until:
        _lockouts.pop(client_key, None)
    return None


def record_login_failure(client_key: str) -> None:
    now = time.monotonic()
    window_start = now - _WINDOW_SECONDS
    recent = [t for t in _failures[client_key] if t >= window_start]
    recent.append(now)
    _failures[client_key] = recent
    if len(recent) >= _MAX_FAILURES:
        _lockouts[client_key] = now + _LOCKOUT_SECONDS
        _failures[client_key] = []


def clear_login_failures(client_key: str) -> None:
    _failures.pop(client_key, None)
    _lockouts.pop(client_key, None)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _parse_expiry(value: str) -> Optional[datetime]:
    try:
        dt = datetime.fromisoformat(value)
    except (TypeError, ValueError):
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def _load_sessions(db: Session) -> dict[str, str]:
    raw = get_config_value(SESSIONS_KEY, db) or ""
    if not raw.strip():
        return {}
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    if not isinstance(data, dict):
        return {}
    return {str(k): str(v) for k, v in data.items() if k and v}


def _save_sessions(db: Session, sessions: dict[str, str]) -> None:
    set_config_value(SESSIONS_KEY, json.dumps(sessions), db, is_secret=True)


def _prune(sessions: dict[str, str]) -> dict[str, str]:
    now = _now()
    kept: dict[str, str] = {}
    for token, exp_raw in sessions.items():
        exp = _parse_expiry(exp_raw)
        if exp and exp >= now:
            kept[token] = exp.isoformat()
    return kept


def create_session(db: Optional[Session] = None) -> str:
    """Create a durable session token (persisted in DB, survives server restarts)."""
    owns_db = db is None
    session = db or SessionLocal()
    try:
        sessions = _prune(_load_sessions(session))
        token = secrets.token_urlsafe(48)
        sessions[token] = (_now() + timedelta(days=_SESSION_TTL_DAYS)).isoformat()
        _save_sessions(session, sessions)
        return token
    finally:
        if owns_db:
            session.close()


def validate_session(token: Optional[str], db: Optional[Session] = None) -> bool:
    """Return True if token is still valid. Extends expiry on successful checks."""
    if not token:
        return False

    owns_db = db is None
    session = db or SessionLocal()
    try:
        sessions = _prune(_load_sessions(session))
        if token not in sessions:
            if sessions != _load_sessions(session):
                _save_sessions(session, sessions)
            return False

        sessions[token] = (_now() + timedelta(days=_SESSION_TTL_DAYS)).isoformat()
        _save_sessions(session, sessions)
        return True
    finally:
        if owns_db:
            session.close()


def revoke_session(token: Optional[str], db: Optional[Session] = None) -> None:
    """Invalidate a session (logout). Only removes this token."""
    if not token:
        return

    owns_db = db is None
    session = db or SessionLocal()
    try:
        sessions = _prune(_load_sessions(session))
        if token in sessions:
            sessions.pop(token, None)
            _save_sessions(session, sessions)
    finally:
        if owns_db:
            session.close()
