"""Upload one published HTML file (or all local published blogs) to MinIO.

Usage:
  cd backend
  .venv/bin/python -m scripts.upload_blogs_to_minio
  .venv/bin/python -m scripts.upload_blogs_to_minio --slug my-post-slug
  .venv/bin/python -m scripts.upload_blogs_to_minio --status
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Allow running as module from backend/
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.config import settings  # noqa: E402
from app.services.minio_storage import (  # noqa: E402
    MinioUploadError,
    connection_status,
    minio_configured,
    upload_published_html,
)


def main() -> int:
    parser = argparse.ArgumentParser(description="Upload published blog HTML to MinIO")
    parser.add_argument("--slug", help="Upload a single slug (file: {slug}.html)")
    parser.add_argument("--status", action="store_true", help="Check MinIO connection")
    parser.add_argument(
        "--dir",
        default=settings.blog_html_dir,
        help="Local HTML directory (default: BLOG_HTML_DIR)",
    )
    args = parser.parse_args()

    if args.status:
        status = connection_status()
        print(status)
        return 0 if status.get("ok") else 1

    if not minio_configured():
        print(
            "MinIO is not configured. Set MINIO_ENDPOINT, MINIO_ACCESS_KEY, "
            "MINIO_SECRET_KEY, MINIO_BUCKET in backend/.env or Settings → Integrations."
        )
        return 1

    html_dir = Path(args.dir)
    if args.slug:
        files = [html_dir / f"{args.slug}.html"]
    else:
        files = sorted(html_dir.glob("*.html"))

    if not files:
        print(f"No HTML files found in {html_dir}")
        return 1

    ok = 0
    for path in files:
        if not path.is_file():
            print(f"SKIP missing: {path}")
            continue
        slug = path.stem
        try:
            meta = upload_published_html(slug=slug, html_path=path)
            print(f"OK {slug} -> {meta}")
            ok += 1
        except MinioUploadError as exc:
            print(f"FAIL {slug}: {exc}")
        except Exception as exc:
            print(f"FAIL {slug}: {exc}")

    print(f"Uploaded {ok}/{len(files)} file(s)")
    return 0 if ok == len(files) else 1


if __name__ == "__main__":
    raise SystemExit(main())
