#!/usr/bin/env python3
"""One-time import of legacy SQLite application rows into an empty Postgres DB.

This script exists only for migration. The application runtime itself accepts
PostgreSQL exclusively.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

from sqlalchemy import (
    Boolean,
    DateTime,
    Enum,
    JSON,
    MetaData,
    create_engine,
    func,
    inspect,
    select,
    text,
)

BACKEND_ROOT = Path(__file__).resolve().parents[1]
if str(BACKEND_ROOT) not in sys.path:
    sys.path.insert(0, str(BACKEND_ROOT))

from app.database import Base
import app.models  # noqa: F401  # register every model with Base.metadata


TABLE_ORDER = (
    "products",
    "app_config",
    "dashboard_users",
    "scraper_settings",
    "blog_posts",
    "app_notifications",
)


def _parse_args() -> argparse.Namespace:
    root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(
        description="Import a legacy SQLite database into an empty PostgreSQL database."
    )
    parser.add_argument(
        "--source",
        default=str(root / "storage" / "hyperpark_blog.db"),
        help="Path to the legacy SQLite .db file",
    )
    parser.add_argument(
        "--target",
        default=os.environ.get("DATABASE_URL", ""),
        help="PostgreSQL URL (defaults to DATABASE_URL)",
    )
    return parser.parse_args()


def _converted(column, value: Any) -> Any:
    if value is None:
        return None
    if isinstance(column.type, JSON) and isinstance(value, str):
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return value
    if isinstance(column.type, Boolean):
        return bool(value)
    if isinstance(column.type, DateTime) and isinstance(value, str):
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return value
    if isinstance(column.type, Enum) and column.type.enum_class:
        enum_class = column.type.enum_class
        for member in enum_class:
            if value in (member.name, member.value):
                return member
    return value


def migrate(source_path: Path, target_url: str) -> dict[str, int]:
    if not source_path.is_file():
        raise RuntimeError(f"Legacy SQLite database not found: {source_path}")
    if not target_url.startswith(("postgresql://", "postgresql+psycopg2://")):
        raise RuntimeError("The migration target must be a PostgreSQL DATABASE_URL")

    source = create_engine(f"sqlite:///{source_path}", connect_args={"check_same_thread": False})
    target = create_engine(target_url, pool_pre_ping=True)
    if target.dialect.name != "postgresql":
        raise RuntimeError("The migration target is not PostgreSQL")

    Base.metadata.create_all(bind=target)
    source_metadata = MetaData()
    source_metadata.reflect(bind=source)
    available = set(inspect(source).get_table_names())

    counts: dict[str, int] = {}
    with target.begin() as target_conn:
        non_empty = []
        for table_name in TABLE_ORDER:
            table = Base.metadata.tables[table_name]
            count = target_conn.execute(select(func.count()).select_from(table)).scalar_one()
            if count:
                non_empty.append(f"{table_name} ({count})")
        if non_empty:
            raise RuntimeError(
                "Target Postgres database is not empty; migration stopped to prevent "
                f"duplicates or overwrites: {', '.join(non_empty)}"
            )

        with source.connect() as source_conn:
            for table_name in TABLE_ORDER:
                if table_name not in available:
                    counts[table_name] = 0
                    continue
                source_table = source_metadata.tables[table_name]
                target_table = Base.metadata.tables[table_name]
                rows = source_conn.execute(select(source_table)).mappings().all()

                converted_rows = []
                for row in rows:
                    converted_rows.append(
                        {
                            column.name: _converted(column, row[column.name])
                            for column in target_table.columns
                            if column.name in row
                        }
                    )
                if converted_rows:
                    target_conn.execute(target_table.insert(), converted_rows)
                counts[table_name] = len(converted_rows)

        # Explicit IDs were copied, so move each Postgres sequence past MAX(id).
        for table_name in TABLE_ORDER:
            table = Base.metadata.tables[table_name]
            if "id" not in table.c:
                continue
            sequence = target_conn.execute(
                text("SELECT pg_get_serial_sequence(:table_name, 'id')"),
                {"table_name": table_name},
            ).scalar_one_or_none()
            max_id = target_conn.execute(select(func.max(table.c.id))).scalar_one_or_none()
            if sequence and max_id is not None:
                target_conn.execute(
                    text("SELECT setval(CAST(:sequence AS regclass), :value, true)"),
                    {"sequence": sequence, "value": max_id},
                )

    source.dispose()
    target.dispose()
    return counts


def main() -> None:
    args = _parse_args()
    counts = migrate(Path(args.source).expanduser().resolve(), args.target.strip())
    print("SQLite → PostgreSQL migration completed successfully.")
    for table, count in counts.items():
        print(f"  {table}: {count} row(s)")


if __name__ == "__main__":
    main()
