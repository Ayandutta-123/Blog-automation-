/**
 * Optional Apps Script for product Google Sheet ledger (no service account).
 *
 * Setup:
 * 1. Open your Google Sheet → Extensions → Apps Script
 * 2. Paste this file, save
 * 3. Deploy → New deployment → Web app
 *    - Execute as: Me
 *    - Who has access: Anyone
 * 4. Paste the web-app URL into the product “Google Sheet link” field
 *
 * Expected columns (row 1): Serial No | Slug | Blog Title | Image URL | HTML Page Path
 * Preferred sheet/tab name: Blogs
 */

var HEADERS = ["Serial No", "Slug", "Blog Title", "Image URL", "HTML Page Path"];
var TAB = "Blogs";

function doPost(e) {
  var body = {};
  try {
    body = JSON.parse(e.postData.contents || "{}");
  } catch (err) {
    return json_({ ok: false, error: "Invalid JSON" });
  }

  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(TAB) || ss.getSheets()[0];
  ensureHeader_(sheet);

  var serial = Number(body.serial_no || body["Serial No"] || 0);
  if (!serial || serial < 1) {
    serial = nextSerial_(sheet);
  }

  var row = [
    serial,
    String(body.slug || body.Slug || ""),
    String(body.blog_title || body["Blog Title"] || ""),
    String(body.image_url || body["Image URL"] || ""),
    String(body.html_page_path || body["HTML Page Path"] || ""),
  ];
  sheet.appendRow(row);
  return json_({ ok: true, serial_no: serial, row: row });
}

function ensureHeader_(sheet) {
  var values = sheet.getRange(1, 1, 1, 5).getValues()[0];
  var match = HEADERS.every(function (h, i) {
    return String(values[i] || "").trim() === h;
  });
  if (!match) {
    sheet.getRange(1, 1, 1, 5).setValues([HEADERS]);
  }
}

function nextSerial_(sheet) {
  var last = sheet.getLastRow();
  if (last < 2) return 1;
  var vals = sheet.getRange(2, 1, last, 1).getValues();
  var max = 0;
  vals.forEach(function (r) {
    var n = Number(r[0]);
    if (!isNaN(n)) max = Math.max(max, n);
  });
  return max + 1;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(
    ContentService.MimeType.JSON
  );
}
