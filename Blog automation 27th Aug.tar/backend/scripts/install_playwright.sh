#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
BACKEND="$ROOT/backend"
BROWSERS="$ROOT/storage/playwright-browsers"

cd "$BACKEND"
source .venv/bin/activate

export PLAYWRIGHT_BROWSERS_PATH="$BROWSERS"
mkdir -p "$BROWSERS"

echo "Installing Playwright Chromium to: $BROWSERS"
playwright install chromium
echo "Done. Restart the backend if it is already running."
