from collections.abc import Generator
from datetime import datetime

from sqlalchemy import create_engine, text
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.config import settings


# Configuration validation in app.config rejects SQLite and other runtime
# databases. pool_pre_ping recovers cleanly after Postgres restarts.
engine = create_engine(settings.database_url, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    pass


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def run_schema_migrations() -> None:
    """Apply additive PostgreSQL migrations for databases from older releases."""
    if engine.dialect.name != "postgresql":
        raise RuntimeError(
            f"PostgreSQL is required; configured database dialect is {engine.dialect.name!r}"
        )

    additions = {
        "blog_posts": {
            "content_archetype": "VARCHAR(32) DEFAULT 'tutorial'",
            "product_id": "INTEGER",
            "discovery_snapshot_json": "JSON",
            "research_pack_json": "JSON",
            "published_at": "TIMESTAMP",
            "publish_serial": "INTEGER",
            "include_charts": "BOOLEAN",
            "chart_type": "VARCHAR(32)",
        },
        "scraper_settings": {
            "product_id": "INTEGER",
        },
        "products": {
            "cron_day_of_week": "VARCHAR(8) DEFAULT 'mon'",
            "cron_hour": "INTEGER DEFAULT 9",
            "cron_minute": "INTEGER DEFAULT 0",
            "cron_timezone": "VARCHAR(64) DEFAULT 'Asia/Kolkata'",
            "schedule_enabled": "BOOLEAN DEFAULT TRUE",
            "brand_palette_json": "JSON",
            "content_archetype": "VARCHAR(32) DEFAULT 'tutorial'",
            "discovery_schedules_json": "JSON",
            "pdfs_json": "JSON",
            "topic_selection_mode": "VARCHAR(16) DEFAULT 'manual'",
            "wordpress_json": "JSON",
            "google_json": "JSON",
            "slug": "VARCHAR(128)",
            "google_sheet_url": "VARCHAR(1024)",
            "auto_include_charts": "BOOLEAN DEFAULT TRUE",
            "default_chart_type": "VARCHAR(32) DEFAULT 'auto'",
            "publish_destination": "VARCHAR(16) DEFAULT 'both'",
        },
    }

    with engine.begin() as conn:
        for table, columns in additions.items():
            for column, sql_type in columns.items():
                # Names and types are controlled constants above, never user input.
                conn.execute(
                    text(
                        f'ALTER TABLE "{table}" '
                        f'ADD COLUMN IF NOT EXISTS "{column}" {sql_type}'
                    )
                )

    _backfill_publish_metadata()


def _backfill_publish_metadata() -> None:
    """Fill published timestamps and per-product serials for older posts."""
    with engine.begin() as conn:
        rows = conn.execute(
            text(
                """
                SELECT id, product_id, created_at, feedback_history,
                       published_at, publish_serial
                FROM blog_posts
                WHERE status = 'PUBLISHED'
                ORDER BY id ASC
                """
            )
        ).fetchall()
        if not rows:
            return

        grouped: dict[int, list[tuple[int, object, int | None]]] = {}
        timestamps: dict[int, object] = {}
        for row in rows:
            post_id, product_id, created_at, history, published_at, serial = row
            timestamp = published_at
            if not timestamp and history:
                try:
                    entries = history if isinstance(history, list) else []
                    for entry in reversed(entries):
                        if isinstance(entry, dict) and entry.get("type") == "published":
                            raw = entry.get("timestamp")
                            if raw:
                                timestamp = datetime.fromisoformat(
                                    str(raw).replace("Z", "+00:00")
                                )
                                break
                except (TypeError, ValueError):
                    timestamp = None
            timestamp = timestamp or created_at
            timestamps[post_id] = timestamp
            grouped.setdefault(product_id or 0, []).append((post_id, timestamp, serial))

        for posts in grouped.values():
            posts.sort(key=lambda item: (str(item[1] or ""), item[0]))
            for index, (post_id, _timestamp, existing_serial) in enumerate(posts, start=1):
                conn.execute(
                    text(
                        """
                        UPDATE blog_posts
                        SET published_at = COALESCE(published_at, :timestamp),
                            publish_serial = COALESCE(publish_serial, :serial)
                        WHERE id = :post_id
                        """
                    ),
                    {
                        "timestamp": timestamps[post_id],
                        "serial": existing_serial or index,
                        "post_id": post_id,
                    },
                )
