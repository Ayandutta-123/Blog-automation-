"""Per-product WordPress connect / test / logout / status."""

from __future__ import annotations

from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from loguru import logger
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Product
from app.services.notification_service import emit_notification
from app.services.wordpress_publisher import (
    WordPressError,
    disconnect_wordpress,
    save_wordpress_credentials,
    test_wordpress_connection,
    wordpress_public_status,
)

router = APIRouter(prefix="/api/wordpress", tags=["wordpress"])


class WordPressConnectRequest(BaseModel):
    site_url: str = Field(..., min_length=4, max_length=512)
    username: str = Field(..., min_length=1, max_length=128)
    app_password: str = Field(..., min_length=8, max_length=256)
    auto_publish: bool = True
    post_status: Optional[str] = Field(default=None, pattern="^(publish|draft|pending|private)$")


class WordPressTestRequest(BaseModel):
    site_url: str = Field(..., min_length=4, max_length=512)
    username: str = Field(..., min_length=1, max_length=128)
    app_password: str = Field(..., min_length=8, max_length=256)


def _notify(db: Session, *, type: str, title: str, message: str, severity: str) -> None:
    try:
        emit_notification(
            db,
            type=type,
            title=title,
            message=message[:2000],
            severity=severity,
        )
    except Exception as exc:
        logger.warning("WordPress notification emit failed: {}", exc)


@router.get("/accounts")
def list_wordpress_accounts(db: Session = Depends(get_db)) -> List[dict]:
    """Status for every product — which have WordPress connected."""
    products = db.query(Product).order_by(Product.id.asc()).all()
    return [wordpress_public_status(p) for p in products]


@router.get("/products/{product_id}/status")
def wordpress_status(product_id: int, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return wordpress_public_status(product)


@router.post("/products/{product_id}/connect")
def wordpress_connect(
    product_id: int,
    payload: WordPressConnectRequest,
    db: Session = Depends(get_db),
):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    try:
        status = save_wordpress_credentials(
            db,
            product,
            site_url=payload.site_url,
            username=payload.username,
            app_password=payload.app_password,
            auto_publish=payload.auto_publish,
            post_status=payload.post_status,
        )
        _notify(
            db,
            type="published",
            title=f"WordPress connected · {product.name}",
            message=f"Linked to {status.get('site_url')} as {status.get('display_name') or status.get('username')}",
            severity="success",
        )
        return status
    except WordPressError as exc:
        _notify(
            db,
            type="error",
            title=f"WordPress connect failed · {product.name}",
            message=str(exc),
            severity="error",
        )
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/products/{product_id}/test")
def wordpress_test(
    product_id: int,
    payload: WordPressTestRequest,
    db: Session = Depends(get_db),
):
    """Test credentials without saving (or re-test before connect)."""
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    try:
        result = test_wordpress_connection(
            site_url=payload.site_url,
            username=payload.username,
            app_password=payload.app_password,
        )
        _notify(
            db,
            type="published",
            title=f"WordPress login OK · {product.name}",
            message=f"{result.get('display_name') or result.get('username')} on {result.get('site_url')}",
            severity="success",
        )
        return {"ok": True, "product_id": product_id, **result}
    except WordPressError as exc:
        _notify(
            db,
            type="error",
            title=f"WordPress test failed · {product.name}",
            message=str(exc),
            severity="error",
        )
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/products/{product_id}/logout")
@router.delete("/products/{product_id}")
def wordpress_logout(product_id: int, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    status = disconnect_wordpress(db, product)
    _notify(
        db,
        type="published",
        title=f"WordPress disconnected · {product.name}",
        message="Credentials cleared for this product.",
        severity="success",
    )
    return status
