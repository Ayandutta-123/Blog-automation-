from __future__ import annotations

from typing import Any, Optional

from fastapi import APIRouter, BackgroundTasks, HTTPException, Request
from loguru import logger
from pydantic import BaseModel

from app.services.seo_pipeline import BlogSeoValidationError
from app.services.workflow import approve_post, redo_post, select_topic_and_generate


def _approve_or_raise(post_id: int):
    try:
        result = approve_post(post_id)
    except BlogSeoValidationError as exc:
        raise HTTPException(
            status_code=422,
            detail={
                "message": "Publish blocked — SEO validation failed",
                "failures": exc.failures,
            },
        ) from exc
    if not result:
        raise HTTPException(status_code=404, detail="Post not found")
    return result

router = APIRouter(prefix="/api/teams", tags=["teams"])


class TeamsActionPayload(BaseModel):
    action: str
    blog_post_id: int
    topic_title: Optional[str] = None
    feedback: Optional[str] = None


class TeamsTestRequest(BaseModel):
    webhook_url: Optional[str] = None
    channel_name: Optional[str] = "Blog automation Chatbot"


@router.post("/notify-review/{post_id}")
def notify_review_teams(post_id: int):
    """Send the real Review Required card for a blog post to Teams."""
    from app.database import SessionLocal
    from app.models import BlogPost
    from app.services.teams_notifier import notify_review_required

    db = SessionLocal()
    try:
        post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
        if not post:
            raise HTTPException(status_code=404, detail="Post not found")
        notify_review_required(post)
        title = post.title_tag or post.selected_topic_title or f"Post #{post.id}"
        return {"success": True, "message": f"Review card sent to Teams: {title}"}
    finally:
        db.close()


@router.post("/test")
def test_teams_notification(payload: TeamsTestRequest = TeamsTestRequest()):
    """Send a test Adaptive Card to the configured Teams incoming webhook."""
    from app.services.teams_notifier import send_teams_test_message

    ok, message = send_teams_test_message(
        channel_hint=payload.channel_name or "Blog automation Chatbot",
        webhook_url=payload.webhook_url,
    )
    if not ok:
        raise HTTPException(status_code=400, detail=message)
    return {"success": True, "message": message}


@router.post("/topic-select")
async def teams_topic_select(
    request: Request,
    background_tasks: BackgroundTasks,
):
    body: dict[str, Any] = await request.json()
    logger.info(f"Teams topic-select webhook: {body}")

    action = body.get("action", "")
    post_id = body.get("blog_post_id")
    topic_title = body.get("topic_title")

    if action != "select_topic" or not post_id or not topic_title:
        raise HTTPException(status_code=400, detail="Invalid payload")

    background_tasks.add_task(
        select_topic_and_generate,
        int(post_id),
        topic_title,
        None,
    )
    return {"message": "Topic selected via Teams", "post_id": post_id}


@router.post("/approve")
async def teams_approve(request: Request, background_tasks: BackgroundTasks):
    body: dict[str, Any] = await request.json()
    logger.info(f"Teams approve webhook: {body}")

    action = body.get("action", "")
    post_id = body.get("blog_post_id")

    if action == "approve" and post_id:
        result = _approve_or_raise(int(post_id))
        return {"message": "Published via Teams", "slug": result.slug}

    if action == "redo" and post_id:
        feedback = body.get("feedback", "Please revise the content based on editorial review.")
        background_tasks.add_task(redo_post, int(post_id), feedback)
        return {"message": "Redo requested via Teams", "post_id": post_id}

    raise HTTPException(status_code=400, detail="Invalid payload")


@router.post("/webhook")
async def teams_unified_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
):
    """Unified webhook endpoint for all Teams Adaptive Card actions."""
    body: dict[str, Any] = await request.json()
    logger.info(f"Teams unified webhook: {body}")

    action = body.get("action", "")
    post_id = body.get("blog_post_id")

    if not post_id:
        raise HTTPException(status_code=400, detail="Missing blog_post_id")

    post_id = int(post_id)

    if action == "select_topic":
        topic_title = body.get("topic_title")
        if not topic_title:
            raise HTTPException(status_code=400, detail="Missing topic_title")
        background_tasks.add_task(select_topic_and_generate, post_id, topic_title, None)
        return {"message": "Topic selected", "post_id": post_id}

    if action == "approve":
        result = _approve_or_raise(post_id)
        return {"message": "Published", "slug": result.slug}

    if action == "redo":
        feedback = body.get("feedback", "Please revise based on editorial feedback.")
        background_tasks.add_task(redo_post, post_id, feedback)
        return {"message": "Redo started", "post_id": post_id}

    raise HTTPException(status_code=400, detail=f"Unknown action: {action}")
