from typing import List, Literal, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Product
from app.services.content_archetypes import list_archetypes_for_api, normalize_archetype
from app.services.product_context import get_product
from app.services.runtime_config import get_config_value, save_single_integration
from app.services.scheduler import reschedule_all_discovery_jobs
from app.services.workflow import get_default_content_archetype, get_topic_selection_mode

router = APIRouter(prefix="/api/workflow", tags=["workflow"])


class TopicModeResponse(BaseModel):
    mode: str
    product_id: Optional[int] = None


class TopicModeUpdate(BaseModel):
    mode: Literal["manual", "auto", "hybrid"]
    product_id: Optional[int] = None


class ContentArchetypeResponse(BaseModel):
    archetype: str
    archetypes: List[dict]


class ContentArchetypeUpdate(BaseModel):
    archetype: Literal["quick_faq", "news_update", "tutorial", "listicle", "pillar"]


def _resolve_product_id(db: Session, product_id: Optional[int]) -> Optional[int]:
    if product_id:
        return product_id
    raw = get_config_value("active_product_id", db)
    if raw and str(raw).isdigit():
        return int(raw)
    product = get_product(db, None)
    return product.id if product else None


@router.get("/topic-mode", response_model=TopicModeResponse)
def read_topic_mode(product_id: Optional[int] = None, db: Session = Depends(get_db)):
    """Return the topic mode for a product (defaults to the active product)."""
    resolved = _resolve_product_id(db, product_id)
    return TopicModeResponse(mode=get_topic_selection_mode(resolved), product_id=resolved)


@router.put("/topic-mode", response_model=TopicModeResponse)
def write_topic_mode(payload: TopicModeUpdate, db: Session = Depends(get_db)):
    """Save topic mode on the given (or active) product. Prefer PATCH /api/products/{id}."""
    resolved = _resolve_product_id(db, payload.product_id)
    if not resolved:
        raise HTTPException(status_code=404, detail="No product found")

    product = db.query(Product).filter(Product.id == resolved).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    product.topic_selection_mode = payload.mode
    if payload.mode == "manual":
        product.schedule_enabled = False
    # Keep a legacy global mirror so older clients / Integrations still see a value
    save_single_integration("topic_selection_mode", payload.mode, db)
    db.commit()
    reschedule_all_discovery_jobs()
    return TopicModeResponse(mode=get_topic_selection_mode(resolved), product_id=resolved)


@router.get("/content-archetype", response_model=ContentArchetypeResponse)
def read_content_archetype():
    return ContentArchetypeResponse(
        archetype=get_default_content_archetype(),
        archetypes=list_archetypes_for_api(),
    )


@router.put("/content-archetype", response_model=ContentArchetypeResponse)
def write_content_archetype(payload: ContentArchetypeUpdate, db: Session = Depends(get_db)):
    archetype = normalize_archetype(payload.archetype)
    save_single_integration("content_archetype", archetype, db)
    return ContentArchetypeResponse(
        archetype=get_default_content_archetype(),
        archetypes=list_archetypes_for_api(),
    )
