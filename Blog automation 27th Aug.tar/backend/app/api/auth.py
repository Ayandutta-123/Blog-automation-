from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.database import get_db
from app.services.auth import (
    change_password,
    authenticate,
    authenticate_user,
    check_rate_limit,
    create_user,
    clear_login_failures,
    create_session,
    get_expected_username,
    get_stored_password_hash,
    get_session_identity,
    record_login_failure,
    revoke_session,
    validate_session,
    change_user_password,
)
from app.models import DashboardRole

router = APIRouter(prefix="/api/auth", tags=["auth"])


class LoginRequest(BaseModel):
    username: str = Field(..., min_length=1, max_length=128)
    password: str = Field(..., min_length=1, max_length=256)


class LoginResponse(BaseModel):
    token: str
    message: str = "Signed in"


class SessionResponse(BaseModel):
    authenticated: bool
    username: Optional[str] = None
    role: Optional[str] = None


class ChangePasswordRequest(BaseModel):
    current_password: str = Field(..., min_length=1, max_length=256)
    new_password: str = Field(..., min_length=8, max_length=256)


class CreateUserRequest(BaseModel):
    username: str = Field(..., min_length=1, max_length=64)
    password: str = Field(..., min_length=1, max_length=256)
    role: Optional[str] = Field(
        default="user",
        description="Role for the dashboard user: admin or user",
    )


def _client_key(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()[:128]
    if request.client and request.client.host:
        return request.client.host
    return "unknown"


def _extract_token(authorization: Optional[str]) -> Optional[str]:
    if not authorization:
        return None
    if authorization.lower().startswith("bearer "):
        return authorization[7:].strip()
    return None


def require_session(
    authorization: Optional[str] = Header(default=None),
    db: Session = Depends(get_db),
) -> str:
    token = _extract_token(authorization)
    if not validate_session(token, db):
        raise HTTPException(status_code=401, detail="Not authenticated")
    return token  # type: ignore[return-value]


@router.post("/login", response_model=LoginResponse)
def login(payload: LoginRequest, request: Request, db: Session = Depends(get_db)):
    key = _client_key(request)
    locked = check_rate_limit(key)
    if locked:
        raise HTTPException(status_code=429, detail=locked)

    user = authenticate_user(payload.username, payload.password, db)
    if user:
        clear_login_failures(key)
        token = create_session(
            db,
            user_id=user.id,
            username=user.username,
            role=user.role.value,
        )
        return LoginResponse(token=token)

    # If multi-user accounts exist, treat wrong credentials as invalid (401),
    # even if the legacy env-based admin is not configured.
    from app.models import DashboardUser as _DashboardUser

    has_any_users = bool(db.query(_DashboardUser).limit(1).first())

    if has_any_users:
        record_login_failure(key)
        raise HTTPException(status_code=401, detail="Invalid credentials")

    # Fallback to legacy single-admin login (env-based) for backward compatibility.
    if not get_expected_username() or not get_stored_password_hash(db):
        # Misconfigured server — do not leak details to the client
        raise HTTPException(status_code=503, detail="Sign-in is temporarily unavailable")

    if not authenticate(payload.username, payload.password, db):
        record_login_failure(key)
        raise HTTPException(status_code=401, detail="Invalid credentials")

    clear_login_failures(key)
    token = create_session(
        db,
        username=get_expected_username(),
        role=DashboardRole.ADMIN.value,
    )
    return LoginResponse(token=token)


@router.post("/logout")
def logout(
    authorization: Optional[str] = Header(default=None),
    db: Session = Depends(get_db),
):
    token = _extract_token(authorization)
    revoke_session(token, db)
    return {"message": "Signed out"}


@router.get("/session", response_model=SessionResponse)
def session_status(
    authorization: Optional[str] = Header(default=None),
    db: Session = Depends(get_db),
):
    token = _extract_token(authorization)
    if not validate_session(token, db):
        return SessionResponse(authenticated=False)

    identity = get_session_identity(token, db)
    return SessionResponse(
        authenticated=True,
        username=(identity or {}).get("username") if identity else None,
        role=(identity or {}).get("role") if identity else None,
    )


@router.post("/change-password")
def update_password(
    payload: ChangePasswordRequest,
    db: Session = Depends(get_db),
    _token: str = Depends(require_session),
):
    try:
        identity = get_session_identity(_token, db) or {}
        user_id = identity.get("user_id")
        if isinstance(user_id, int):
            change_user_password(
                db=db,
                user_id=user_id,
                current_password=payload.current_password,
                new_password=payload.new_password,
            )
        else:
            # Legacy env-based admin password
            change_password(payload.current_password, payload.new_password, db)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"message": "Password updated successfully"}


@router.post("/users/create")
def create_dashboard_user(
    payload: CreateUserRequest,
    db: Session = Depends(get_db),
    _token: str = Depends(require_session),
):
    identity = get_session_identity(_token, db)
    if not identity or identity.get("role") != DashboardRole.ADMIN.value:
        raise HTTPException(status_code=403, detail="Admin access required")

    role_raw = (payload.role or "user").strip().lower()
    role = DashboardRole.ADMIN if role_raw == "admin" else DashboardRole.USER
    try:
        user = create_user(
            db=db,
            username=payload.username,
            password=payload.password,
            role=role,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return {
        "id": user.id,
        "username": user.username,
        "role": user.role.value,
        "is_active": user.is_active,
    }
