from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.schemas_integrations import (
    INTEGRATION_GROUPS,
    IntegrationFieldResponse,
    IntegrationKeyUpdate,
    IntegrationsResponse,
    IntegrationsUpdateRequest,
)
from app.services.runtime_config import (
    delete_single_integration,
    get_integrations_view,
    save_single_integration,
    update_integrations,
)

router = APIRouter(prefix="/api/integrations", tags=["integrations"])


def _to_response(views) -> IntegrationsResponse:
    return IntegrationsResponse(
        fields=[
            IntegrationFieldResponse(
                key=v.key,
                label=v.label,
                description=v.description,
                group=v.group,
                secret=v.secret,
                is_set=v.is_set,
                source=v.source,
                is_placeholder=v.is_placeholder,
                value=v.value,
                masked_value=v.masked_value,
            )
            for v in views
        ],
        groups=INTEGRATION_GROUPS,
    )


def _field_to_response(view) -> IntegrationFieldResponse:
    return IntegrationFieldResponse(
        key=view.key,
        label=view.label,
        description=view.description,
        group=view.group,
        secret=view.secret,
        is_set=view.is_set,
        source=view.source,
        is_placeholder=view.is_placeholder,
        value=view.value,
        masked_value=view.masked_value,
    )


@router.get("", response_model=IntegrationsResponse)
def get_integrations(db: Session = Depends(get_db)):
    return _to_response(get_integrations_view(db))


@router.put("/{key}", response_model=IntegrationFieldResponse)
def save_integration_key(
    key: str,
    payload: IntegrationKeyUpdate,
    db: Session = Depends(get_db),
):
    view = save_single_integration(key, payload.value, db)
    return _field_to_response(view)


@router.delete("/{key}", response_model=IntegrationFieldResponse)
def delete_integration_key(key: str, db: Session = Depends(get_db)):
    view = delete_single_integration(key, db)
    return _field_to_response(view)


@router.put("", response_model=IntegrationsResponse)
def update_integration_settings(
    payload: IntegrationsUpdateRequest,
    db: Session = Depends(get_db),
):
    updates = payload.to_updates()
    views = update_integrations(updates, db)
    return _to_response(views)


@router.get("/minio/status")
def minio_status():
    """Check MinIO S3 connectivity using configured credentials."""
    from app.services.minio_storage import connection_status

    return connection_status()
