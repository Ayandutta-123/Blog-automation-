from fastapi import APIRouter

from app.database import SessionLocal
from app.schemas import NotificationsResponse
from app.services.notification_service import build_notifications

router = APIRouter(prefix="/api/notifications", tags=["notifications"])


@router.get("", response_model=NotificationsResponse)
def list_notifications():
    db = SessionLocal()
    try:
        items = build_notifications(db)
        unread_action = sum(1 for n in items if n["severity"] == "action")
        unread_errors = sum(1 for n in items if n["severity"] == "error")
        unread_success = sum(1 for n in items if n["severity"] == "success")
        return {
            "items": items,
            "counts": {
                "total": len(items),
                "action": unread_action,
                "error": unread_errors,
                "success": unread_success,
            },
        }
    finally:
        db.close()
