from __future__ import annotations

from typing import List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import ScraperCategory, ScraperSettings
from app.schemas import (
    ScraperSettingBulkCreate,
    ScraperSettingBulkResponse,
    ScraperSettingCreate,
    ScraperSettingResponse,
    ScraperSettingUpdate,
)
from app.services.notification_service import emit_notification
from app.services.scraper_bulk import insert_scraper_values, parse_spreadsheet_values, split_scraper_values

router = APIRouter(prefix="/api/settings", tags=["settings"])


@router.get("", response_model=List[ScraperSettingResponse])
def list_settings(
    category: Optional[ScraperCategory] = None,
    product_id: Optional[int] = None,
    db: Session = Depends(get_db),
):
    query = db.query(ScraperSettings)
    if category:
        query = query.filter(ScraperSettings.category == category)
    if product_id is not None:
        query = query.filter(ScraperSettings.product_id == product_id)
    return query.order_by(ScraperSettings.id).all()


@router.post("", response_model=ScraperSettingResponse, status_code=201)
def create_setting(payload: ScraperSettingCreate, db: Session = Depends(get_db)):
    values = split_scraper_values(payload.value)
    if not values:
        raise HTTPException(status_code=400, detail="Value cannot be empty")
    if len(values) > 1:
        added, skipped, parsed = insert_scraper_values(
            db,
            category=payload.category,
            values=values,
            product_id=payload.product_id,
            added_by=payload.added_by,
        )
        if not added:
            raise HTTPException(
                status_code=400,
                detail="All values already exist for this product.",
            )
        _notify_bulk(db, payload.category, added, skipped, parsed)
        return added[0]
    value = values[0]
    if payload.category == ScraperCategory.RSS_FEED:
        from app.services.scraper import normalize_rss_feed_url

        value = normalize_rss_feed_url(value)
    setting = ScraperSettings(
        category=payload.category,
        value=value,
        added_by=payload.added_by,
        is_active=True,
        product_id=payload.product_id,
    )
    db.add(setting)
    db.commit()
    db.refresh(setting)
    label = {
        ScraperCategory.INDUSTRY_KEYWORD: "Keyword",
        ScraperCategory.COMPETITOR_URL: "Competitor URL",
        ScraperCategory.RSS_FEED: "RSS feed",
    }.get(setting.category, "Scraper target")
    emit_notification(
        db,
        type="published",
        title=f"{label} saved",
        message=f'Added "{setting.value}" to scraper targets.',
        severity="success",
    )
    return setting


@router.post("/bulk", response_model=ScraperSettingBulkResponse)
def create_settings_bulk(payload: ScraperSettingBulkCreate, db: Session = Depends(get_db)):
    values = split_scraper_values(payload.value)
    if not values:
        raise HTTPException(status_code=400, detail="No values found after splitting on commas")
    added, skipped, parsed = insert_scraper_values(
        db,
        category=payload.category,
        values=values,
        product_id=payload.product_id,
        added_by=payload.added_by,
    )
    if not added and parsed:
        raise HTTPException(
            status_code=400,
            detail="All values already exist for this product.",
        )
    _notify_bulk(db, payload.category, added, skipped, parsed)
    return ScraperSettingBulkResponse(
        added=added,
        added_count=len(added),
        skipped_count=skipped,
        total_parsed=parsed,
    )


@router.post("/upload", response_model=ScraperSettingBulkResponse)
async def upload_settings_spreadsheet(
    category: ScraperCategory = Form(...),
    product_id: Optional[int] = Form(None),
    added_by: str = Form("Admin"),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    filename = (file.filename or "").lower()
    if not filename.endswith((".xlsx", ".xlsm", ".csv", ".txt")):
        raise HTTPException(
            status_code=400,
            detail="Upload an Excel (.xlsx) or CSV file.",
        )
    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="Uploaded file is empty")
    try:
        values = parse_spreadsheet_values(data, filename)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Could not read spreadsheet: {exc}") from exc
    if not values:
        raise HTTPException(
            status_code=400,
            detail="No keywords, URLs, or feeds found in the file.",
        )
    added, skipped, parsed = insert_scraper_values(
        db,
        category=category,
        values=values,
        product_id=product_id,
        added_by=added_by,
    )
    if not added and parsed:
        raise HTTPException(
            status_code=400,
            detail="All values from the file already exist for this product.",
        )
    _notify_bulk(db, category, added, skipped, parsed)
    return ScraperSettingBulkResponse(
        added=added,
        added_count=len(added),
        skipped_count=skipped,
        total_parsed=parsed,
    )


def _notify_bulk(
    db: Session,
    category: ScraperCategory,
    added: list,
    skipped: int,
    parsed: int,
) -> None:
    label = {
        ScraperCategory.INDUSTRY_KEYWORD: "keywords",
        ScraperCategory.COMPETITOR_URL: "competitor URLs",
        ScraperCategory.RSS_FEED: "RSS feeds",
    }.get(category, "targets")
    extra = f" ({skipped} already existed)" if skipped else ""
    emit_notification(
        db,
        type="published",
        title=f"{len(added)} {label} saved",
        message=f"Added {len(added)} of {parsed} {label}{extra}.",
        severity="success",
    )


@router.patch("/{setting_id}", response_model=ScraperSettingResponse)
def update_setting(
    setting_id: int,
    payload: ScraperSettingUpdate,
    db: Session = Depends(get_db),
):
    setting = db.query(ScraperSettings).filter(ScraperSettings.id == setting_id).first()
    if not setting:
        raise HTTPException(status_code=404, detail="Setting not found")
    if payload.value is not None:
        value = payload.value.strip()
        if setting.category == ScraperCategory.RSS_FEED:
            from app.services.scraper import normalize_rss_feed_url

            value = normalize_rss_feed_url(value)
        setting.value = value
    if payload.is_active is not None:
        setting.is_active = payload.is_active
    db.commit()
    db.refresh(setting)
    return setting


@router.delete("/{setting_id}", status_code=204)
def delete_setting(setting_id: int, db: Session = Depends(get_db)):
    setting = db.query(ScraperSettings).filter(ScraperSettings.id == setting_id).first()
    if not setting:
        raise HTTPException(status_code=404, detail="Setting not found")
    db.delete(setting)
    db.commit()
