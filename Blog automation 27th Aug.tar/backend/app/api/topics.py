from __future__ import annotations

import re
from typing import List

from fastapi import APIRouter, BackgroundTasks, Body, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import BlogPost, BlogStatus
from app.schemas import BlogPostDetail, BlogPostSummary, TopicAutoSelectRequest, TopicSelectRequest
from app.services.workflow import auto_select_topic, select_topic_and_generate

router = APIRouter(prefix="/api/topics", tags=["topics"])


@router.get("/pending", response_model=List[BlogPostSummary])
def list_pending_topics(db: Session = Depends(get_db)):
    return (
        db.query(BlogPost)
        .filter(BlogPost.status == BlogStatus.PENDING_TOPIC)
        .order_by(BlogPost.created_at.desc())
        .all()
    )


@router.get("/{post_id}", response_model=BlogPostDetail)
def get_topic_post(post_id: int, db: Session = Depends(get_db)):
    from app.services.blog_structure import layout_needs_hero_lock
    from app.services.content_enricher import lock_hero_before_content
    from app.services.topic_synthesis import (
        attach_source_links_to_topics,
        flatten_topics,
    )

    post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    if post.html_content and post.slug and layout_needs_hero_lock(post.html_content):
        post.html_content = lock_hero_before_content(post.html_content, post.slug)
        db.commit()
        db.refresh(post)

    # Mandatory for all products: backfill missing source links from discovery snapshot
    topics = post.scraped_topics_json
    snapshot = post.discovery_snapshot_json or {}
    if (
        post.status == BlogStatus.PENDING_TOPIC
        and isinstance(topics, dict)
        and snapshot
    ):
        missing = any(
            not (t.get("source_links") or [])
            for t in flatten_topics(topics)
        )
        if missing:
            post.scraped_topics_json = attach_source_links_to_topics(topics, snapshot)
            db.commit()
            db.refresh(post)

    return post


@router.post("/{post_id}/select", status_code=202)
def select_topic(
    post_id: int,
    payload: TopicSelectRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    if post.status != BlogStatus.PENDING_TOPIC:
        raise HTTPException(status_code=400, detail=f"Post is in status {post.status}")

    primary_keyword = None
    from app.services.topic_synthesis import flatten_topics

    if not payload.custom and post.scraped_topics_json:
        for t in flatten_topics(post.scraped_topics_json):
            if t.get("title") == payload.topic_title:
                primary_keyword = t.get("primary_keyword")
                break
    if payload.custom:
        # Prefer a clean keyword phrase from the custom topic (not the raw typo-filled sentence)
        cleaned = re.sub(r"\s+", " ", (payload.topic_title or "").strip())
        primary_keyword = cleaned.lower()[:80] or cleaned[:80]

    post.selected_topic_title = payload.topic_title
    if payload.content_archetype:
        post.content_archetype = payload.content_archetype
    if payload.include_charts is not None:
        post.include_charts = bool(payload.include_charts)
    if payload.chart_type is not None:
        from app.services.content_enricher import normalize_chart_type

        post.chart_type = normalize_chart_type(payload.chart_type)
    post.status = BlogStatus.GENERATING
    db.commit()

    background_tasks.add_task(
        select_topic_and_generate,
        post_id,
        payload.topic_title,
        primary_keyword,
        payload.content_archetype,
        payload.include_charts,
        payload.chart_type,
    )
    return {"message": "Topic selected. Content generation started.", "post_id": post_id}


@router.post("/{post_id}/auto-select", status_code=202)
def auto_select(
    post_id: int,
    background_tasks: BackgroundTasks,
    payload: TopicAutoSelectRequest = Body(default_factory=TopicAutoSelectRequest),
    db: Session = Depends(get_db),
):
    post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
    if not post:
        raise HTTPException(status_code=404, detail="Post not found")
    if post.status != BlogStatus.PENDING_TOPIC:
        raise HTTPException(status_code=400, detail=f"Post is in status {post.status}")
    if not post.scraped_topics_json:
        raise HTTPException(status_code=400, detail="No topics available")
    from app.services.topic_synthesis import flatten_topics

    if not flatten_topics(post.scraped_topics_json):
        raise HTTPException(status_code=400, detail="No topics available")

    if payload.include_charts is not None:
        post.include_charts = bool(payload.include_charts)
    if payload.chart_type is not None:
        from app.services.content_enricher import normalize_chart_type

        post.chart_type = normalize_chart_type(payload.chart_type)
        db.commit()
    elif payload.include_charts is not None:
        db.commit()

    background_tasks.add_task(
        auto_select_topic,
        post_id,
        payload.content_archetype,
        payload.include_charts,
        payload.chart_type,
    )
    return {"message": "Auto-selecting best topic. Content generation started.", "post_id": post_id}
