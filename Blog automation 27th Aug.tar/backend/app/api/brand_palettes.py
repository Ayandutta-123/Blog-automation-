from __future__ import annotations

from typing import Dict, List

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.database import get_db
from app.services.brand_palette_batches import (
    create_palette_batch,
    delete_palette_batch,
    list_palette_batches,
)

router = APIRouter(prefix="/api/brand-palettes", tags=["brand-palettes"])


class PaletteColors(BaseModel):
    primary: str = Field(..., pattern=r"^#[0-9A-Fa-f]{6}$")
    navy: str = Field(..., pattern=r"^#[0-9A-Fa-f]{6}$")
    accent: str = Field(..., pattern=r"^#[0-9A-Fa-f]{6}$")
    cta: str = Field(..., pattern=r"^#[0-9A-Fa-f]{6}$")
    link: str = Field(..., pattern=r"^#[0-9A-Fa-f]{6}$")


class PaletteBatchCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=80)
    colors: PaletteColors


class PaletteBatchResponse(BaseModel):
    id: str
    name: str
    builtin: bool = False
    colors: Dict[str, str]


class PaletteBatchListResponse(BaseModel):
    batches: List[PaletteBatchResponse]


@router.get("", response_model=PaletteBatchListResponse)
def get_brand_palette_batches(db: Session = Depends(get_db)):
    batches = list_palette_batches(db)
    return PaletteBatchListResponse(batches=[PaletteBatchResponse(**b) for b in batches])


@router.post("", response_model=PaletteBatchResponse, status_code=201)
def add_brand_palette_batch(payload: PaletteBatchCreate, db: Session = Depends(get_db)):
    try:
        batch = create_palette_batch(
            db,
            name=payload.name,
            colors=payload.colors.model_dump(),
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return PaletteBatchResponse(**batch)


@router.delete("/{batch_id}", response_model=PaletteBatchListResponse)
def remove_brand_palette_batch(batch_id: str, db: Session = Depends(get_db)):
    try:
        batches = delete_palette_batch(db, batch_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return PaletteBatchListResponse(batches=[PaletteBatchResponse(**b) for b in batches])
