"""Per-product Google Blogger connect / test / logout."""

from __future__ import annotations

from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from loguru import logger
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Product
from app.services.google_blogger_publisher import (
    GoogleBloggerError,
    disconnect_google,
    google_public_status,
    save_google_credentials,
    test_google_connection,
)
from app.services.notification_service import emit_notification

router = APIRouter(prefix="/api/google", tags=["google"])


class GoogleConnectRequest(BaseModel):
    blog_id: str = Field(..., min_length=1, max_length=128)
    access_token: str = Field(..., min_length=10, max_length=4096)
    refresh_token: Optional[str] = Field(default="", max_length=4096)
    client_id: Optional[str] = Field(default="", max_length=512)
    client_secret: Optional[str] = Field(default="", max_length=512)
    is_draft: bool = False


class GoogleTestRequest(BaseModel):
    blog_id: str = Field(..., min_length=1, max_length=128)
    access_token: str = Field(..., min_length=10, max_length=4096)
    refresh_token: Optional[str] = Field(default="", max_length=4096)
    client_id: Optional[str] = Field(default="", max_length=512)
    client_secret: Optional[str] = Field(default="", max_length=512)


def _notify(db: Session, *, type: str, title: str, message: str, severity: str) -> None:
    try:
        emit_notification(db, type=type, title=title, message=message[:2000], severity=severity)
    except Exception as exc:
        logger.warning("Google notification emit failed: {}", exc)


@router.get("/accounts")
def list_accounts(db: Session = Depends(get_db)) -> List[dict]:
    products = db.query(Product).order_by(Product.id.asc()).all()
    return [google_public_status(p) for p in products]


@router.get("/products/{product_id}/status")
def status(product_id: int, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return google_public_status(product)


@router.post("/products/{product_id}/connect")
def connect(product_id: int, payload: GoogleConnectRequest, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    try:
        status = save_google_credentials(
            db,
            product,
            blog_id=payload.blog_id,
            access_token=payload.access_token,
            refresh_token=payload.refresh_token or "",
            client_id=payload.client_id or "",
            client_secret=payload.client_secret or "",
            is_draft=payload.is_draft,
        )
        _notify(
            db,
            type="published",
            title=f"Google Blogger connected · {product.name}",
            message=f"{status.get('blog_name') or status.get('blog_id')} · {status.get('blog_url') or ''}",
            severity="success",
        )
        return status
    except GoogleBloggerError as exc:
        _notify(
            db,
            type="error",
            title=f"Google Blogger connect failed · {product.name}",
            message=str(exc),
            severity="error",
        )
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/products/{product_id}/test")
def test(product_id: int, payload: GoogleTestRequest, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    try:
        result = test_google_connection(
            blog_id=payload.blog_id,
            access_token=payload.access_token,
            refresh_token=payload.refresh_token or "",
            client_id=payload.client_id or "",
            client_secret=payload.client_secret or "",
        )
        _notify(
            db,
            type="published",
            title=f"Google Blogger OK · {product.name}",
            message=f"{result.get('blog_name') or result.get('blog_id')}",
            severity="success",
        )
        return {"ok": True, "product_id": product_id, **result}
    except GoogleBloggerError as exc:
        _notify(
            db,
            type="error",
            title=f"Google Blogger test failed · {product.name}",
            message=str(exc),
            severity="error",
        )
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/products/{product_id}/logout")
@router.delete("/products/{product_id}")
def logout(product_id: int, db: Session = Depends(get_db)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    status = disconnect_google(db, product)
    _notify(
        db,
        type="published",
        title=f"Google Blogger disconnected · {product.name}",
        message="Credentials cleared for this product.",
        severity="success",
    )
    return status
