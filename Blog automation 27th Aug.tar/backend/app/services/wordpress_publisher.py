"""WordPress REST API publisher — per-product credentials.

Many hosts (nginx/CGI) strip the Authorization header, so Application Password
Basic-auth never reaches WordPress (always `rest_not_logged_in`). This module:

1. Tries REST Basic auth (Application Password) first
2. Falls back to cookie login (normal WordPress password) + REST nonce
"""

from __future__ import annotations

import base64
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urljoin, urlparse

import httpx
from loguru import logger
from sqlalchemy.orm import Session

from app.models import Product


class WordPressError(Exception):
    pass


def _normalize_site_url(raw: str) -> str:
    value = (raw or "").strip()
    if not value:
        raise WordPressError("WordPress site URL is required")
    if not value.startswith(("http://", "https://")):
        value = f"https://{value}"
    value = re.sub(r"/wp-admin/?.*$", "", value, flags=re.I)
    value = re.sub(r"/wp-login\.php.*$", "", value, flags=re.I)
    value = value.rstrip("/")
    parsed = urlparse(value)
    if not parsed.netloc:
        raise WordPressError(f"Invalid WordPress site URL: {raw}")
    return f"{parsed.scheme}://{parsed.netloc}"


def get_wordpress_config(product: Product) -> dict[str, Any]:
    raw = getattr(product, "wordpress_json", None) or {}
    return dict(raw) if isinstance(raw, dict) else {}


def wordpress_configured(product: Product) -> bool:
    cfg = get_wordpress_config(product)
    return bool(
        cfg.get("site_url")
        and cfg.get("username")
        and cfg.get("app_password")
        and cfg.get("connected")
    )


def wordpress_public_status(product: Product) -> dict[str, Any]:
    cfg = get_wordpress_config(product)
    connected = wordpress_configured(product)
    return {
        "product_id": product.id,
        "product_name": product.name,
        "connected": connected,
        "site_url": cfg.get("site_url") or None,
        "username": cfg.get("username") or None,
        "display_name": cfg.get("display_name") or None,
        "user_id": cfg.get("user_id"),
        "connected_at": cfg.get("connected_at"),
        "auto_publish": bool(cfg.get("auto_publish", True)),
        "post_status": cfg.get("post_status")
        or ("publish" if cfg.get("auto_publish", True) else "draft"),
        "has_password": bool(cfg.get("app_password")),
        "auth_mode": cfg.get("auth_mode") or None,
    }


def _clean_password(password: str) -> str:
    # Application passwords are often shown with spaces — strip for Basic auth
    return re.sub(r"\s+", "", password or "")


def _basic_auth_header(username: str, password: str) -> dict[str, str]:
    token = base64.b64encode(
        f"{username}:{_clean_password(password)}".encode("utf-8")
    ).decode("ascii")
    return {"Authorization": f"Basic {token}"}


def _api_base(site_url: str) -> str:
    return f"{_normalize_site_url(site_url)}/wp-json/wp/v2/"


def _parse_login_error(html: str) -> str:
    m = re.search(
        r'id=["\']login_error["\'][^>]*>([\s\S]*?)</div>',
        html or "",
        flags=re.I,
    )
    if not m:
        return ""
    text = re.sub(r"<[^>]+>", " ", m.group(1))
    text = re.sub(r"\s+", " ", text).strip()
    return text[:300]


def _extract_rest_nonce(html: str) -> Optional[str]:
    patterns = [
        r'wpApiSettings\s*=\s*\{[^}]*"nonce"\s*:\s*"([a-zA-Z0-9]+)"',
        r'"nonce"\s*:\s*"([a-zA-Z0-9]+)"[^}]*"root"\s*:\s*"[^"]*wp-json',
        r'createNonce\([\'"]wp_rest[\'"]\)\s*,\s*[\'"]([a-zA-Z0-9]+)[\'"]',
        r'wp\.apiFetch\.createNonceMiddleware\(\s*[\'"]([a-zA-Z0-9]+)[\'"]\s*\)',
        r'restNonce["\']?\s*[:=]\s*["\']([a-zA-Z0-9]+)["\']',
        r'X-WP-Nonce["\']?\s*[:=]\s*["\']([a-zA-Z0-9]+)["\']',
    ]
    for pat in patterns:
        m = re.search(pat, html or "", flags=re.I)
        if m:
            return m.group(1)
    return None


def _cookie_login(client: httpx.Client, site_url: str, username: str, password: str) -> str:
    """Log in via wp-login.php. Returns wp_rest nonce for authenticated REST calls."""
    login_url = f"{site_url}/wp-login.php"
    client.cookies.set("wordpress_test_cookie", "WP Cookie check")
    client.get(login_url, headers={"Accept": "text/html"})

    # Try raw password first (normal login), then spaced-stripped (app password pasted)
    candidates = []
    raw = (password or "").strip()
    cleaned = _clean_password(password)
    if raw:
        candidates.append(raw)
    if cleaned and cleaned != raw:
        candidates.append(cleaned)

    last_error = ""
    for pwd in candidates:
        resp = client.post(
            login_url,
            data={
                "log": username,
                "pwd": pwd,
                "rememberme": "forever",
                "wp-submit": "Log In",
                "redirect_to": f"{site_url}/wp-admin/",
                "testcookie": "1",
            },
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Referer": login_url,
                "Accept": "text/html,application/xhtml+xml",
            },
        )
        cookie_names = [k.lower() for k in client.cookies.keys()]
        logged_in = any(
            n.startswith("wordpress_logged_in") or n.startswith("wordpress_sec")
            for n in cookie_names
        )
        if logged_in or ("/wp-admin" in str(resp.url) and resp.status_code < 400):
            # Fetch nonce from wp-admin (or profile)
            admin = client.get(
                f"{site_url}/wp-admin/",
                headers={"Accept": "text/html"},
            )
            nonce = _extract_rest_nonce(admin.text)
            if not nonce:
                # Some installs expose it on the post editor bootstrap page
                alt = client.get(
                    f"{site_url}/wp-admin/post-new.php",
                    headers={"Accept": "text/html"},
                )
                nonce = _extract_rest_nonce(alt.text)
            if not nonce:
                # Last resort: users/me with cookies alone (GET often works)
                me = client.get(
                    f"{site_url}/wp-json/wp/v2/users/me",
                    params={"context": "edit"},
                    headers={"Accept": "application/json"},
                )
                if me.status_code < 400:
                    return ""
                raise WordPressError(
                    "Logged into WordPress, but could not obtain a REST API nonce. "
                    "Open wp-admin once in a browser, or ask hosting to pass through "
                    "the Authorization header for Application Passwords."
                )
            return nonce

        last_error = _parse_login_error(resp.text) or last_error

    raise WordPressError(
        last_error
        or (
            "WordPress cookie login failed. Use your normal wp-admin username/password "
            "(or an Application Password if your host supports API Basic auth)."
        )
    )


def _try_basic_auth_me(
    client: httpx.Client, site_url: str, username: str, password: str
) -> Optional[dict[str, Any]]:
    headers = {
        **_basic_auth_header(username, password),
        "Accept": "application/json",
    }
    # Also try with spaces kept (some hosts expect the displayed form)
    variants = [
        headers,
        {
            "Authorization": "Basic "
            + base64.b64encode(f"{username}:{password.strip()}".encode()).decode(),
            "Accept": "application/json",
        },
    ]
    for hdr in variants:
        me = client.get(
            f"{site_url}/wp-json/wp/v2/users/me",
            headers=hdr,
            params={"context": "edit"},
        )
        if me.status_code < 400:
            return {"user": me.json(), "headers": hdr, "mode": "basic"}
        try:
            code = me.json().get("code")
        except Exception:
            code = None
        # rest_not_logged_in ⇒ Authorization never reached PHP
        if code and code not in ("rest_not_logged_in",):
            # Wrong password / disabled — stop and report
            msg = me.json().get("message") or code
            raise WordPressError(f"WordPress Basic auth rejected: {msg}")
    return None


def _try_cookie_auth_me(
    client: httpx.Client, site_url: str, username: str, password: str
) -> dict[str, Any]:
    nonce = _cookie_login(client, site_url, username, password)
    headers: dict[str, str] = {"Accept": "application/json"}
    if nonce:
        headers["X-WP-Nonce"] = nonce
    me = client.get(
        f"{site_url}/wp-json/wp/v2/users/me",
        headers=headers,
        params={"context": "edit"},
    )
    if me.status_code >= 400:
        raise WordPressError(
            f"WordPress cookie session could not call the REST API "
            f"(HTTP {me.status_code}): {(me.text or '')[:240]}"
        )
    return {"user": me.json(), "headers": headers, "mode": "cookie", "nonce": nonce}


def authenticate_wordpress(
    *,
    site_url: str,
    username: str,
    password: str,
    client: Optional[httpx.Client] = None,
) -> dict[str, Any]:
    """
    Authenticate and return {site_url, username, user, mode, headers, client_owned}.
    Caller must close client if client_owned is True / if we created it.
    """
    site = _normalize_site_url(site_url)
    user = (username or "").strip()
    if not user or not (password or "").strip():
        raise WordPressError("Username and password are required")

    owns_client = client is None
    client = client or httpx.Client(
        timeout=httpx.Timeout(30.0, connect=12.0),
        follow_redirects=True,
    )
    try:
        # 1) Application Password / Basic auth
        basic = _try_basic_auth_me(client, site, user, password)
        if basic:
            return {
                "site_url": site,
                "username": user,
                "user": basic["user"],
                "mode": "basic",
                "headers": basic["headers"],
                "client": client,
                "owns_client": owns_client,
            }

        # 2) Cookie login fallback (host strips Authorization header)
        logger.warning(
            "WordPress Basic auth ignored at {} (Authorization likely stripped) — "
            "trying cookie login",
            site,
        )
        cookie = _try_cookie_auth_me(client, site, user, password)
        return {
            "site_url": site,
            "username": user,
            "user": cookie["user"],
            "mode": "cookie",
            "headers": cookie["headers"],
            "client": client,
            "owns_client": owns_client,
        }
    except Exception:
        if owns_client:
            client.close()
        raise


def test_wordpress_connection(
    *,
    site_url: str,
    username: str,
    app_password: str,
) -> dict[str, Any]:
    """Verify credentials (Basic auth, then cookie login fallback)."""
    auth = None
    try:
        auth = authenticate_wordpress(
            site_url=site_url,
            username=username,
            password=app_password,
        )
        data = auth["user"]
        return {
            "ok": True,
            "site_url": auth["site_url"],
            "username": username.strip(),
            "user_id": data.get("id"),
            "display_name": data.get("name") or data.get("slug") or username,
            "roles": data.get("roles") or [],
            "auth_mode": auth["mode"],
        }
    except WordPressError:
        raise
    except httpx.HTTPError as exc:
        raise WordPressError(f"Could not reach WordPress site: {exc}") from exc
    finally:
        if auth and auth.get("owns_client") and auth.get("client"):
            auth["client"].close()


def save_wordpress_credentials(
    db: Session,
    product: Product,
    *,
    site_url: str,
    username: str,
    app_password: str,
    auto_publish: bool = True,
    post_status: Optional[str] = None,
) -> dict[str, Any]:
    """Validate credentials, then store on the product (password never returned to clients)."""
    from sqlalchemy.orm.attributes import flag_modified

    probe = test_wordpress_connection(
        site_url=site_url,
        username=username,
        app_password=app_password,
    )
    status = (post_status or ("publish" if auto_publish else "draft")).strip().lower()
    if status not in ("publish", "draft", "pending", "private"):
        status = "publish" if auto_publish else "draft"

    product.wordpress_json = {
        "site_url": probe["site_url"],
        "username": username.strip(),
        "app_password": app_password.strip(),
        "connected": True,
        "connected_at": datetime.now(timezone.utc).isoformat(),
        "user_id": probe.get("user_id"),
        "display_name": probe.get("display_name"),
        "auto_publish": bool(auto_publish),
        "post_status": status,
        "auth_mode": probe.get("auth_mode"),
    }
    flag_modified(product, "wordpress_json")
    db.commit()
    db.refresh(product)
    logger.info(
        "WordPress connected for product #{} ({}) → {} via {}",
        product.id,
        product.name,
        probe["site_url"],
        probe.get("auth_mode"),
    )
    return wordpress_public_status(product)


def disconnect_wordpress(db: Session, product: Product) -> dict[str, Any]:
    from sqlalchemy.orm.attributes import flag_modified

    product.wordpress_json = None
    flag_modified(product, "wordpress_json")
    db.commit()
    db.refresh(product)
    logger.info("WordPress disconnected for product #{}", product.id)
    return wordpress_public_status(product)


def _extract_body_html(html: str) -> str:
    text = html or ""
    m = re.search(r"<body[^>]*>([\s\S]*)</body>", text, flags=re.I)
    if m:
        text = m.group(1)
    return text.strip()


def _normalize_title_text(value: str) -> str:
    text = re.sub(r"\s+", " ", (value or "").strip().lower())
    text = re.sub(r"[^\w\s]", "", text)
    return text.strip()


def _remove_node_and_empty_wrapper(tag) -> None:
    """Remove a tag; if its parent becomes an empty figure/p/div/picture, remove that too."""
    parent = tag.parent
    tag.decompose()
    if parent is None or getattr(parent, "name", None) is None:
        return
    if parent.name not in ("p", "figure", "div", "picture", "span"):
        return
    # Keep wrappers that still have meaningful content
    leftover = parent.get_text(strip=True)
    has_media = parent.find(["img", "svg", "video", "iframe", "table"])
    if not leftover and not has_media:
        parent.decompose()


def _strip_hero_from_wordpress_body(soup, *, post_title: str = "") -> None:
    """Featured image carries the banner — do not also embed the hero in post content.

    Removes .blog-hero-image (and empty wrappers) plus a duplicate H1 that matches the
    WordPress post title (theme already renders the title / tagline).
    """
    def _is_hero_img(img) -> bool:
        classes = img.get("class") or []
        if isinstance(classes, str):
            classes = classes.split()
        if "blog-hero-image" in classes:
            return True
        return False

    # 1) Explicit hero class (and common wrappers)
    for img in list(soup.find_all("img")):
        if _is_hero_img(img):
            _remove_node_and_empty_wrapper(img)

    article = soup.find("article") or soup

    # 2) Duplicate title H1 (theme shows title / tagline)
    title_norm = _normalize_title_text(post_title)
    if title_norm:
        for h1 in list(article.find_all("h1")):
            if _normalize_title_text(h1.get_text()) == title_norm:
                h1.decompose()

    # 3) Banner still sitting at the very top (legacy drafts without the class)
    #    Only remove if it is the first content node after optional empty wrappers.
    first_img = article.find("img")
    if not first_img:
        return
    # Walk previous elements in document order within article
    saw_body = False
    for el in article.descendants:
        if el is first_img:
            break
        name = getattr(el, "name", None)
        if name in ("h2", "h3", "h4", "table", "ul", "ol", "section"):
            saw_body = True
            break
        if name == "p":
            text = el.get_text(strip=True) if hasattr(el, "get_text") else ""
            if len(text) > 40:
                saw_body = True
                break
    if not saw_body:
        _remove_node_and_empty_wrapper(first_img)


def build_wordpress_excerpt(
    *,
    title: str = "",
    meta_description: str = "",
    html_fragment: str = "",
) -> str:
    """Clickbait-style excerpt for the WordPress Excerpt field only (never injected into HTML)."""
    from bs4 import BeautifulSoup

    meta = re.sub(r"\s+", " ", (meta_description or "").strip())
    title_clean = re.sub(r"\s+", " ", (title or "").strip())

    # Prefer an already-hooky meta description
    if 40 <= len(meta) <= 180:
        return meta[:180].rstrip()

    # Pull first meaningful paragraph from the article body
    intro = ""
    if html_fragment:
        soup = BeautifulSoup(html_fragment, "html.parser")
        for p in soup.find_all("p"):
            text = re.sub(r"\s+", " ", p.get_text(" ", strip=True))
            if len(text) >= 50:
                intro = text
                break

    if title_clean and intro:
        hook = f"{title_clean} — {intro}"
    elif title_clean:
        hook = (
            f"{title_clean}: what operators keep missing — and the fix that actually sticks."
        )
    else:
        hook = intro or meta

    hook = re.sub(r"\s+", " ", hook).strip()
    if len(hook) > 160:
        cut = hook[:157].rsplit(" ", 1)[0].rstrip(",;:-")
        hook = f"{cut}…"
    return hook


def _ensure_closed_style_block(css: str) -> str:
    """Return a complete <style>…</style> block; never emit an unclosed tag."""
    # Neutralize any accidental </style> inside CSS comments/strings
    safe_css = (css or "").replace("</style>", "<\\/style>").replace("</STYLE>", "<\\/STYLE>")
    block = f'<style type="text/css" id="hyperpark-prose-blog">\n{safe_css}\n</style>'
    opens = len(re.findall(r"<style\b", block, flags=re.I))
    closes = len(re.findall(r"</style>", block, flags=re.I))
    if opens != closes:
        # Hard fail-safe: append missing closers
        block = block + ("</style>" * max(0, opens - closes))
    return block


def _apply_wordpress_inline_fallbacks(soup, product: Optional[Product] = None) -> None:
    """Inline brand colors so layout still works if WordPress strips the <style> tag.

    Intentionally does NOT set font-size — the theme owns typography size.
    """
    from app.services.product_context import get_brand_palette, get_core_brand_colors

    colors = get_core_brand_colors(get_brand_palette(product))
    navy = colors.get("navy") or "#1b1f4a"
    primary = colors.get("primary") or "#252a61"
    accent = colors.get("accent") or "#ff6002"
    cta = colors.get("cta") or "#c1262a"
    link = colors.get("link") or "#1d4ed8"

    article = soup.find(class_="prose-blog") or soup.find("article") or soup
    # Soft shell — no font-size
    existing = (article.get("style") or "").rstrip().rstrip(";")
    shell = (
        f"color:#0f172a;max-width:100%;margin:0 auto;"
        f"--hyper-navy:{navy};--hyper-primary:{primary};"
        f"--hyper-orange:{accent};--hyper-cta:{cta};--hyper-link:{link};"
    )
    article["style"] = f"{existing};{shell}" if existing else shell

    for h in article.find_all(["h2", "h3", "h4"]):
        style = (h.get("style") or "").rstrip().rstrip(";")
        color = f"color:{navy};"
        h["style"] = f"{style};{color}" if style else color

    for a in article.find_all("a", href=True):
        classes = a.get("class") or []
        style = (a.get("style") or "").rstrip().rstrip(";")
        if "cta-button" in classes:
            btn = (
                f"display:inline-block;background:{cta};color:#fff;"
                f"padding:0.65rem 1.1rem;border-radius:0.65rem;text-decoration:none;font-weight:600;"
            )
            a["style"] = f"{style};{btn}" if style else btn
        else:
            link_style = f"color:{link};"
            a["style"] = f"{style};{link_style}" if style else link_style

    for cta_block in article.find_all(class_="blog-cta"):
        style = (cta_block.get("style") or "").rstrip().rstrip(";")
        block = (
            f"background:linear-gradient(135deg,{primary},{navy});"
            f"color:#fff;padding:1.25rem 1.35rem;border-radius:0.85rem;margin:1.5rem 0;"
        )
        cta_block["style"] = f"{style};{block}" if style else block

    for toc in article.find_all("nav", class_="toc"):
        style = (toc.get("style") or "").rstrip().rstrip(";")
        box = (
            f"border:1px solid #e8eaef;background:#f8f9fc;"
            f"padding:0.9rem 1rem;border-radius:0.75rem;margin:0 0 1.25rem;"
        )
        toc["style"] = f"{style};{box}" if style else box


def build_wordpress_content(
    html: str,
    product: Optional[Product] = None,
    *,
    hero_source_url: str = "",
    hero_replacement_url: str = "",
    post_title: str = "",
    remove_hero_from_body: bool = True,
) -> str:
    """Build WordPress post HTML: closed <style>, no font-size CSS, hero only as featured image.

    - Stylesheet has no font-size (theme typography size applies)
    - Hero banner is omitted from content when ``remove_hero_from_body`` (use featured_media)
    - Remaining images keep absolute https URLs (download-safe / theme-safe)
    - Inline brand fallbacks survive if the host strips ``<style>``
    """
    from bs4 import BeautifulSoup

    from app.services.blog_prose_css import blog_prose_css_for_wordpress
    from app.utils.link_sanitizer import sanitize_markdown_urls_in_html, unwrap_markdown_url

    soup = BeautifulSoup(
        sanitize_markdown_urls_in_html(_extract_body_html(html)),
        "html.parser",
    )

    # Palette vars are re-emitted by the scoped stylesheet.
    for style in list(soup.find_all("style", id="product-brand-palette")):
        style.decompose()

    # Drop any pre-existing style tags inside the fragment (we emit one closed block)
    for style in list(soup.find_all("style")):
        style.decompose()

    if remove_hero_from_body:
        _strip_hero_from_wordpress_body(soup, post_title=post_title)
    elif hero_replacement_url:
        # Legacy path: rewrite hero src to WP media URL (absolute)
        clean_hero = unwrap_markdown_url(hero_replacement_url)
        clean_source = unwrap_markdown_url(hero_source_url) if hero_source_url else ""
        for img in soup.find_all("img"):
            src = unwrap_markdown_url((img.get("src") or "").strip())
            if not src or (clean_source and src != clean_source):
                continue
            img["src"] = clean_hero
            img.attrs.pop("srcset", None)

    # Force any leftover images to absolute http(s) URLs when we have a media URL fallback
    if hero_replacement_url:
        clean_hero = unwrap_markdown_url(hero_replacement_url)
        for img in soup.find_all("img"):
            src = unwrap_markdown_url((img.get("src") or "").strip())
            if src and not src.startswith(("http://", "https://", "data:")):
                # Relative/local path would break offline download & WP themes
                img["src"] = clean_hero
                img.attrs.pop("srcset", None)

    article = soup.find("article")
    inner = article.decode_contents() if article else str(soup)

    css = blog_prose_css_for_wordpress(product)
    style_block = _ensure_closed_style_block(css)

    # Build article separately so BeautifulSoup cannot mangle the </style> closer
    article_soup = BeautifulSoup(
        f'<article class="prose-blog">\n{inner}\n</article>',
        "html.parser",
    )
    _apply_wordpress_inline_fallbacks(article_soup, product)
    article_html = str(article_soup)

    out = f"{style_block}\n{article_html}"
    if out.lower().count("<style") != out.lower().count("</style>"):
        logger.warning("WordPress content style tag mismatch — forcing closed block")
        out = f"{style_block}\n{article_html}"
    if "<style" in out.lower() and "</style>" not in out.lower():
        out = f"{out}\n</style>"
    return out


def _upload_featured_image(
    client: httpx.Client,
    *,
    base: str,
    headers: dict[str, str],
    image_path: Path,
    title: str,
) -> Optional[dict[str, Any]]:
    if not image_path.is_file():
        return None
    data = image_path.read_bytes()
    if not data:
        return None
    suffix = image_path.suffix.lower() or ".webp"
    mime = {
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
        ".webp": "image/webp",
        ".gif": "image/gif",
    }.get(suffix, "application/octet-stream")
    filename = image_path.name
    media_headers = {
        **headers,
        "Content-Disposition": f'attachment; filename="{filename}"',
        "Content-Type": mime,
    }
    resp = client.post(
        urljoin(base, "media"),
        headers=media_headers,
        content=data,
        params={"title": title[:120]},
    )
    if resp.status_code >= 400:
        logger.warning(
            "WordPress media upload failed: {} {}", resp.status_code, resp.text[:200]
        )
        return None
    media = resp.json()
    mid = media.get("id")
    if not mid:
        return None
    source_url = media.get("source_url") or (media.get("guid") or {}).get("rendered") or ""
    return {"id": int(mid), "source_url": str(source_url)}


def publish_post_to_wordpress(
    *,
    product: Product,
    title: str,
    content_html: str,
    slug: str,
    excerpt: str = "",
    meta_description: str = "",
    status: Optional[str] = None,
    featured_image_path: Optional[Path] = None,
    hero_source_url: str = "",
    update_if_exists: bool = False,
) -> dict[str, Any]:
    """Create a WordPress post via REST API (Basic or cookie session).

    Same logic for every product:
    - Featured image = banner only (hero removed from post body)
    - Excerpt field = clickbait summary (not injected into HTML content)
    - Stylesheet without font-size; closed ``</style>``; inline color fallbacks

    When ``update_if_exists`` is True (user clicked Republish), look up an existing post by
    slug and update it; if the WP admin deleted it, create a new post again so destinations
    match product settings. First-time Approve & Publish always creates.
    """
    if not wordpress_configured(product):
        raise WordPressError("WordPress is not connected for this product")

    cfg = get_wordpress_config(product)
    site_url = cfg["site_url"]
    username = cfg["username"]
    password = cfg["app_password"]
    post_status = (status or cfg.get("post_status") or "publish").strip().lower()
    if post_status not in ("publish", "draft", "pending", "private"):
        post_status = "publish"

    wp_excerpt = (excerpt or "").strip() or build_wordpress_excerpt(
        title=title,
        meta_description=meta_description or excerpt or "",
        html_fragment=content_html,
    )

    base = _api_base(site_url)
    body: dict[str, Any] = {
        "title": title or slug,
        "status": post_status,
        "slug": slug,
        "excerpt": wp_excerpt,
    }

    auth = None
    existing_id: Optional[int] = None
    try:
        auth = authenticate_wordpress(
            site_url=site_url,
            username=username,
            password=password,
        )
        client: httpx.Client = auth["client"]
        headers = {
            **auth["headers"],
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

        if update_if_exists and slug:
            try:
                lookup = client.get(
                    urljoin(base, "posts"),
                    headers=headers,
                    params={"slug": slug, "status": "any", "per_page": 1},
                )
                if lookup.status_code < 400:
                    found = lookup.json()
                    if isinstance(found, list) and found:
                        existing_id = int(found[0].get("id") or 0) or None
            except (TypeError, ValueError, httpx.HTTPError) as lookup_exc:
                logger.warning(
                    "WordPress slug lookup failed for '{}': {}", slug, lookup_exc
                )

        hero_media_url = ""
        if featured_image_path:
            media = _upload_featured_image(
                client,
                base=base,
                headers={k: v for k, v in headers.items() if k != "Content-Type"},
                image_path=Path(featured_image_path),
                title=title or slug,
            )
            if media:
                body["featured_media"] = media["id"]
                hero_media_url = media.get("source_url") or ""

        body["content"] = build_wordpress_content(
            content_html,
            product,
            hero_source_url=hero_source_url,
            hero_replacement_url=hero_media_url,
            post_title=title or slug,
            remove_hero_from_body=True,
        )

        # Safety: never leave excerpt text duplicated inside content
        if wp_excerpt and wp_excerpt in body["content"]:
            body["content"] = body["content"].replace(
                f"<p>{wp_excerpt}</p>", "", 1
            )

        if existing_id:
            resp = client.post(
                urljoin(base, f"posts/{existing_id}"),
                headers=headers,
                json=body,
            )
        else:
            # First publish, or user Republish after WP admin deleted the post
            resp = client.post(urljoin(base, "posts"), headers=headers, json=body)
        if resp.status_code in (401, 403):
            raise WordPressError(
                "WordPress rejected credentials while publishing. "
                "Reconnect under Settings → Integrations → WordPress."
            )
        if resp.status_code >= 400:
            raise WordPressError(
                f"WordPress publish failed (HTTP {resp.status_code}): {(resp.text or '')[:400]}"
            )
        data = resp.json()
    except WordPressError:
        raise
    except httpx.HTTPError as exc:
        raise WordPressError(f"WordPress publish request failed: {exc}") from exc
    finally:
        if auth and auth.get("owns_client") and auth.get("client"):
            auth["client"].close()

    link = data.get("link") or data.get("guid", {}).get("rendered")
    content = data.get("content") or {}
    saved_html = ""
    if isinstance(content, dict):
        saved_html = str(content.get("raw") or content.get("rendered") or "")
    styles_kept = "<style" in saved_html.lower() and "</style>" in saved_html.lower()
    if saved_html and not styles_kept:
        logger.warning(
            "WordPress stripped or broke the embedded <style>…</style> block for '{}'. "
            "Inline brand fallbacks were still applied. Grant 'unfiltered_html' "
            "(Administrator on a single site) and republish for full CSS.",
            slug,
        )

    result = {
        "id": data.get("id"),
        "link": link,
        "status": data.get("status") or post_status,
        "slug": data.get("slug") or slug,
        "site_url": site_url,
        "auth_mode": auth.get("mode") if auth else None,
        "styles_kept": styles_kept if saved_html else True,
        "excerpt": wp_excerpt,
        "featured_media": body.get("featured_media"),
        "updated_existing": bool(existing_id),
        "skipped": False,
        "recreated": bool(update_if_exists and not existing_id),
    }
    logger.info(
        "{} WordPress for product #{}: {} → {} ({})",
        (
            "Updated"
            if existing_id
            else ("Recreated on" if update_if_exists else "Published to")
        ),
        product.id,
        result.get("id"),
        link,
        result.get("auth_mode"),
    )
    return result
