"""Build in-app notification feed from stored events + live pipeline state."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional

from sqlalchemy.orm import Session

from app.models import AppNotification, BlogPost, BlogStatus


def _post_title(post: BlogPost) -> str:
    return (
        post.selected_topic_title
        or post.title_tag
        or post.slug
        or f"Post #{post.id}"
    )


def _last_error_entry(history: list[dict[str, Any]]) -> dict[str, Any] | None:
    for entry in reversed(history):
        if entry.get("type") == "error":
            return entry
    return None


def emit_notification(
    db: Session,
    *,
    type: str,
    title: str,
    message: str,
    severity: str = "action",
    post_id: Optional[int] = None,
) -> AppNotification:
    row = AppNotification(
        type=type,
        title=(title or "Notification")[:256],
        message=(message or "")[:2000],
        severity=severity,
        post_id=post_id,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


def emit_notification_standalone(
    *,
    type: str,
    title: str,
    message: str,
    severity: str = "action",
    post_id: Optional[int] = None,
) -> None:
    from app.database import SessionLocal

    db = SessionLocal()
    try:
        emit_notification(
            db,
            type=type,
            title=title,
            message=message,
            severity=severity,
            post_id=post_id,
        )
    finally:
        db.close()


def build_notifications(db: Session, limit: int = 40) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []

    stored = (
        db.query(AppNotification)
        .order_by(AppNotification.created_at.desc(), AppNotification.id.desc())
        .limit(limit)
        .all()
    )
    for row in stored:
        items.append(
            {
                "id": f"stored-{row.id}",
                "type": row.type,
                "post_id": row.post_id or 0,
                "title": row.title,
                "message": row.message,
                "timestamp": row.created_at.isoformat()
                if row.created_at
                else datetime.now(timezone.utc).isoformat(),
                "severity": row.severity or "action",
            }
        )

    posts = (
        db.query(BlogPost)
        .order_by(BlogPost.created_at.desc())
        .limit(100)
        .all()
    )

    for post in posts:
        title = _post_title(post)
        ts = (
            post.created_at.isoformat()
            if post.created_at
            else datetime.now(timezone.utc).isoformat()
        )

        if post.status == BlogStatus.SCRAPING:
            err = _last_error_entry(list(post.feedback_history or []))
            if err:
                items.append(
                    {
                        "id": f"error-discovery-{post.id}",
                        "type": "error",
                        "post_id": post.id,
                        "title": f"Discovery failed · Post #{post.id}",
                        "message": err.get("feedback") or "Discovery failed — open the card and click Retry",
                        "timestamp": err.get("timestamp") or ts,
                        "severity": "error",
                    }
                )
            else:
                items.append(
                    {
                        "id": f"scraping-{post.id}",
                        "type": "topic_selection",
                        "post_id": post.id,
                        "title": title,
                        "message": "Discovery is running — topics will appear soon",
                        "timestamp": ts,
                        "severity": "action",
                    }
                )
        elif post.status == BlogStatus.PENDING_TOPIC:
            items.append(
                {
                    "id": f"topic-{post.id}",
                    "type": "topic_selection",
                    "post_id": post.id,
                    "title": title,
                    "message": "Choose a topic to continue generation",
                    "timestamp": ts,
                    "severity": "action",
                }
            )
        elif post.status == BlogStatus.GENERATING:
            err = _last_error_entry(list(post.feedback_history or []))
            if err:
                items.append(
                    {
                        "id": f"error-generation-{post.id}",
                        "type": "error",
                        "post_id": post.id,
                        "title": f"Generation failed · Post #{post.id}",
                        "message": err.get("feedback") or "Generation failed — open the card and click Retry",
                        "timestamp": err.get("timestamp") or ts,
                        "severity": "error",
                    }
                )
            else:
                items.append(
                    {
                        "id": f"generating-{post.id}",
                        "type": "review_required",
                        "post_id": post.id,
                        "title": title,
                        "message": "Content is being generated",
                        "timestamp": ts,
                        "severity": "action",
                    }
                )
        elif post.status == BlogStatus.PENDING_REVIEW:
            items.append(
                {
                    "id": f"review-{post.id}",
                    "type": "review_required",
                    "post_id": post.id,
                    "title": title,
                    "message": "Content is ready for your review",
                    "timestamp": ts,
                    "severity": "action",
                }
            )
        elif post.status == BlogStatus.REJECTED:
            history = list(post.feedback_history or [])
            err = _last_error_entry(history)
            if err:
                err_ts = err.get("timestamp") or ts
                items.append(
                    {
                        "id": f"error-{post.id}-{err_ts}",
                        "type": "error",
                        "post_id": post.id,
                        "title": title,
                        "message": err.get("feedback") or "Workflow failed",
                        "timestamp": err_ts,
                        "severity": "error",
                    }
                )
        elif post.status == BlogStatus.PUBLISHED:
            items.append(
                {
                    "id": f"published-{post.id}",
                    "type": "published",
                    "post_id": post.id,
                    "title": title,
                    "message": "Blog published successfully",
                    "timestamp": ts,
                    "severity": "success",
                }
            )

    # Prefer unique ids (stored first, then live)
    seen: set[str] = set()
    deduped: list[dict[str, Any]] = []
    for item in items:
        key = item["id"]
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)

    deduped.sort(key=lambda n: n.get("timestamp") or "", reverse=True)
    return deduped[:limit]
