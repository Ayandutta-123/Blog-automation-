"""Shared blog formatting rules, authoritative backlink sources, and image prompts."""

from __future__ import annotations

from app.services.runtime_config import get_config_value

# Real domains only — model must not invent URLs.
# Only homepage / stable topic hubs that typically stay live (probed at publish time).
AUTHORITATIVE_EXTERNAL_SOURCES = [
    ("OECD / ITF urban mobility", "https://www.itf-oecd.org/urban-mobility"),
    ("IEA transport", "https://www.iea.org/topics/transport"),
    ("McKinsey insights", "https://www.mckinsey.com/insights"),
    ("Gartner IT research", "https://www.gartner.com/en/information-technology"),
    ("US EPA green vehicles", "https://www.epa.gov/greenvehicles"),
    ("NHTSA vehicle safety", "https://www.nhtsa.gov/"),
    ("Smart Cities World", "https://www.smartcitiesworld.net/"),
    ("International Parking & Mobility Institute", "https://www.parking.org/"),
    ("World Bank urban transport", "https://www.worldbank.org/en/topic/transport"),
    ("UN-Habitat urban mobility", "https://unhabitat.org/topic/mobility"),
]

# HARDCODED for ALL products — broken / fake / invented backlinks are forbidden.
BACKLINK_HARD_RULES = """
BACKLINK HARD RULES (MANDATORY — ALL PRODUCTS — NEVER SKIP):
1. NEVER invent URLs, guess paths, or link to example.com / localhost / competitor blogs not on the approved list.
2. ONLY use URLs from APPROVED EXTERNAL SOURCES + APPROVED INTERNAL LINKS (+ discovery source URLs listed for this topic).
3. Every external link MUST be a genuine, live page relevant to the paragraph where it appears.
4. Place sources INLINE in body paragraphs (bold/colored anchors) — never a fake "Sources" dump at the bottom.
5. Minimum 2 live external authoritative citations AND 3 internal product links in every article.
6. If you cannot find an approved URL for a claim, state the insight without a hyperlink.
7. Server strips any dead (4xx/5xx) or non-approved link before publish — do not rely on broken links surviving.
"""

# HARDCODED for ALL products — chosen/custom topic is the only story; no mid-article drift.
TOPIC_LOCK_HARD_RULES = """
TOPIC LOCK HARD RULES (MANDATORY — ALL PRODUCTS — NEVER SKIP):
1. The EXACT chosen topic OR custom topic command is the ONLY subject of the article — start to finish.
2. EVERY section (intro, every H2/H3, table, chart captions, conclusion, CTA copy) must stay about THAT topic.
3. NEVER pivot after 2–4 paragraphs into generic product fluff, unrelated cities, or a different problem.
4. If the topic names a place, industry, product, or use-case (e.g. Bangalore smart parking), keep that
   specific angle in H1, intro, body, examples, table rows, and conclusion — do not broaden into
   "enterprise parking in general" or another geography/product.
5. Secondary keywords / research pack items may SUPPORT the topic only — they must not replace it.
6. Brand/product mentions are allowed only as solutions TO this topic — never as a new article subject.
7. Off-topic drafts are rejected and regenerated. Do not invent a different brief.
"""


def build_topic_lock_block(
    topic_title: str,
    primary_keyword: str,
    *,
    topic_description: str = "",
) -> str:
    """Per-post topic lock block injected into the generation user message (all products)."""
    topic = (topic_title or "").strip() or "the selected topic"
    keyword = (primary_keyword or topic).strip()
    desc = (topic_description or "").strip()
    desc_line = f"- Scraped topic angle: {desc}\n" if desc else ""
    return f"""
{TOPIC_LOCK_HARD_RULES}

LOCKED TOPIC FOR THIS POST (DO NOT CHANGE):
- Topic command: {topic}
- Primary keyword: {keyword}
{desc_line}- Required: weave "{keyword}" and the distinctive words from the topic through intro + every major H2.
- Forbidden: switching to a different city, vertical, or generic SaaS pitch that abandons the locked topic.
"""


HEADLINE_STYLES: dict[str, dict[str, str]] = {
    "how_to": {
        "label": "How-to / without tradeoff",
        "pattern": 'How to [outcome] without [pain] — e.g. "How to Cut Gate Queues Without Extra Guards"',
        "ban_hint": "Do not force a fake % into the title.",
    },
    "number_proof": {
        "label": "Specific proof number",
        "pattern": '[Thing] [verb] [N%/N] [stakes] — e.g. "ANPR Validation Cuts 18% Leakage in Year One"',
        "ban_hint": "Only use a number if the scraped topic or research supports it; inventing the same 18% every time is forbidden.",
    },
    "mistake": {
        "label": "Costly mistake",
        "pattern": 'The [X] Mistake Still Costing [audience] — e.g. "The Manual Exit Mistake Still Costing Operators"',
        "ban_hint": "Lead with the mistake, not a How-to.",
    },
    "why_still": {
        "label": "Why still / gap",
        "pattern": 'Why [audience] Still [pain] With [topic] — e.g. "Why Sites Still Miss Peak Dwell Spikes"',
        "ban_hint": "Frame as a lingering gap, not a How X Stops Y formula.",
    },
    "question": {
        "label": "Provocative question",
        "pattern": 'Is [X] Quietly [hurting Y]? — e.g. "Is Cashier Override Quietly Killing Your Margin?"',
        "ban_hint": "Title must end with ? and stay answerable in the article.",
    },
    "listicle": {
        "label": "Numbered signals / ways",
        "pattern": 'N [signals/moves] for [topic] — e.g. "7 Occupancy Signals Every Ops Lead Should Track"',
        "ban_hint": "Use 5–9 as the number; do not use a How-to opener.",
    },
    "contrast": {
        "label": "Before/after or X vs Y",
        "pattern": '[Old way] vs [new way] / Stop [A], Start [B] — e.g. "Paper Logs vs Live ANPR: What Changes Overnight"',
        "ban_hint": "Show contrast; avoid generic Stop 18% Leakage phrasing.",
    },
    "playbook": {
        "label": "Operating playbook",
        "pattern": 'The [topic] Playbook for [audience] — e.g. "The Site Access Playbook for Multi-Lot Operators"',
        "ban_hint": "Promise a practical playbook, not a leakage % hook.",
    },
    "myth": {
        "label": "Myth vs reality",
        "pattern": 'Myth: [belief]. Reality: [truth] — e.g. "Myth: More Guards Fix Leakage. Reality: Validation Does"',
        "ban_hint": "Two-beat myth/reality structure required.",
    },
    "urgency": {
        "label": "Time-bound urgency",
        "pattern": 'Before [deadline/event], fix [topic] — e.g. "Before Your Next Audit, Fix Exit Validation Gaps"',
        "ban_hint": "Urgency must come from the topic angle, not a recycled Daily Leak title.",
    },
    "secret": {
        "label": "Insider reveal",
        "pattern": 'What [experts] Won\'t Tell You About [topic] — e.g. "What Integrators Won\'t Tell You About Gate APIs"',
        "ban_hint": "Reveal angle; do not default to How X Stops Y%.",
    },
    "case_angle": {
        "label": "From pain to outcome",
        "pattern": 'From [pain] to [result] with [topic] — e.g. "From Blind Spots to Live Lane Control With ANPR"',
        "ban_hint": "Journey framing; avoid identical Revenue Leak Daily templates.",
    },
}

_HEADLINE_ROTATION = tuple(HEADLINE_STYLES.keys())


def pick_headline_style(
    *,
    topic: str = "",
    keyword: str = "",
    description: str = "",
    research_pack: dict | None = None,
) -> str:
    """Choose a headline formula from scraped topic content so titles are not all one shape."""
    import hashlib
    import re

    research = research_pack or {}
    questions = " ".join(str(q) for q in (research.get("questions_to_answer") or [])[:6])
    outline = " ".join(str(s) for s in (research.get("recommended_outline") or [])[:6])
    text = f"{topic} {keyword} {description} {questions} {outline}".lower()

    if re.search(r"\b(myth|reality|misconception|false belief)\b", text):
        return "myth"
    if re.search(
        r"\b(top\s+\d+|\d+\s+(ways|signals|moves|steps|tips|checks)|\d+\s+\w+\s+(ways|signals|moves|steps|tips|checks))\b",
        text,
    ):
        return "listicle"
    if re.search(r"\b(vs\.?|versus|compared to|before.?after|instead of|stop .+ start)\b", text):
        return "contrast"
    if re.search(r"\b(playbook|roadmap|operating model|framework)\b", text):
        return "playbook"
    if re.search(r"\b(mistake|failing|wrong|pitfall|trap|costing you)\b", text):
        return "mistake"
    if re.search(r"\b(why .+ still|still missing|still ignore|gap remains)\b", text):
        return "why_still"
    if re.search(r"\b(won't tell|secret|hidden|insider|underreported)\b", text):
        return "secret"
    if re.search(r"\b(this quarter|before your|deadline|urgent|audit season|now)\b", text):
        return "urgency"
    if "?" in (topic or "") or re.search(r"\b(is |are |should |can |does )\b", topic.lower()[:48]):
        return "question"
    if re.search(r"\b(how to|without |step[- ]by[- ]step|guide to)\b", text):
        return "how_to"
    if re.search(r"\b(from .+ to |journey|transformation|rolled out)\b", text):
        return "case_angle"
    if re.search(r"\b(\d+%|\d+\s*percent|roi|payback|leakage|save[sd]?|cut[s]?)\b", text):
        # Numbers in topic → proof style sometimes, but rotate so every numeric topic
        # does not become the same "Stop 18% Leaks Daily" clone.
        seed = hashlib.md5(f"{topic}|{keyword}|proof".encode("utf-8")).hexdigest()
        options = ("number_proof", "how_to", "contrast", "case_angle", "urgency")
        return options[int(seed, 16) % len(options)]

    seed = hashlib.md5(f"{topic}|{keyword}|{description}".encode("utf-8")).hexdigest()
    # Prefer non-number_proof for weak signals to break the default sameness.
    pool = [s for s in _HEADLINE_ROTATION if s != "number_proof"]
    return pool[int(seed, 16) % len(pool)]


def build_headline_style_block(
    *,
    topic: str = "",
    keyword: str = "",
    description: str = "",
    research_pack: dict | None = None,
    style: str | None = None,
) -> str:
    """Prompt block that forces a content-matched headline formula for this post."""
    resolved = style if style in HEADLINE_STYLES else pick_headline_style(
        topic=topic,
        keyword=keyword,
        description=description,
        research_pack=research_pack,
    )
    meta = HEADLINE_STYLES[resolved]
    others = ", ".join(
        f"{key} ({HEADLINE_STYLES[key]['label']})"
        for key in _HEADLINE_ROTATION
        if key != resolved
    )
    return f"""
HEADLINE STYLE FOR THIS POST (MANDATORY — dynamic from scraped topic content):
- Assigned style id: «{resolved}» — {meta['label']}
- Required pattern: {meta['pattern']}
- Style note: {meta['ban_hint']}
- Ground the title in the LOCKED TOPIC words and scraped angle — do not invent a different brief.
- title_tag / H1 / og_title must all follow this style and stay 55–60 characters.
- BANNED default (unless the locked topic already is this exact shape): 
  "How … Stop …% Revenue Leak(s) Daily" and near-clones. That template is overused.
- Do NOT reuse the same formula as a previous post; other styles available next time: {others}.
"""


HYPERPARK_INTERNAL_LINKS = [
    ("Book a live demo", "https://calendly.com/vijayrhts/htssales"),
    ("Smart parking platform", "https://hyperpark.io/smart-parking"),
    ("Access management solutions", "https://hyperpark.io/access-management"),
    ("HyperPark platform", "https://hyperpark.io/"),
]

CLICKBAIT_ENGAGEMENT_RULES = """
HARDCODED CLICKBAIT + THUMBNAIL RULES (ALWAYS — never skip):

TITLES (title_tag, H1, og_title):
- Must be curiosity-driven click magnets grounded in THIS scraped topic's real angle — not a recycled template.
- DYNAMIC: follow the HEADLINE STYLE FOR THIS POST block (how_to, number_proof, mistake, why_still,
  question, listicle, contrast, playbook, myth, urgency, secret, or case_angle).
- Rotate formulas across posts. NEVER ship the same "How X Stop Y% Revenue Leaks Daily" shape
  on every article — that pattern is banned unless the locked scraped topic already uses it.
- Prefer specificity from the topic (place, system, audience, mechanism) over generic leakage claims.
- Never use flat guide titles like "X Guide 2024" or generic "Introduction to X".
- Still honest: the body must deliver on the promise (no bait-and-switch).
- title_tag: 55–60 characters; primary keyword natural near the front; H1 mirrors title_tag;
  og_title matches title_tag.

HERO IMAGE (generated server-side from the final title + keyword + meta):
- Must depict THIS article's topic visually — dynamic per post, never a default parking garage.
- Only show parking/ANPR/barriers when the article is explicitly about parking facilities.
- Style: high-CTR blog/YouTube thumbnail energy — bold focal subject, curiosity gap, scroll-stopping.
"""

SEO_ANATOMY_RULES = f"""
ANATOMY OF AN SEO-OPTIMIZED BLOG (STRICT — follow every section in order):

{CLICKBAIT_ENGAGEMENT_RULES}

A. TITLE TAG & H1 (THE HOOK)
- Write a clickbait-style, content-true title using the assigned HEADLINE STYLE for this post.
- Keyword placement: primary keyword as close to the beginning of the title tag as sounds natural.
- Character limit: title tag 55–60 characters (never truncated in Google).
- H1 rule: exactly ONE <h1> per page; it must closely mirror the title tag intent and include the keyword.

B. THE INTRODUCTION (FIRST 100–150 WORDS — immediately after H1, BEFORE the first body H2)
- The Hook: open with a relatable problem, surprising statistic, or direct acknowledgement of why the reader searched.
  NEVER use robotic "welcome to our blog" intros.
- BLUF (Bottom Line Up Front): answer the core search query in the first 2–3 sentences for Featured Snippet eligibility.
- The Roadmap: tell the reader exactly what they will learn (use "In this article, you'll learn…" or similar).
- Write the intro as 2–4 short <p> tags AFTER the hero image and TOC (hero is always directly under H1).

C. THE BODY (H2s AND H3s)
- Logical hierarchy: H2 for main themes, H3 for subtopics within each H2. NEVER skip levels (no H1→H3).
- Semantic SEO: weave secondary keywords and related NLP terms naturally into subheadings and copy.
- Micro-paragraphs: 2–4 sentences per <p> — no wall-of-text blocks (critical for mobile bounce rate).
- Visual formatting: use <ul>/<ol> lists, <strong> for key terms, and comparison <table> blocks to guide the eye.
- Give every major H2 a unique id attribute (TOC is auto-generated from these headings).

D. MEDIA & VISUAL BREAKS
- Frequency: include a relevant visual every 300–500 words (hero image + mid-body chart/table/stat-grid count).
- Optimization: keyword-rich, descriptive alt text on every <img> (no stuffing). Hero uses HERO_IMAGE_SRC placeholder.

E. THE CONCLUSION & CALL TO ACTION (FIXED ORDER)
- Conclusion H2: <h2 id="conclusion"> with 2–3 sentences summarizing core takeaways.
- CTA section: <section id="cta" class="blog-cta"> MUST be the LAST element in <article>.
  Include primary CTA → https://hyperpark.io/demo and link to ROI calculator.
- NEVER include FAQ — no <h2 id="faq">, no "Frequently Asked Questions" section, no FAQPage schema.
  FAQ is inserted later only via the dashboard Add FAQ button.

F. JSON-LD — Article schema in <script type="application/ld+json"> at the top of html_content.
   NEVER add FAQPage schema during generation.
"""

BLOG_FORMAT_RULES = f"""
HYPERPARK CONTENT REQUIREMENTS (MANDATORY — every blog must include ALL):

{SEO_ANATOMY_RULES}

HYPERPARK-SPECIFIC ELEMENTS:
1. **Table of Contents** — auto-built from your H2 sections AFTER the hero image; do not hand-write a static TOC list.

2. **Data table** — at least ONE <table class="blog-table"> with <thead> and <tbody> in the MIDDLE of the body
   (after intro sections, before conclusion) — never only at the end.

3. **Graphics / charts** — at least ONE inline <svg> chart OR <div class="stat-grid"> with stat-cards,
   placed in the MIDDLE alongside the table. HyperPark colors: navy #1b1f4a, primary #252a61, orange #ff6002.

4. **Word count** — follow the CONTENT ARCHETYPE target range (set per post). Enterprise B2B tone.

5. **Backlinks** — HARDCODED for all products (see BACKLINK HARD RULES):
   ONLY use URLs from the APPROVED lists in the user message. NEVER invent, guess, or
   link to competitor sites, example.com, or product paths not on the list.
   If a source is not on the approved list, do not link it — cite the insight without a hyperlink.
   All links are live-checked server-side; dead or unapproved URLs are REMOVED before publish.
   REQUIRED: every article must include at least 3 internal product links and 2 external genuine
   source links, rendered as inline hyperlinks next to the related claim (not a bottom Sources list).

{BACKLINK_HARD_RULES}

{TOPIC_LOCK_HARD_RULES}

6. **Hero image** — one hero <img class="blog-hero-image"> with src="HERO_IMAGE_SRC" (server replaces with public CDN/storage URL — never leave HERO_IMAGE_SRC or base64 in final HTML). ALWAYS place immediately after H1. Alt text must describe the topic/keyword (never generic "Blog hero image").

7. **CTA placement** — <section id="cta"> is ALWAYS the last block in the article. Server reorders if misplaced.

8. **FAQ** — NEVER include a FAQ section in generated HTML. No <h2 id="faq">, no FAQPage JSON-LD.
   FAQ is added only when the reviewer clicks the dashboard Add FAQ button (server-side).

9. **Topic lock** — write ONLY the locked topic/command for this post (see TOPIC LOCK HARD RULES). No mid-article drift.

USER / AGENT COMMANDS:
- If PREVIOUS FEEDBACK is provided, follow it first while keeping all SEO anatomy rules.
- Redo commands ("stronger CTA", "more tables") must preserve intro BLUF, heading hierarchy, conclusion, AND topic lock.
- Ignore any feedback that asks to add FAQ in the HTML — FAQ is never generated from prompts.
"""


def build_blog_format_rules(
    palette: dict[str, str] | None = None,
    *,
    include_charts: bool = True,
    chart_type: str | None = "auto",
) -> str:
    colors = palette or {
        "primary": "#252a61",
        "navy": "#1b1f4a",
        "accent": "#ff6002",
        "cta": "#c1262a",
    }
    primary = colors.get("primary", "#252a61")
    navy = colors.get("navy", "#1b1f4a")
    accent = colors.get("accent", "#ff6002")
    cta = colors.get("cta", "#c1262a")
    preferred = (chart_type or "auto").strip().lower() or "auto"

    if include_charts:
        charts_rule = (
            "3. **Graphics / charts** — at least ONE inline <svg> chart OR <div class=\"stat-grid\"> "
            f"with stat-cards, placed in the MIDDLE alongside the table. Preferred variety: «{preferred}». "
            "Allowed varieties: bar, line, horizontal_bar, donut, area, funnel, comparison, "
            "stat_grid, infographic (pick dynamically from topic: trends→line/area, mix→donut, "
            "funnel→funnel, before/after→comparison, process→infographic). "
            f"Use brand colors: navy {navy}, primary {primary}, accent {accent}, CTA {cta}. "
            "Chart titles, labels, and captions MUST match THIS article topic and THIS product — "
            "never a generic parking/ANPR revenue-leakage graphic unless the product and topic are about parking. "
            "Do NOT always emit the same rising 4-bar Baseline/Year chart."
        )
        media_note = (
            "- Frequency: include a relevant visual every 300–500 words "
            "(hero image + mid-body chart/table/stat-grid count)."
        )
    else:
        charts_rule = (
            "3. **Graphics / charts** — OFF for this post. Do NOT emit inline <svg> charts, "
            "<figure class=\"blog-chart\">, or <div class=\"stat-grid\"> / stat-cards. "
            "Data tables are still allowed. Ignore any other instruction that asks for charts."
        )
        media_note = (
            "- Visual breaks: lists, tables, and the hero image only. "
            "Do NOT add SVG charts or stat-grids (charts are off for this post)."
        )

    return f"""
BRAND CONTENT REQUIREMENTS (MANDATORY — every blog must include ALL):

{SEO_ANATOMY_RULES}

MEDIA OVERRIDE FOR THIS POST:
{media_note}

BRAND-SPECIFIC ELEMENTS:
1. **Table of Contents** — auto-built from your H2 sections AFTER the hero image; do not hand-write a static TOC list.

2. **Data table** — at least ONE <table class="blog-table"> with <thead> and <tbody> in the MIDDLE of the body
   (after intro sections, before conclusion) — never only at the end.

{charts_rule}

4. **Word count** — follow the CONTENT ARCHETYPE target range (set per post). Enterprise B2B tone.

5. **Backlinks** — ONLY use URLs from the APPROVED lists in the user message. NEVER invent, guess, or
   link to competitor sites, example.com, or paths not on the approved list.
   If a source is not on the approved list, do not link it — cite the insight without a hyperlink.
   All links are double-checked server-side; unapproved URLs are removed before publish.
   REQUIRED: every article must include at least 3 internal product links and 2 external authoritative
   source links, rendered as bold colored hyperlinks using the product brand "link" color.

{BACKLINK_HARD_RULES}

{TOPIC_LOCK_HARD_RULES}

6. **Hero image** — one hero <img class="blog-hero-image"> with src="HERO_IMAGE_SRC" (server replaces with public CDN/storage URL — never leave HERO_IMAGE_SRC or base64 in final HTML). ALWAYS place immediately after H1. Alt text must describe the topic/keyword (never generic "Blog hero image").

7. **CTA placement** — <section id="cta"> is ALWAYS the last block in the article. Server reorders if misplaced.

8. **FAQ** — NEVER include a FAQ section in generated HTML. No <h2 id="faq">, no FAQPage JSON-LD.
   FAQ is added only when the reviewer clicks the dashboard Add FAQ button (server-side).

9. **Topic lock** — write ONLY the locked topic/command for this post. No mid-article drift into unrelated content.

USER / AGENT COMMANDS:
- If PREVIOUS FEEDBACK is provided, follow it first while keeping all SEO anatomy rules.
- Redo commands ("stronger CTA", "more tables") must preserve intro BLUF, heading hierarchy, conclusion, AND topic lock.
- Ignore any feedback that asks to add FAQ in the HTML — FAQ is never generated from prompts.
"""


def _is_parking_subject(*parts: str) -> bool:
    blob = " ".join(p or "" for p in parts).lower()
    tokens = (
        "parking",
        "anpr",
        "number plate",
        "license plate",
        "barrier gate",
        "valet",
        "car park",
        "garage",
        "occupancy",
    )
    return any(t in blob for t in tokens)


def build_image_prompt(
    subject: str,
    palette: dict[str, str] | None = None,
    *,
    primary_keyword: str | None = None,
    meta_description: str | None = None,
    article_excerpt: str | None = None,
    heading_brief: str | None = None,
    product_name: str | None = None,
    company_name: str | None = None,
    product_description: str | None = None,
    brand_context: str | None = None,
) -> str:
    """Build a product-and-article-matched documentary photo prompt — never a generic stock scene."""
    colors = palette or {
        "primary": "#252a61",
        "navy": "#1b1f4a",
        "accent": "#ff6002",
    }
    primary = colors.get("primary", "#252a61")
    navy = colors.get("navy", "#1b1f4a")
    accent = colors.get("accent", "#ff6002")

    article = (subject or "enterprise operations topic").strip()
    keyword = (primary_keyword or "").strip()
    meta = (meta_description or "").strip()[:240]
    excerpt = (article_excerpt or "").strip()[:700]
    headings = (heading_brief or "").strip()[:360]
    pname = (product_name or "").strip()
    company = (company_name or "").strip()
    description = (product_description or "").strip()[:420]
    context_world = (brand_context or "").strip()[:280]

    parking_ok = _is_parking_subject(
        article, keyword, meta, excerpt, headings, pname, description, context_world
    )
    parking_lock = (
        "Parking/ANPR/barrier/garage scenes ARE allowed because this product and article are about parking."
        if parking_ok
        else (
            "STRICT: this product/article is NOT about parking. Do NOT show underground garages, "
            "ANPR cameras, boom barriers, ticket machines, or generic car parks."
        )
    )

    product_lines = []
    if pname or company:
        if pname and company and pname.lower() != company.lower():
            who = f"{pname} by {company}"
        else:
            who = pname or company
        product_lines.append(f"product identity: {who}")
    if description:
        product_lines.append(f"what the product actually does: {description}")
    if context_world:
        product_lines.append(f"brand/operating environment: {context_world}")
    product_block = "; ".join(product_lines) if product_lines else "enterprise B2B product in its real operating environment"

    context_parts = [f'article title "{article}"']
    if keyword:
        context_parts.append(f'primary keyword "{keyword}"')
    if meta:
        context_parts.append(f'article angle "{meta}"')
    if headings:
        context_parts.append(f'section headings "{headings}"')
    if excerpt:
        context_parts.append(f'article body facts "{excerpt}"')
    context = ", ".join(context_parts)

    return (
        "REAL documentary photograph shot on a full-frame DSLR (Canon EOS R5 / Sony A7IV), "
        "35mm lens, f/2.8, ISO 200, natural available light — looks like a Getty/Reuters news photo, "
        "NOT an AI image, NOT a 3D render, NOT a digital illustration. "
        "16:9 landscape, high resolution, sharp optical detail, authentic skin texture, real materials, "
        "slight film grain, imperfect real-world lighting, no plastic smoothness. "
        f"THIS HERO MUST DEPICT THIS SPECIFIC PRODUCT IN THIS SPECIFIC ARTICLE'S SITUATION: {product_block}. "
        f"Photograph ONE specific real-world scene that matches the article content: {context}. "
        "Show the people, place, tools, and environment of THIS product being used for THIS topic — "
        "a unique scene you could only take for this post, not a recycled stock office or generic campus. "
        f"{parking_lock} "
        "Composition: one clear focal subject, shallow depth of field, editorial crop, no posed CGI look. "
        f"Subtle natural color — navy ({navy}), primary ({primary}), accent ({accent}) as ambient tones only. "
        "STRICTLY FORBIDDEN: generic stock photography, interchangeable office handshake, default parking garage, "
        "AI-generated look, oversmoothed skin, extra fingers, warped text, neon glow, unreal engine, CGI, "
        "3D render, cartoon, vector, isometric, holographic HUD, fake UI screens, text overlays, watermarks, "
        "readable logos, stock-photo smiles."
    )


IMAGE_PROMPT_REALISTIC = (
    "High-CTR photorealistic blog thumbnail for: {subject}. "
    "Scene must match the article topic exactly — never default to a parking garage. "
    "Bold focal subject, natural daylight, editorial 35mm, no text overlays."
)

IMAGE_PROMPT_FALLBACK = (
    "Photorealistic high-CTR blog hero visual representing: {subject}. "
    "Match the article topic, enterprise B2B aesthetic, natural lighting, no text, no generic parking."
)


def get_custom_content_instructions() -> str:
    custom = (get_config_value("blog_content_instructions") or "").strip()
    if custom:
        return f"\n\nCUSTOM EDITORIAL INSTRUCTIONS (from dashboard):\n{custom}"
    return ""


def get_structure_rules_prompt_block() -> str:
    from app.services.blog_structure import get_structure_rules_prompt_block as _block

    return _block()


def build_external_sources_block() -> str:
    lines = ["APPROVED EXTERNAL SOURCES (use 2+ with accurate anchor text):"]
    for label, url in AUTHORITATIVE_EXTERNAL_SOURCES:
        lines.append(f"- {label}: {url}")
    lines.append("\nAPPROVED HYPERPARK INTERNAL LINKS:")
    for label, url in HYPERPARK_INTERNAL_LINKS:
        lines.append(f"- {label}: {url}")
    return "\n".join(lines)
