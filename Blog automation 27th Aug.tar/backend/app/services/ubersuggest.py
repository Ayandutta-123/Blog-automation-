"""Ubersuggest MCP integration.

Ubersuggest has no classic REST API — it exposes an official MCP
(Model Context Protocol) server instead, authenticated via OAuth 2.1 +
PKCE with Dynamic Client Registration. This module implements a minimal
MCP client so the backend can call Ubersuggest's keyword-research and
backlink tools programmatically (outside of a chat/AI-assistant context).

Flow:
  1. `ensure_client_registered` — one-time dynamic client registration.
  2. `build_authorize_url` — generates PKCE verifier/challenge + state,
     returns the URL the user's browser must visit to log in & consent.
  3. `exchange_code_for_token` — the OAuth callback exchanges the auth
     code for an access + refresh token.
  4. `list_tools` / `call_tool` — JSON-RPC calls against the MCP endpoint
     using the stored (auto-refreshed) access token.
"""

from __future__ import annotations

import base64
import hashlib
import json
import secrets
import time
from typing import Any, Optional

import httpx
from loguru import logger
from sqlalchemy.orm import Session

from app.services.runtime_config import get_config_value, set_config_value, clear_config_value

MCP_ISSUER = "https://ubersuggest-mcp.neilpatelapi.com"
AUTHORIZE_URL = f"{MCP_ISSUER}/authorize"
TOKEN_URL = f"{MCP_ISSUER}/token"
REGISTER_URL = f"{MCP_ISSUER}/register"
MCP_URL = f"{MCP_ISSUER}/mcp"

SCOPES = "profile keywords backlinks serp domain content"

# Config keys — reuse the AppConfig key/value store (not part of the
# user-facing CONFIG_REGISTRY since these are managed by the OAuth flow,
# not hand-typed).
K_CLIENT_ID = "ubersuggest_client_id"
K_ACCESS_TOKEN = "ubersuggest_access_token"
K_REFRESH_TOKEN = "ubersuggest_refresh_token"
K_EXPIRES_AT = "ubersuggest_token_expires_at"
K_OAUTH_STATE = "ubersuggest_oauth_state"
K_CONNECTED_AT = "ubersuggest_connected_at"
K_KEYWORD_TOOL = "ubersuggest_keyword_tool"
K_BACKLINKS_TOOL = "ubersuggest_backlinks_tool"

# In-memory cache of the negotiated MCP session id (Streamable HTTP transport).
# Not persisted — a fresh session is renegotiated whenever the process restarts
# or the server rejects a stale session id.
_session_id: Optional[str] = None


class UbersuggestError(Exception):
    pass


class UbersuggestNotConnected(UbersuggestError):
    pass


def _b64url(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def is_connected(db: Session) -> bool:
    return bool(get_config_value(K_ACCESS_TOKEN, db) and get_config_value(K_REFRESH_TOKEN, db))


def connection_status(db: Session) -> dict[str, Any]:
    return {
        "connected": is_connected(db),
        "connected_at": get_config_value(K_CONNECTED_AT, db) or None,
        "keyword_tool": get_config_value(K_KEYWORD_TOOL, db) or None,
        "backlinks_tool": get_config_value(K_BACKLINKS_TOOL, db) or None,
    }


def ensure_client_registered(db: Session, redirect_uri: str) -> str:
    """Dynamic Client Registration — register once, reuse the client_id forever."""
    client_id = get_config_value(K_CLIENT_ID, db)
    if client_id:
        return client_id

    payload = {
        "client_name": "HyperPark Blog Automation",
        "redirect_uris": [redirect_uri],
        "grant_types": ["authorization_code", "refresh_token"],
        "response_types": ["code"],
        "token_endpoint_auth_method": "none",
    }
    resp = httpx.post(REGISTER_URL, json=payload, timeout=15)
    if resp.status_code >= 400:
        raise UbersuggestError(f"Client registration failed ({resp.status_code}): {resp.text}")
    data = resp.json()
    client_id = data.get("client_id")
    if not client_id:
        raise UbersuggestError("Registration response missing client_id")
    set_config_value(K_CLIENT_ID, client_id, db, is_secret=False)
    logger.info("Ubersuggest MCP client registered: {}", client_id)
    return client_id


def build_authorize_url(db: Session, redirect_uri: str) -> str:
    client_id = ensure_client_registered(db, redirect_uri)

    code_verifier = _b64url(secrets.token_bytes(40))
    code_challenge = _b64url(hashlib.sha256(code_verifier.encode("ascii")).digest())
    state = _b64url(secrets.token_bytes(24))

    set_config_value(
        K_OAUTH_STATE,
        json.dumps({"state": state, "code_verifier": code_verifier, "redirect_uri": redirect_uri}),
        db,
        is_secret=True,
    )

    params = {
        "response_type": "code",
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "scope": SCOPES,
        "state": state,
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
    }
    query = str(httpx.QueryParams(params))
    return f"{AUTHORIZE_URL}?{query}"


def exchange_code_for_token(db: Session, code: str, state: str) -> None:
    raw = get_config_value(K_OAUTH_STATE, db)
    if not raw:
        raise UbersuggestError("No pending OAuth request found (state missing/expired)")
    try:
        pending = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise UbersuggestError("Corrupt OAuth state") from exc

    if pending.get("state") != state:
        raise UbersuggestError("OAuth state mismatch — possible CSRF, please retry connecting")

    client_id = get_config_value(K_CLIENT_ID, db)
    if not client_id:
        raise UbersuggestError("No registered client_id — retry connecting")

    resp = httpx.post(
        TOKEN_URL,
        data={
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": pending["redirect_uri"],
            "client_id": client_id,
            "code_verifier": pending["code_verifier"],
        },
        timeout=15,
    )
    clear_config_value(K_OAUTH_STATE, db)
    if resp.status_code >= 400:
        raise UbersuggestError(f"Token exchange failed ({resp.status_code}): {resp.text}")

    _store_tokens(db, resp.json())
    set_config_value(K_CONNECTED_AT, str(int(time.time())), db, is_secret=False)
    logger.info("Ubersuggest MCP connected successfully")


def _store_tokens(db: Session, data: dict[str, Any]) -> None:
    access_token = data.get("access_token")
    refresh_token = data.get("refresh_token")
    expires_in = data.get("expires_in", 3600)
    if not access_token:
        raise UbersuggestError("Token response missing access_token")
    set_config_value(K_ACCESS_TOKEN, access_token, db, is_secret=True)
    if refresh_token:
        set_config_value(K_REFRESH_TOKEN, refresh_token, db, is_secret=True)
    set_config_value(K_EXPIRES_AT, str(int(time.time()) + int(expires_in) - 60), db, is_secret=False)


def _refresh_access_token(db: Session) -> str:
    refresh_token = get_config_value(K_REFRESH_TOKEN, db)
    client_id = get_config_value(K_CLIENT_ID, db)
    if not refresh_token or not client_id:
        raise UbersuggestNotConnected("Ubersuggest is not connected")

    resp = httpx.post(
        TOKEN_URL,
        data={
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "client_id": client_id,
        },
        timeout=15,
    )
    if resp.status_code >= 400:
        raise UbersuggestError(f"Token refresh failed ({resp.status_code}): {resp.text}")
    _store_tokens(db, resp.json())
    return get_config_value(K_ACCESS_TOKEN, db)


def get_valid_access_token(db: Session) -> str:
    access_token = get_config_value(K_ACCESS_TOKEN, db)
    if not access_token:
        raise UbersuggestNotConnected("Ubersuggest is not connected")
    expires_at = int(get_config_value(K_EXPIRES_AT, db) or "0")
    if expires_at and time.time() >= expires_at:
        return _refresh_access_token(db)
    return access_token


def disconnect(db: Session) -> None:
    global _session_id
    for key in (K_ACCESS_TOKEN, K_REFRESH_TOKEN, K_EXPIRES_AT, K_CONNECTED_AT, K_OAUTH_STATE):
        clear_config_value(key, db)
    _session_id = None
    setattr(_mcp_call, "_initialized", False)


def _parse_mcp_body(body: str) -> dict[str, Any]:
    """MCP Streamable HTTP responses are either plain JSON or SSE frames.

    Ubersuggest returns SSE shaped like:
      event: message
      data: {"jsonrpc":"2.0","result":{...},"id":1}
    """
    if not body or not body.strip():
        raise UbersuggestError("Empty response from Ubersuggest MCP server")

    stripped = body.lstrip()
    if stripped.startswith("{") or stripped.startswith("["):
        try:
            return json.loads(stripped)
        except json.JSONDecodeError as exc:
            raise UbersuggestError(f"Invalid JSON from MCP: {exc}") from exc

    # SSE: find the last `data:` line with a JSON payload.
    data_payload: Optional[str] = None
    for line in body.splitlines():
        if line.startswith("data:"):
            candidate = line[len("data:"):].strip()
            if candidate and candidate != "[DONE]":
                data_payload = candidate
    if not data_payload:
        raise UbersuggestError(
            f"MCP response had no data frame (starts with: {stripped[:120]!r})"
        )
    try:
        return json.loads(data_payload)
    except json.JSONDecodeError as exc:
        raise UbersuggestError(f"Invalid SSE JSON from MCP: {exc}") from exc


def _raw_post(url: str, token: str, payload: dict[str, Any], session_id: Optional[str]) -> httpx.Response:
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Accept": "application/json, text/event-stream",
    }
    if session_id:
        headers["Mcp-Session-Id"] = session_id
    return httpx.post(url, json=payload, headers=headers, timeout=45)


def _initialize_session(db: Session, token: str) -> Optional[str]:
    """Run MCP initialize handshake. Session id is optional — Ubersuggest may omit it."""
    resp = _raw_post(
        MCP_URL,
        token,
        {
            "jsonrpc": "2.0",
            "id": secrets.randbelow(1_000_000),
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "hyperpark-blog-automation", "version": "1.0"},
            },
        },
        None,
    )
    if resp.status_code >= 400:
        raise UbersuggestError(f"MCP initialize failed ({resp.status_code}): {resp.text[:300]}")

    # Validate the initialize result parses (raises with a clear message if not).
    data = _parse_mcp_body(resp.text)
    if "error" in data:
        raise UbersuggestError(f"MCP initialize error: {data['error']}")

    session_id = resp.headers.get("Mcp-Session-Id") or resp.headers.get("mcp-session-id")
    if session_id:
        try:
            _raw_post(
                MCP_URL,
                token,
                {"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}},
                session_id,
            )
        except httpx.HTTPError:
            pass
    else:
        # Still send the lifecycle notification even without a session id —
        # some MCP servers accept it as a plain HTTP POST.
        try:
            _raw_post(
                MCP_URL,
                token,
                {"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}},
                None,
            )
        except httpx.HTTPError:
            pass
    return session_id


def _mcp_call(db: Session, method: str, params: dict[str, Any], _retried: bool = False) -> Any:
    global _session_id
    token = get_valid_access_token(db)

    # Track whether we've already initialized this process. Use a sentinel so
    # we don't re-init on every call even when the server returns no session id.
    if not getattr(_mcp_call, "_initialized", False):
        _session_id = _initialize_session(db, token)
        setattr(_mcp_call, "_initialized", True)

    resp = _raw_post(
        MCP_URL,
        token,
        {"jsonrpc": "2.0", "id": secrets.randbelow(1_000_000), "method": method, "params": params},
        _session_id,
    )

    if resp.status_code == 401 and not _retried:
        _refresh_access_token(db)
        return _mcp_call(db, method, params, _retried=True)
    if resp.status_code in (400, 404) and not _retried:
        # Stale/rejected session — renegotiate once and retry.
        _session_id = None
        setattr(_mcp_call, "_initialized", False)
        return _mcp_call(db, method, params, _retried=True)
    if resp.status_code >= 400:
        raise UbersuggestError(f"MCP call failed ({resp.status_code}): {resp.text[:300]}")

    data = _parse_mcp_body(resp.text)
    if "error" in data:
        raise UbersuggestError(f"MCP error: {data['error']}")
    return data.get("result")


def list_tools(db: Session) -> list[dict[str, Any]]:
    result = _mcp_call(db, "tools/list", {})
    return (result or {}).get("tools", [])


def call_tool(db: Session, name: str, arguments: dict[str, Any]) -> Any:
    result = _mcp_call(db, "tools/call", {"name": name, "arguments": arguments})
    return result


def set_tool_mapping(db: Session, keyword_tool: Optional[str], backlinks_tool: Optional[str]) -> None:
    if keyword_tool is not None:
        set_config_value(K_KEYWORD_TOOL, keyword_tool, db, is_secret=False)
    if backlinks_tool is not None:
        set_config_value(K_BACKLINKS_TOOL, backlinks_tool, db, is_secret=False)


def _mcp_text_payload(result: Any) -> tuple[Optional[Any], Optional[str], bool]:
    """Extract JSON/text from an MCP tools/call result.

    Returns (parsed_json_or_none, plain_text_or_none, is_error).
    """
    if not isinstance(result, dict):
        return None, None, False
    is_error = bool(result.get("isError"))
    content = result.get("content")
    if not isinstance(content, list):
        return None, None, is_error
    texts: list[str] = []
    for item in content:
        if isinstance(item, dict) and item.get("type") == "text" and isinstance(item.get("text"), str):
            texts.append(item["text"])
    if not texts:
        return None, None, is_error
    joined = "\n".join(texts).strip()
    try:
        return json.loads(joined), joined, is_error
    except json.JSONDecodeError:
        return None, joined, is_error


def _num(value: Any) -> Optional[float]:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str) and value.strip():
        try:
            return float(value.strip().replace(",", ""))
        except ValueError:
            return None
    return None


def _metrics_from_row(row: dict[str, Any], fallback_keyword: str = "") -> dict[str, Any]:
    return {
        "keyword": str(row.get("keyword") or row.get("query") or fallback_keyword or ""),
        "search_volume": _num(row.get("search_volume", row.get("volume", row.get("searchVolume")))),
        "cpc": _num(row.get("cpc", row.get("cpcDollars", row.get("CPC")))),
        "seo_difficulty": _num(
            row.get("seo_difficulty", row.get("seoDifficulty", row.get("difficulty", row.get("sd"))))
        ),
        "paid_difficulty": _num(row.get("paid_difficulty", row.get("paidDifficulty", row.get("pd")))),
        "competition": _num(row.get("competition")),
    }


def lookup_keyword(
    db: Session,
    keyword: str,
    *,
    language: str = "en",
    loc_id: int = 2840,
) -> dict[str, Any]:
    """Fetch keyword volume metrics with free-tier–friendly fallbacks.

    `keyword_overview` is ideal but free accounts are capped at 3 reports/day.
    `keyword_suggestions` returns volume for the seed keyword in `searched_keywords`
    and usually still works after overview hits the quota.
    """
    keyword = (keyword or "").strip()
    if not keyword:
        raise UbersuggestError("Keyword is required")

    preferred = (get_config_value(K_KEYWORD_TOOL, db) or "").strip() or "keyword_suggestions"
    # Always try a volume-capable path that works on free tier last.
    attempts: list[tuple[str, dict[str, Any]]] = []
    if preferred == "keyword_overview":
        attempts.append(
            ("keyword_overview", {"keyword": keyword, "language": language, "locId": loc_id})
        )
    attempts.append(
        ("keyword_suggestions", {"keywords": [keyword], "language": language, "locId": loc_id})
    )
    if preferred not in ("keyword_overview", "keyword_suggestions"):
        attempts.insert(
            0,
            (preferred, {"keyword": keyword, "language": language, "locId": loc_id}),
        )
    # De-dupe by tool name while preserving order
    seen: set[str] = set()
    unique_attempts: list[tuple[str, dict[str, Any]]] = []
    for name, args in attempts:
        if name in seen:
            continue
        seen.add(name)
        unique_attempts.append((name, args))

    last_error = ""
    for tool_name, args in unique_attempts:
        result = call_tool(db, tool_name, args)
        parsed, text, is_error = _mcp_text_payload(result)

        if is_error or (text and text.lower().startswith("error")):
            last_error = text or "Ubersuggest returned an error"
            # Daily free-tier quota — try next tool
            if "daily reports limit" in last_error.lower() or "403" in last_error:
                logger.warning("Ubersuggest {} quota/limit: {}", tool_name, last_error)
                continue
            raise UbersuggestError(last_error)

        if not isinstance(parsed, dict):
            last_error = text or f"Unexpected response from {tool_name}"
            continue

        row: Optional[dict[str, Any]] = None
        # keyword_suggestions shape
        searched = parsed.get("searched_keywords")
        if isinstance(searched, list) and searched and isinstance(searched[0], dict):
            row = searched[0]
        elif "search_volume" in parsed or "volume" in parsed or "keyword" in parsed:
            row = parsed
        elif isinstance(parsed.get("results"), list) and parsed["results"]:
            first = parsed["results"][0]
            if isinstance(first, dict):
                row = first

        if not row:
            last_error = f"No keyword metrics in {tool_name} response"
            continue

        metrics = _metrics_from_row(row, keyword)
        metrics["source_tool"] = tool_name
        metrics["ok"] = True
        if metrics["search_volume"] is None and metrics["cpc"] is None:
            last_error = f"{tool_name} returned no volume/CPC for '{keyword}'"
            continue
        return metrics

    # Friendly message for free-tier limit
    if "daily reports limit" in last_error.lower():
        raise UbersuggestError(
            "Ubersuggest free plan daily limit reached (3 reports/day for keyword_overview). "
            "Upgrade your Ubersuggest plan, or try again tomorrow. "
            "Tip: keyword_suggestions is used as a fallback when available."
        )
    raise UbersuggestError(last_error or "Could not fetch keyword metrics from Ubersuggest")
