from __future__ import annotations

import re
from typing import Any

import httpx
from bs4 import BeautifulSoup
from loguru import logger

from app.config import settings
from app.services.runtime_config import (
    get_config_value,
    is_placeholder_value,
    teams_notifications_enabled,
)


def _is_local_url(url: str) -> bool:
    u = (url or "").lower()
    return "localhost" in u or "127.0.0.1" in u


def _frontend_base() -> str:
    return (get_config_value("frontend_url") or settings.frontend_url or "").rstrip("/")


def _public_base() -> str:
    return (get_config_value("public_base_url") or settings.public_base_url or "").rstrip("/")


def _dashboard_post_url(post_id: int) -> str:
    base = _frontend_base()
    if not base:
        return ""
    return f"{base}/?post={post_id}"


def _hero_image_url(post: Any) -> str | None:
    """Teams fetches images server-side — skip localhost URLs."""
    base = _public_base()
    if not base or _is_local_url(base) or not post.slug:
        return None
    return f"{base}/api/images/{post.slug}.webp"


def _html_snippet(html: str, limit: int = 700) -> str:
    if not html:
        return ""
    soup = BeautifulSoup(html, "html.parser")
    article = soup.find("article") or soup
    text = article.get_text(" ", strip=True)
    text = re.sub(r"\s+", " ", text)
    if len(text) <= limit:
        return text
    return text[:limit].rsplit(" ", 1)[0] + "…"


def _build_topic_card(post_id: int, topics: list[dict[str, str]]) -> dict[str, Any]:
    body: list[dict[str, Any]] = [
        {
            "type": "TextBlock",
            "text": "HyperPark Blog — Topic Selection Required",
            "weight": "Bolder",
            "size": "Large",
            "color": "Accent",
        },
        {
            "type": "TextBlock",
            "text": "Select a topic below or open the dashboard.",
            "wrap": True,
        },
    ]

    actions: list[dict[str, Any]] = []
    for i, topic in enumerate(topics, 1):
        body.append(
            {
                "type": "TextBlock",
                "text": f"**{i}. {topic['title']}**",
                "wrap": True,
            }
        )
        body.append(
            {
                "type": "TextBlock",
                "text": topic.get("description", ""),
                "wrap": True,
                "spacing": "Small",
                "isSubtle": True,
            }
        )

    dashboard_url = _dashboard_post_url(post_id)
    if dashboard_url:
        actions.append(
            {
                "type": "Action.OpenUrl",
                "title": "Open Dashboard",
                "url": dashboard_url,
            }
        )

    return {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "contentUrl": None,
                "content": {
                    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "type": "AdaptiveCard",
                    "version": "1.5",
                    "body": body,
                    "actions": actions,
                },
            }
        ],
    }


def _build_review_card(post: Any) -> dict[str, Any]:
    dashboard_url = _dashboard_post_url(post.id)
    local_urls = _is_local_url(_frontend_base()) or _is_local_url(_public_base())

    body: list[dict[str, Any]] = [
        {
            "type": "TextBlock",
            "text": "HyperPark Blog — Review Required",
            "weight": "Bolder",
            "size": "Large",
            "color": "Accent",
        },
        {"type": "TextBlock", "text": f"**Title:** {post.title_tag or 'N/A'}", "wrap": True},
        {"type": "TextBlock", "text": f"**Slug:** /blog/{post.slug or 'N/A'}", "wrap": True},
        {"type": "TextBlock", "text": f"**Reading Time:** {post.reading_time or 'N/A'}", "wrap": True},
        {
            "type": "TextBlock",
            "text": f"**Meta:** {(post.meta_description or '')[:240]}",
            "wrap": True,
        },
    ]

    hero = _hero_image_url(post)
    if hero:
        body.append(
            {
                "type": "Image",
                "url": hero,
                "size": "Stretch",
                "altText": post.title_tag or post.selected_topic_title or "Article hero image",
            }
        )

    snippet = _html_snippet(post.html_content or "")
    if snippet:
        body.append(
            {
                "type": "TextBlock",
                "text": "**Article preview**",
                "weight": "Bolder",
                "spacing": "Medium",
            }
        )
        body.append(
            {
                "type": "TextBlock",
                "text": snippet,
                "wrap": True,
                "isSubtle": True,
            }
        )

    if local_urls:
        body.append(
            {
                "type": "TextBlock",
                "text": (
                    "Links and images use localhost — Teams cannot open them from your phone. "
                    "Set **Frontend Dashboard URL** and **Public API Base URL** in Settings "
                    "(use a Cloudflare tunnel or public host) for full preview in Teams."
                ),
                "wrap": True,
                "color": "Warning",
            }
        )

    body.append(
        {
            "type": "TextBlock",
            "text": "Approve or request redo from the HyperPark dashboard.",
            "wrap": True,
            "isSubtle": True,
        }
    )

    actions: list[dict[str, Any]] = []
    if dashboard_url:
        actions.append(
            {
                "type": "Action.OpenUrl",
                "title": "Open in Dashboard",
                "url": dashboard_url,
            }
        )

    return {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "contentUrl": None,
                "content": {
                    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "type": "AdaptiveCard",
                    "version": "1.5",
                    "body": body,
                    "actions": actions,
                },
            }
        ],
    }


def send_teams_message(
    payload: dict[str, Any],
    webhook_url: str | None = None,
    *,
    force: bool = False,
) -> bool:
    """Send Teams card. Returns True on success; never raises.

    force=True bypasses the Teams notifications toggle (used for the settings Test button).
    """
    if not force and not teams_notifications_enabled():
        logger.info("Teams notifications disabled in settings; skipping card")
        return False

    webhook_url = (webhook_url or get_config_value("teams_webhook_url") or "").strip()
    if not webhook_url:
        logger.warning("Teams webhook URL not configured; skipping Teams notification")
        return False
    if is_placeholder_value(webhook_url) or "your-org.webhook.office.com" in webhook_url:
        logger.warning("Teams webhook is a placeholder; skipping Teams notification")
        return False

    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.post(webhook_url, json=payload)
            response.raise_for_status()
        logger.info("Teams notification sent successfully")
        return True
    except httpx.HTTPStatusError as exc:
        logger.warning(
            f"Teams webhook returned {exc.response.status_code}; "
            "discovery continues — update webhook in Settings → Integrations"
        )
        return False
    except Exception as exc:
        logger.warning(f"Teams notification failed: {exc}")
        return False


def notify_topic_selection(post_id: int, topics: list[dict[str, str]]) -> None:
    payload = _build_topic_card(post_id, topics)
    send_teams_message(payload)


def notify_review_required(post: Any) -> None:
    payload = _build_review_card(post)
    send_teams_message(payload)


def send_teams_test_message(
    channel_hint: str = "Blog automation Chatbot",
    webhook_url: str | None = None,
) -> tuple[bool, str]:
    """Send a test card to verify the Teams incoming webhook."""
    hint = channel_hint.strip() or "your Teams channel"
    url = (webhook_url or get_config_value("teams_webhook_url") or "").strip()
    if not url:
        return False, "Teams webhook URL is not configured. Paste the Incoming Webhook URL in Settings and save."
    if is_placeholder_value(url) or "your-org.webhook.office.com" in url:
        return (
            False,
            "Teams webhook is still a placeholder. Create an Incoming Webhook in your Teams channel and paste the real URL.",
        )

    payload = {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "content": {
                    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "type": "AdaptiveCard",
                    "version": "1.5",
                    "body": [
                        {
                            "type": "TextBlock",
                            "text": "HyperPark Blog Automation — Teams test",
                            "weight": "Bolder",
                            "size": "Large",
                            "color": "Good",
                        },
                        {
                            "type": "TextBlock",
                            "text": f"Test message for **{hint}**.",
                            "wrap": True,
                        },
                        {
                            "type": "TextBlock",
                            "text": "When a blog draft is ready you will get a Review Required card. After publish you will see a Published confirmation.",
                            "wrap": True,
                            "isSubtle": True,
                        },
                    ],
                },
            }
        ],
    }
    if send_teams_message(payload, webhook_url=url, force=True):
        return True, f"Test message sent to {hint}."
    return False, "Teams rejected the webhook. Check the URL is from the correct channel and has not expired."


def notify_published(
    title: str,
    slug: str,
    *,
    live_url: str | None = None,
    product_name: str | None = None,
    minio_object: str | None = None,
    wordpress_url: str | None = None,
    google_url: str | None = None,
    post_id: int | None = None,
) -> None:
    """Announce a live publish with the exact MinIO (or other) URL when available."""
    display_title = (title or slug or "Blog post").strip()
    product_bit = f" · {product_name}" if product_name else ""

    body: list[dict[str, Any]] = [
        {
            "type": "TextBlock",
            "text": "Blog is live",
            "weight": "Bolder",
            "size": "Large",
            "color": "Good",
        },
        {
            "type": "TextBlock",
            "text": f"**{display_title}**{product_bit}",
            "wrap": True,
        },
        {
            "type": "TextBlock",
            "text": (
                "Your SEO blog has been published successfully and is available at the live link below."
                if live_url
                else "Your SEO blog has been published successfully."
            ),
            "wrap": True,
        },
    ]

    if live_url:
        body.append(
            {
                "type": "TextBlock",
                "text": f"**Live link (MinIO):** [{live_url}]({live_url})",
                "wrap": True,
            }
        )
        if minio_object:
            body.append(
                {
                    "type": "TextBlock",
                    "text": f"Object: `{minio_object}`",
                    "wrap": True,
                    "isSubtle": True,
                    "spacing": "None",
                }
            )
    else:
        body.append(
            {
                "type": "TextBlock",
                "text": f"Slug: `/blog/{slug}`",
                "wrap": True,
                "isSubtle": True,
            }
        )

    extra_links: list[str] = []
    if wordpress_url:
        extra_links.append(f"[WordPress]({wordpress_url})")
    if google_url:
        extra_links.append(f"[Google Blogger]({google_url})")
    if extra_links:
        body.append(
            {
                "type": "TextBlock",
                "text": "Also published to: " + " · ".join(extra_links),
                "wrap": True,
                "spacing": "Medium",
            }
        )

    body.append(
        {
            "type": "TextBlock",
            "text": (
                "To stop receiving Teams publish / review cards, open **Settings → Integrations** "
                "and turn off **Teams notifications**."
            ),
            "wrap": True,
            "isSubtle": True,
            "spacing": "Medium",
        }
    )

    actions: list[dict[str, Any]] = []
    if live_url and not _is_local_url(live_url):
        actions.append(
            {
                "type": "Action.OpenUrl",
                "title": "Open live blog",
                "url": live_url,
            }
        )
    settings_url = ""
    base = _frontend_base()
    if base and not _is_local_url(base):
        settings_url = f"{base}/settings?tab=integrations"
    elif base:
        settings_url = f"{base}/settings?tab=integrations"
    if settings_url:
        actions.append(
            {
                "type": "Action.OpenUrl",
                "title": "Turn off Teams notifications",
                "url": settings_url,
            }
        )
    if post_id:
        dash = _dashboard_post_url(post_id)
        if dash:
            actions.append(
                {
                    "type": "Action.OpenUrl",
                    "title": "Open in Dashboard",
                    "url": dash,
                }
            )

    payload: dict[str, Any] = {
        "type": "message",
        "attachments": [
            {
                "contentType": "application/vnd.microsoft.card.adaptive",
                "content": {
                    "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                    "type": "AdaptiveCard",
                    "version": "1.5",
                    "body": body,
                    "actions": actions,
                },
            }
        ],
    }
    send_teams_message(payload)
