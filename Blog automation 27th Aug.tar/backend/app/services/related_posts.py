"""Related Hyperthings / product pages index + contextual inline linking.

Updated on every publish. Used by seo_pipeline.finalize_blog_fragment to inject
2–3 contextual internal links into body copy (in addition to the end CTA).
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from bs4 import BeautifulSoup, NavigableString, Tag
from loguru import logger

from app.config import settings

RELATED_INDEX_PATH = Path(settings.storage_root) / "blogs" / "related_posts.json"

# Always-available product-style pages (Hyperthings.ai / HyperPark ecosystem)
DEFAULT_RELATED_PAGES: list[dict[str, str]] = [
    {
        "title": "Hyperthings.ai",
        "url": "https://hyperthings.ai/",
        "keywords": "hyperthings enterprise iot mobility platform",
    },
    {
        "title": "Smart parking platform",
        "url": "https://hyperpark.io/smart-parking",
        "keywords": "parking anpr access occupancy automation",
    },
    {
        "title": "Access management solutions",
        "url": "https://hyperpark.io/access-management",
        "keywords": "access control gate barrier credential",
    },
    {
        "title": "HyperPark platform",
        "url": "https://hyperpark.io/",
        "keywords": "hyperpark enterprise mobility saas",
    },
    {
        "title": "Book a live demo",
        "url": "https://calendly.com/vijayrhts/htssales",
        "keywords": "demo roi pilot procurement",
    },
]


def _index_path() -> Path:
    path = RELATED_INDEX_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def load_related_index() -> list[dict[str, str]]:
    path = _index_path()
    if not path.is_file():
        return list(DEFAULT_RELATED_PAGES)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        posts = data.get("posts") if isinstance(data, dict) else data
        if not isinstance(posts, list):
            return list(DEFAULT_RELATED_PAGES)
        cleaned: list[dict[str, str]] = []
        for item in posts:
            if isinstance(item, dict) and item.get("url") and item.get("title"):
                cleaned.append(
                    {
                        "title": str(item["title"]),
                        "url": str(item["url"]),
                        "keywords": str(item.get("keywords") or item.get("title") or ""),
                    }
                )
        return cleaned or list(DEFAULT_RELATED_PAGES)
    except Exception as exc:
        logger.warning(f"Could not read related posts index: {exc}")
        return list(DEFAULT_RELATED_PAGES)


def save_related_index(posts: list[dict[str, str]]) -> None:
    path = _index_path()
    payload = {"posts": posts}
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    logger.info(f"Related posts index updated ({len(posts)} entries) → {path}")


def register_published_post(
    *,
    title: str,
    url: str,
    primary_keyword: str = "",
    slug: str = "",
) -> None:
    """Append/update this post in the related-pages index after publish."""
    posts = load_related_index()
    # Keep defaults + published blogs; upsert by URL
    posts = [p for p in posts if p.get("url") != url]
    posts.insert(
        0,
        {
            "title": title or slug or url,
            "url": url,
            "keywords": f"{primary_keyword} {title} {slug}".strip(),
        },
    )
    # Cap growth but keep defaults present
    default_urls = {d["url"] for d in DEFAULT_RELATED_PAGES}
    defaults = [p for p in posts if p["url"] in default_urls]
    blogs = [p for p in posts if p["url"] not in default_urls][:40]
    # Prefer defaults first then recent blogs
    seen: set[str] = set()
    merged: list[dict[str, str]] = []
    for p in defaults + blogs:
        if p["url"] in seen:
            continue
        seen.add(p["url"])
        merged.append(p)
    save_related_index(merged)


def _score(page: dict[str, str], haystack: str) -> int:
    score = 0
    hay = haystack.lower()
    for token in re.split(r"\W+", (page.get("keywords") or "").lower()):
        if len(token) > 3 and token in hay:
            score += 2
    for token in re.split(r"\W+", (page.get("title") or "").lower()):
        if len(token) > 3 and token in hay:
            score += 1
    return score


def pick_related_pages(
    html: str,
    product: Any = None,
    *,
    limit: int = 3,
    exclude_url: str | None = None,
) -> list[dict[str, str]]:
    from app.services.product_context import internal_links_tuples

    pages = load_related_index()
    # Merge product internal links
    for label, url in internal_links_tuples(product):
        if not any(p["url"] == url for p in pages):
            pages.append({"title": label, "url": url, "keywords": label})

    text = BeautifulSoup(html or "", "html.parser").get_text(" ", strip=True).lower()
    scored = []
    for page in pages:
        if exclude_url and page["url"].rstrip("/") == exclude_url.rstrip("/"):
            continue
        scored.append((_score(page, text), page))
    scored.sort(key=lambda x: (-x[0], x[1]["title"]))
    # Prefer positive scores; fill with defaults if needed
    chosen = [p for s, p in scored if s > 0][:limit]
    if len(chosen) < limit:
        for _, p in scored:
            if p in chosen:
                continue
            chosen.append(p)
            if len(chosen) >= limit:
                break
    return chosen[:limit]


def insert_contextual_internal_links(html: str, product: Any = None) -> str:
    """Insert 2–3 contextual inline links into body paragraphs (not TOC/CTA/FAQ)."""
    soup = BeautifulSoup(html or "", "html.parser")
    article = soup.find("article")
    if not article:
        return html

    related = pick_related_pages(html, product=product, limit=3)
    if not related:
        return html

    # Skip if enough product-domain links already in body
    existing_hrefs = {
        (a.get("href") or "").rstrip("/")
        for a in article.find_all("a", href=True)
        if not a.find_parent("section", id="cta")
        and not a.find_parent("nav", class_="toc")
    }
    needed = [p for p in related if p["url"].rstrip("/") not in existing_hrefs]
    if not needed:
        return html

    paragraphs = [
        p
        for p in article.find_all("p")
        if not p.find_parent("nav")
        and not p.find_parent("section", id="cta")
        and not p.find_parent(id="faq")
        and len(p.get_text(strip=True)) > 80
    ]
    # Prefer middle body paragraphs
    if len(paragraphs) > 4:
        paragraphs = paragraphs[2 : len(paragraphs) - 1]

    inserted = 0
    for page, p in zip(needed[:3], paragraphs):
        if p.find("a"):
            # Still allow adding if paragraph doesn't already link to this URL
            if any((a.get("href") or "").rstrip("/") == page["url"].rstrip("/") for a in p.find_all("a")):
                continue
        # Append a short contextual clause with the link
        space = NavigableString(" ")
        link = soup.new_tag("a", href=page["url"])
        link.string = page["title"]
        clause = NavigableString(" — explore more on ")
        period = NavigableString(".")
        # Insert before last period if present
        text = p.get_text()
        if text.endswith("."):
            # Rebuild last text node softly: append before end
            p.append(clause)
            p.append(link)
            p.append(period)
        else:
            p.append(clause)
            p.append(link)
            p.append(NavigableString("."))
        inserted += 1

    if inserted:
        logger.info(f"Inserted {inserted} contextual internal link(s)")
    return str(soup)
