"""Split comma/Excel lists into individual scraper targets."""

from __future__ import annotations

import csv
import io
import re
from typing import Iterable

from sqlalchemy.orm import Session

from app.models import ScraperCategory, ScraperSettings

_SPLIT_RE = re.compile(r"[\n\r;]+|,")
_HEADER_SKIP = {
    "keyword",
    "keywords",
    "industry keywords",
    "industry keyword",
    "query",
    "queries",
    "url",
    "urls",
    "competitor url",
    "competitor urls",
    "rss",
    "rss feed",
    "rss feeds",
    "feed",
    "feeds",
    "value",
    "values",
}


def split_scraper_values(raw: str | None) -> list[str]:
    """Turn 'a, b, c' or newline-separated text into unique trimmed values."""
    if not raw:
        return []
    seen: set[str] = set()
    out: list[str] = []
    for part in _SPLIT_RE.split(str(raw)):
        value = " ".join(part.strip().split())
        if not value or value.casefold() in _HEADER_SKIP:
            continue
        key = value.casefold()
        if key in seen:
            continue
        seen.add(key)
        out.append(value[:512])
    return out


def parse_spreadsheet_values(data: bytes, filename: str) -> list[str]:
    name = (filename or "").lower()
    if name.endswith(".csv") or name.endswith(".txt"):
        text = data.decode("utf-8-sig", errors="replace")
        chunks: list[str] = []
        reader = csv.reader(io.StringIO(text))
        for row in reader:
            for cell in row:
                if cell and str(cell).strip():
                    chunks.append(str(cell).strip())
        if not chunks:
            chunks = [text]
        return split_scraper_values("\n".join(chunks))

    from openpyxl import load_workbook

    workbook = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    try:
        sheet = workbook.active
        chunks = []
        for row in sheet.iter_rows(values_only=True):
            for cell in row:
                if cell is None:
                    continue
                text = str(cell).strip()
                if text:
                    chunks.append(text)
        return split_scraper_values("\n".join(chunks))
    finally:
        workbook.close()


def insert_scraper_values(
    db: Session,
    *,
    category: ScraperCategory,
    values: Iterable[str],
    product_id: int | None,
    added_by: str = "Admin",
) -> tuple[list[ScraperSettings], int, int]:
    cleaned = split_scraper_values("\n".join(str(v) for v in values))
    if category == ScraperCategory.RSS_FEED:
        from app.services.scraper import normalize_rss_feed_url

        normalized: list[str] = []
        seen: set[str] = set()
        for item in cleaned:
            value = normalize_rss_feed_url(item)
            key = value.casefold()
            if key in seen:
                continue
            seen.add(key)
            normalized.append(value)
        cleaned = normalized

    existing_q = db.query(ScraperSettings).filter(ScraperSettings.category == category)
    if product_id is None:
        existing_q = existing_q.filter(ScraperSettings.product_id.is_(None))
    else:
        existing_q = existing_q.filter(ScraperSettings.product_id == product_id)
    existing = {row.value.casefold() for row in existing_q.all()}

    added_models: list[ScraperSettings] = []
    skipped = 0
    for value in cleaned:
        if value.casefold() in existing:
            skipped += 1
            continue
        existing.add(value.casefold())
        row = ScraperSettings(
            category=category,
            value=value,
            added_by=added_by or "Admin",
            is_active=True,
            product_id=product_id,
        )
        db.add(row)
        added_models.append(row)

    if added_models:
        db.commit()
        for row in added_models:
            db.refresh(row)

    return added_models, skipped, len(cleaned)
