from __future__ import annotations

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from loguru import logger
from sqlalchemy.orm import Session
from zoneinfo import ZoneInfo

from app.config import settings
from app.database import SessionLocal
from app.models import Product
from app.services.product_assets import schedules_from_product
from app.services.runtime_config import get_config_value
from app.services.workflow import complete_discovery_run, start_discovery_run

scheduler = BackgroundScheduler()

WEEKDAY_IDS = {"mon", "tue", "wed", "thu", "fri", "sat", "sun"}


def _zoneinfo(tz_name: str | None) -> ZoneInfo:
    name = (tz_name or settings.cron_timezone or "Asia/Kolkata").strip()
    try:
        return ZoneInfo(name)
    except Exception:
        logger.warning(f"Invalid timezone '{name}', falling back to Asia/Kolkata")
        return ZoneInfo("Asia/Kolkata")


def _normalize_day(day: str | None) -> str:
    value = (day or settings.cron_day_of_week or "mon").strip().lower()[:3]
    return value if value in WEEKDAY_IDS else "mon"


def _run_product_discovery(product_id: int) -> None:
    post_id = start_discovery_run(product_id)
    complete_discovery_run(post_id)


def migrate_global_schedule_to_products(db: Session) -> None:
    """Copy legacy global cron settings into the default product once."""
    product = db.query(Product).filter(Product.is_default.is_(True)).first()
    if not product:
        product = db.query(Product).order_by(Product.id).first()
    if not product:
        return

    day = get_config_value("cron_day_of_week", db)
    hour = get_config_value("cron_hour", db)
    minute = get_config_value("cron_minute", db)
    tz = get_config_value("cron_timezone", db)

    changed = False
    if day:
        product.cron_day_of_week = _normalize_day(day)
        changed = True
    if hour is not None and str(hour).isdigit():
        product.cron_hour = int(hour)
        changed = True
    if minute is not None and str(minute).isdigit():
        product.cron_minute = int(minute)
        changed = True
    if tz:
        product.cron_timezone = str(tz).strip()
        changed = True

    if changed and not product.discovery_schedules_json:
        product.discovery_schedules_json = [
            {
                "id": "default",
                "day_of_week": product.cron_day_of_week or "mon",
                "hour": int(product.cron_hour if product.cron_hour is not None else 9),
                "minute": int(product.cron_minute if product.cron_minute is not None else 0),
            }
        ]

    if changed:
        db.commit()
        logger.info(f"Migrated global discovery schedule to product #{product.id}")


def reschedule_all_discovery_jobs() -> None:
    if not scheduler.running:
        return

    db = SessionLocal()
    try:
        products = (
            db.query(Product)
            .filter(Product.is_active.is_(True), Product.schedule_enabled.is_(True))
            .order_by(Product.id)
            .all()
        )
        keep_ids: set[str] = set()

        for product in products:
            # Manual mode is fully human-driven — never fire cron for these products
            mode = (getattr(product, "topic_selection_mode", None) or "manual").strip().lower()
            if mode not in ("auto", "hybrid"):
                logger.info(
                    f"Skipping schedule for '{product.name}' (#{product.id}): mode={mode}"
                )
                continue

            schedules = schedules_from_product(product)
            tz = _zoneinfo(product.cron_timezone)
            for slot in schedules:
                job_id = f"weekly_discovery_{product.id}_{slot['id']}"
                keep_ids.add(job_id)
                trigger = CronTrigger(
                    day_of_week=_normalize_day(slot["day_of_week"]),
                    hour=int(slot["hour"]),
                    minute=int(slot["minute"]),
                    timezone=tz,
                )
                scheduler.add_job(
                    _run_product_discovery,
                    trigger=trigger,
                    args=[product.id],
                    id=job_id,
                    replace_existing=True,
                    misfire_grace_time=3600,
                )
                logger.info(
                    f"Scheduled discovery for '{product.name}' (#{product.id} / {slot['id']}): "
                    f"{slot['day_of_week']} {int(slot['hour']):02d}:{int(slot['minute']):02d} ({tz})"
                )

        for job in list(scheduler.get_jobs()):
            if not job.id.startswith("weekly_discovery_"):
                continue
            if job.id not in keep_ids:
                scheduler.remove_job(job.id)
    finally:
        db.close()


def start_scheduler() -> None:
    reschedule_all_discovery_jobs()
    scheduler.start()
    logger.info("Per-product discovery scheduler started")


def stop_scheduler() -> None:
    if scheduler.running:
        scheduler.shutdown(wait=False)
        logger.info("Scheduler stopped")
