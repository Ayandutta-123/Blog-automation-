from __future__ import annotations

import uuid
from typing import Any


WEEKDAY_IDS = {"mon", "tue", "wed", "thu", "fri", "sat", "sun"}


def _normalize_day(day: str | None) -> str:
    value = (day or "mon").strip().lower()[:3]
    return value if value in WEEKDAY_IDS else "mon"


def normalize_schedule_slot(raw: dict[str, Any] | None) -> dict[str, Any] | None:
    if not isinstance(raw, dict):
        return None
    try:
        hour = int(raw.get("hour", 9))
        minute = int(raw.get("minute", 0))
    except (TypeError, ValueError):
        return None
    hour = max(0, min(23, hour))
    minute = max(0, min(59, minute))
    slot_id = str(raw.get("id") or uuid.uuid4().hex[:10])
    return {
        "id": slot_id,
        "day_of_week": _normalize_day(str(raw.get("day_of_week") or raw.get("day") or "mon")),
        "hour": hour,
        "minute": minute,
    }


def normalize_schedules(
    raw: Any,
    *,
    fallback_day: str = "mon",
    fallback_hour: int = 9,
    fallback_minute: int = 0,
) -> list[dict[str, Any]]:
    slots: list[dict[str, Any]] = []
    if isinstance(raw, list):
        for item in raw:
            slot = normalize_schedule_slot(item if isinstance(item, dict) else None)
            if slot:
                slots.append(slot)
    if not slots:
        slots.append(
            {
                "id": "default",
                "day_of_week": _normalize_day(fallback_day),
                "hour": int(fallback_hour),
                "minute": int(fallback_minute),
            }
        )
    # de-dupe identical day+time
    seen: set[tuple[str, int, int]] = set()
    unique: list[dict[str, Any]] = []
    for slot in slots:
        key = (slot["day_of_week"], slot["hour"], slot["minute"])
        if key in seen:
            continue
        seen.add(key)
        unique.append(slot)
    return unique[:14]


def schedules_from_product(product: Any) -> list[dict[str, Any]]:
    return normalize_schedules(
        getattr(product, "discovery_schedules_json", None),
        fallback_day=getattr(product, "cron_day_of_week", None) or "mon",
        fallback_hour=getattr(product, "cron_hour", None) if getattr(product, "cron_hour", None) is not None else 9,
        fallback_minute=getattr(product, "cron_minute", None) if getattr(product, "cron_minute", None) is not None else 0,
    )


def sync_legacy_cron_fields(product: Any, schedules: list[dict[str, Any]]) -> None:
    first = schedules[0] if schedules else {
        "day_of_week": "mon",
        "hour": 9,
        "minute": 0,
    }
    product.cron_day_of_week = first["day_of_week"]
    product.cron_hour = first["hour"]
    product.cron_minute = first["minute"]


def normalize_pdf_entry(raw: dict[str, Any] | None) -> dict[str, Any] | None:
    if not isinstance(raw, dict):
        return None
    filename = str(raw.get("filename") or "").strip()
    if not filename:
        return None
    return {
        "id": str(raw.get("id") or uuid.uuid4().hex[:12]),
        "filename": filename,
        "original_name": str(raw.get("original_name") or filename),
        "extracted_text": str(raw.get("extracted_text") or "")[:12000],
    }


def normalize_pdfs(raw: Any) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    if isinstance(raw, list):
        for item in raw:
            entry = normalize_pdf_entry(item if isinstance(item, dict) else None)
            if entry:
                out.append(entry)
    return out


def pdfs_from_product(product: Any) -> list[dict[str, Any]]:
    pdfs = normalize_pdfs(getattr(product, "pdfs_json", None))
    if pdfs:
        return pdfs
    # Legacy single-PDF fields
    legacy_name = getattr(product, "pdf_filename", None)
    if legacy_name:
        return [
            {
                "id": "legacy",
                "filename": legacy_name,
                "original_name": legacy_name,
                "extracted_text": str(getattr(product, "pdf_extracted_text", None) or "")[:12000],
            }
        ]
    return []


def sync_legacy_pdf_fields(product: Any, pdfs: list[dict[str, Any]]) -> None:
    if not pdfs:
        product.pdf_filename = None
        product.pdf_extracted_text = None
        return
    product.pdf_filename = pdfs[0]["filename"]
    product.pdf_extracted_text = pdfs[0].get("extracted_text") or None
