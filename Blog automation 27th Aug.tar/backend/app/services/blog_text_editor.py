"""Plain-text editing for blog HTML — preserves tables, charts, CTA structure."""

from __future__ import annotations

import re
import time

from bs4 import BeautifulSoup, NavigableString

_SKIP_ANCESTORS = frozenset({"table", "svg", "script", "section", "nav"})


def extract_editable_text(html: str) -> str:
    """Pull human-readable text from article (no raw HTML)."""
    soup = BeautifulSoup(html, "html.parser")
    article = soup.find("article")
    root = article if article else soup
    lines: list[str] = []

    for el in root.find_all(["h1", "h2", "h3", "p", "li"]):
        if _is_inside_skipped(el):
            continue
        text = el.get_text(" ", strip=True)
        if not text:
            continue
        if el.name in ("h1", "h2", "h3"):
            lines.append(f"## {text}")
        else:
            lines.append(text)

    if not lines and root:
        return root.get_text("\n\n", strip=True)
    return "\n\n".join(lines)


def _is_inside_skipped(el) -> bool:
    for parent in el.parents:
        if getattr(parent, "name", None) in _SKIP_ANCESTORS:
            return True
    return False


def apply_editable_text(html: str, body_text: str) -> str:
    """Merge plain-text edits into existing HTML without touching tables/charts/CTA."""
    soup = BeautifulSoup(html, "html.parser")
    article = soup.find("article")
    if not article:
        return html

    blocks = [b.strip() for b in re.split(r"\n\s*\n", body_text.strip()) if b.strip()]
    editable = [
        el
        for el in article.find_all(["h1", "h2", "h3", "p", "li"])
        if not _is_inside_skipped(el)
    ]

    for el, block in zip(editable, blocks):
        if block.startswith("## "):
            block = block[3:].strip()
        el.clear()
        el.append(NavigableString(block))

    return str(soup)


def hero_img_tag(slug: str, base_url: str, alt: str | None = None) -> str:
    """Hero img with public URL + cache-bust. Never base64; alt must be topic-specific."""
    from html import escape

    from app.services.seo_pipeline import descriptive_hero_alt

    v = int(time.time())
    src = f"{base_url.rstrip('/')}/api/images/{slug}.webp?v={v}"
    alt_text = escape(
        alt or descriptive_hero_alt(slug.replace("-", " "), None),
        quote=True,
    )
    return (
        f'<img src="{src}" loading="lazy" decoding="async" '
        f'width="1200" height="630" class="blog-hero-image" alt="{alt_text}" />'
    )
