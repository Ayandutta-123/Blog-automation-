"""Server-stored brand palette batches (5 core colors) shared across products."""

from __future__ import annotations

import json
import re
import uuid
from typing import Any

from sqlalchemy.orm import Session

from app.models import AppConfig
from app.services.product_context import BRAND_PALETTE_KEYS, DEFAULT_BRAND_PALETTE, normalize_brand_palette

STORAGE_KEY = "brand_palette_batches"

HEX_RE = re.compile(r"^#[0-9A-Fa-f]{6}$")

# Seeded once when the store is empty — users can add more batches anytime.
DEFAULT_BATCHES: list[dict[str, Any]] = [
    {
        "id": "hyperpark",
        "name": "Default · Navy & Orange",
        "builtin": True,
        "colors": {
            "primary": "#252a61",
            "navy": "#1b1f4a",
            "accent": "#ff6002",
            "cta": "#c1262a",
            "link": "#1d4ed8",
        },
    },
    {
        "id": "ocean",
        "name": "Ocean Blue",
        "builtin": True,
        "colors": {
            "primary": "#0ea5e9",
            "navy": "#0c4a6e",
            "accent": "#38bdf8",
            "cta": "#0284c7",
            "link": "#0369a1",
        },
    },
    {
        "id": "forest",
        "name": "Forest Green",
        "builtin": True,
        "colors": {
            "primary": "#166534",
            "navy": "#14532d",
            "accent": "#22c55e",
            "cta": "#15803d",
            "link": "#15803d",
        },
    },
    {
        "id": "slate",
        "name": "Enterprise Slate",
        "builtin": True,
        "colors": {
            "primary": "#475569",
            "navy": "#1e293b",
            "accent": "#94a3b8",
            "cta": "#334155",
            "link": "#2563eb",
        },
    },
    {
        "id": "crimson",
        "name": "Crimson",
        "builtin": True,
        "colors": {
            "primary": "#b91c1c",
            "navy": "#7f1d1d",
            "accent": "#f87171",
            "cta": "#dc2626",
            "link": "#b91c1c",
        },
    },
]


def _normalize_hex(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    cleaned = value.strip()
    if not cleaned.startswith("#"):
        cleaned = f"#{cleaned}"
    if not HEX_RE.match(cleaned):
        return None
    return cleaned.lower()


def _normalize_colors(raw: Any) -> dict[str, str]:
    palette = normalize_brand_palette(raw if isinstance(raw, dict) else None)
    return {key: str(palette[key]) for key in BRAND_PALETTE_KEYS}


def _normalize_batch(raw: Any) -> dict[str, Any] | None:
    if not isinstance(raw, dict):
        return None
    name = str(raw.get("name") or "").strip()
    if not name:
        return None
    batch_id = str(raw.get("id") or "").strip() or str(uuid.uuid4())
    colors = _normalize_colors(raw.get("colors") or raw)
    return {
        "id": batch_id[:64],
        "name": name[:80],
        "builtin": bool(raw.get("builtin")),
        "colors": colors,
    }


def _read_raw(db: Session) -> list[dict[str, Any]] | None:
    row = db.query(AppConfig).filter(AppConfig.key == STORAGE_KEY).first()
    if not row or not (row.value or "").strip():
        return None
    try:
        data = json.loads(row.value)
    except Exception:
        return None
    if not isinstance(data, list):
        return None
    return data


def _write_batches(db: Session, batches: list[dict[str, Any]]) -> None:
    payload = json.dumps(batches, ensure_ascii=False)
    row = db.query(AppConfig).filter(AppConfig.key == STORAGE_KEY).first()
    if row:
        row.value = payload
        row.is_secret = False
    else:
        db.add(AppConfig(key=STORAGE_KEY, value=payload, is_secret=False))
    db.commit()


def list_palette_batches(db: Session) -> list[dict[str, Any]]:
    raw = _read_raw(db)
    if raw is None:
        seeded = [dict(b) for b in DEFAULT_BATCHES]
        _write_batches(db, seeded)
        return seeded

    batches: list[dict[str, Any]] = []
    for item in raw:
        normalized = _normalize_batch(item)
        if normalized:
            batches.append(normalized)

    if not batches:
        seeded = [dict(b) for b in DEFAULT_BATCHES]
        _write_batches(db, seeded)
        return seeded
    return batches


def create_palette_batch(
    db: Session,
    *,
    name: str,
    colors: dict[str, Any],
) -> dict[str, Any]:
    cleaned_name = (name or "").strip()
    if not cleaned_name:
        raise ValueError("Batch name is required")

    batch = {
        "id": str(uuid.uuid4()),
        "name": cleaned_name[:80],
        "builtin": False,
        "colors": _normalize_colors(colors),
    }
    batches = list_palette_batches(db)
    batches.append(batch)
    _write_batches(db, batches)
    return batch


def delete_palette_batch(db: Session, batch_id: str) -> list[dict[str, Any]]:
    batches = list_palette_batches(db)
    target = next((b for b in batches if b["id"] == batch_id), None)
    if not target:
        raise KeyError("Palette batch not found")
    if target.get("builtin") and target["id"] == "hyperpark":
        raise ValueError("The default HyperPark palette cannot be deleted")
    next_batches = [b for b in batches if b["id"] != batch_id]
    if not next_batches:
        next_batches = [dict(DEFAULT_BATCHES[0])]
    _write_batches(db, next_batches)
    return next_batches


def empty_core_colors() -> dict[str, str]:
    return {key: DEFAULT_BRAND_PALETTE[key] for key in BRAND_PALETTE_KEYS}
