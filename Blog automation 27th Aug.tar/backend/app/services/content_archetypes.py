"""Content archetypes with word-count targets and SEO intent."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

ContentArchetypeId = Literal[
    "quick_faq",
    "news_update",
    "tutorial",
    "listicle",
    "pillar",
]

DEFAULT_ARCHETYPE: ContentArchetypeId = "tutorial"


@dataclass(frozen=True)
class ContentArchetype:
    id: ContentArchetypeId
    label: str
    min_words: int
    max_words: int
    intent: str
    structure_notes: str


ARCHETYPES: dict[ContentArchetypeId, ContentArchetype] = {
    "quick_faq": ContentArchetype(
        id="quick_faq",
        label="Quick Answers & FAQs",
        min_words=400,
        max_words=800,
        intent="Immediate definition, single-question resolution, winning Featured Snippets.",
        structure_notes=(
            "Lead with a direct BLUF answer in the first paragraph. Use 2–4 short Q&A-style H2/H3s "
            "(question as heading). Do NOT add a Frequently Asked Questions / <h2 id=\"faq\"> block — "
            "that is only added later via the dashboard Add FAQ button. Keep sections short."
        ),
    ),
    "news_update": ContentArchetype(
        id="news_update",
        label="News & Industry Updates",
        min_words=500,
        max_words=900,
        intent="Time-sensitive reporting, summarizing a new release or tool update.",
        structure_notes=(
            "Open with what happened and why it matters today. Include date/context, key changes, "
            "and impact on enterprise parking/mobility teams. Short sections; link to approved sources inline."
        ),
    ),
    "tutorial": ContentArchetype(
        id="tutorial",
        label="Standard Tutorials & How-Tos",
        min_words=1200,
        max_words=1800,
        intent="Actionable step-by-step guidance, prerequisite lists, basic troubleshooting.",
        structure_notes=(
            "Include prerequisites, numbered implementation steps, troubleshooting H3s, and mid-body table/chart. "
            "Micro-paragraphs (2–4 sentences). End with Conclusion + CTA (no FAQ section)."
        ),
    ),
    "listicle": ContentArchetype(
        id="listicle",
        label="Listicles & Reviews",
        min_words=1500,
        max_words=2500,
        intent="Comparing 5–10 items; ~150–250 words per list item plus comparison tables.",
        structure_notes=(
            "Use H2 per list item (5–10 items). Each item gets pros/cons or feature bullets. "
            "Include a comparison table in the middle. Bold key terms per item."
        ),
    ),
    "pillar": ContentArchetype(
        id="pillar",
        label="Pillar Posts & Ultimate Guides",
        min_words=2500,
        max_words=4000,
        intent="Deep-dive evergreen authority; designed to attract backlinks and act as a link hub.",
        structure_notes=(
            "Comprehensive H2 chapters with multiple H3 subsections. Multiple tables/charts spaced every 300–500 words. "
            "Strong internal links to HyperPark pages. Do NOT add an <h2 id=\"faq\"> block."
        ),
    ),
}


def normalize_archetype(value: str | None) -> ContentArchetypeId:
    key = (value or DEFAULT_ARCHETYPE).strip().lower().replace("-", "_")
    if key in ARCHETYPES:
        return key  # type: ignore[return-value]
    return DEFAULT_ARCHETYPE


def get_archetype(value: str | None) -> ContentArchetype:
    return ARCHETYPES[normalize_archetype(value)]


def word_count_in_range(count: int, archetype_id: str | None) -> bool:
    arch = get_archetype(archetype_id)
    return arch.min_words <= count <= arch.max_words


def build_archetype_prompt_block(archetype_id: str | None) -> str:
    arch = get_archetype(archetype_id)
    return f"""
CONTENT ARCHETYPE: {arch.label}
HARD WORD COUNT LIMIT (NON-NEGOTIABLE — count only visible article body words):
- MINIMUM: {arch.min_words} words
- MAXIMUM: {arch.max_words} words
- Target midpoint (~{ (arch.min_words + arch.max_words) // 2 } words).
- Exceeding {arch.max_words} or falling below {arch.min_words} is a FAILED draft.
- Prefer fewer, tighter sections over long essays when the max is under 1000 words.
PRIMARY SEO / USER INTENT: {arch.intent}
STRUCTURE FOR THIS ARCHETYPE: {arch.structure_notes}
"""


def list_archetypes_for_api() -> list[dict]:
    return [
        {
            "id": a.id,
            "label": a.label,
            "min_words": a.min_words,
            "max_words": a.max_words,
            "intent": a.intent,
        }
        for a in ARCHETYPES.values()
    ]
