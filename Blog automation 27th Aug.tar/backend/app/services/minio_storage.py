"""Upload published blog HTML to MinIO / S3-compatible storage.

This deployment exposes the MinIO *Console* on HTTPS :443. The S3 API listens on
127.0.0.1:9000 inside the cluster and is not reachable externally (ports 9000/9001
time out). Uploads therefore:

1. Try the native S3 API (MinIO Python SDK) with a short timeout.
2. Fall back to the Console REST API (login cookie + multipart upload), which is
   what the browser UI uses and is reachable from outside.
"""

from __future__ import annotations

from datetime import datetime
from io import BytesIO
from pathlib import Path
from typing import Any, Optional
from urllib.parse import quote, urlencode, urlparse

import httpx
from loguru import logger

from app.services.runtime_config import get_config_value

# Long-lived share links for Google Sheet / Excel (≈10 years). Path-style URLs
# are preferred when the bucket is publicly readable; share is the fallback.
_SHARE_EXPIRES = "87600h"


class MinioUploadError(Exception):
    pass


def _cfg(key: str, default: str = "") -> str:
    return (get_config_value(key) or default or "").strip()


def minio_configured() -> bool:
    return bool(
        _cfg("minio_endpoint")
        and _cfg("minio_access_key")
        and _cfg("minio_secret_key")
        and _cfg("minio_bucket")
    )


def _parse_endpoint(raw: str) -> tuple[str, bool]:
    """Return (host[:port], secure) from a URL or host:port string."""
    value = (raw or "").strip().rstrip("/")
    if not value:
        raise MinioUploadError("MinIO endpoint is empty")

    if "://" in value:
        parsed = urlparse(value)
        host = parsed.hostname or ""
        if parsed.port:
            host = f"{host}:{parsed.port}"
        secure = parsed.scheme != "http"
        if not host:
            raise MinioUploadError(f"Invalid MinIO endpoint: {raw}")
        return host, secure

    secure_flag = _cfg("minio_secure", "true").lower()
    secure = secure_flag not in ("0", "false", "no", "off")
    return value, secure


def _console_base_url() -> str:
    """Public console origin (strip :9000/:9001 — those ports are not reachable externally)."""
    endpoint_raw = _cfg("minio_endpoint")
    endpoint, _secure = _parse_endpoint(endpoint_raw)
    host = endpoint.split(":")[0]
    # Console is fronted by HTTPS (Caddy). Only use http if explicitly configured
    # without an API port (rare).
    if endpoint_raw.strip().lower().startswith("http://") and ":900" not in endpoint:
        scheme = "http"
    else:
        scheme = "https"
    return f"{scheme}://{host}"


def _public_base_url() -> str:
    """Origin used for clickable public object links (sheet / Excel / HTML)."""
    explicit = _cfg("minio_public_base_url").rstrip("/")
    if explicit:
        return explicit
    return _console_base_url()


def public_object_url(object_name: str, *, bucket: str | None = None) -> str:
    """Stable public HTTPS URL for a MinIO object (clickable in Google Sheets).

    Format: ``{public_base}/{bucket}/{object_key}``
    Works when the bucket (or prefix) allows anonymous GetObject. Prefer this over
    local ``/api/images/...`` paths in ledgers.
    """
    bucket_name = (bucket or _cfg("minio_bucket") or "").strip()
    key = (object_name or "").lstrip("/")
    if not bucket_name or not key:
        return ""
    base = _public_base_url().rstrip("/")
    return f"{base}/{bucket_name}/{quote(key, safe='/')}"


def public_download_url(object_name: str, *, bucket: str | None = None) -> str:
    """Console download URL (serves the file bytes when anonymous download is allowed)."""
    bucket_name = (bucket or _cfg("minio_bucket") or "").strip()
    key = (object_name or "").lstrip("/")
    if not bucket_name or not key:
        return ""
    base = _public_base_url().rstrip("/")
    qs = urlencode({"prefix": key})
    return f"{base}/api/v1/buckets/{quote(bucket_name, safe='')}/objects/download?{qs}"


def resolve_public_url(
    object_name: str,
    *,
    existing_url: str = "",
    bucket: str | None = None,
) -> str:
    """Pick the best public URL for ledgers: existing → path-style → download API."""
    for candidate in (
        (existing_url or "").strip(),
        public_object_url(object_name, bucket=bucket),
        public_download_url(object_name, bucket=bucket),
    ):
        if candidate.startswith("http://") or candidate.startswith("https://"):
            return candidate
    return (existing_url or "").strip()


def _object_key(
    slug: str,
    *,
    filename: str | None = None,
    published_at: Optional[datetime] = None,
) -> str:
    """Build object key: {prefix}/{YYYY}/{MM}/{DD}/{HHMMSS}_{slug}.html"""
    from datetime import timezone

    prefix = _cfg("minio_prefix", "blogs").strip().strip("/")
    ts = published_at or datetime.now(timezone.utc)
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    date_path = ts.strftime("%Y/%m/%d")
    stamp = ts.strftime("%H%M%S")
    name = filename or f"{stamp}_{slug}.html"
    if prefix:
        return f"{prefix}/{date_path}/{name}"
    return f"{date_path}/{name}"


def get_minio_client():
    from minio import Minio
    from urllib3 import PoolManager, Timeout
    from app.config import settings as env_settings

    endpoint_raw = _cfg("minio_endpoint")
    access_key = _cfg("minio_access_key")
    secret_key = _cfg("minio_secret_key")
    if not endpoint_raw or not access_key or not secret_key:
        raise MinioUploadError(
            "MinIO is not configured. Set minio_endpoint, minio_access_key, "
            "minio_secret_key, and minio_bucket in Settings → Integrations or .env."
        )

    endpoint, secure = _parse_endpoint(endpoint_raw)
    region = (_cfg("minio_region") or getattr(env_settings, "minio_region", "") or "").strip() or None
    http_client = PoolManager(
        timeout=Timeout(connect=4.0, read=10.0),
        retries=False,
    )
    return Minio(
        endpoint,
        access_key=access_key,
        secret_key=secret_key,
        secure=secure,
        region=region,
        http_client=http_client,
    )


def _client_variants() -> list[Any]:
    """Build S3 client(s) — short timeout; used only when API port is actually open."""
    from minio import Minio
    from urllib3 import PoolManager, Timeout
    from app.config import settings as env_settings

    endpoint_raw = _cfg("minio_endpoint")
    access_key = _cfg("minio_access_key")
    secret_key = _cfg("minio_secret_key")
    if not endpoint_raw or not access_key or not secret_key:
        raise MinioUploadError("MinIO is not configured")

    endpoint, secure = _parse_endpoint(endpoint_raw)
    region = (_cfg("minio_region") or getattr(env_settings, "minio_region", "") or "").strip() or None
    http_client = PoolManager(
        timeout=Timeout(connect=4.0, read=10.0),
        retries=False,
    )

    # Prefer host without :9000/:9001 first when console URL was given, then API ports
    host_only = endpoint.split(":")[0]
    candidates: list[tuple[str, bool]] = []
    seen: set[tuple[str, bool]] = set()

    def add(ep: str, sec: bool) -> None:
        key = (ep, sec)
        if key not in seen:
            seen.add(key)
            candidates.append(key)

    add(endpoint, secure)
    if ":9000" in endpoint or ":9001" in endpoint:
        add(endpoint, not secure)
        add(host_only, True)
    else:
        # Console hostname — S3 API is usually on :9000 internally (often unreachable)
        add(f"{host_only}:9000", False)
        add(f"{host_only}:9000", True)
        add(f"{host_only}:9001", False)
        add(f"{host_only}:9001", True)

    clients = []
    for ep, mode in candidates:
        clients.append(
            Minio(
                ep,
                access_key=access_key,
                secret_key=secret_key,
                secure=mode,
                region=region,
                http_client=http_client,
            )
        )
    return clients


def _with_working_s3_client(fn):
    last_exc: Optional[Exception] = None
    for client in _client_variants():
        try:
            return fn(client)
        except Exception as exc:
            last_exc = exc
            logger.debug("MinIO S3 client attempt failed: {}", exc)
            continue
    raise MinioUploadError(f"MinIO S3 API unreachable: {last_exc}") from last_exc


def ensure_bucket(client: Any, bucket: str) -> None:
    from minio.error import S3Error

    try:
        if not client.bucket_exists(bucket):
            client.make_bucket(bucket)
            logger.info("Created MinIO bucket: {}", bucket)
    except S3Error as exc:
        if exc.code not in ("BucketAlreadyOwnedByYou", "BucketAlreadyExists"):
            raise MinioUploadError(f"MinIO bucket check failed: {exc}") from exc


def _upload_via_s3(
    *,
    data: bytes,
    object_name: str,
    content_type: str,
) -> dict[str, str]:
    bucket = _cfg("minio_bucket")
    if not bucket:
        raise MinioUploadError("minio_bucket is not configured")

    def _do(client: Any) -> dict[str, str]:
        ensure_bucket(client, bucket)
        stream = BytesIO(data)
        result = client.put_object(
            bucket,
            object_name,
            stream,
            length=len(data),
            content_type=content_type,
        )
        is_secure = getattr(client, "_secure", True)
        endpoint = str(getattr(getattr(client, "_base_url", None), "host", None) or _parse_endpoint(_cfg("minio_endpoint"))[0])
        # Prefer the configured public base (console / CDN), not the internal S3 host.
        public_url = public_object_url(object_name, bucket=bucket) or (
            f"{'https' if is_secure else 'http'}://{endpoint}/{bucket}/{object_name}"
        )
        logger.info(
            "Uploaded via S3 API: s3://{}/{} (etag={})",
            bucket,
            object_name,
            getattr(result, "etag", None),
        )
        return {
            "bucket": bucket,
            "object_name": object_name,
            "etag": str(getattr(result, "etag", "") or ""),
            "url": public_url,
            "via": "s3",
        }

    return _with_working_s3_client(_do)


def _upload_via_console(
    *,
    data: bytes,
    object_name: str,
    content_type: str,
) -> dict[str, str]:
    """Upload through MinIO Console REST API (public :443).

    Console expects:
      POST /api/v1/buckets/{bucket}/objects/upload?prefix=<full-object-key>
      multipart form field name = file size (decimal string)
    """
    bucket = _cfg("minio_bucket")
    access_key = _cfg("minio_access_key")
    secret_key = _cfg("minio_secret_key")
    if not bucket or not access_key or not secret_key:
        raise MinioUploadError("MinIO is not configured")

    base = _console_base_url()
    key = object_name.lstrip("/")
    filename = Path(key).name or "upload.bin"

    with httpx.Client(timeout=httpx.Timeout(10.0, connect=8.0), follow_redirects=True) as client:
        login = client.post(
            f"{base}/api/v1/login",
            json={"accessKey": access_key, "secretKey": secret_key},
        )
        if login.status_code not in (200, 204):
            raise MinioUploadError(
                f"MinIO console login failed ({login.status_code}): {login.text[:300]}"
            )

        # Form field *name* must be the byte size (Console API contract)
        files = {
            str(len(data)): (filename, data, content_type or "application/octet-stream"),
        }
        upload = client.post(
            f"{base}/api/v1/buckets/{bucket}/objects/upload",
            params={"prefix": key},
            files=files,
        )
        if upload.status_code not in (200, 201, 204):
            raise MinioUploadError(
                f"MinIO console upload failed ({upload.status_code}): {upload.text[:500]}"
            )

        # Verify object appears in listing
        listed = client.get(
            f"{base}/api/v1/buckets/{bucket}/objects",
            params={"prefix": key},
        )
        if listed.status_code == 200:
            body = listed.json() if listed.content else {}
            objects = body.get("objects") or []
            names = {o.get("name") for o in objects if isinstance(o, dict)}
            # Console may return name with or without trailing specifics
            if objects and key not in names and not any(
                (n or "").rstrip("/") == key or (n or "").endswith(filename) for n in names
            ):
                logger.warning(
                    "MinIO console upload returned OK but object not listed under prefix={!r} names={}",
                    key,
                    names,
                )

        public_url = public_object_url(key, bucket=bucket) or f"{base}/{bucket}/{key}"
        share_url = _console_share_url(client, base=base, bucket=bucket, key=key)
        if share_url:
            public_url = share_url

    logger.info("Uploaded via MinIO Console API: {} → {}", key, public_url)
    return {
        "bucket": bucket,
        "object_name": key,
        "etag": "",
        "url": public_url,
        "via": "console",
    }


def _console_share_url(
    client: httpx.Client,
    *,
    base: str,
    bucket: str,
    key: str,
) -> Optional[str]:
    """Ask MinIO Console for a long-lived share URL (clickable without login)."""
    try:
        resp = client.post(
            f"{base}/api/v1/buckets/{bucket}/objects/share",
            json={"prefix": key, "expires": _SHARE_EXPIRES},
        )
        if resp.status_code >= 400:
            logger.debug(
                "MinIO share URL unavailable ({}): {}",
                resp.status_code,
                (resp.text or "")[:200],
            )
            return None
        data = resp.json() if resp.content else None
        if isinstance(data, str) and data.startswith("http"):
            return data.strip()
        if isinstance(data, dict):
            for field in ("url", "shareUrl", "share_url", "downloadUrl"):
                value = data.get(field)
                if isinstance(value, str) and value.startswith("http"):
                    return value.strip()
        text = (resp.text or "").strip().strip('"')
        if text.startswith("http"):
            return text
    except Exception as exc:
        logger.debug("MinIO share URL request failed: {}", exc)
    return None


def upload_bytes(
    *,
    data: bytes,
    object_name: str,
    content_type: str = "application/octet-stream",
) -> dict[str, str]:
    """Upload raw bytes — Console API first (public :443), then S3 SDK fallback."""
    if not data:
        raise MinioUploadError("Nothing to upload (empty bytes)")

    bucket = _cfg("minio_bucket")
    if not bucket:
        raise MinioUploadError("minio_bucket is not configured")

    # This cluster's S3 API is internal-only (127.0.0.1:9000); Console on :443 works.
    # Try Console first so publish does not wait on connect timeouts to :9000/:9001.
    console_error: Optional[Exception] = None
    try:
        return _upload_via_console(data=data, object_name=object_name, content_type=content_type)
    except Exception as exc:
        console_error = exc
        logger.warning("MinIO Console upload failed — trying S3 API: {}", exc)

    try:
        return _upload_via_s3(data=data, object_name=object_name, content_type=content_type)
    except Exception as exc:
        raise MinioUploadError(
            f"MinIO upload failed (Console: {console_error}; S3: {exc})"
        ) from exc


def upload_file(
    path: Path | str,
    *,
    object_name: str | None = None,
    content_type: str = "application/octet-stream",
) -> dict[str, str]:
    file_path = Path(path)
    if not file_path.is_file():
        raise MinioUploadError(f"File not found: {file_path}")
    key = object_name or file_path.name
    return upload_bytes(
        data=file_path.read_bytes(),
        object_name=key,
        content_type=content_type,
    )


def upload_published_html(
    *,
    slug: str,
    html_path: Path | str,
    html_content: Optional[str] = None,
    published_at: Optional[datetime] = None,
) -> Optional[dict[str, str]]:
    """Upload a published blog HTML file. Returns None if MinIO is not configured."""
    if not minio_configured():
        logger.info("MinIO not configured — skipping HTML upload for '{}'", slug)
        return None

    path = Path(html_path)
    if html_content is not None:
        data = html_content.encode("utf-8")
    elif path.is_file():
        data = path.read_bytes()
    else:
        raise MinioUploadError(f"Published HTML missing for slug '{slug}': {path}")

    object_name = _object_key(slug, published_at=published_at)
    try:
        return upload_bytes(
            data=data,
            object_name=object_name,
            content_type="text/html; charset=utf-8",
        )
    except MinioUploadError:
        raise
    except Exception as exc:
        raise MinioUploadError(f"MinIO upload failed for '{slug}': {exc}") from exc


def upload_hero_image(
    *,
    slug: str,
    image_path: Path | str,
    published_at: Optional[datetime] = None,
) -> Optional[dict[str, str]]:
    """Upload the hero image next to the HTML so the published page is self-contained.

    Without this the page points back at ``public_base_url``; if that host is private
    (or still the localhost default) every reader sees a broken image.
    """
    if not minio_configured():
        return None

    path = Path(image_path)
    if not path.is_file():
        return None

    suffix = path.suffix.lower() or ".webp"
    content_type = {
        ".webp": "image/webp",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".png": "image/png",
        ".gif": "image/gif",
    }.get(suffix, "application/octet-stream")

    from datetime import timezone as _tz

    ts = published_at or datetime.now(_tz.utc)
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=_tz.utc)
    filename = f"{ts.strftime('%H%M%S')}_{slug}{suffix}"
    object_name = _object_key(slug, filename=filename, published_at=ts)

    try:
        return upload_bytes(
            data=path.read_bytes(),
            object_name=object_name,
            content_type=content_type,
        )
    except Exception as exc:
        logger.warning("MinIO hero image upload failed for '{}': {}", slug, exc)
        return None


def connection_status() -> dict[str, Any]:
    """Lightweight status for Settings / health checks."""
    configured = minio_configured()
    status: dict[str, Any] = {
        "configured": configured,
        "endpoint": _cfg("minio_endpoint") or None,
        "console_url": _console_base_url() if configured else None,
        "bucket": _cfg("minio_bucket") or None,
        "prefix": _cfg("minio_prefix", "blogs") or "blogs",
        "ok": False,
        "mode": None,
        "error": None,
        "buckets": [],
        "server_endpoint": None,
    }
    if not configured:
        status["error"] = "Missing MinIO endpoint / credentials / bucket"
        return status

    # Prefer Console probe — matches what publish actually uses externally
    try:
        base = _console_base_url()
        access_key = _cfg("minio_access_key")
        secret_key = _cfg("minio_secret_key")
        with httpx.Client(timeout=httpx.Timeout(8.0, connect=5.0), follow_redirects=True) as client:
            login = client.post(
                f"{base}/api/v1/login",
                json={"accessKey": access_key, "secretKey": secret_key},
            )
            if login.status_code not in (200, 204):
                raise MinioUploadError(f"Console login failed ({login.status_code})")
            sess = client.get(f"{base}/api/v1/session")
            if sess.status_code == 200:
                payload = sess.json()
                status["server_endpoint"] = payload.get("serverEndPoint")
            buckets_resp = client.get(f"{base}/api/v1/buckets")
            buckets_resp.raise_for_status()
            payload = buckets_resp.json()
            names = [b.get("name") for b in (payload.get("buckets") or []) if b.get("name")]
            status["buckets"] = names
            status["ok"] = True
            status["mode"] = "console"
            bucket = _cfg("minio_bucket")
            if bucket and bucket not in names:
                status["error"] = f"Bucket '{bucket}' not found (will try to create on upload)"
            if status.get("server_endpoint") and "127.0.0.1" in str(status["server_endpoint"]):
                # Informational — S3 API is internal-only
                status["error"] = (
                    status.get("error")
                    or "S3 API is internal-only (127.0.0.1:9000); uploads use Console API on :443"
                )
        return status
    except Exception as console_exc:
        logger.debug("MinIO console status probe failed: {}", console_exc)

    try:
        def _probe(client: Any) -> list[str]:
            return [b.name for b in client.list_buckets()]

        buckets = _with_working_s3_client(_probe)
        status["buckets"] = buckets
        status["ok"] = True
        status["mode"] = "s3"
        bucket = _cfg("minio_bucket")
        if bucket and bucket not in buckets:
            status["error"] = f"Bucket '{bucket}' not found (will try to create on upload)"
    except Exception as exc:
        status["error"] = str(exc)
    return status
