"""Google Blogger publisher — per-product OAuth access token + blog ID."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional

import httpx
from loguru import logger
from sqlalchemy.orm import Session
from sqlalchemy.orm.attributes import flag_modified

from app.models import Product

BLOGGER_API = "https://www.googleapis.com/blogger/v3"
GOOGLE_TOKEN = "https://oauth2.googleapis.com/token"


class GoogleBloggerError(Exception):
    pass


def get_google_config(product: Product) -> dict[str, Any]:
    raw = getattr(product, "google_json", None) or {}
    return dict(raw) if isinstance(raw, dict) else {}


def google_configured(product: Product) -> bool:
    cfg = get_google_config(product)
    return bool(
        cfg.get("blog_id")
        and cfg.get("access_token")
        and cfg.get("connected")
    )


def google_public_status(product: Product) -> dict[str, Any]:
    cfg = get_google_config(product)
    return {
        "product_id": product.id,
        "product_name": product.name,
        "connected": google_configured(product),
        "blog_id": cfg.get("blog_id"),
        "blog_name": cfg.get("blog_name"),
        "blog_url": cfg.get("blog_url"),
        "connected_at": cfg.get("connected_at"),
        "is_draft": bool(cfg.get("is_draft", False)),
        "has_token": bool(cfg.get("access_token")),
        "has_refresh_token": bool(cfg.get("refresh_token")),
    }


def _auth_headers(access_token: str) -> dict[str, str]:
    return {
        "Authorization": f"Bearer {access_token.strip()}",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }


def refresh_google_access_token(cfg: dict[str, Any]) -> Optional[str]:
    refresh = (cfg.get("refresh_token") or "").strip()
    client_id = (cfg.get("client_id") or "").strip()
    client_secret = (cfg.get("client_secret") or "").strip()
    if not (refresh and client_id and client_secret):
        return None
    try:
        with httpx.Client(timeout=httpx.Timeout(20.0, connect=10.0)) as client:
            resp = client.post(
                GOOGLE_TOKEN,
                data={
                    "client_id": client_id,
                    "client_secret": client_secret,
                    "refresh_token": refresh,
                    "grant_type": "refresh_token",
                },
            )
            if resp.status_code >= 400:
                logger.warning("Google token refresh failed: {}", resp.text[:200])
                return None
            return (resp.json() or {}).get("access_token")
    except httpx.HTTPError as exc:
        logger.warning("Google token refresh error: {}", exc)
        return None


def test_google_connection(
    *,
    blog_id: str,
    access_token: str,
    refresh_token: str = "",
    client_id: str = "",
    client_secret: str = "",
) -> dict[str, Any]:
    blog = (blog_id or "").strip()
    token = (access_token or "").strip()
    if not blog:
        raise GoogleBloggerError("Blogger blog ID is required")
    if not token:
        raise GoogleBloggerError("Google OAuth access token is required")

    cfg = {
        "refresh_token": refresh_token,
        "client_id": client_id,
        "client_secret": client_secret,
    }

    def _get(tok: str) -> httpx.Response:
        with httpx.Client(timeout=httpx.Timeout(20.0, connect=10.0)) as client:
            return client.get(
                f"{BLOGGER_API}/blogs/{blog}",
                headers=_auth_headers(tok),
            )

    resp = _get(token)
    if resp.status_code in (401, 403):
        refreshed = refresh_google_access_token(cfg)
        if refreshed:
            token = refreshed
            resp = _get(token)
        if resp.status_code in (401, 403):
            raise GoogleBloggerError(
                "Google rejected this access token. Generate a token with the "
                "Blogger scope (https://www.googleapis.com/auth/blogger) via "
                "OAuth Playground, and optionally save a refresh token."
            )
    if resp.status_code == 404:
        raise GoogleBloggerError(
            f"Blogger blog ID '{blog}' was not found for this Google account."
        )
    if resp.status_code >= 400:
        raise GoogleBloggerError(
            f"Blogger API error (HTTP {resp.status_code}): {(resp.text or '')[:300]}"
        )

    data = resp.json() or {}
    return {
        "ok": True,
        "blog_id": str(data.get("id") or blog),
        "blog_name": data.get("name"),
        "blog_url": data.get("url"),
        "access_token": token,
    }


def save_google_credentials(
    db: Session,
    product: Product,
    *,
    blog_id: str,
    access_token: str,
    refresh_token: str = "",
    client_id: str = "",
    client_secret: str = "",
    is_draft: bool = False,
) -> dict[str, Any]:
    probe = test_google_connection(
        blog_id=blog_id,
        access_token=access_token,
        refresh_token=refresh_token,
        client_id=client_id,
        client_secret=client_secret,
    )
    product.google_json = {
        "blog_id": probe["blog_id"],
        "blog_name": probe.get("blog_name"),
        "blog_url": probe.get("blog_url"),
        "access_token": probe.get("access_token") or access_token.strip(),
        "refresh_token": (refresh_token or "").strip() or None,
        "client_id": (client_id or "").strip() or None,
        "client_secret": (client_secret or "").strip() or None,
        "connected": True,
        "connected_at": datetime.now(timezone.utc).isoformat(),
        "is_draft": bool(is_draft),
    }
    flag_modified(product, "google_json")
    db.commit()
    db.refresh(product)
    logger.info(
        "Google Blogger connected for product #{} → {}",
        product.id,
        probe.get("blog_url") or probe.get("blog_id"),
    )
    return google_public_status(product)


def disconnect_google(db: Session, product: Product) -> dict[str, Any]:
    product.google_json = None
    flag_modified(product, "google_json")
    db.commit()
    db.refresh(product)
    return google_public_status(product)


def _ensure_access_token(db: Optional[Session], product: Product, cfg: dict[str, Any]) -> str:
    token = (cfg.get("access_token") or "").strip()
    refreshed = refresh_google_access_token(cfg)
    if refreshed:
        token = refreshed
        cfg["access_token"] = refreshed
        product.google_json = cfg
        if db is not None:
            flag_modified(product, "google_json")
            db.commit()
    if not token:
        raise GoogleBloggerError("Missing Google access token")
    return token


def publish_post_to_google(
    *,
    product: Product,
    title: str,
    content_html: str,
    labels: Optional[list[str]] = None,
    is_draft: Optional[bool] = None,
    db: Optional[Session] = None,
) -> dict[str, Any]:
    if not google_configured(product):
        raise GoogleBloggerError("Google Blogger is not connected for this product")

    cfg = get_google_config(product)
    blog_id = cfg["blog_id"]
    draft = bool(cfg.get("is_draft")) if is_draft is None else bool(is_draft)
    token = _ensure_access_token(db, product, cfg)

    body: dict[str, Any] = {
        "kind": "blogger#post",
        "blog": {"id": str(blog_id)},
        "title": title or "Untitled",
        "content": content_html or "",
    }
    if labels:
        body["labels"] = [l for l in labels if l][:20]

    params = {"isDraft": "true" if draft else "false"}

    try:
        with httpx.Client(timeout=httpx.Timeout(45.0, connect=12.0)) as client:
            resp = client.post(
                f"{BLOGGER_API}/blogs/{blog_id}/posts/",
                headers=_auth_headers(token),
                params=params,
                json=body,
            )
            if resp.status_code in (401, 403):
                # One retry after refresh
                new_tok = refresh_google_access_token(cfg)
                if new_tok:
                    token = new_tok
                    cfg["access_token"] = new_tok
                    product.google_json = cfg
                    if db is not None:
                        flag_modified(product, "google_json")
                        db.commit()
                    resp = client.post(
                        f"{BLOGGER_API}/blogs/{blog_id}/posts/",
                        headers=_auth_headers(token),
                        params=params,
                        json=body,
                    )
            if resp.status_code in (401, 403):
                raise GoogleBloggerError(
                    "Google rejected credentials while publishing. Reconnect Blogger in Settings."
                )
            if resp.status_code >= 400:
                raise GoogleBloggerError(
                    f"Blogger publish failed (HTTP {resp.status_code}): {(resp.text or '')[:400]}"
                )
            data = resp.json() or {}
    except GoogleBloggerError:
        raise
    except httpx.HTTPError as exc:
        raise GoogleBloggerError(f"Blogger publish request failed: {exc}") from exc

    result = {
        "id": data.get("id"),
        "url": data.get("url"),
        "title": data.get("title"),
        "status": "draft" if draft else "live",
        "blog_id": blog_id,
    }
    logger.info("Published to Blogger for product #{}: {}", product.id, result.get("url"))
    return result
