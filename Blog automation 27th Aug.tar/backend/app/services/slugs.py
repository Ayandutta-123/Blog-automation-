"""Deterministic, unique slugs for products and blog posts."""

from __future__ import annotations

import re
import unicodedata
from typing import Any, Optional

from sqlalchemy.orm import Session

from app.models import BlogPost, Product

_SLUG_RE = re.compile(r"[^a-z0-9]+")
_MULTI_DASH = re.compile(r"-{2,}")


def slugify(text: str, *, max_len: int = 80) -> str:
    """Stable ASCII slug — same input always yields the same output."""
    raw = (text or "").strip()
    if not raw:
        return "item"
    normalized = unicodedata.normalize("NFKD", raw)
    ascii_text = normalized.encode("ascii", "ignore").decode("ascii")
    slug = _SLUG_RE.sub("-", ascii_text.lower()).strip("-")
    slug = _MULTI_DASH.sub("-", slug)
    if not slug:
        slug = "item"
    return slug[:max_len].strip("-") or "item"


def allocate_product_slug(
    db: Session,
    name: str,
    *,
    exclude_product_id: Optional[int] = None,
) -> str:
    """Unique product slug derived from name. Fixed once assigned (call only on create/backfill)."""
    base = slugify(name, max_len=64) or "product"
    candidate = base
    n = 2
    while True:
        q = db.query(Product).filter(Product.slug == candidate)
        if exclude_product_id is not None:
            q = q.filter(Product.id != exclude_product_id)
        if not q.first():
            return candidate
        suffix = f"-{n}"
        candidate = f"{base[: max(1, 64 - len(suffix))]}{suffix}"
        n += 1
        if n > 500:
            return f"{base[:50]}-{exclude_product_id or 'x'}"


def ensure_product_slug(db: Session, product: Product) -> str:
    """Return existing product slug, or assign a fixed unique one once."""
    current = (getattr(product, "slug", None) or "").strip()
    if current:
        return current
    product.slug = allocate_product_slug(db, product.name or f"product-{product.id}", exclude_product_id=product.id)
    return product.slug


def backfill_product_slugs(db: Session) -> int:
    """Assign fixed unique slugs to any products missing one."""
    updated = 0
    products = db.query(Product).order_by(Product.id.asc()).all()
    for product in products:
        before = (getattr(product, "slug", None) or "").strip()
        ensure_product_slug(db, product)
        if (product.slug or "") != before:
            updated += 1
    if updated:
        db.commit()
    return updated


def allocate_blog_slug(
    db: Session,
    *,
    product: Optional[Any],
    primary_keyword: str,
    topic_title: str = "",
    post_id: Optional[int] = None,
    lock_slug: Optional[str] = None,
) -> str:
    """
    Fixed blog slug for a post.

    - If lock_slug is set (revisions), keep it forever.
    - Otherwise: ``{product_slug}-{keyword}`` — deterministic and unique across products.
    - On collision with another post, append ``-{post_id}`` (stable for that post).
    """
    if lock_slug and lock_slug.strip():
        return slugify(lock_slug, max_len=200)

    product_slug = "product"
    if product is not None:
        if getattr(product, "slug", None):
            product_slug = slugify(str(product.slug), max_len=64)
        elif getattr(product, "id", None):
            product_slug = f"p{product.id}"
        elif getattr(product, "name", None):
            product_slug = slugify(str(product.name), max_len=64)

    keyword = (primary_keyword or topic_title or "post").strip()
    base_kw = slugify(keyword, max_len=100)
    base = slugify(f"{product_slug}-{base_kw}", max_len=180)

    taken_q = db.query(BlogPost).filter(BlogPost.slug == base)
    if post_id is not None:
        taken_q = taken_q.filter(BlogPost.id != post_id)
    taken = taken_q.first()
    if not taken:
        return base

    # Collision: pin to this post id so it stays fixed forever for this post
    if post_id:
        pinned = slugify(f"{base}-{post_id}", max_len=200)
        return pinned

    # No post id yet — numeric suffix (rare path)
    n = 2
    while n < 500:
        candidate = slugify(f"{base}-{n}", max_len=200)
        exists = db.query(BlogPost).filter(BlogPost.slug == candidate).first()
        if not exists:
            return candidate
        n += 1
    return slugify(f"{base}-x", max_len=200)
