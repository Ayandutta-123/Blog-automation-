from __future__ import annotations

from typing import Any

import anthropic
from loguru import logger

from app.services.runtime_config import get_anthropic_model, get_config_value, is_placeholder_value

# Current Sonnet models (July 2026). Older 3.5 ids are retired.
ANTHROPIC_MODEL_FALLBACKS = (
    "claude-sonnet-4-5",
    "claude-sonnet-4-5-20250929",
    "claude-sonnet-4-6",
    "claude-haiku-4-5",
)


def anthropic_api_key_configured() -> bool:
    key = (get_config_value("anthropic_api_key") or "").strip()
    return bool(key) and not is_placeholder_value(key)


def anthropic_models_to_try() -> list[str]:
    preferred = (get_anthropic_model() or "").strip()
    models: list[str] = []
    if preferred:
        models.append(preferred)
    for model in ANTHROPIC_MODEL_FALLBACKS:
        if model not in models:
            models.append(model)
    return models


def create_claude_message(
    client: anthropic.Anthropic,
    *,
    max_tokens: int,
    system: str,
    messages: list[dict[str, Any]],
) -> anthropic.types.Message:
    last_error: Exception | None = None
    for model in anthropic_models_to_try():
        try:
            logger.info(f"Calling Anthropic model: {model}")
            return client.messages.create(
                model=model,
                max_tokens=max_tokens,
                system=system,
                messages=messages,
            )
        except anthropic.NotFoundError as exc:
            logger.warning(f"Anthropic model not found: {model}")
            last_error = exc
        except anthropic.AuthenticationError as exc:
            raise RuntimeError(
                "Anthropic API key is invalid. Update it in Settings → Integrations."
            ) from exc
        except anthropic.APIStatusError as exc:
            if exc.status_code == 404 and "model" in str(exc).lower():
                logger.warning(f"Anthropic model unavailable: {model}")
                last_error = exc
                continue
            raise

    models = ", ".join(anthropic_models_to_try())
    raise RuntimeError(
        f"No supported Anthropic model available. Tried: {models}. "
        "Set Anthropic Model in Settings → AI & Content (e.g. claude-sonnet-4-5)."
    ) from last_error
