"""Score discovered topics for SEO potential before topic selection."""

from __future__ import annotations

import math
import re
from copy import deepcopy
from typing import Any, Optional

from loguru import logger
from sqlalchemy.orm import Session

from app.services.topic_synthesis import (
    SOURCE_KEYS,
    _compact_competitor,
    _compact_industry,
    _compact_rss,
    flatten_topics,
    normalize_topic_groups,
    pack_topic_groups,
)


def compact_discovery_snapshot(discovery_data: dict[str, Any]) -> dict[str, Any]:
    """Store a compact discovery snapshot on the post for research-pack building."""
    return {
        "industry_trends": _compact_industry(discovery_data.get("industry_trends") or [])[:6],
        "competitor_articles": _compact_competitor(discovery_data.get("competitor_articles") or [])[:8],
        "rss_articles": _compact_rss(discovery_data.get("rss_articles") or [])[:6],
    }


def _tokenize(text: str) -> set[str]:
    return {t for t in re.findall(r"[a-z0-9]{3,}", (text or "").lower()) if len(t) >= 3}


def _keyword_tokens(keyword: str) -> set[str]:
    return _tokenize(keyword)


def count_competitor_matches(keyword: str, discovery_data: dict[str, Any]) -> int:
    """How many scraped competitor articles overlap with the topic keyword."""
    tokens = _keyword_tokens(keyword)
    if not tokens:
        return 0
    matches = 0
    for block in discovery_data.get("competitor_articles") or []:
        for article in block.get("articles") or []:
            hay = " ".join(
                [
                    str(article.get("title") or ""),
                    str(article.get("summary") or ""),
                    str(article.get("url") or ""),
                ]
            ).lower()
            hit = sum(1 for t in tokens if t in hay)
            if hit >= max(1, len(tokens) // 2):
                matches += 1
    return matches


def _volume_score(volume: Optional[float], max_volume: float) -> float:
    if volume is None or volume <= 0:
        return 25.0
    if max_volume <= 0:
        return 50.0
    ratio = min(1.0, math.log1p(volume) / math.log1p(max_volume))
    return 20.0 + ratio * 80.0


def _difficulty_score(difficulty: Optional[float]) -> float:
    if difficulty is None:
        return 50.0
    return max(0.0, min(100.0, 100.0 - float(difficulty)))


def _gap_score(volume: Optional[float], competitor_matches: int, max_volume: float) -> float:
    """High volume + low competitor coverage = opportunity."""
    vol = _volume_score(volume, max_volume) / 100.0
    coverage_penalty = min(1.0, competitor_matches / 5.0)
    return max(0.0, min(100.0, (vol * (1.0 - coverage_penalty * 0.7)) * 100.0))


def _intent_score(topic: dict[str, Any]) -> float:
    source = str(topic.get("source") or "").lower()
    keyword = str(topic.get("primary_keyword") or topic.get("title") or "")
    if source == "industry_keywords":
        return 85.0
    if source == "competitor_urls":
        return 78.0
    if source == "rss_feeds":
        return 70.0
    if len(keyword.split()) >= 2:
        return 72.0
    return 60.0


def _recommendation_label(score: float) -> str:
    if score >= 75:
        return "strong_pick"
    if score >= 60:
        return "good"
    if score >= 45:
        return "moderate"
    return "weak"


def _build_why_lines(
    *,
    volume: Optional[float],
    difficulty: Optional[float],
    competitor_matches: int,
    score: float,
    ubersuggest_used: bool,
) -> list[str]:
    lines: list[str] = []
    if volume and volume > 0:
        if volume >= 1000:
            lines.append(f"Solid search demand (~{int(volume):,}/mo)")
        else:
            lines.append(f"Niche keyword volume (~{int(volume):,}/mo)")
    elif not ubersuggest_used:
        lines.append("Volume estimated from discovery signals (connect Ubersuggest for live data)")
    if difficulty is not None:
        if difficulty < 35:
            lines.append(f"Lower SEO difficulty ({int(difficulty)}) — easier to rank")
        elif difficulty > 60:
            lines.append(f"Higher SEO difficulty ({int(difficulty)}) — competitive space")
    if competitor_matches == 0:
        lines.append("Few direct competitor articles found — content gap opportunity")
    elif competitor_matches <= 2:
        lines.append(f"Only {competitor_matches} overlapping competitor article(s) — room to differentiate")
    else:
        lines.append(f"{competitor_matches} competitor articles cover similar terms — validate your angle")
    if score >= 75:
        lines.append("Overall: strong SEO pick for this discovery run")
    elif score >= 60:
        lines.append("Overall: good balance of demand and feasibility")
    return lines[:4]


def fetch_topic_keyword_metrics(db: Session, keyword: str) -> dict[str, Any]:
    """Best-effort Ubersuggest metrics; returns empty dict when unavailable."""
    from app.services.ubersuggest import UbersuggestError, is_connected, lookup_keyword

    if not is_connected(db) or not keyword.strip():
        return {}
    try:
        return lookup_keyword(db, keyword)
    except UbersuggestError as exc:
        logger.warning("Ubersuggest metrics for '{}': {}", keyword, exc)
        return {}


def score_single_topic(
    topic: dict[str, Any],
    discovery_data: dict[str, Any],
    db: Session,
    *,
    max_volume: float,
    metrics: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    keyword = (topic.get("primary_keyword") or topic.get("title") or "").strip()
    if metrics is None:
        metrics = fetch_topic_keyword_metrics(db, keyword)
    volume = metrics.get("search_volume")
    difficulty = metrics.get("seo_difficulty")
    competitor_matches = count_competitor_matches(keyword, discovery_data)

    vol_score = _volume_score(volume, max_volume)
    diff_score = _difficulty_score(difficulty)
    gap = _gap_score(volume, competitor_matches, max_volume)
    intent = _intent_score(topic)
    citation = 70.0 if metrics else 45.0

    seo_score = round(
        vol_score * 0.30
        + diff_score * 0.25
        + gap * 0.20
        + intent * 0.15
        + citation * 0.10,
        1,
    )

    enriched = {**topic}
    enriched["seo_score"] = seo_score
    enriched["recommendation"] = _recommendation_label(seo_score)
    enriched["seo_signals"] = {
        "search_volume": volume,
        "seo_difficulty": difficulty,
        "cpc": metrics.get("cpc"),
        "competitor_matches": competitor_matches,
        "competitor_gap_score": round(gap, 1),
        "volume_score": round(vol_score, 1),
        "difficulty_score": round(diff_score, 1),
        "ubersuggest_connected": bool(metrics),
        "source_tool": metrics.get("source_tool"),
    }
    enriched["seo_why"] = _build_why_lines(
        volume=volume if isinstance(volume, (int, float)) else None,
        difficulty=difficulty if isinstance(difficulty, (int, float)) else None,
        competitor_matches=competitor_matches,
        score=seo_score,
        ubersuggest_used=bool(metrics),
    )
    return enriched


def enrich_topics_with_seo_analysis(
    topics_payload: dict[str, Any],
    discovery_data: dict[str, Any],
    db: Session,
    *,
    lookup_limit: int = 12,
) -> dict[str, Any]:
    """Attach seo_score / recommendation to each topic; mark global top picks."""
    payload = deepcopy(topics_payload)
    groups = normalize_topic_groups(payload)
    flat = flatten_topics(groups)

    # Pre-fetch volumes for normalization (cap API calls)
    volumes: list[float] = []
    lookup_count = 0
    pre_metrics: dict[str, dict[str, Any]] = {}
    for topic in flat:
        keyword = (topic.get("primary_keyword") or topic.get("title") or "").strip()
        if not keyword or lookup_count >= lookup_limit:
            continue
        metrics = fetch_topic_keyword_metrics(db, keyword)
        pre_metrics[keyword.lower()] = metrics
        vol = metrics.get("search_volume")
        if isinstance(vol, (int, float)) and vol > 0:
            volumes.append(float(vol))
        lookup_count += 1

    max_volume = max(volumes) if volumes else 10000.0

    enriched_flat: list[dict[str, Any]] = []
    for topic in flat:
        keyword = (topic.get("primary_keyword") or topic.get("title") or "").strip()
        key = keyword.lower()
        if key in pre_metrics:
            metrics_arg: Optional[dict[str, Any]] = pre_metrics[key]
        else:
            metrics_arg = {}  # cap exceeded — score from discovery signals only
        scored = score_single_topic(
            topic,
            discovery_data,
            db,
            max_volume=max_volume,
            metrics=metrics_arg,
        )
        enriched_flat.append(scored)

    enriched_flat.sort(key=lambda t: float(t.get("seo_score") or 0), reverse=True)
    for i, topic in enumerate(enriched_flat):
        topic["recommended"] = i < 2
        topic["seo_rank"] = i + 1

    # Map back into groups, sorted by score within each group
    by_title = {t.get("title"): t for t in enriched_flat if t.get("title")}
    for key in SOURCE_KEYS:
        updated: list[dict[str, Any]] = []
        for topic in groups.get(key) or []:
            title = topic.get("title")
            if title and title in by_title:
                updated.append(by_title[title])
            else:
                updated.append(score_single_topic(topic, discovery_data, db, max_volume=max_volume))
        updated.sort(key=lambda t: float(t.get("seo_score") or 0), reverse=True)
        groups[key] = updated

    packed = pack_topic_groups(groups)
    merged_groups = normalize_topic_groups(packed)

    return {
        "version": 2,
        "groups": merged_groups,
        "top_picks": [
            {
                "title": t.get("title"),
                "primary_keyword": t.get("primary_keyword"),
                "seo_score": t.get("seo_score"),
                "recommendation": t.get("recommendation"),
                "source": t.get("source"),
                "source_links": t.get("source_links") or [],
            }
            for t in enriched_flat[:3]
        ],
    }


def rank_topics_for_auto_pick(topics_payload: Any) -> list[dict[str, Any]]:
    """Return topics sorted by seo_score (highest first)."""
    flat = flatten_topics(topics_payload)
    if not flat:
        return []
    if any(t.get("seo_score") is not None for t in flat):
        return sorted(flat, key=lambda t: float(t.get("seo_score") or 0), reverse=True)
    return flat
