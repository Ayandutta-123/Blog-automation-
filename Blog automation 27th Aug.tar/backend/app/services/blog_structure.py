"""Hardcoded blog layout — hero first after H1, CTA always last."""

from __future__ import annotations

from bs4 import BeautifulSoup, NavigableString, Tag
from loguru import logger

from app.services.runtime_config import get_config_value

# Server-enforced on every post. Custom rules in Settings extend/override prompts only;
# hero position and CTA-at-end are always re-applied after generation.
DEFAULT_BLOG_STRUCTURE_RULES = """FIXED BLOG LAYOUT (mandatory — server enforces on every post):

1. H1 — exactly one title
2. Hero image — <img class="blog-hero-image"> IMMEDIATELY after H1 (first visual)
3. Table of Contents — <nav class="toc"> (auto-generated from H2 headings; AFTER hero)
4. Introduction — 2–4 short <p> tags (hook, BLUF, roadmap) AFTER hero + TOC, before the first body H2
5. Body — H2/H3 sections, tables, charts, lists (flexible middle content)
6. Conclusion — <h2 id="conclusion"> key takeaways
7. CTA — <section id="cta" class="blog-cta"> ALWAYS the last element inside <article>

NEVER include FAQ (<h2 id="faq"> / FAQPage). FAQ is added only via the dashboard Add FAQ button.

Never place TOC, intro, or body content before the hero."""


def get_blog_structure_rules() -> str:
    """Custom structure rules from Settings, or the hardcoded default."""
    custom = (get_config_value("blog_structure_rules") or "").strip()
    if custom:
        return custom
    return DEFAULT_BLOG_STRUCTURE_RULES


def get_structure_rules_prompt_block() -> str:
    return f"\n\nBLOG STRUCTURE RULES (fixed layout):\n{get_blog_structure_rules()}\n"


def _is_conclusion_h2(h2: Tag) -> bool:
    hid = (h2.get("id") or "").lower()
    title = h2.get_text(" ", strip=True).lower()
    return hid in ("conclusion", "key-takeaways", "summary", "key-takeaway") or any(
        k in title for k in ("conclusion", "key takeaway", "takeaways", "summary")
    )


def _is_faq_h2(h2: Tag) -> bool:
    hid = (h2.get("id") or "").lower()
    title = h2.get_text(" ", strip=True).lower()
    return hid == "faq" or title.startswith("faq") or "frequently asked" in title


def _class_list(tag: Tag) -> list[str]:
    classes = tag.get("class") or []
    if isinstance(classes, str):
        return [classes]
    return list(classes)


def _is_hero_img(tag: Tag) -> bool:
    if tag.name != "img":
        return False
    return "blog-hero-image" in _class_list(tag)


def _is_toc(tag: Tag) -> bool:
    if tag.name not in ("nav", "div"):
        return False
    return "toc" in _class_list(tag)


def _section_nodes_from_h2(h2: Tag, stop_at: set[str] | None = None) -> list[Tag | NavigableString]:
    """Collect h2 and following siblings until the next h2 or CTA section."""
    stop_at = stop_at or set()
    nodes: list[Tag | NavigableString] = [h2]
    for sib in h2.next_siblings:
        if isinstance(sib, NavigableString) and not str(sib).strip():
            nodes.append(sib)
            continue
        if not isinstance(sib, Tag):
            continue
        if sib.name == "h2":
            break
        if _is_hero_img(sib):
            break
        if sib.name == "section" and (sib.get("id") == "cta" or "blog-cta" in " ".join(sib.get("class", []))):
            break
        if sib.name in stop_at:
            break
        nodes.append(sib)
    return nodes


def _extract_nodes(nodes: list) -> list[Tag | NavigableString]:
    extracted: list[Tag | NavigableString] = []
    for n in nodes:
        if isinstance(n, Tag) and _is_hero_img(n):
            continue
        if isinstance(n, Tag):
            extracted.append(n.extract())
        elif isinstance(n, NavigableString) and str(n).strip():
            extracted.append(n.extract())
    return extracted


def _unwrap_hero(article: Tag) -> Tag | None:
    """
    Find the hero image and promote it to a direct child of <article>.
    Handles <p>/<figure>/<div>/<picture> wrappers that leave content visually above hero.
    """
    hero = article.find("img", class_=lambda c: c and "blog-hero-image" in c)
    if not hero:
        hero = article.find("img")
    if not hero:
        return None

    # Walk up wrappers that only wrap the hero (no real text content)
    while True:
        parent = hero.parent
        if parent is None or parent is article or not isinstance(parent, Tag):
            break
        if parent.name not in ("p", "figure", "div", "picture", "span", "a"):
            break
        # Keep wrappers that have other meaningful children
        siblings = [
            c
            for c in parent.children
            if (isinstance(c, Tag) and c is not hero)
            or (isinstance(c, NavigableString) and str(c).strip())
        ]
        other_imgs = [c for c in siblings if isinstance(c, Tag) and c.name == "img"]
        other_content = [
            c
            for c in siblings
            if isinstance(c, Tag) and c.name in ("p", "h1", "h2", "h3", "ul", "ol", "table", "nav", "section")
        ]
        if other_imgs or other_content:
            break
        parent.insert_after(hero.extract())
        if not parent.get_text(strip=True) and not parent.find(True):
            parent.decompose()
        else:
            break

    return hero


def _find_hero(article: Tag) -> Tag | None:
    return _unwrap_hero(article)


def _append_nodes(parent: Tag, nodes: list[Tag | NavigableString]) -> None:
    for n in nodes:
        parent.append(n)


def enforce_fixed_blog_structure(html: str, slug: str, alt: str, hero_src: str) -> str:
    """
    Lock layout: H1 → Hero → TOC → Intro → Body → Conclusion → FAQ → CTA (last).
    No content may appear above the hero banner.
    """
    soup = BeautifulSoup(html, "html.parser")
    article = soup.find("article")
    if not article:
        return html

    # Promote wrapped heroes before we start extracting
    hero = _find_hero(article)
    toc = article.find("nav", class_="toc") or article.find("div", class_="toc")
    h1 = article.find("h1")

    # Keep existing CTA to re-append last (never drop it)
    cta_e: Tag | None = None
    for old in list(article.find_all("section", id="cta")):
        cta_e = old.extract()
        break
    if cta_e is None:
        for old in list(article.select("section.blog-cta")):
            cta_e = old.extract()
            break
    # Remove any remaining duplicate CTAs
    for old in list(article.find_all("section", id="cta")):
        old.extract()
    for old in list(article.select("section.blog-cta")):
        old.extract()

    conclusion_nodes: list = []
    faq_nodes: list = []
    for h2 in list(article.find_all("h2")):
        if h2.find_parent("nav"):
            continue
        if _is_conclusion_h2(h2):
            conclusion_nodes = _section_nodes_from_h2(h2)
        elif _is_faq_h2(h2):
            faq_nodes = _section_nodes_from_h2(h2)

    toc_e = toc.extract() if toc else None
    h1_e = h1.extract() if h1 else None
    hero_e = hero.extract() if hero else None
    conclusion_e = _extract_nodes(conclusion_nodes)
    faq_e = _extract_nodes(faq_nodes)

    intro_e: list = []
    body_e: list = []
    seen_h2 = False

    for child in list(article.children):
        if isinstance(child, NavigableString):
            text = str(child).strip()
            if not text:
                continue
            (body_e if seen_h2 else intro_e).append(child.extract())
            continue
        if not isinstance(child, Tag):
            continue
        if child.name == "h2":
            seen_h2 = True
            body_e.append(child.extract())
        elif _is_hero_img(child) or (
            child.name in ("p", "figure", "div", "picture") and child.find("img", class_=lambda c: c and "blog-hero-image" in c)
        ):
            # Drop duplicate heroes / empty wrappers
            child.extract()
            continue
        elif _is_toc(child):
            child.extract()
            continue
        elif child.name == "h3" or child.name in ("p", "ul", "ol", "table", "figure", "div", "blockquote"):
            (body_e if seen_h2 else intro_e).append(child.extract())
        else:
            body_e.append(child.extract())

    if not hero_e and h1_e:
        hero_e = soup.new_tag(
            "img",
            src=hero_src,
            alt=alt,
            loading="eager",
            decoding="async",
            width="1200",
            height="630",
        )
        hero_e["class"] = "blog-hero-image"

    # Clear and rebuild — H1 → Hero → TOC → rest (content never above hero)
    for child in list(article.children):
        child.extract()

    if h1_e:
        article.append(h1_e)
    if hero_e:
        if isinstance(hero_e, Tag):
            if hero_e.name != "img":
                # Safety: if we somehow kept a wrapper, prefer the inner img
                inner = hero_e.find("img") if isinstance(hero_e, Tag) else None
                if inner:
                    hero_e = inner.extract()
            if isinstance(hero_e, Tag) and hero_e.name == "img":
                hero_e["class"] = list(
                    dict.fromkeys([*(_class_list(hero_e)), "blog-hero-image"])
                )
                hero_e["src"] = hero_src or hero_e.get("src") or ""
                hero_e["alt"] = alt or hero_e.get("alt") or ""
                hero_e["loading"] = "eager"
                hero_e["decoding"] = "async"
                hero_e["width"] = hero_e.get("width") or "1200"
                hero_e["height"] = hero_e.get("height") or "630"
        article.append(hero_e)
    if toc_e:
        # Normalize to <nav class="toc">
        if isinstance(toc_e, Tag) and toc_e.name != "nav":
            toc_e.name = "nav"
        if isinstance(toc_e, Tag):
            toc_e["class"] = list(dict.fromkeys([*(_class_list(toc_e)), "toc"]))
        article.append(toc_e)
    _append_nodes(article, intro_e)
    _append_nodes(article, body_e)
    _append_nodes(article, conclusion_e)
    _append_nodes(article, faq_e)
    if cta_e:
        article.append(cta_e)

    logger.debug(f"Fixed blog structure enforced for {slug}")
    return str(soup)


def hero_is_after_h1(html: str) -> bool:
    """True when the first visual after H1 is the hero (no content above hero)."""
    soup = BeautifulSoup(html, "html.parser")
    article = soup.find("article")
    if not article:
        return True
    h1 = article.find("h1")
    if not h1:
        return True
    for sib in h1.next_siblings:
        if isinstance(sib, NavigableString) and not str(sib).strip():
            continue
        if not isinstance(sib, Tag):
            continue
        if _is_hero_img(sib):
            return True
        if sib.name == "img":
            return True
        if sib.name in ("p", "figure", "div", "picture"):
            img = sib.find("img")
            if img:
                return True
        # Any real content (TOC, intro, body) before hero = layout broken
        return False
    return False


def toc_is_after_hero(html: str) -> bool:
    """True when TOC (if present) comes after the hero image."""
    soup = BeautifulSoup(html, "html.parser")
    article = soup.find("article")
    if not article:
        return True
    toc = article.find("nav", class_="toc") or article.find("div", class_="toc")
    if not toc:
        return True
    hero = article.find("img", class_=lambda c: c and "blog-hero-image" in c) or article.find("img")
    if not hero:
        return True
    # Hero must appear before TOC in document order
    for el in article.descendants:
        if el is hero:
            return True
        if el is toc:
            return False
    return True


def layout_needs_hero_lock(html: str) -> bool:
    return not (hero_is_after_h1(html) and toc_is_after_hero(html))
