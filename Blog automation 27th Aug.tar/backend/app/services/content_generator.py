from __future__ import annotations

import json
import re
from typing import Any

import anthropic
from loguru import logger

from app.config import settings
from app.services.blog_format import (
    BLOG_FORMAT_RULES,
    build_headline_style_block,
    build_topic_lock_block,
    get_custom_content_instructions,
    get_structure_rules_prompt_block,
    pick_headline_style,
)
from app.services.content_archetypes import build_archetype_prompt_block, get_archetype
from app.services.keyword_research import build_research_prompt_block
from app.services.content_enricher import enrich_blog_html
from app.services.llm import anthropic_api_key_configured, create_claude_message
from app.services.runtime_config import get_config_value
from app.utils.content_format import log_format_warnings, validate_word_count
from app.utils.seo_structure import validate_seo_structure
from app.utils.word_count import count_blog_words

MAX_WORD_COUNT_ATTEMPTS = 3
MAX_TOPIC_LOCK_ATTEMPTS = 2
REQUIRED_BLOG_KEYS = (
    "slug",
    "title_tag",
    "meta_description",
    "reading_time",
    "primary_keyword",
    "hero_image_alt",
    "canonical_url",
    "og_title",
    "og_description",
    "html_content",
)


class WordCountValidationError(ValueError):
    """Raised when generated HTML is outside the chosen archetype word range."""

    def __init__(self, message: str, *, word_count: int, min_words: int, max_words: int):
        super().__init__(message)
        self.word_count = word_count
        self.min_words = min_words
        self.max_words = max_words


SEO_SYSTEM_PROMPT = f"""You are HyperPark's senior SEO content strategist. Generate enterprise-grade blog content 
for https://hyperpark.io/ — a smart parking and urban mobility SaaS platform.

STRICT TECHNICAL SEO RULES (MUST FOLLOW):
1. URL Slug: lowercase, hyphenated, primary keyword included, NO dates
2. Title Tag: DYNAMIC clickbait — follow the assigned headline style for THIS scraped topic
   (55–60 chars, primary keyword near front); never reuse the same "How X Stop Y% Leak Daily"
   template on every post; og_title must match
3. Meta Description: 140–160 characters, CTA verb + primary keyword + curiosity hook
4. H1: exactly ONE, mirrors the clickbait title_tag, keyword near the start
5. Article order: JSON-LD scripts → <article> → H1 → hero img → TOC → intro (100–150 words) →
   body H2/H3 → mid-body table+chart → conclusion H2 → CTA section (ALWAYS last)
6. Image alt: describes the specific article visual metaphor (not generic parking). Hero attrs required.
7. Schema: Article JSON-LD in <script type="application/ld+json"> at the VERY TOP of html_content
   (NEVER include FAQPage JSON-LD — FAQ is added only via the dashboard Add FAQ button)
8. Reading time: word count ÷ 200 WPM, format "X min read"
9. Semantic HTML only — no markdown fences in output; NEVER put Markdown links inside
   href/src (wrong: href="[https://x](https://x)"; correct: href="https://x")
10. Return ONLY valid JSON
11. NEVER place intro, TOC, or body content above the hero image — hero is always immediately under H1
12. NEVER include an FAQ section, <h2 id="faq">, or FAQPage schema — even if feedback mentions FAQ
13. Hero scene and title MUST match THIS article's topic every time (dynamic per post)

{BLOG_FORMAT_RULES}

Return ONLY valid JSON (no markdown fences):
{{
  "slug": "...",
  "title_tag": "...",
  "meta_description": "...",
  "reading_time": "X min read",
  "primary_keyword": "...",
  "hero_image_alt": "...",
  "canonical_url": "https://hyperpark.io/blog/{{slug}}",
  "og_title": "...",
  "og_description": "...",
  "html_content": "<script type=\\"application/ld+json\\">...</script><article>...</article>"
}}"""


def _count_words(html: str) -> int:
    text = re.sub(r"<[^>]+>", " ", html)
    return len(text.split())


def _calc_reading_time(html: str) -> str:
    words = _count_words(html)
    minutes = max(1, round(words / 200))
    return f"{minutes} min read"


def _word_count_correction_note(wc: int, arch) -> str:
    mid = (arch.min_words + arch.max_words) // 2
    if wc > arch.max_words:
        over = wc - arch.max_words
        return (
            f"WORD COUNT HARD FAIL: this draft is {wc} words ({over} over the max). "
            f"Archetype '{arch.label}' REQUIRES {arch.min_words}–{arch.max_words} words. "
            f"Rewrite SHORTER (~{mid} words). Cut H2 sections, shorten paragraphs, "
            f"keep only the highest-value points. Do NOT exceed {arch.max_words} words."
        )
    under = arch.min_words - wc
    return (
        f"WORD COUNT HARD FAIL: this draft is {wc} words ({under} under the min). "
        f"Archetype '{arch.label}' REQUIRES {arch.min_words}–{arch.max_words} words. "
        f"Expand to ~{mid} words with actionable detail, one table, and clear H2/H3s. "
        f"Do NOT go below {arch.min_words} words."
    )


_TOPIC_STOPWORDS = frozenset(
    {
        "the",
        "and",
        "for",
        "with",
        "from",
        "that",
        "this",
        "into",
        "your",
        "about",
        "guide",
        "blog",
        "post",
        "how",
        "why",
        "what",
        "when",
        "where",
        "which",
        "their",
        "there",
        "using",
        "based",
        "using",
        "over",
        "under",
        "after",
        "before",
        "opportunity",
        "oppertunity",
        "opportunities",
        "solution",
        "solutions",
        "system",
        "systems",
        "best",
        "real",
        "full",
        "complete",
    }
)


def topic_focus_tokens(topic_title: str, primary_keyword: str) -> list[str]:
    """Distinctive tokens that must keep appearing throughout the article."""
    text = f"{topic_title or ''} {primary_keyword or ''}".lower()
    raw = re.findall(r"[a-z0-9]{3,}", text)
    seen: set[str] = set()
    out: list[str] = []
    # Prefer longer / more specific tokens first (e.g. bangalore before smart)
    for tok in sorted(raw, key=lambda t: (-len(t), t)):
        if tok in _TOPIC_STOPWORDS or tok in seen:
            continue
        seen.add(tok)
        out.append(tok)
    return out[:8]


def evaluate_topic_lock(
    html: str,
    topic_title: str,
    primary_keyword: str,
) -> list[str]:
    """Return issues when the draft drifts off the locked topic (all products)."""
    tokens = topic_focus_tokens(topic_title, primary_keyword)
    if not tokens:
        return []

    text = re.sub(r"<[^>]+>", " ", html or "").lower()
    text = re.sub(r"\s+", " ", text)
    if not text.strip():
        return ["empty body — cannot verify topic lock"]

    issues: list[str] = []
    missing = [t for t in tokens if t not in text]
    # Require the most specific tokens (length >= 5) to appear; shorter ones are softer
    critical_missing = [t for t in missing if len(t) >= 5]
    if critical_missing:
        issues.append(
            "missing locked-topic terms in the body: " + ", ".join(critical_missing[:5])
        )

    # Paragraph coverage: distinctive tokens should appear across the article, not only intro
    paras = [
        p.strip()
        for p in re.split(r"</p>|<p[^>]*>", html or "", flags=re.I)
        if len(re.sub(r"<[^>]+>", " ", p).strip()) > 40
    ]
    if len(paras) >= 4:
        hit = 0
        for p in paras:
            pl = p.lower()
            if any(t in pl for t in tokens):
                hit += 1
        ratio = hit / len(paras)
        if ratio < 0.45:
            issues.append(
                f"only {hit}/{len(paras)} body paragraphs stay on the locked topic "
                f"(need ≥45%). Later sections drifted into unrelated content."
            )
        # Tail drift: last third of paragraphs must still mention topic tokens
        tail = paras[-(max(2, len(paras) // 3)) :]
        tail_hit = sum(1 for p in tail if any(t in p.lower() for t in tokens))
        if tail_hit == 0:
            issues.append(
                "final sections abandoned the locked topic — rewrite the whole article "
                "so conclusion/CTA still discuss the same topic."
            )
        # Specific anchors (places/products len>=5) must recur, not only in the intro
        for t in tokens:
            if len(t) < 5:
                continue
            appearances = sum(1 for p in paras if t in p.lower())
            if appearances < 2:
                issues.append(
                    f"«{t}» appears in only {appearances} paragraph(s) — keep it present "
                    "through the middle and end of the article, not just the intro."
                )

    headings = re.findall(r"<h[23][^>]*>(.*?)</h[23]>", html or "", flags=re.I | re.S)
    if len(headings) >= 2:
        heading_text = " ".join(re.sub(r"<[^>]+>", " ", h).lower() for h in headings)
        if not any(t in heading_text for t in tokens if len(t) >= 5):
            issues.append(
                "H2/H3 headings do not reflect the locked topic — retitle sections "
                "around the topic command."
            )

    return issues


def _topic_lock_correction_note(
    topic_title: str,
    primary_keyword: str,
    issues: list[str],
) -> str:
    tokens = ", ".join(topic_focus_tokens(topic_title, primary_keyword)[:6]) or primary_keyword
    return (
        "TOPIC LOCK HARD FAIL (ALL PRODUCTS): the draft drifted off the locked topic. "
        f"Locked topic: «{topic_title}». Primary keyword: «{primary_keyword}». "
        f"Must keep these terms throughout: {tokens}. "
        f"Issues: {'; '.join(issues)}. "
        "REWRITE THE ENTIRE ARTICLE about ONLY this topic — every H2, example, table row, "
        "and the conclusion. Do NOT switch to generic product marketing or a different subject."
    )


def _strip_code_fences(raw: str) -> str:
    text = (raw or "").strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[-1]
        text = text.rsplit("```", 1)[0].strip()
        if text.lower().startswith("json"):
            text = text[4:].lstrip()
    return text.strip()


def _read_json_string(payload: str, start: int) -> tuple[str, int]:
    """Read a JSON string value starting at the opening quote index."""
    if start >= len(payload) or payload[start] != '"':
        raise json.JSONDecodeError("Expected string", payload, start)
    i = start + 1
    out: list[str] = []
    while i < len(payload):
        ch = payload[i]
        if ch == "\\":
            if i + 1 >= len(payload):
                raise json.JSONDecodeError("Unterminated escape", payload, i)
            nxt = payload[i + 1]
            escapes = {
                '"': '"',
                "\\": "\\",
                "/": "/",
                "b": "\b",
                "f": "\f",
                "n": "\n",
                "r": "\r",
                "t": "\t",
            }
            if nxt in escapes:
                out.append(escapes[nxt])
                i += 2
                continue
            if nxt == "u" and i + 5 < len(payload):
                hex_part = payload[i + 2 : i + 6]
                try:
                    out.append(chr(int(hex_part, 16)))
                    i += 6
                    continue
                except ValueError:
                    pass
            out.append(nxt)
            i += 2
            continue
        if ch == '"':
            return "".join(out), i + 1
        # Models often emit raw newlines/tabs inside HTML strings — keep them.
        out.append(ch)
        i += 1
    raise json.JSONDecodeError("Unterminated string", payload, start)


def _extract_html_content_loose(text: str) -> str | None:
    """Recover html_content when the model left raw quotes/newlines inside the string."""
    m = re.search(r'"html_content"\s*:\s*"', text)
    if not m:
        # Sometimes models emit html_content without wrapping quotes after a repair attempt
        m2 = re.search(r'"html_content"\s*:\s*', text)
        if not m2:
            return None
        rest = text[m2.end() :].lstrip()
        if rest.startswith('"'):
            m = re.search(r'"html_content"\s*:\s*"', text)
        else:
            # Unquoted — take until final closing brace
            end = rest.rfind("}")
            chunk = rest[:end] if end > 0 else rest
            return chunk.strip().rstrip(",").strip()
    if not m:
        return None
    start = m.end()
    end = -1
    for pat in ('"\n}', '"\r\n}', '"\n  }', '" }', '"}'):
        idx = text.rfind(pat)
        if idx > start:
            end = max(end, idx)
    if end < 0:
        chunk = text[start:]
        # Truncated response — keep what we have
        return (
            chunk.replace("\\n", "\n")
            .replace("\\t", "\t")
            .replace('\\"', '"')
            .replace("\\\\", "\\")
            .rstrip()
            .rstrip("}")
            .rstrip('"')
        )
    chunk = text[start:end]
    return (
        chunk.replace("\\n", "\n")
        .replace("\\t", "\t")
        .replace('\\"', '"')
        .replace("\\\\", "\\")
    )


def _extract_blog_object(raw: str) -> dict[str, Any]:
    """Tolerant field extractor when json.loads fails on large html_content."""
    text = _strip_code_fences(raw)
    start = text.find("{")
    if start < 0:
        raise json.JSONDecodeError("No JSON object found", text, 0)
    text = text[start:]

    result: dict[str, Any] = {}
    for key in REQUIRED_BLOG_KEYS:
        if key == "html_content":
            continue
        marker = f'"{key}"'
        idx = text.find(marker)
        if idx < 0:
            continue
        colon = text.find(":", idx + len(marker))
        if colon < 0:
            continue
        j = colon + 1
        while j < len(text) and text[j].isspace():
            j += 1
        if j >= len(text) or text[j] != '"':
            continue
        try:
            value, _ = _read_json_string(text, j)
            result[key] = value
        except json.JSONDecodeError:
            continue

    html = _extract_html_content_loose(text)
    if not html or not html.strip():
        raise json.JSONDecodeError("Missing html_content after tolerant parse", text, 0)
    result["html_content"] = html

    # Fill minimal defaults so enrichment can proceed
    if not result.get("title_tag"):
        result["title_tag"] = "Untitled"
    if not result.get("slug"):
        result["slug"] = "untitled"
    if not result.get("primary_keyword"):
        result["primary_keyword"] = str(result.get("title_tag") or "untitled")
    if not result.get("meta_description"):
        result["meta_description"] = str(result.get("title_tag") or "")[:160]
    if not result.get("og_title"):
        result["og_title"] = result["title_tag"]
    if not result.get("og_description"):
        result["og_description"] = result["meta_description"]
    if not result.get("hero_image_alt"):
        result["hero_image_alt"] = result["title_tag"]
    if not result.get("reading_time"):
        result["reading_time"] = "5 min read"
    if not result.get("canonical_url"):
        result["canonical_url"] = f"https://hyperpark.io/blog/{result['slug']}"
    return result

def _repair_raw_newlines_in_json(raw: str) -> str:
    """Escape raw control characters that appear inside JSON string values."""
    out: list[str] = []
    in_string = False
    escaped = False
    for ch in raw:
        if in_string:
            if escaped:
                out.append(ch)
                escaped = False
                continue
            if ch == "\\":
                out.append(ch)
                escaped = True
                continue
            if ch == '"':
                out.append(ch)
                in_string = False
                continue
            if ch == "\n":
                out.append("\\n")
                continue
            if ch == "\r":
                out.append("\\r")
                continue
            if ch == "\t":
                out.append("\\t")
                continue
            if ord(ch) < 32:
                out.append(f"\\u{ord(ch):04x}")
                continue
            out.append(ch)
            continue
        if ch == '"':
            in_string = True
        out.append(ch)
    return "".join(out)


def parse_llm_blog_json(raw: str) -> dict[str, Any]:
    """Parse Claude blog JSON, tolerating common HTML/escape failures."""
    text = _strip_code_fences(raw)
    candidates = [text]
    start = text.find("{")
    end = text.rfind("}")
    if start >= 0 and end > start:
        candidates.append(text[start : end + 1])
    candidates.append(_repair_raw_newlines_in_json(text))
    if start >= 0 and end > start:
        candidates.append(_repair_raw_newlines_in_json(text[start : end + 1]))

    last_err: Exception | None = None
    for cand in candidates:
        try:
            data = json.loads(cand)
            if isinstance(data, dict) and data.get("html_content"):
                return data
        except json.JSONDecodeError as exc:
            last_err = exc

    try:
        return _extract_blog_object(text)
    except json.JSONDecodeError as exc:
        last_err = exc

    raise json.JSONDecodeError(
        f"Could not parse blog JSON ({last_err})",
        text[:200],
        getattr(last_err, "pos", 0) or 0,
    )


def _repair_blog_json_with_llm(client: anthropic.Anthropic, broken: str) -> dict[str, Any]:
    """Ask the model to re-emit strictly valid JSON when the first parse fails."""
    snippet = (broken or "")[:12000]
    response = create_claude_message(
        client,
        max_tokens=8192,
        system=(
            "You repair malformed JSON. Return ONLY a valid JSON object with these string keys: "
            + ", ".join(REQUIRED_BLOG_KEYS)
            + ". Escape all quotes/newlines inside html_content correctly. No markdown fences."
        ),
        messages=[
            {
                "role": "user",
                "content": (
                    "Fix this into ONE valid JSON object. Keep the HTML body intact.\n\n"
                    f"{snippet}"
                ),
            }
        ],
    )
    return parse_llm_blog_json(response.content[0].text)


def generate_blog_content(
    topic_title: str,
    primary_keyword: str,
    feedback_history: list[dict[str, Any]] | None = None,
    content_archetype: str | None = "tutorial",
    product: Any | None = None,
    lock_slug: str | None = None,
    research_pack: dict[str, Any] | None = None,
    include_charts: bool = True,
    chart_type: str | None = "auto",
    topic_description: str = "",
) -> dict[str, Any]:
    """Generate a full blog post that respects the chosen archetype word limit.

    lock_slug: when set (revision/redo of an existing post), the returned slug is forced to
    this exact value regardless of what the model produces, so the existing hero image file
    (named after the slug) keeps matching the post. Revision prompts must only change
    content/charts — never the image — and the image is keyed by slug on disk.
    """
    from app.services.content_enricher import pick_chart_type
    from app.services.product_context import (
        blog_base_url,
        build_external_sources_block,
        build_seo_system_prompt,
        company_label,
    )
    from app.services.seo_pipeline import iso_date_today

    arch = get_archetype(content_archetype)
    archetype_block = build_archetype_prompt_block(arch.id)
    company = company_label(product)
    blog_url = blog_base_url(product)
    resolved_chart = pick_chart_type(
        topic=topic_title, keyword=primary_keyword, preferred=chart_type
    )
    headline_style = pick_headline_style(
        topic=topic_title,
        keyword=primary_keyword,
        description=topic_description,
        research_pack=research_pack,
    )
    headline_block = build_headline_style_block(
        topic=topic_title,
        keyword=primary_keyword,
        description=topic_description,
        research_pack=research_pack,
        style=headline_style,
    )
    # FAQ is NEVER generated here — only the Add FAQ button may insert it later
    api_key = get_config_value("anthropic_api_key")
    if not anthropic_api_key_configured():
        logger.warning("Anthropic API key not configured; returning placeholder content")
        slug = lock_slug or primary_keyword.lower().replace(" ", "-")[:60]
        html = enrich_blog_html(
            _placeholder_html(topic_title, primary_keyword, slug, product),
            slug,
            topic_title,
            primary_keyword,
            product=product,
            allow_faq=False,
            research_pack=research_pack,
            include_charts=include_charts,
            chart_type=resolved_chart,
        )
        return {
            "slug": slug,
            "title_tag": topic_title[:60],
            "meta_description": (
                f"Discover how {primary_keyword} transforms enterprise operations. "
                f"See how {company} delivers measurable ROI."
            )[:160],
            "reading_time": _calc_reading_time(html),
            "primary_keyword": primary_keyword,
            "hero_image_alt": f"{company} {primary_keyword} in a real operating environment",
            "canonical_url": f"{blog_url}/{slug}",
            "og_title": topic_title[:60],
            "og_description": f"Discover enterprise {primary_keyword} strategies with {company}.",
            "html_content": html,
            "content_archetype": arch.id,
        }

    client = anthropic.Anthropic(api_key=api_key)

    base_feedback = list(feedback_history or [])
    length_notes: list[dict[str, Any]] = []
    best_content: dict[str, Any] | None = None
    best_distance: int | None = None
    topic_lock_block = build_topic_lock_block(
        topic_title,
        primary_keyword,
        topic_description=topic_description,
    )
    max_attempts = MAX_WORD_COUNT_ATTEMPTS + MAX_TOPIC_LOCK_ATTEMPTS

    faq_instruction = (
        "\n\nFAQ POLICY (STRICT): Do NOT include any FAQ section, <h2 id=\"faq\">, "
        "Frequently Asked Questions heading, or FAQPage JSON-LD. FAQ is added later only via "
        "the dashboard Add FAQ button — never from generation or feedback text."
    )
    if include_charts:
        charts_instruction = (
            "\n\nCHARTS POLICY: Charts are ON. Prefer chart variety type "
            f"«{resolved_chart}» (bar, line, horizontal_bar, donut, area, funnel, comparison, "
            "stat_grid, or infographic). Include at least one topic-and-product-specific "
            "inline SVG or stat-grid. Match the visual form to the article argument "
            "(trends→line/area, mix→donut, funnel→funnel, vs→comparison). "
            "Never use a generic parking/ANPR leakage chart unless "
            "THIS product and THIS topic are about parking. "
            "The server may replace free-form SVG with a typed template — keep labels on-topic."
        )
    else:
        charts_instruction = (
            "\n\nCHARTS POLICY (STRICT): Charts are OFF for this post. Do NOT emit <svg>, "
            "blog-chart figures, or stat-grid/stat-card blocks. Data tables are still allowed. "
            "Ignore any other instruction that asks for charts or infographics."
        )

    for attempt in range(1, max_attempts + 1):
        attempt_feedback = base_feedback + length_notes
        feedback_block = ""
        if attempt_feedback:
            feedback_block = "\n\nPREVIOUS FEEDBACK TO INCORPORATE:\n" + json.dumps(
                attempt_feedback, indent=2
            )

        user_message = f"""Write a complete SEO-optimized blog post for {company}.

TOPIC: {topic_title}
PRIMARY KEYWORD: {primary_keyword}

{topic_lock_block}

HARDCODED ENGAGEMENT RULES (ALWAYS):
- Rewrite the scraped topic into a content-true title_tag + H1 + og_title (55–60 chars)
  using the assigned HEADLINE STYLE below — not a recycled "How X Stop Y% Leak Daily" clone.
- The body must fulfill the title promise AND stay on the locked topic from first paragraph to CTA.
- Visual tone of the article should inspire a matching high-CTR hero thumbnail
  (server generates image from your title_tag + meta).

{headline_block}
{archetype_block}
{get_structure_rules_prompt_block()}
{build_external_sources_block(product)}
{build_research_prompt_block(research_pack)}
{get_custom_content_instructions()}
{feedback_block}
{faq_instruction}
{charts_instruction}

HARD REQUIREMENT: visible article body word count MUST be between {arch.min_words} and {arch.max_words}
(inclusive). Aim ~{(arch.min_words + arch.max_words) // 2} words. Drafts outside this range are rejected.
HARD REQUIREMENT: every section must stay on the locked topic «{topic_title}» — no mid-article drift.
STRICTLY follow the SEO anatomy and CONTENT ARCHETYPE rules above.
Return ONLY the JSON object with all required fields.
JSON SAFETY: html_content must be a single JSON string — escape every " as \\", every newline as \\n,
and never truncate mid-string. Put html_content as the LAST key."""

        response = create_claude_message(
            client,
            max_tokens=8192,
            system=build_seo_system_prompt(
                product, include_charts=include_charts, chart_type=resolved_chart
            ),
            messages=[{"role": "user", "content": user_message}],
        )

        raw = response.content[0].text.strip()
        stop_reason = getattr(response, "stop_reason", None)
        if stop_reason == "max_tokens":
            logger.warning(
                "Blog JSON response truncated (stop_reason=max_tokens) for topic '{}'",
                topic_title[:80],
            )

        try:
            content = parse_llm_blog_json(raw)
        except (json.JSONDecodeError, ValueError) as parse_exc:
            logger.warning(
                "Blog JSON parse failed for '{}': {}. Attempting LLM repair.",
                topic_title[:80],
                parse_exc,
            )
            try:
                content = _repair_blog_json_with_llm(client, raw)
            except Exception as repair_exc:
                raise ValueError(
                    f"Content generation returned invalid JSON and repair failed: {parse_exc}"
                ) from repair_exc

        # Prefer lock_slug (server-allocated, unique+fixed). Never let the model invent a new slug.
        slug = lock_slug or content.get("slug") or primary_keyword.lower().replace(" ", "-")[:60]
        content["slug"] = slug
        content["canonical_url"] = f"{blog_url}/{slug}"
        published = iso_date_today()
        content.setdefault("date_published", published)
        content.setdefault("date_modified", published)
        content["content_archetype"] = arch.id

        if "html_content" in content:
            content["html_content"] = enrich_blog_html(
                content["html_content"],
                slug,
                topic_title,
                primary_keyword,
                product=product,
                allow_faq=False,
                title_tag=content.get("title_tag") or topic_title,
                meta_description=content.get("meta_description") or "",
                date_published=content.get("date_published"),
                date_modified=content.get("date_modified"),
                research_pack=research_pack,
                include_charts=include_charts,
                chart_type=resolved_chart,
            )
            content["reading_time"] = _calc_reading_time(content["html_content"])
            log_format_warnings(content["html_content"])
            seo_issues = validate_seo_structure(content["html_content"], arch.id)
            if seo_issues:
                logger.warning(f"SEO structure gaps: {', '.join(seo_issues)}")

        html = content.get("html_content") or ""
        wc = count_blog_words(html)
        issues = validate_word_count(html, arch.id)
        topic_issues = evaluate_topic_lock(html, topic_title, primary_keyword)
        distance = 0 if not issues else (
            wc - arch.max_words if wc > arch.max_words else arch.min_words - wc
        )
        # Prefer on-topic drafts even if word count is slightly off
        ranked_distance = distance + (50 if topic_issues else 0)
        if best_distance is None or ranked_distance < best_distance:
            best_content = content
            best_distance = ranked_distance

        if topic_issues:
            logger.warning(
                "Topic lock failed for '{}' (attempt {}/{}): {}",
                topic_title[:80],
                attempt,
                max_attempts,
                "; ".join(topic_issues),
            )
            length_notes.append(
                {
                    "type": "system",
                    "feedback": _topic_lock_correction_note(
                        topic_title, primary_keyword, topic_issues
                    ),
                }
            )
            continue

        if not issues:
            logger.info(
                "Word count OK for archetype '{}': {} words (range {}–{}) on attempt {}",
                arch.id,
                wc,
                arch.min_words,
                arch.max_words,
                attempt,
            )
            return content

        logger.warning(
            "Word count {} outside {}–{} for '{}' (attempt {}/{}): {}",
            wc,
            arch.min_words,
            arch.max_words,
            arch.id,
            attempt,
            max_attempts,
            issues[0],
        )
        length_notes.append(
            {
                "type": "system",
                "feedback": _word_count_correction_note(wc, arch),
            }
        )

    assert best_content is not None
    final_html = best_content.get("html_content") or ""
    final_wc = count_blog_words(final_html)
    final_topic_issues = evaluate_topic_lock(final_html, topic_title, primary_keyword)
    final_wc_issues = validate_word_count(final_html, arch.id)
    if final_topic_issues:
        logger.error(
            "Topic lock still failing after {} attempts for '{}': {}. Shipping closest draft.",
            max_attempts,
            topic_title[:80],
            "; ".join(final_topic_issues),
        )
        best_content["topic_lock_violation"] = {
            "topic": topic_title,
            "primary_keyword": primary_keyword,
            "issues": final_topic_issues,
        }
    if final_wc_issues:
        logger.error(
            "Word count still out of range after {} attempts for '{}': {} words "
            "(required {}–{}). Shipping closest draft — publish will stay blocked until fixed.",
            max_attempts,
            arch.id,
            final_wc,
            arch.min_words,
            arch.max_words,
        )
        best_content["word_count_violation"] = {
            "word_count": final_wc,
            "min_words": arch.min_words,
            "max_words": arch.max_words,
            "archetype": arch.id,
        }
    return best_content


def _placeholder_html(topic: str, keyword: str, slug: str, product: Any | None = None) -> str:
    from app.services.product_context import company_label, internal_links_tuples

    org = company_label(product)
    links = internal_links_tuples(product)
    platform_url = links[2][1] if len(links) > 2 else (product.website_url if product else "https://hyperpark.io/")
    demo_url = links[0][1] if links else "https://hyperpark.io/demo"
    roi_url = links[1][1] if len(links) > 1 else "https://hyperpark.io/roi-calculator"
    schema = {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": topic,
        "author": {"@type": "Organization", "name": org},
        "publisher": {"@type": "Organization", "name": org},
    }
    return f"""<script type="application/ld+json">{json.dumps(schema)}</script>
<article>
<h1>{topic}</h1>
<img src="HERO_IMAGE_SRC" alt="{org} {keyword} operating environment matching this article" loading="lazy" decoding="async" width="1200" height="630" class="blog-hero-image" />
<p>Teams that still run {keyword} as a spreadsheet ritual lose time, miss exceptions, and cannot show a clean audit trail when leadership asks what changed this quarter.</p>
<p>{org} treats {keyword} as an operational system — live data, clear ownership, and a path from detection to action — instead of another slide in a quarterly review.</p>
<p>In this article, you'll learn how {keyword} works in practice, which metrics matter, how a focused program compares with the status quo, and the steps to deploy without boiling the ocean.</p>
<h2 id="overview">Why {keyword} Matters Now</h2>
<p>Enterprise campuses — hospitals, malls, and corporate parks — face rising pressure to digitize access control without ripping out existing hardware.</p>
<h3 id="leakage-drivers">Top Revenue Leakage Drivers</h3>
<ul>
<li>Unvalidated tailgating at exit lanes</li>
<li>Manual permit checks with no audit trail</li>
<li>Disconnected payment and access systems</li>
</ul>
<h3 id="anpr-advantage">The ANPR Advantage</h3>
<p>ANPR validates every plate against permits and payments in milliseconds — eliminating guesswork at the gate.</p>
<h2 id="comparison">ROI Comparison</h2>
<table class="blog-table">
<thead><tr><th>Metric</th><th>Status quo</th><th>With a focused {keyword} program</th></tr></thead>
<tbody>
<tr><td>Visibility</td><td>Fragmented / delayed</td><td>Live and auditable</td></tr>
<tr><td>Staff hours / week on manual checks</td><td>35–50</td><td>8–15</td></tr>
<tr><td>Payback window</td><td>Unclear</td><td>12–18 months</td></tr>
</tbody>
</table>
<div class="stat-grid">
<div class="stat-card"><strong>67%</strong><span>Labor cost reduction</span></div>
<div class="stat-card"><strong>$2.4M</strong><span>Avg. annual savings</span></div>
</div>
<p>Industry data from the <a href="https://www.itf-oecd.org/urban-mobility" target="_blank" rel="noopener noreferrer">OECD urban mobility program</a> 
and <a href="https://www.parking.org/" target="_blank" rel="noopener noreferrer">International Parking Institute</a> 
confirms accelerating enterprise adoption of automated access control.</p>
<h2 id="deployment">Deployment Roadmap</h2>
<h3 id="phase-one">Phase 1: Site Assessment</h3>
<p>Map entry/exit lanes, camera sightlines, and integration points with existing barriers.</p>
<h3 id="phase-two">Phase 2: Go-Live</h3>
<p>Deploy integrated systems, connect to {org} cloud, and validate outcomes against live operations.</p>
<h2 id="conclusion">Key Takeaways</h2>
<p>{keyword} delivers measurable ROI when organizations pair <strong>real-time validation</strong> with structured enforcement. 
<a href="{platform_url}">Explore the {org} platform</a> to see deployment in action.</p>
<section id="cta" class="blog-cta">
<h2>Ready to modernize your parking operations?</h2>
<ul>
<li>Eliminate revenue leakage with ANPR validation</li>
<li>Deploy in weeks with hardware-agnostic IoT</li>
</ul>
<p><a href="{demo_url}" class="cta-button">Book a Live Demo</a> 
or <a href="{roi_url}">run your ROI estimate</a>.</p>
</section>
</article>"""
