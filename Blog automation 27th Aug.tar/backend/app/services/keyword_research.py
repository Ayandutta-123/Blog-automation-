"""Build a keyword research pack before blog generation (Phase 2)."""

from __future__ import annotations

import re
from typing import Any, Optional

from loguru import logger
from sqlalchemy.orm import Session

from app.services.blog_format import AUTHORITATIVE_EXTERNAL_SOURCES
from app.services.topic_seo_analyzer import count_competitor_matches, fetch_topic_keyword_metrics


def _tokenize(text: str) -> set[str]:
    return {t for t in re.findall(r"[a-z0-9]{3,}", (text or "").lower()) if len(t) >= 3}


def fetch_keyword_cluster(db: Session, keyword: str, *, limit: int = 10) -> list[dict[str, Any]]:
    """Related keywords from Ubersuggest keyword_suggestions."""
    from app.services.ubersuggest import (
        UbersuggestError,
        _metrics_from_row,
        _mcp_text_payload,
        call_tool,
        get_config_value,
        is_connected,
        K_KEYWORD_TOOL,
    )

    keyword = (keyword or "").strip()
    if not keyword or not is_connected(db):
        return []

    tool = (get_config_value(K_KEYWORD_TOOL, db) or "").strip() or "keyword_suggestions"
    try:
        result = call_tool(
            db,
            tool if tool != "keyword_overview" else "keyword_suggestions",
            {"keywords": [keyword], "language": "en", "locId": 2840},
        )
    except UbersuggestError as exc:
        logger.warning("Keyword cluster fetch failed for '{}': {}", keyword, exc)
        return []

    parsed, text, is_error = _mcp_text_payload(result)
    if is_error or not isinstance(parsed, dict):
        return []

    rows: list[dict[str, Any]] = []
    for key in ("suggestions", "keywords", "results", "data"):
        block = parsed.get(key)
        if isinstance(block, list):
            rows.extend([r for r in block if isinstance(r, dict)])
    searched = parsed.get("searched_keywords")
    if isinstance(searched, list):
        rows.extend([r for r in searched if isinstance(r, dict)])

    cluster: list[dict[str, Any]] = []
    seen: set[str] = set()
    for row in rows:
        metrics = _metrics_from_row(row, keyword)
        kw = (metrics.get("keyword") or "").strip().lower()
        if not kw or kw == keyword.lower() or kw in seen:
            continue
        seen.add(kw)
        cluster.append(
            {
                "keyword": metrics.get("keyword") or kw,
                "search_volume": metrics.get("search_volume"),
                "seo_difficulty": metrics.get("seo_difficulty"),
                "cpc": metrics.get("cpc"),
            }
        )
        if len(cluster) >= limit:
            break
    return cluster


def _pick_citation_targets(
    keyword: str,
    limit: int = 4,
    *,
    discovery_data: Optional[dict[str, Any]] = None,
) -> list[dict[str, str]]:
    """Match LIVE authoritative + discovery sources to topic keyword (all products).

    Dead URLs are never returned. Discovery page URLs that match the topic are preferred
    so in-body citations stay genuine and content-relevant.
    """
    from app.utils.link_sanitizer import filter_live_links, _normalize_url

    tokens = _tokenize(keyword)
    candidates: list[tuple[int, str, str, str]] = []  # score, label, url, reason

    # 1) Discovery URLs (industry / RSS / configured competitor pages) — highest relevance
    if discovery_data:
        for block in discovery_data.get("industry_trends") or []:
            kw = str(block.get("keyword") or "")
            for result in block.get("results") or []:
                title = str(result.get("title") or "Industry source")
                url = str(result.get("url") or "").strip()
                if not url.startswith(("http://", "https://")):
                    continue
                hay = f"{title} {kw} {url}".lower()
                score = 3 + sum(1 for t in tokens if t in hay)
                candidates.append((score, title[:80], url, "Discovery industry source"))
        for block in discovery_data.get("rss_articles") or []:
            for article in block.get("articles") or []:
                title = str(article.get("title") or "RSS article")
                url = str(article.get("url") or "").strip()
                if not url.startswith(("http://", "https://")):
                    continue
                hay = f"{title} {url}".lower()
                score = 2 + sum(1 for t in tokens if t in hay)
                candidates.append((score, title[:80], url, "Discovery RSS source"))
        for block in discovery_data.get("competitor_articles") or []:
            url = str(block.get("source_url") or "").strip()
            label = str(block.get("page_title") or "Competitor page").strip() or "Competitor page"
            if not url.startswith(("http://", "https://")):
                continue
            hay = f"{label} {url}".lower()
            score = 2 + sum(1 for t in tokens if t in hay)
            candidates.append((score, label[:80], url, "Configured competitor source"))

    # 2) Curated authoritative whitelist
    for label, url in AUTHORITATIVE_EXTERNAL_SOURCES:
        hay = f"{label} {url}".lower()
        score = sum(1 for t in tokens if t in hay)
        if any(t in hay for t in ("parking", "mobility", "transport", "urban", "vehicle", "iot", "smart")):
            score += 2
        candidates.append((score, label, url, "Authoritative industry source"))

    # De-dupe by normalized URL, keep highest score
    best: dict[str, tuple[int, str, str, str]] = {}
    for score, label, url, reason in candidates:
        key = _normalize_url(url)
        if not key:
            continue
        prev = best.get(key)
        if not prev or score > prev[0]:
            best[key] = (score, label, url, reason)

    ranked = sorted(best.values(), key=lambda x: (-x[0], x[1]))
    # Live-check top pool (hard rule: never return dead links)
    pool = [(label, url) for _, label, url, _ in ranked[:12]]
    live = filter_live_links(pool)
    live_urls = {url for _, url in live}
    picks: list[dict[str, str]] = []
    for score, label, url, reason in ranked:
        if url not in live_urls:
            continue
        picks.append({"label": label, "url": url, "reason": reason})
        if len(picks) >= limit:
            break

    # If still short, fill from any remaining live authoritative sources
    if len(picks) < 2:
        for label, url in filter_live_links(list(AUTHORITATIVE_EXTERNAL_SOURCES)):
            if any(p["url"] == url for p in picks):
                continue
            picks.append({"label": label, "url": url, "reason": "Live authoritative fallback"})
            if len(picks) >= 2:
                break
    return picks[:limit]


def _competitor_insights(
    keyword: str,
    discovery_data: Optional[dict[str, Any]],
) -> dict[str, Any]:
    if not discovery_data:
        return {"top_pages": [], "missing_angles": []}

    tokens = _tokenize(keyword)
    top_pages: list[dict[str, str]] = []
    for block in discovery_data.get("competitor_articles") or []:
        source = str(block.get("source_url") or "")
        for article in block.get("articles") or []:
            title = str(article.get("title") or "")
            summary = str(article.get("summary") or "")
            hay = f"{title} {summary}".lower()
            if tokens and not any(t in hay for t in tokens):
                continue
            top_pages.append(
                {
                    "title": title,
                    "url": str(article.get("url") or ""),
                    "source": source,
                    "summary": summary[:200],
                }
            )
    top_pages = top_pages[:5]

    missing_angles: list[str] = []
    if len(top_pages) <= 1:
        missing_angles.append("Enterprise ROI and payback benchmarks")
        missing_angles.append("Implementation checklist for facility operators")
    if len(top_pages) <= 3:
        missing_angles.append("Comparison table vs legacy manual systems")
        missing_angles.append("Integration with existing barriers and payment stacks")
    return {"top_pages": top_pages, "missing_angles": missing_angles[:4]}


def _build_questions(primary: str, secondary: list[dict[str, Any]]) -> list[str]:
    base = (primary or "this topic").strip()
    questions = [
        f"What is {base} and why does it matter for enterprise operators?",
        f"How does {base} reduce cost or revenue leakage?",
        f"What should teams evaluate before adopting {base}?",
    ]
    for item in secondary[:3]:
        kw = item.get("keyword")
        if kw:
            questions.append(f"How does {kw} relate to {base}?")
    return questions[:6]


def _build_outline(
    primary: str,
    secondary: list[dict[str, Any]],
    competitor_insights: dict[str, Any],
) -> list[str]:
    sections = [
        f"Why {primary} matters now (problem + stakes)",
        f"How {primary} works in enterprise deployments",
    ]
    for item in secondary[:3]:
        kw = item.get("keyword")
        if kw:
            sections.append(f"{kw.title()} — practical implications")
    for angle in competitor_insights.get("missing_angles") or []:
        sections.append(angle)
    sections.extend(
        [
            "ROI comparison table (legacy vs modern)",
            "Implementation roadmap",
            "Key takeaways and next steps",
        ]
    )
    # De-dupe while preserving order
    seen: set[str] = set()
    out: list[str] = []
    for s in sections:
        key = s.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(s)
    return out[:10]


def build_research_pack(
    db: Session,
    *,
    topic_title: str,
    primary_keyword: str,
    discovery_data: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """Assemble research pack stored on BlogPost and injected into generation."""
    primary = (primary_keyword or topic_title or "").strip()
    metrics = fetch_topic_keyword_metrics(db, primary)
    secondary = fetch_keyword_cluster(db, primary, limit=10)

    # Ensure primary is not duplicated in secondary
    secondary = [
        s
        for s in secondary
        if str(s.get("keyword") or "").lower() != primary.lower()
    ][:8]

    discovery = discovery_data or {}
    competitor = _competitor_insights(primary, discovery)
    questions = _build_questions(primary, secondary)
    outline = _build_outline(primary, secondary, competitor)
    citations = _pick_citation_targets(primary, discovery_data=discovery)

    pack = {
        "topic_title": topic_title,
        "primary_keyword": primary,
        "primary_metrics": {
            "search_volume": metrics.get("search_volume"),
            "seo_difficulty": metrics.get("seo_difficulty"),
            "cpc": metrics.get("cpc"),
            "source_tool": metrics.get("source_tool"),
        },
        "secondary_keywords": secondary,
        "questions_to_answer": questions,
        "recommended_outline": outline,
        "citation_targets": citations,
        "competitor_insights": competitor,
        "competitor_matches": count_competitor_matches(primary, discovery),
        "ubersuggest_connected": bool(metrics or secondary),
    }
    logger.info(
        "Research pack for '{}': {} secondary keywords, {} citations",
        primary,
        len(secondary),
        len(citations),
    )
    return pack


def build_research_prompt_block(pack: Optional[dict[str, Any]]) -> str:
    """Format research pack for the Claude user prompt."""
    if not pack:
        return ""

    primary = pack.get("primary_keyword") or ""
    metrics = pack.get("primary_metrics") or {}
    vol = metrics.get("search_volume")
    diff = metrics.get("seo_difficulty")

    lines = [
        "\n\nUBERSUGGEST RESEARCH PACK (MUST FOLLOW — semantic coverage, no keyword stuffing):",
        f"- Primary keyword: {primary}",
        "- TOPIC LOCK: secondary keywords may only SUPPORT the locked topic — never replace it "
        "or pivot the article into a different subject after the intro.",
    ]
    if vol is not None:
        lines.append(f"- Primary search volume: ~{int(vol):,}/mo")
    if diff is not None:
        lines.append(f"- SEO difficulty: {int(diff)} (calibrate depth and specificity)")

    secondary = pack.get("secondary_keywords") or []
    if secondary:
        lines.append("- Secondary keywords (weave naturally in H2/H3 and body):")
        for item in secondary[:8]:
            kw = item.get("keyword")
            sv = item.get("search_volume")
            if kw:
                suffix = f" (~{int(sv):,}/mo)" if isinstance(sv, (int, float)) else ""
                lines.append(f"  • {kw}{suffix}")

    questions = pack.get("questions_to_answer") or []
    if questions:
        lines.append("- Answer these reader questions in the body:")
        for q in questions:
            lines.append(f"  • {q}")

    outline = pack.get("recommended_outline") or []
    if outline:
        lines.append("- Recommended H2 coverage (adapt section titles to the post headline style):")
        for section in outline:
            lines.append(f"  • {section}")

    citations = pack.get("citation_targets") or []
    if citations:
        lines.append(
            "- Cite 2+ of these GENUINE LIVE sources INLINE where the claim appears "
            "(never invent URLs; never dump a Sources section at the bottom):"
        )
        for c in citations:
            reason = c.get("reason") or "Approved source"
            lines.append(f"  • {c.get('label')}: {c.get('url')} ({reason})")

    missing = (pack.get("competitor_insights") or {}).get("missing_angles") or []
    if missing:
        lines.append("- Differentiate from competitors by covering:")
        for angle in missing:
            lines.append(f"  • {angle}")

    lines.append(
        "- AI/search-friendly: BLUF in intro, clear entities, short paragraphs, fulfill title promise."
    )
    return "\n".join(lines)
