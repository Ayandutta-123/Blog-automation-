from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from sqlalchemy.orm import Session

from app.config import settings as env_settings
from app.database import SessionLocal
from app.models import AppConfig

# Registry of all user-configurable integration fields
CONFIG_REGISTRY: list[dict[str, Any]] = [
    {
        "key": "tavily_api_key",
        "label": "Tavily API Key",
        "description": "Industry trend search via Tavily API",
        "group": "Search & Scraping",
        "secret": True,
        "env_fallback": "tavily_api_key",
    },
    {
        "key": "anthropic_api_key",
        "label": "Anthropic API Key",
        "description": "Claude 3.5 Sonnet for topics and SEO content",
        "group": "AI & Content",
        "secret": True,
        "env_fallback": "anthropic_api_key",
    },
    {
        "key": "anthropic_model",
        "label": "Anthropic Model",
        "description": (
            "Claude model used for all blog generation, topics, and SEO. "
            "Pick a model and Save — every product uses this id."
        ),
        "group": "AI & Content",
        "secret": False,
        "env_fallback": "anthropic_model",
    },
    {
        "key": "fal_key",
        "label": "Fal.ai API Key",
        "description": "Fal.ai key for blog hero images (Flux, Imagen, Nano Banana, Seedream, …)",
        "group": "AI & Content",
        "secret": True,
        "env_fallback": "fal_key",
    },
    {
        "key": "fal_image_model",
        "label": "Fal.ai image model",
        "description": (
            "Hero image model used for every product — saved and new. "
            "Pick one and Save; all AI Generate / auto-generation uses this Fal endpoint."
        ),
        "group": "AI & Content",
        "secret": False,
        "env_fallback": "fal_image_model",
    },
    {
        "key": "teams_notifications_enabled",
        "label": "Teams notifications",
        "description": "Send topic, review, and publish cards to Teams. Turn off to silence all Teams messages.",
        "group": "Notifications",
        "secret": False,
        "env_fallback": "",
    },
    {
        "key": "teams_webhook_url",
        "label": "MS Teams Webhook URL",
        "description": "Incoming webhook for HITL Adaptive Cards",
        "group": "Notifications",
        "secret": True,
        "env_fallback": "teams_webhook_url",
    },
    {
        "key": "frontend_url",
        "label": "Frontend Dashboard URL",
        "description": "Public dashboard URL for Teams links. Use your tunnel URL (not localhost) so Teams/mobile can open posts.",
        "group": "App URLs",
        "secret": False,
        "env_fallback": "frontend_url",
    },
    {
        "key": "public_base_url",
        "label": "Public API Base URL",
        "description": "Public API URL for hero images in Teams. Must be reachable from the internet (not localhost).",
        "group": "App URLs",
        "secret": False,
        "env_fallback": "public_base_url",
    },
    {
        "key": "topic_selection_mode",
        "label": "Topic Selection Mode",
        "description": "manual = you pick topics; auto = AI picks best; hybrid = both options",
        "group": "Workflow",
        "secret": False,
        "env_fallback": "topic_selection_mode",
    },
    {
        "key": "blog_structure_rules",
        "label": "Blog Structure Rules",
        "description": "Custom layout rules for every blog (archetype sections, order). Hero-after-H1 and CTA-last are always enforced server-side.",
        "group": "Workflow",
        "secret": False,
        "env_fallback": "blog_structure_rules",
    },
    {
        "key": "blog_content_instructions",
        "label": "Blog Content Instructions",
        "description": "Extra editor commands for every blog (tables, tone, CTA style). Applied on generate + redo.",
        "group": "Workflow",
        "secret": False,
        "env_fallback": "blog_content_instructions",
    },
    {
        "key": "minio_endpoint",
        "label": "MinIO Endpoint",
        "description": "Console URL (https://minio-s3.app.knowerai.com) or S3 API host:port. This cluster uses Console API for uploads because S3 :9000 is internal-only.",
        "group": "Storage (MinIO)",
        "secret": False,
        "env_fallback": "minio_endpoint",
    },
    {
        "key": "minio_access_key",
        "label": "MinIO Access Key",
        "description": "MinIO username / access key",
        "group": "Storage (MinIO)",
        "secret": True,
        "env_fallback": "minio_access_key",
    },
    {
        "key": "minio_secret_key",
        "label": "MinIO Secret Key",
        "description": "MinIO password / secret key",
        "group": "Storage (MinIO)",
        "secret": True,
        "env_fallback": "minio_secret_key",
    },
    {
        "key": "minio_bucket",
        "label": "MinIO Bucket",
        "description": "Bucket name for published blog HTML files",
        "group": "Storage (MinIO)",
        "secret": False,
        "env_fallback": "minio_bucket",
    },
    {
        "key": "minio_prefix",
        "label": "MinIO Object Prefix",
        "description": "Folder prefix inside the bucket (default: blogs/html)",
        "group": "Storage (MinIO)",
        "secret": False,
        "env_fallback": "minio_prefix",
    },
    {
        "key": "minio_secure",
        "label": "MinIO Use HTTPS",
        "description": "true/false — use HTTPS when endpoint has no scheme",
        "group": "Storage (MinIO)",
        "secret": False,
        "env_fallback": "minio_secure",
    },
    {
        "key": "minio_public_base_url",
        "label": "MinIO Public Base URL",
        "description": (
            "Optional public HTTPS origin for clickable object links in Google Sheets "
            "(e.g. https://minio-s3.app.knowerai.com). Defaults to the console host "
            "from MinIO Endpoint. Sheet columns store {base}/{bucket}/{object}."
        ),
        "group": "Storage (MinIO)",
        "secret": False,
        "env_fallback": "minio_public_base_url",
    },
]

SECRET_KEYS = {f["key"] for f in CONFIG_REGISTRY if f.get("secret")}

VALID_KEYS = {f["key"] for f in CONFIG_REGISTRY}


def is_placeholder_value(value: str) -> bool:
    """Detect .env.example style placeholders, not real API keys."""
    if not value or not value.strip():
        return False
    v = value.strip().lower()
    if v.startswith("your_") or v.startswith("your-"):
        return True
    if v in ("changeme", "placeholder", "xxx", "test"):
        return True
    if "your" in v and "_key" in v:
        return True
    if v.startswith("sk-") is False and "api_key" in v and len(v) < 28:
        return True
    return False


def validate_integration_value(key: str, value: str) -> None:
    from fastapi import HTTPException

    if not value or not value.strip():
        raise HTTPException(status_code=400, detail="Value cannot be empty")
    if key == "topic_selection_mode":
        mode = value.strip().lower()
        if mode not in ("manual", "auto", "hybrid"):
            raise HTTPException(
                status_code=400,
                detail="Topic selection mode must be manual, auto, or hybrid",
            )
        return
    if key == "content_archetype":
        from app.services.content_archetypes import normalize_archetype

        normalize_archetype(value)
        return
    if key == "fal_image_model":
        from app.services.fal_models import FAL_IMAGE_MODEL_IDS

        model = value.strip()
        if model not in FAL_IMAGE_MODEL_IDS:
            raise HTTPException(
                status_code=400,
                detail="Unknown Fal image model. Choose a model from the list.",
            )
        return
    if key == "teams_notifications_enabled":
        mode = value.strip().lower()
        if mode not in ("true", "false", "1", "0", "on", "off", "yes", "no"):
            raise HTTPException(
                status_code=400,
                detail="Teams notifications must be true or false",
            )
        return
    if is_placeholder_value(value):
        raise HTTPException(
            status_code=400,
            detail="This looks like a placeholder. Paste your real API key.",
        )
    if key == "teams_webhook_url" and not value.startswith("http"):
        raise HTTPException(status_code=400, detail="Webhook URL must start with http")
    if key in ("frontend_url", "public_base_url") and not value.startswith("http"):
        raise HTTPException(status_code=400, detail="URL must start with http")


def _mask_secret(value: str) -> str:
    if not value:
        return ""
    if len(value) <= 4:
        return "****"
    return f"{'•' * 8}...{value[-4:]}"


def _env_default(key: str) -> str:
    meta = next((f for f in CONFIG_REGISTRY if f["key"] == key), None)
    if not meta:
        return ""
    env_key = meta.get("env_fallback", key)
    raw = getattr(env_settings, env_key, "")
    return str(raw) if raw is not None else ""


def get_config_value(key: str, db: Optional[Session] = None) -> str:
    """Resolve config: database value first, then .env fallback."""
    own_session = db is None
    if own_session:
        db = SessionLocal()
    try:
        row = db.query(AppConfig).filter(AppConfig.key == key).first()
        if row is not None and row.value.strip():
            return row.value.strip()
    finally:
        if own_session:
            db.close()
    return _env_default(key)


def get_config_int(key: str, default: int = 0) -> int:
    raw = get_config_value(key)
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def get_config_bool(key: str, default: bool = False) -> bool:
    raw = (get_config_value(key) or "").strip().lower()
    if not raw:
        return default
    if raw in ("1", "true", "yes", "on"):
        return True
    if raw in ("0", "false", "no", "off"):
        return False
    return default


def teams_notifications_enabled() -> bool:
    """Default ON when unset so existing installs keep receiving cards."""
    return get_config_bool("teams_notifications_enabled", default=True)


def get_anthropic_model() -> str:
    return get_config_value("anthropic_model") or "claude-sonnet-5"


def get_fal_image_model() -> str:
    from app.services.fal_models import DEFAULT_FAL_IMAGE_MODEL, normalize_fal_image_model

    return normalize_fal_image_model(get_config_value("fal_image_model") or DEFAULT_FAL_IMAGE_MODEL)


def get_app_base_url(key: str) -> str:
    """Return a configured application origin without deployment-specific fallbacks."""
    if key not in ("frontend_url", "public_base_url"):
        raise ValueError(f"Unsupported application URL key: {key}")
    value = (get_config_value(key) or "").strip().rstrip("/")
    if not value:
        env_name = key.upper()
        raise RuntimeError(
            f"{env_name} is not configured. Set it in the environment or Settings → "
            "Integrations → App URLs."
        )
    return value


def get_frontend_url() -> str:
    return get_app_base_url("frontend_url")


def get_public_base_url() -> str:
    return get_app_base_url("public_base_url")


def set_config_value(key: str, value: str, db: Session, is_secret: Optional[bool] = None) -> None:
    meta = next((f for f in CONFIG_REGISTRY if f["key"] == key), None)
    secret = is_secret if is_secret is not None else (meta.get("secret", False) if meta else False)

    row = db.query(AppConfig).filter(AppConfig.key == key).first()
    if row:
        row.value = value
        row.is_secret = secret
    else:
        db.add(AppConfig(key=key, value=value, is_secret=secret))
    db.commit()


def clear_config_value(key: str, db: Session) -> None:
    row = db.query(AppConfig).filter(AppConfig.key == key).first()
    if row:
        db.delete(row)
        db.commit()


@dataclass
class ConfigFieldView:
    key: str
    label: str
    description: str
    group: str
    secret: bool
    is_set: bool
    source: str  # "database" | "env" | "none"
    is_placeholder: bool = False
    value: Optional[str] = None
    masked_value: Optional[str] = None


def get_integrations_view(db: Session) -> list[ConfigFieldView]:
    views: list[ConfigFieldView] = []
    for field in CONFIG_REGISTRY:
        key = field["key"]
        row = db.query(AppConfig).filter(AppConfig.key == key).first()
        db_val = row.value.strip() if row and row.value else ""
        env_val = _env_default(key).strip()

        if db_val:
            effective = db_val
            source = "database"
        elif env_val:
            effective = env_val
            source = "env"
        else:
            effective = ""
            source = "none"

        is_secret = field.get("secret", False)
        placeholder = is_placeholder_value(effective)
        truly_set = bool(effective) and not placeholder

        # Boolean toggles: unset = default ON, always expose a concrete value in the UI
        if key == "teams_notifications_enabled" and not effective:
            effective = "true"
            source = "none"
            truly_set = True
            placeholder = False

        views.append(
            ConfigFieldView(
                key=key,
                label=field["label"],
                description=field["description"],
                group=field["group"],
                secret=is_secret,
                is_set=truly_set,
                source=source,
                is_placeholder=placeholder,
                value=effective if not is_secret else None,
                masked_value=_mask_secret(effective) if is_secret and effective else None,
            )
        )
    return views


def update_integrations(updates: dict[str, Optional[str]], db: Session) -> list[ConfigFieldView]:
    """
    Update integration settings.
    - Key absent from updates: no change
    - Key present with empty string: clear database override (falls back to .env)
    - Key present with value: save to database
    """
    for key, value in updates.items():
        if key not in {f["key"] for f in CONFIG_REGISTRY}:
            continue
        if value is None:
            continue
        if value.strip() == "":
            clear_config_value(key, db)
        else:
            validate_integration_value(key, value.strip())
            set_config_value(key, value.strip(), db)
    return get_integrations_view(db)


def save_single_integration(key: str, value: str, db: Session) -> ConfigFieldView:
    if key not in VALID_KEYS:
        from fastapi import HTTPException

        raise HTTPException(status_code=404, detail=f"Unknown config key: {key}")
    validate_integration_value(key, value)
    set_config_value(key, value.strip(), db)
    views = get_integrations_view(db)
    return next(v for v in views if v.key == key)


def delete_single_integration(key: str, db: Session) -> ConfigFieldView:
    if key not in VALID_KEYS:
        from fastapi import HTTPException

        raise HTTPException(status_code=404, detail=f"Unknown config key: {key}")
    clear_config_value(key, db)
    views = get_integrations_view(db)
    return next(v for v in views if v.key == key)
