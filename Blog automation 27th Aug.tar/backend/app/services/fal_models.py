"""Curated Fal.ai text-to-image models for blog hero generation.

One global selection (Settings → Integrations) is used for every product.
"""

from __future__ import annotations

from typing import Any

DEFAULT_FAL_IMAGE_MODEL = "fal-ai/flux-pro/v1.1-ultra"

# args_kind drives subscribe() argument shape — Fal endpoints are not identical.
FAL_IMAGE_MODELS: list[dict[str, str]] = [
    {
        "id": "fal-ai/nano-banana-pro",
        "label": "Google Nano Banana Pro — latest SOTA (Gemini 3 Pro Image)",
        "group": "Latest & recommended",
        "args_kind": "google_nano",
    },
    {
        "id": "fal-ai/nano-banana-2",
        "label": "Google Nano Banana 2 — fast photoreal, native 2K/4K",
        "group": "Latest & recommended",
        "args_kind": "google_nano",
    },
    {
        "id": "fal-ai/flux-2-max",
        "label": "FLUX.2 [max] — highest-quality Black Forest Labs",
        "group": "Latest & recommended",
        "args_kind": "flux2",
    },
    {
        "id": "fal-ai/flux-2-pro",
        "label": "FLUX.2 [pro] — studio-grade, zero-config",
        "group": "Latest & recommended",
        "args_kind": "flux2",
    },
    {
        "id": "fal-ai/flux-2/flash",
        "label": "FLUX.2 Flash — latest FLUX, faster / cheaper",
        "group": "Latest & recommended",
        "args_kind": "flux2",
    },
    {
        "id": "bytedance/seedream/v5/pro/text-to-image",
        "label": "Seedream 5.0 Pro — ByteDance flagship, strong layouts",
        "group": "Latest & recommended",
        "args_kind": "seedream5",
    },
    {
        "id": "openai/gpt-image-2",
        "label": "OpenAI GPT Image 2 — latest OpenAI, fine typography",
        "group": "Latest & recommended",
        "args_kind": "gpt_image_2",
    },
    {
        "id": "fal-ai/gpt-image-1.5",
        "label": "OpenAI GPT Image 1.5 — high prompt fidelity",
        "group": "OpenAI",
        "args_kind": "gpt_image",
    },
    {
        "id": "fal-ai/gpt-image-1/text-to-image",
        "label": "OpenAI GPT Image 1 — prompt-faithful stills",
        "group": "OpenAI",
        "args_kind": "gpt_image",
    },
    {
        "id": "fal-ai/imagen4/preview",
        "label": "Google Imagen 4 — highest-quality Google stills",
        "group": "Google",
        "args_kind": "imagen4",
    },
    {
        "id": "fal-ai/recraft/v4.1/text-to-image",
        "label": "Recraft V4.1 — editorial / brand-clean stills",
        "group": "Design",
        "args_kind": "recraft",
    },
    {
        "id": "fal-ai/recraft/v4/pro/text-to-image",
        "label": "Recraft V4 Pro — design-first photoreal",
        "group": "Design",
        "args_kind": "recraft",
    },
    {
        "id": "fal-ai/flux-pro/v1.1-ultra",
        "label": "FLUX 1.1 [pro] Ultra — 2K photoreal (current default)",
        "group": "FLUX 1.x",
        "args_kind": "ultra",
    },
    {
        "id": "fal-ai/flux-pro/v1.1",
        "label": "FLUX 1.1 [pro] — photoreal, reliable fallback",
        "group": "FLUX 1.x",
        "args_kind": "flux_size",
    },
    {
        "id": "fal-ai/flux-pro",
        "label": "FLUX.1 [pro] — original Flux Pro",
        "group": "FLUX 1.x",
        "args_kind": "flux_size",
    },
    {
        "id": "fal-ai/bytedance/seedream/v4.5/text-to-image",
        "label": "Seedream 4.5 — ByteDance, strong composition",
        "group": "ByteDance (previous)",
        "args_kind": "seedream",
    },
]

FAL_IMAGE_MODEL_IDS = {m["id"] for m in FAL_IMAGE_MODELS}

_FALLBACK_MODELS = (
    DEFAULT_FAL_IMAGE_MODEL,
    "fal-ai/flux-pro/v1.1",
)


def normalize_fal_image_model(value: str | None) -> str:
    raw = (value or "").strip()
    if raw in FAL_IMAGE_MODEL_IDS:
        return raw
    return DEFAULT_FAL_IMAGE_MODEL


def fal_model_label(model_id: str) -> str:
    for item in FAL_IMAGE_MODELS:
        if item["id"] == model_id:
            return item["label"]
    return model_id


def _spec(model_id: str) -> dict[str, str]:
    for item in FAL_IMAGE_MODELS:
        if item["id"] == model_id:
            return item
    return {"id": DEFAULT_FAL_IMAGE_MODEL, "args_kind": "ultra"}


def arguments_for_fal_model(model_id: str, prompt: str) -> dict[str, Any]:
    """Build subscribe() arguments for a text-to-image hero at 16:9."""
    kind = _spec(model_id).get("args_kind") or "ultra"
    if kind == "ultra":
        return {
            "prompt": prompt,
            "aspect_ratio": "16:9",
            "num_images": 1,
            "output_format": "png",
            "safety_tolerance": "2",
            "raw": True,
            "enable_safety_checker": True,
        }
    if kind == "flux_size":
        return {
            "prompt": prompt,
            "image_size": "landscape_16_9",
            "num_images": 1,
            "output_format": "png",
            "safety_tolerance": "2",
            "enable_safety_checker": True,
        }
    if kind == "flux2":
        return {
            "prompt": prompt,
            "image_size": "landscape_16_9",
            "output_format": "png",
            "safety_tolerance": "2",
            "enable_safety_checker": True,
        }
    if kind == "google_nano":
        return {
            "prompt": prompt,
            "aspect_ratio": "16:9",
            "num_images": 1,
            "output_format": "png",
            "resolution": "2K",
            "safety_tolerance": "4",
        }
    if kind == "imagen4":
        return {
            "prompt": prompt,
            "aspect_ratio": "16:9",
            "num_images": 1,
            "output_format": "png",
            "resolution": "2K",
        }
    if kind == "seedream":
        return {
            "prompt": prompt,
            "image_size": {"width": 1920, "height": 1080},
            "num_images": 1,
            "enable_safety_checker": True,
        }
    if kind == "seedream5":
        return {
            "prompt": prompt,
            "image_size": {"width": 1920, "height": 1080},
            "num_images": 1,
        }
    if kind == "recraft":
        return {
            "prompt": prompt,
            "image_size": "landscape_16_9",
            "num_images": 1,
        }
    if kind == "gpt_image":
        return {
            "prompt": prompt,
            "image_size": "1536x1024",
            "quality": "high",
            "num_images": 1,
            "output_format": "png",
        }
    if kind == "gpt_image_2":
        return {
            "prompt": prompt,
            "image_size": "landscape_16_9",
            "quality": "high",
            "num_images": 1,
            "output_format": "png",
        }
    return arguments_for_fal_model(DEFAULT_FAL_IMAGE_MODEL, prompt)


def fal_subscribe_chain(selected_id: str) -> list[str]:
    """Selected model first, then stable Flux fallbacks (no duplicates)."""
    chosen = normalize_fal_image_model(selected_id)
    chain: list[str] = [chosen]
    for fallback in _FALLBACK_MODELS:
        if fallback not in chain:
            chain.append(fallback)
    return chain
