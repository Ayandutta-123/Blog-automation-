from __future__ import annotations

import hashlib
import json
import secrets
import time
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Optional

from sqlalchemy.orm import Session

from app.config import settings as env_settings
from app.database import SessionLocal
from app.services.runtime_config import get_config_value, set_config_value
from app.models import DashboardRole, DashboardUser

PASSWORD_HASH_KEY = "dashboard_password_hash"
SESSIONS_KEY = "dashboard_sessions"
_PBKDF_SALT = b"blog-automation-dashboard-v1"
_SESSION_TTL_DAYS = 14
_MIN_PASSWORD_LEN = 8

# Brute-force protection (in-memory; per process)
_MAX_FAILURES = 5
_WINDOW_SECONDS = 15 * 60
_LOCKOUT_SECONDS = 15 * 60
_failures: dict[str, list[float]] = defaultdict(list)
_lockouts: dict[str, float] = {}


def hash_password(password: str) -> str:
    digest = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        _PBKDF_SALT,
        120_000,
    )
    return digest.hex()


def verify_password(password: str, stored_hash: str) -> bool:
    if not password or not stored_hash:
        return False
    return secrets.compare_digest(hash_password(password), stored_hash)


def get_expected_username() -> str:
    return (env_settings.dashboard_username or "").strip()


def get_stored_password_hash(db: Session) -> str:
    stored = get_config_value(PASSWORD_HASH_KEY, db)
    if stored:
        return stored
    plain = (env_settings.dashboard_password or "").strip()
    if not plain:
        # No bootstrap password configured — leave unset (login will fail).
        return ""
    hashed = hash_password(plain)
    set_config_value(PASSWORD_HASH_KEY, hashed, db, is_secret=True)
    return hashed


def _dummy_hash() -> str:
    return hash_password("__unused_dummy_password__")


def authenticate(username: str, password: str, db: Session) -> bool:
    """Constant-time-ish check of username + password. Never reveals which failed."""
    expected_user = get_expected_username()
    stored = get_stored_password_hash(db) or _dummy_hash()

    provided_user = (username or "").strip()
    # Pad lengths before compare_digest to reduce trivial length leaks
    max_len = max(len(provided_user), len(expected_user), 1)
    user_ok = bool(expected_user) and secrets.compare_digest(
        provided_user.ljust(max_len),
        expected_user.ljust(max_len),
    )
    pass_ok = verify_password(password or "", stored)
    return user_ok and pass_ok


def get_user_by_username(db: Session, username: str) -> Optional[DashboardUser]:
    return db.query(DashboardUser).filter(DashboardUser.username == (username or "").strip()).first()


def authenticate_user(
    username: str, password: str, db: Session
) -> Optional[DashboardUser]:
    user = get_user_by_username(db, username)
    if not user or not user.is_active:
        return None
    if not verify_password(password or "", user.password_hash):
        return None
    return user


def create_user(
    *,
    db: Session,
    username: str,
    password: str,
    role: DashboardRole = DashboardRole.USER,
) -> DashboardUser:
    cleaned_username = (username or "").strip()
    cleaned_password = (password or "").strip()
    if not cleaned_username:
        raise ValueError("Username is required")
    if len(cleaned_username) < 2:
        raise ValueError("Username must be at least 2 characters")
    if len(cleaned_password) < _MIN_PASSWORD_LEN:
        raise ValueError(f"Password must be at least {_MIN_PASSWORD_LEN} characters")

    existing = get_user_by_username(db, cleaned_username)
    if existing:
        raise ValueError("Username already exists")

    hashed = hash_password(cleaned_password)
    user = DashboardUser(
        username=cleaned_username,
        password_hash=hashed,
        role=role,
        is_active=True,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def change_user_password(
    *,
    db: Session,
    user_id: int,
    current_password: str,
    new_password: str,
) -> None:
    cleaned_new = (new_password or "").strip()
    if len(cleaned_new) < _MIN_PASSWORD_LEN:
        raise ValueError(f"New password must be at least {_MIN_PASSWORD_LEN} characters")
    user = db.query(DashboardUser).filter(DashboardUser.id == user_id).first()
    if not user or not user.is_active:
        raise ValueError("User not found")
    if not verify_password(current_password or "", user.password_hash):
        raise ValueError("Current password is incorrect")

    user.password_hash = hash_password(cleaned_new)
    db.commit()


def change_password(current: str, new_password: str, db: Session) -> None:
    cleaned = (new_password or "").strip()
    if len(cleaned) < _MIN_PASSWORD_LEN:
        raise ValueError(f"New password must be at least {_MIN_PASSWORD_LEN} characters")
    stored = get_stored_password_hash(db)
    if not stored or not verify_password(current, stored):
        raise ValueError("Current password is incorrect")
    set_config_value(PASSWORD_HASH_KEY, hash_password(cleaned), db, is_secret=True)


def check_rate_limit(client_key: str) -> Optional[str]:
    """Return an error message if locked out, else None."""
    now = time.monotonic()
    until = _lockouts.get(client_key)
    if until and until > now:
        secs = int(until - now) + 1
        return f"Too many failed attempts. Try again in {secs}s."
    if until:
        _lockouts.pop(client_key, None)
    return None


def record_login_failure(client_key: str) -> None:
    now = time.monotonic()
    window_start = now - _WINDOW_SECONDS
    recent = [t for t in _failures[client_key] if t >= window_start]
    recent.append(now)
    _failures[client_key] = recent
    if len(recent) >= _MAX_FAILURES:
        _lockouts[client_key] = now + _LOCKOUT_SECONDS
        _failures[client_key] = []


def clear_login_failures(client_key: str) -> None:
    _failures.pop(client_key, None)
    _lockouts.pop(client_key, None)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _parse_expiry(value: str) -> Optional[datetime]:
    try:
        dt = datetime.fromisoformat(value)
    except (TypeError, ValueError):
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def _extract_session_exp(value: object) -> Optional[datetime]:
    """Support legacy sessions (value=str iso-expiry) and new sessions (value=dict)."""
    if isinstance(value, str):
        return _parse_expiry(value)
    if isinstance(value, dict):
        exp_raw = value.get("exp") or value.get("expires_at") or value.get("expiry")
        return _parse_expiry(str(exp_raw)) if exp_raw else None
    return None


def _extract_session_identity(value: object) -> dict[str, object]:
    """Return optional identity stored in the session."""
    if isinstance(value, dict):
        return {
            k: v
            for k, v in value.items()
            if k in ("user_id", "username", "role") and v is not None
        }
    return {}


def _load_sessions(db: Session) -> dict[str, object]:
    raw = get_config_value(SESSIONS_KEY, db) or ""
    if not raw.strip():
        return {}
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    if not isinstance(data, dict):
        return {}
    # Preserve non-string session payloads (new sessions store dict metadata)
    return {str(k): v for k, v in data.items() if k and v is not None}


def _save_sessions(db: Session, sessions: dict[str, object]) -> None:
    set_config_value(SESSIONS_KEY, json.dumps(sessions), db, is_secret=True)


def _prune(sessions: dict[str, object]) -> dict[str, object]:
    now = _now()
    kept: dict[str, object] = {}
    for token, entry in sessions.items():
        exp = _extract_session_exp(entry)
        if exp and exp >= now:
            kept[token] = entry
    return kept


def create_session(
    db: Optional[Session] = None,
    *,
    user_id: Optional[int] = None,
    username: Optional[str] = None,
    role: Optional[str] = None,
) -> str:
    """Create a durable session token (persisted in DB, survives server restarts)."""
    owns_db = db is None
    session = db or SessionLocal()
    try:
        sessions = _prune(_load_sessions(session))
        token = secrets.token_urlsafe(48)
        entry: dict[str, object] = {
            "exp": (_now() + timedelta(days=_SESSION_TTL_DAYS)).isoformat()
        }
        if user_id is not None:
            entry["user_id"] = user_id
        if username:
            entry["username"] = username
        if role:
            entry["role"] = role
        sessions[token] = entry
        _save_sessions(session, sessions)
        return token
    finally:
        if owns_db:
            session.close()


def validate_session(token: Optional[str], db: Optional[Session] = None) -> bool:
    """Return True if token is still valid. Extends expiry on successful checks."""
    if not token:
        return False

    owns_db = db is None
    session = db or SessionLocal()
    try:
        sessions = _prune(_load_sessions(session))
        if token not in sessions:
            if sessions != _load_sessions(session):
                _save_sessions(session, sessions)
            return False

        # Normalize/extend entry to new dict format so identity survives future calls.
        existing = sessions.get(token)
        identity = _extract_session_identity(existing)
        normalized: dict[str, object] = {
            "exp": (_now() + timedelta(days=_SESSION_TTL_DAYS)).isoformat(),
        }
        normalized.update(identity)
        # Legacy sessions had no identity; treat as admin based on env bootstrap.
        if "role" not in normalized:
            normalized["role"] = DashboardRole.ADMIN.value
            normalized["username"] = get_expected_username()
        sessions[token] = normalized
        _save_sessions(session, sessions)
        return True
    finally:
        if owns_db:
            session.close()


def revoke_session(token: Optional[str], db: Optional[Session] = None) -> None:
    """Invalidate a session (logout). Only removes this token."""
    if not token:
        return

    owns_db = db is None
    session = db or SessionLocal()
    try:
        sessions = _prune(_load_sessions(session))
        if token in sessions:
            sessions.pop(token, None)
            _save_sessions(session, sessions)
    finally:
        if owns_db:
            session.close()


def get_session_identity(
    token: Optional[str], db: Optional[Session] = None
) -> Optional[dict[str, object]]:
    """Return stored identity for an already-valid session token."""
    if not token:
        return None
    owns_db = db is None
    session = db or SessionLocal()
    try:
        sessions = _load_sessions(session)
        entry = sessions.get(token)
        if not entry:
            return None
        exp = _extract_session_exp(entry)
        if not exp or exp < _now():
            return None
        identity = _extract_session_identity(entry)
        if not identity:
            # Legacy session: no stored identity; treat as admin.
            return {
                "role": DashboardRole.ADMIN.value,
                "username": get_expected_username(),
            }
        return identity
    finally:
        if owns_db:
            session.close()
