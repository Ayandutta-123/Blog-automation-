from __future__ import annotations

import io
import re
from pathlib import Path
from typing import Any

import httpx
from loguru import logger
from PIL import Image

from app.config import settings
from app.services.blog_format import build_image_prompt
from app.services.product_context import get_brand_palette, get_core_brand_colors
from app.services.runtime_config import get_config_value, get_fal_image_model, is_placeholder_value
from app.utils.retry import with_retry

# Keep 16:9 at high web resolution (do not crush Fal Ultra 2K down to 1200×630).
_HERO_MAX_WIDTH = 1920
_HERO_MAX_HEIGHT = 1080


def _article_excerpt_for_image(html: str | None) -> str:
    """Plain-text body brief so the photo matches the generated article, not a generic topic."""
    if not html:
        return ""
    text = re.sub(r"<script[\s\S]*?</script>", " ", html, flags=re.I)
    text = re.sub(r"<style[\s\S]*?</style>", " ", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) > 700:
        text = text[:697].rsplit(" ", 1)[0] + "…"
    return text


def _article_heading_brief(html: str | None) -> str:
    """H2 titles so the photo can follow the article's actual sections."""
    if not html:
        return ""
    headings = re.findall(r"<h2\b[^>]*>(.*?)</h2>", html, flags=re.I | re.S)
    cleaned: list[str] = []
    for raw in headings:
        text = re.sub(r"<[^>]+>", " ", raw)
        text = re.sub(r"\s+", " ", text).strip()
        if text and text.lower() not in ("conclusion", "key takeaways", "table of contents"):
            cleaned.append(text[:80])
        if len(cleaned) >= 6:
            break
    return "; ".join(cleaned)


def _prompt_kwargs_for_product(product: Any | None) -> dict[str, str]:
    if product is None:
        return {}
    description = (getattr(product, "description", None) or "").strip()
    brand = (getattr(product, "brand_context", None) or "").strip()
    pdf = (getattr(product, "pdf_extracted_text", None) or "").strip()
    if pdf and len(description) < 200:
        pdf_snip = re.sub(r"\s+", " ", pdf)[:240]
        description = f"{description} {pdf_snip}".strip() if description else pdf_snip
    return {
        "product_name": (getattr(product, "name", None) or "").strip(),
        "company_name": (getattr(product, "company_name", None) or "").strip(),
        "product_description": description,
        "brand_context": brand,
    }


@with_retry(max_attempts=3, base_delay=3.0)
def generate_hero_image(
    topic_title: str,
    slug: str,
    feedback_history: list | None = None,
    product: Any | None = None,
    custom_prompt: str | None = None,
    primary_keyword: str | None = None,
    meta_description: str | None = None,
    html_content: str | None = None,
) -> str:
    """Generate a product-and-article-matched documentary hero photo (not a generic stock scene)."""
    custom = (custom_prompt or "").strip()
    palette = get_core_brand_colors(get_brand_palette(product))
    keyword = (primary_keyword or "").strip() or None
    meta = (meta_description or "").strip() or None
    excerpt = _article_excerpt_for_image(html_content)
    headings = _article_heading_brief(html_content)
    product_kwargs = _prompt_kwargs_for_product(product)

    if custom:
        prompt = build_image_prompt(
            custom[:600],
            palette,
            primary_keyword=keyword,
            meta_description=meta,
            article_excerpt=excerpt,
            heading_brief=headings,
            **product_kwargs,
        )
    else:
        subject = (topic_title or slug or "enterprise topic").strip()
        if feedback_history:
            latest = feedback_history[-1].get("feedback", "")
            low = (latest or "").lower()
            if any(w in low for w in ("image", "visual", "photo", "realistic", "thumbnail", "banner")):
                subject = f"{subject}. Visual notes: {(latest or '')[:180]}"
        prompt = build_image_prompt(
            subject,
            palette,
            primary_keyword=keyword,
            meta_description=meta,
            article_excerpt=excerpt,
            heading_brief=headings,
            **product_kwargs,
        )

    output_path = Path(settings.blog_images_dir) / f"{slug}.webp"
    output_path.parent.mkdir(parents=True, exist_ok=True)

    fal_key = get_config_value("fal_key")
    if not fal_key or is_placeholder_value(fal_key):
        logger.warning("Fal.ai API key not configured; creating placeholder image")
        return _create_placeholder_image(output_path, slug, topic_title, product)

    try:
        import fal_client
        import os

        os.environ["FAL_KEY"] = fal_key

        from app.services.fal_models import (
            arguments_for_fal_model,
            fal_model_label,
            fal_subscribe_chain,
        )

        selected = get_fal_image_model()
        chain = fal_subscribe_chain(selected)
        logger.info(
            "Hero image for '{}' using Fal model {} ({})",
            slug,
            selected,
            fal_model_label(selected),
        )
        logger.info(f"Hero image prompt for '{slug}': {prompt[:220]}...")
        result = None
        last_exc: Exception | None = None
        for model_id in chain:
            try:
                result = fal_client.subscribe(
                    model_id,
                    arguments=arguments_for_fal_model(model_id, prompt),
                )
                if model_id != selected:
                    logger.warning(
                        "Primary Fal model '{}' failed; generated '{}' with fallback {}",
                        selected,
                        slug,
                        model_id,
                    )
                else:
                    logger.info("Fal hero generated for '{}' with {}", slug, model_id)
                break
            except Exception as model_exc:
                last_exc = model_exc
                logger.warning("Fal model {} failed for '{}': {}", model_id, slug, model_exc)
        if result is None:
            raise last_exc or RuntimeError("Fal.ai returned no image")

        image_url = _extract_image_url(result)
        if not image_url:
            raise RuntimeError(f"Fal.ai response had no image URL: {result}")
        return _download_and_convert(image_url, output_path)
    except Exception as exc:
        logger.error(f"Fal.ai generation failed: {exc}")
        return _create_placeholder_image(output_path, slug, topic_title, product)


def _extract_image_url(result: Any) -> str:
    if not result:
        return ""
    data = result
    if hasattr(result, "images"):
        data = {"images": getattr(result, "images")}
    if isinstance(result, dict) and "data" in result and isinstance(result["data"], dict):
        data = result["data"]
    images = data.get("images") if isinstance(data, dict) else None
    if not images:
        return ""
    first = images[0]
    if isinstance(first, str):
        return first
    if isinstance(first, dict):
        return str(first.get("url") or "")
    return str(getattr(first, "url", "") or "")


def _download_and_convert(url: str, output_path: Path) -> str:
    with httpx.Client(timeout=120.0) as client:
        response = client.get(url)
        response.raise_for_status()

    img = Image.open(io.BytesIO(response.content)).convert("RGB")
    width, height = img.size
    # Downscale only if larger than 1920×1080; never upscale (keeps optical detail)
    if width > _HERO_MAX_WIDTH or height > _HERO_MAX_HEIGHT:
        img.thumbnail((_HERO_MAX_WIDTH, _HERO_MAX_HEIGHT), Image.Resampling.LANCZOS)
    img.save(output_path, "WEBP", quality=95, method=6)
    logger.info(f"Hero image saved: {output_path}")
    return str(output_path)


def _hex_to_rgb(hex_color: str, fallback: tuple[int, int, int]) -> tuple[int, int, int]:
    value = (hex_color or "").strip().lstrip("#")
    if len(value) != 6:
        return fallback
    try:
        return (
            int(value[0:2], 16),
            int(value[2:4], 16),
            int(value[4:6], 16),
        )
    except ValueError:
        return fallback


def _create_placeholder_image(
    output_path: Path,
    slug: str,
    title: str = "",
    product: Any | None = None,
) -> str:
    palette = get_core_brand_colors(get_brand_palette(product))
    navy = _hex_to_rgb(palette.get("navy", "#1b1f4a"), (27, 31, 74))
    primary = _hex_to_rgb(palette.get("primary", "#252a61"), (37, 42, 97))
    accent = _hex_to_rgb(palette.get("accent", "#ff6002"), (255, 96, 2))
    cta = _hex_to_rgb(palette.get("cta", "#c1262a"), (193, 38, 42))

    img = Image.new("RGB", (1200, 630), color=(244, 245, 250))
    from PIL import ImageDraw

    draw = ImageDraw.Draw(img)
    draw.rectangle([0, 420, 1200, 630], fill=navy)
    draw.rectangle([60, 80, 1140, 400], fill=primary)
    draw.rectangle([80, 260, 380, 380], fill=primary, outline=accent, width=3)
    draw.rectangle([420, 120, 1120, 360], fill=cta)
    label = (title[:52] + "…") if len(title) > 52 else (title or slug)
    draw.text((80, 430), label, fill=(255, 255, 255))
    company = getattr(product, "company_name", None) or getattr(product, "name", None) or "blog Automation"
    draw.text((80, 460), company, fill=accent)
    img.save(output_path, "WEBP", quality=100, method=6)
    logger.info(f"Placeholder image created: {output_path}")
    return str(output_path)
