"""Append published-blog rows to a per-product Google Sheet (exact 5-column format).

Required header row (exact):
  Serial No | Slug | Blog Title | Image URL | HTML Page Path

Auth options (all products):
1) Product google_sheet_url = Google Sheet link + Integrations service-account JSON
   (share the sheet with the service-account email, or Anyone-with-link can edit + SA shared)
2) Product google_sheet_url = Apps Script Web App URL (script.google.com/macros/s/...)
   — no service account needed; script appends into the bound sheet
"""

from __future__ import annotations

import json
import re
from typing import Any, Optional
from urllib.parse import urlparse

import httpx
from loguru import logger
from sqlalchemy.orm import Session

from app.models import Product
from app.services.runtime_config import get_config_value, is_placeholder_value

SHEET_HEADERS = ["Serial No", "Slug", "Blog Title", "Image URL", "HTML Page Path"]
SHEETS_SCOPE = "https://www.googleapis.com/auth/spreadsheets"
PREFERRED_TAB = "Blogs"


class GoogleSheetsLedgerError(Exception):
    pass


def get_product_sheet_url(product: Product | None) -> str:
    if not product:
        return ""
    return str(getattr(product, "google_sheet_url", None) or "").strip()


def sheet_configured(product: Product | None) -> bool:
    return bool(get_product_sheet_url(product))


def extract_spreadsheet_id(url: str) -> Optional[str]:
    text = (url or "").strip()
    if not text:
        return None
    m = re.search(r"/spreadsheets/d/([a-zA-Z0-9-_]+)", text)
    if m:
        return m.group(1)
    # Bare spreadsheet id
    if re.fullmatch(r"[a-zA-Z0-9-_]{20,}", text):
        return text
    return None


def is_apps_script_webapp(url: str) -> bool:
    host = urlparse(url or "").netloc.lower()
    return "script.google.com" in host and "/macros/" in (url or "")


def _load_service_account_info() -> dict[str, Any]:
    raw = (get_config_value("google_sheets_service_account_json") or "").strip()
    if not raw or is_placeholder_value(raw):
        raise GoogleSheetsLedgerError(
            "Google Sheets service account JSON is not configured. "
            "Add it in Settings → Integrations, then share the sheet with that client_email."
        )
    try:
        info = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise GoogleSheetsLedgerError("Service account JSON is invalid") from exc
    if not isinstance(info, dict) or not info.get("client_email"):
        raise GoogleSheetsLedgerError("Service account JSON must include client_email")
    return info


def _service_account_access_token(info: dict[str, Any]) -> str:
    try:
        from google.oauth2 import service_account
        from google.auth.transport.requests import Request
    except ImportError as exc:
        raise GoogleSheetsLedgerError(
            "google-auth is not installed. Add google-auth to backend requirements."
        ) from exc

    creds = service_account.Credentials.from_service_account_info(
        info, scopes=[SHEETS_SCOPE]
    )
    creds.refresh(Request())
    if not creds.token:
        raise GoogleSheetsLedgerError("Could not refresh Google Sheets access token")
    return creds.token


def _sheets_headers(token: str) -> dict[str, str]:
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }


def _resolve_tab_title(client: httpx.Client, spreadsheet_id: str, token: str) -> str:
    resp = client.get(
        f"https://sheets.googleapis.com/v4/spreadsheets/{spreadsheet_id}",
        headers=_sheets_headers(token),
        params={"fields": "sheets.properties.title"},
    )
    if resp.status_code >= 400:
        raise GoogleSheetsLedgerError(
            f"Cannot open spreadsheet (HTTP {resp.status_code}): {(resp.text or '')[:300]}"
        )
    sheets = (resp.json() or {}).get("sheets") or []
    titles = [
        str((s.get("properties") or {}).get("title") or "").strip()
        for s in sheets
        if isinstance(s, dict)
    ]
    titles = [t for t in titles if t]
    if PREFERRED_TAB in titles:
        return PREFERRED_TAB
    if not titles:
        raise GoogleSheetsLedgerError("Spreadsheet has no sheets/tabs")
    return titles[0]


def _quote_tab(title: str) -> str:
    safe = title.replace("'", "''")
    return f"'{safe}'"


def _read_column_a(
    client: httpx.Client, spreadsheet_id: str, tab: str, token: str
) -> list[list[Any]]:
    rng = f"{_quote_tab(tab)}!A:A"
    resp = client.get(
        f"https://sheets.googleapis.com/v4/spreadsheets/{spreadsheet_id}/values/{rng}",
        headers=_sheets_headers(token),
    )
    if resp.status_code >= 400:
        raise GoogleSheetsLedgerError(
            f"Cannot read sheet column A (HTTP {resp.status_code}): {(resp.text or '')[:300]}"
        )
    return list((resp.json() or {}).get("values") or [])


def _ensure_header_row(
    client: httpx.Client,
    spreadsheet_id: str,
    tab: str,
    token: str,
    existing_a: list[list[Any]],
) -> None:
    first = [str(c).strip() for c in (existing_a[0] if existing_a else [])]
    if first[:5] == SHEET_HEADERS:
        return
    # Empty sheet or wrong header — write/overwrite header row
    rng = f"{_quote_tab(tab)}!A1:E1"
    resp = client.put(
        f"https://sheets.googleapis.com/v4/spreadsheets/{spreadsheet_id}/values/{rng}",
        headers=_sheets_headers(token),
        params={"valueInputOption": "USER_ENTERED"},
        json={"values": [SHEET_HEADERS]},
    )
    if resp.status_code >= 400:
        raise GoogleSheetsLedgerError(
            f"Cannot write header row (HTTP {resp.status_code}): {(resp.text or '')[:300]}"
        )


def _next_serial(existing_a: list[list[Any]]) -> int:
    last = 0
    for i, row in enumerate(existing_a):
        if i == 0:
            # skip header
            cell = str(row[0]).strip() if row else ""
            if cell.lower() in ("serial no", "serial", "s.no", "sno"):
                continue
        if not row:
            continue
        try:
            last = max(last, int(float(str(row[0]).strip())))
        except (ValueError, TypeError):
            continue
    return last + 1


def _append_via_sheets_api(
    spreadsheet_url: str,
    *,
    serial: int,
    slug: str,
    title: str,
    image_url: str,
    html_path: str,
) -> dict[str, Any]:
    spreadsheet_id = extract_spreadsheet_id(spreadsheet_url)
    if not spreadsheet_id:
        raise GoogleSheetsLedgerError(
            "Invalid Google Sheet URL. Paste a link like "
            "https://docs.google.com/spreadsheets/d/SHEET_ID/edit"
        )

    info = _load_service_account_info()
    token = _service_account_access_token(info)

    with httpx.Client(timeout=httpx.Timeout(30.0, connect=12.0)) as client:
        tab = _resolve_tab_title(client, spreadsheet_id, token)
        existing_a = _read_column_a(client, spreadsheet_id, tab, token)
        _ensure_header_row(client, spreadsheet_id, tab, token, existing_a)
        # Re-read after possible header write
        existing_a = _read_column_a(client, spreadsheet_id, tab, token)
        serial_no = serial if serial > 0 else _next_serial(existing_a)
        row = [serial_no, slug, title, image_url, html_path]
        rng = f"{_quote_tab(tab)}!A:E"
        resp = client.post(
            f"https://sheets.googleapis.com/v4/spreadsheets/{spreadsheet_id}/values/{rng}:append",
            headers=_sheets_headers(token),
            params={
                "valueInputOption": "USER_ENTERED",
                "insertDataOption": "INSERT_ROWS",
                "includeValuesInResponse": "false",
            },
            json={"values": [row]},
        )
        if resp.status_code >= 400:
            raise GoogleSheetsLedgerError(
                f"Sheet append failed (HTTP {resp.status_code}): {(resp.text or '')[:400]}"
            )

    return {
        "ok": True,
        "mode": "sheets_api",
        "spreadsheet_id": spreadsheet_id,
        "tab": tab,
        "serial_no": serial_no,
        "row": row,
        "service_account": info.get("client_email"),
    }


def _append_via_apps_script(
    webapp_url: str,
    *,
    serial: int,
    slug: str,
    title: str,
    image_url: str,
    html_path: str,
) -> dict[str, Any]:
    payload = {
        "serial_no": serial,
        "slug": slug,
        "blog_title": title,
        "image_url": image_url,
        "html_page_path": html_path,
        # Also send exact header keys for flexible scripts
        "Serial No": serial,
        "Slug": slug,
        "Blog Title": title,
        "Image URL": image_url,
        "HTML Page Path": html_path,
    }
    with httpx.Client(timeout=httpx.Timeout(30.0, connect=12.0), follow_redirects=True) as client:
        resp = client.post(webapp_url, json=payload)
        if resp.status_code >= 400:
            raise GoogleSheetsLedgerError(
                f"Apps Script web app failed (HTTP {resp.status_code}): {(resp.text or '')[:400]}"
            )
    return {
        "ok": True,
        "mode": "apps_script",
        "serial_no": serial,
        "row": [serial, slug, title, image_url, html_path],
    }


def append_blog_ledger_row(
    product: Product | None,
    *,
    serial_no: int,
    slug: str,
    blog_title: str,
    image_url: str,
    html_page_path: str,
    db: Session | None = None,
) -> Optional[dict[str, Any]]:
    """Append one ledger row for a published blog. Returns None if product has no sheet URL."""
    _ = db
    url = get_product_sheet_url(product)
    if not url:
        return None

    slug_v = (slug or "").strip()
    title_v = (blog_title or slug_v or "Untitled").strip()
    image_v = (image_url or "").strip()
    html_v = (html_page_path or "").strip()
    serial = int(serial_no) if serial_no and int(serial_no) > 0 else 0

    if is_apps_script_webapp(url):
        result = _append_via_apps_script(
            url,
            serial=serial or 1,
            slug=slug_v,
            title=title_v,
            image_url=image_v,
            html_path=html_v,
        )
    else:
        result = _append_via_sheets_api(
            url,
            serial=serial,
            slug=slug_v,
            title=title_v,
            image_url=image_v,
            html_path=html_v,
        )

    logger.info(
        "Google Sheet ledger row appended for product #{} serial={} slug={}",
        getattr(product, "id", None),
        result.get("serial_no"),
        slug_v,
    )
    return result
