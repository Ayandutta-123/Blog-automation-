from __future__ import annotations

import re
from html import unescape
from typing import Any
from urllib.parse import urljoin, urlparse

from loguru import logger
from sqlalchemy.orm import Session
from tavily import TavilyClient

from app.models import ScraperCategory, ScraperSettings
from app.services.runtime_config import get_config_value
from app.utils.retry import with_retry

_FEED_PATH_SUFFIXES = ("/feed", "/feed/", "/rss", "/rss.xml", "/atom.xml", "/feed/rss2", "/blog/feed", "/blog/feed/")


def _strip_html(text: str) -> str:
    cleaned = re.sub(r"<[^>]+>", " ", text or "")
    cleaned = unescape(cleaned)
    return re.sub(r"\s+", " ", cleaned).strip()


def _feed_candidates(url: str) -> list[str]:
    raw = (url or "").strip()
    if not raw:
        return []
    if not raw.startswith(("http://", "https://")):
        raw = f"https://{raw}"

    parsed = urlparse(raw)
    base = f"{parsed.scheme}://{parsed.netloc}{parsed.path.rstrip('/')}"
    candidates: list[str] = []

    def add(candidate: str) -> None:
        if candidate and candidate not in candidates:
            candidates.append(candidate)

    add(raw.rstrip("/"))
    if parsed.path in ("", "/"):
        for suffix in _FEED_PATH_SUFFIXES:
            add(urljoin(base + "/", suffix.lstrip("/")))
    else:
        for suffix in ("", "/feed", "/feed/", "/rss.xml"):
            add(f"{base}{suffix}")

    return candidates


def _parse_feed_entries(feed_url: str, max_entries: int = 10) -> dict[str, Any]:
    import feedparser

    feed = feedparser.parse(
        feed_url,
        agent="blog-Automation/1.0 (+https://hyperpark.io)",
    )

    if feed.bozo and not feed.entries:
        raise ValueError(getattr(feed, "bozo_exception", "Invalid or empty RSS feed"))

    articles: list[dict[str, str]] = []
    for entry in feed.entries[:max_entries]:
        title = (entry.get("title") or "").strip()
        link = (entry.get("link") or "").strip()
        if not title or not link:
            continue
        summary_raw = entry.get("summary") or entry.get("description") or ""
        articles.append(
            {
                "title": title,
                "url": link,
                "summary": _strip_html(summary_raw)[:500],
                "published": (entry.get("published") or entry.get("updated") or "").strip(),
            }
        )

    return {
        "source_url": feed_url,
        "feed_title": (feed.feed.get("title") or "").strip(),
        "articles": articles,
    }


@with_retry(max_attempts=2, base_delay=1.5)
def scrape_rss_feeds(urls: list[str], max_entries: int = 10) -> list[dict[str, Any]]:
    if not urls:
        return []

    results: list[dict[str, Any]] = []

    for original_url in urls:
        last_error = ""
        parsed = False
        for candidate in _feed_candidates(original_url):
            try:
                payload = _parse_feed_entries(candidate, max_entries=max_entries)
                if payload["articles"]:
                    payload["requested_url"] = original_url
                    results.append(payload)
                    parsed = True
                    logger.info(
                        f"RSS feed parsed: {candidate} ({len(payload['articles'])} articles)"
                    )
                    break
                last_error = "Feed returned no articles"
            except Exception as exc:
                last_error = str(exc)
                logger.debug(f"RSS candidate failed {candidate}: {exc}")

        if not parsed:
            logger.error(f"RSS scrape failed for '{original_url}': {last_error}")
            results.append(
                {
                    "source_url": original_url,
                    "requested_url": original_url,
                    "articles": [],
                    "error": last_error or "Could not parse RSS feed",
                }
            )

    return results


def normalize_rss_feed_url(url: str) -> str:
    """Normalize user input for RSS feed settings."""
    value = (url or "").strip()
    if not value:
        raise ValueError("RSS feed URL is required")
    if not value.startswith(("http://", "https://")):
        value = f"https://{value}"
    return value.rstrip("/")


@with_retry(max_attempts=3, base_delay=2.0)
def search_industry_trends(keywords: list[str]) -> list[dict[str, Any]]:
    if not keywords:
        return []
    api_key = get_config_value("tavily_api_key")
    if not api_key:
        logger.warning("Tavily API key not configured; skipping industry search")
        return []

    client = TavilyClient(api_key=api_key)
    results: list[dict[str, Any]] = []

    for keyword in keywords:
        try:
            response = client.search(
                query=keyword,
                search_depth="advanced",
                max_results=5,
                include_answer=True,
            )
            results.append(
                {
                    "keyword": keyword,
                    "answer": response.get("answer", ""),
                    "results": [
                        {
                            "title": r.get("title", ""),
                            "url": r.get("url", ""),
                            "content": r.get("content", "")[:500],
                        }
                        for r in response.get("results", [])
                    ],
                }
            )
        except Exception as exc:
            logger.error(f"Tavily search failed for '{keyword}': {exc}")
            raise

    return results


@with_retry(max_attempts=3, base_delay=2.0)
def scrape_competitor_blogs(urls: list[str]) -> list[dict[str, Any]]:
    """Scrape ONLY the configured competitor URLs — never follow/crawl child links."""
    if not urls:
        return []

    from app.utils.playwright_setup import configure_playwright_browsers_path, ensure_playwright_browsers

    configure_playwright_browsers_path()
    if not ensure_playwright_browsers():
        logger.warning("Playwright Chromium not available; skipping competitor scraping")
        return [
            {
                "source_url": url,
                "page_title": "",
                "excerpt": "",
                "headings": [],
                "articles": [],
                "error": "Playwright Chromium not installed. Run: cd backend && playwright install chromium",
            }
            for url in urls
        ]

    from playwright.sync_api import sync_playwright

    competitor_data: list[dict[str, Any]] = []

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context(
                user_agent=(
                    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                )
            )

            for url in urls:
                try:
                    page = context.new_page()
                    page.goto(url, wait_until="domcontentloaded", timeout=30000)
                    page.wait_for_timeout(2000)

                    # Stay on this exact page — extract content only (no following other hrefs)
                    snapshot = page.evaluate(
                        """() => {
                        const title = (document.querySelector('h1')?.textContent
                            || document.title
                            || '').trim().slice(0, 200);
                        const headings = Array.from(
                            document.querySelectorAll('h1, h2, h3')
                        )
                            .map(el => (el.textContent || '').trim())
                            .filter(t => t.length >= 8)
                            .slice(0, 12);
                        const paras = Array.from(document.querySelectorAll('p'))
                            .map(el => (el.textContent || '').trim())
                            .filter(t => t.length >= 40)
                            .slice(0, 8);
                        const excerpt = paras.join(' ').replace(/\\s+/g, ' ').slice(0, 900);
                        return { title, headings, excerpt };
                    }"""
                    )
                    page_title = str((snapshot or {}).get("title") or "").strip()
                    headings = list((snapshot or {}).get("headings") or [])
                    excerpt = str((snapshot or {}).get("excerpt") or "").strip()
                    # Keep a single "article" entry pointing at the configured URL itself
                    # so topic synthesis always has a genuine, fixed source link.
                    articles = [
                        {
                            "title": page_title or url,
                            "url": url,
                            "summary": excerpt[:280],
                        }
                    ]
                    competitor_data.append(
                        {
                            "source_url": url,
                            "page_title": page_title,
                            "excerpt": excerpt,
                            "headings": headings,
                            "articles": articles,
                        }
                    )
                    page.close()
                except Exception as exc:
                    logger.error(f"Playwright scrape failed for '{url}': {exc}")
                    competitor_data.append(
                        {
                            "source_url": url,
                            "page_title": "",
                            "excerpt": "",
                            "headings": [],
                            "articles": [],
                            "error": str(exc),
                        }
                    )

            browser.close()
    except Exception as exc:
        logger.error(f"Playwright browser launch failed: {exc}")
        return [
            {
                "source_url": url,
                "page_title": "",
                "excerpt": "",
                "headings": [],
                "articles": [],
                "error": str(exc),
            }
            for url in urls
        ]

    return competitor_data


def run_discovery(db: Session, product_id: int | None = None) -> dict[str, Any]:
    keyword_query = db.query(ScraperSettings).filter(
        ScraperSettings.category == ScraperCategory.INDUSTRY_KEYWORD,
        ScraperSettings.is_active.is_(True),
    )
    url_query = db.query(ScraperSettings).filter(
        ScraperSettings.category == ScraperCategory.COMPETITOR_URL,
        ScraperSettings.is_active.is_(True),
    )
    rss_query = db.query(ScraperSettings).filter(
        ScraperSettings.category == ScraperCategory.RSS_FEED,
        ScraperSettings.is_active.is_(True),
    )
    if product_id:
        keyword_query = keyword_query.filter(ScraperSettings.product_id == product_id)
        url_query = url_query.filter(ScraperSettings.product_id == product_id)
        rss_query = rss_query.filter(ScraperSettings.product_id == product_id)

    keywords = [s.value for s in keyword_query.all() if (s.value or "").strip()]
    urls = [s.value for s in url_query.all() if (s.value or "").strip()]
    rss_urls = [s.value for s in rss_query.all() if (s.value or "").strip()]

    logger.info(
        f"Discovery: {len(keywords)} keywords, {len(urls)} competitor URLs, {len(rss_urls)} RSS feeds"
    )

    industry_data = search_industry_trends(keywords)
    competitor_data = scrape_competitor_blogs(urls)
    rss_data = scrape_rss_feeds(rss_urls)

    return {
        "industry_trends": industry_data,
        "competitor_articles": competitor_data,
        "rss_articles": rss_data,
    }
