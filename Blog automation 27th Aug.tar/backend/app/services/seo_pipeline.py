"""Permanent SEO / technical rules for every generated blog page.

Rules enforced here (not one-offs):
1. Never embed images as base64 — public storage URL only
2. Always include canonical <link>
3. Always include Open Graph + Twitter Card tags
4. JSON-LD dates are dynamic (never hardcoded)
5. Hero alt text is topic-specific (never generic)
6. Fail loudly on placeholders / base64 / missing tags
7. Contextual internal linking (used with related_posts)
"""

from __future__ import annotations

import json
import re
from datetime import date, datetime, timezone
from html import escape
from pathlib import Path
from typing import Any, Optional

from bs4 import BeautifulSoup
from loguru import logger

from app.config import settings
from app.services.runtime_config import get_public_base_url

SITE_NAME = "Hyperthings.ai"

# Match real placeholders only — do NOT use re.I on the ALL_CAPS branch or
# legitimate values like content="article" / content="summary_large_image" fail.
_PLACEHOLDER_ATTR_RE = re.compile(
    r"""(?:src|href|content)\s*=\s*["']\s*(?:"""
    r"""HERO_IMAGE_SRC|hero_image_src|"""
    r"""\{\{[^"']+\}\}|\{%[^"']+%\}|"""
    r"""[A-Z][A-Z0-9_]{5,}"""
    r""")\s*["']"""
)
_TEMPLATE_SYNTAX_RE = re.compile(r"\{\{[\s\S]*?\}\}|\{%[\s\S]*?%\}")
_BASE64_IMG_RE = re.compile(
    r"""<img\b[^>]*\bsrc\s*=\s*["']\s*data:image/[^"']+["'][^>]*>""",
    re.I,
)
_GENERIC_ALT = re.compile(
    r"^(blog\s*hero(\s*image)?|hero\s*image|image|photo|banner|untitled)$",
    re.I,
)
# Markdown link syntax inside HTML attributes (invalid): src="[https://x](https://x)"
_MARKDOWN_URL_ATTR_RE = re.compile(
    r"""(?:src|href|content|data-src|poster)\s*=\s*["']\s*\[[^\]]*\]\(\s*https?://[^)"']+\)\s*["']""",
    re.I,
)


class BlogSeoValidationError(ValueError):
    """Raised when a generated blog fails mandatory SEO checks — never publish silently."""

    def __init__(self, failures: list[str]):
        self.failures = failures
        super().__init__(
            "Blog SEO validation failed:\n- " + "\n- ".join(failures)
        )


def public_storage_base() -> str:
    return get_public_base_url()


def ensure_hero_uploaded(slug: str) -> Path:
    """Require the hero file to exist in local image storage (served publicly via /api/images).

    TODO(CDN): If you add S3/Cloudflare R2/etc., upload here and return the CDN URL from
    ``public_hero_image_url`` instead of the API path. Today storage is
    ``settings.blog_images_dir`` + ``GET /api/images/{slug}.webp`` behind ``public_base_url``.
    """
    path = Path(settings.blog_images_dir) / f"{slug}.webp"
    if not path.is_file():
        raise BlogSeoValidationError(
            [
                f"Hero image missing on disk for slug '{slug}' at {path}. "
                "Generate/upload the image before finalizing HTML — never embed base64."
            ]
        )
    return path


def public_hero_image_url(slug: str, *, require_file: bool = True) -> str:
    """Always return a public HTTP(S) URL — never a data: URI."""
    if require_file:
        ensure_hero_uploaded(slug)
    return f"{public_storage_base()}/api/images/{slug}.webp"


def descriptive_hero_alt(
    primary_keyword: str | None,
    title: str | None = None,
    image_prompt: str | None = None,
) -> str:
    """Topic-relevant alt — never generic 'Blog hero image'."""
    for candidate in (image_prompt, title, primary_keyword):
        text = (candidate or "").strip()
        if text and not _GENERIC_ALT.match(text):
            # Keep alt concise for a11y
            cleaned = re.sub(r"\s+", " ", text)[:160]
            if cleaned.lower().startswith("create ") or "photorealistic" in cleaned.lower():
                # image-generation prompt noise — prefer keyword/title
                continue
            return cleaned
    keyword = (primary_keyword or "enterprise topic").strip() or "enterprise topic"
    return f"{keyword} — illustrative hero visual for this article"


def strip_base64_from_images(html: str, slug: str, alt: str) -> str:
    """HARD RULE: replace every data:image src with the public hero URL."""
    public = public_hero_image_url(slug, require_file=False)
    soup = BeautifulSoup(html or "", "html.parser")
    changed = 0
    for img in soup.find_all("img"):
        src = (img.get("src") or "").strip()
        if src.lower().startswith("data:image"):
            img["src"] = public
            if not (img.get("alt") or "").strip() or _GENERIC_ALT.match(img.get("alt") or ""):
                img["alt"] = alt
            if "blog-hero-image" not in (img.get("class") or []):
                classes = list(img.get("class") or [])
                classes.append("blog-hero-image")
                img["class"] = classes
            changed += 1
    if changed:
        logger.info(f"Stripped {changed} base64 <img> src(s) for slug={slug}; set public URL")
    return str(soup)


def canonical_url_for(product: Any, slug: str, explicit: str | None = None) -> str:
    from app.services.product_context import blog_base_url

    if explicit and explicit.strip():
        return explicit.strip().rstrip("/")
    return f"{blog_base_url(product).rstrip('/')}/{slug}"


def iso_date_today() -> str:
    """ISO 8601 date (YYYY-MM-DD) computed fresh each run — never a hardcoded template string."""
    return datetime.now(timezone.utc).date().isoformat()


def bump_json_ld_date_modified(html: str, date_modified: str | None = None) -> str:
    """Update Article dateModified independently (CMS edits). Preserves datePublished."""
    modified = date_modified or iso_date_today()
    soup = BeautifulSoup(html or "", "html.parser")
    for script in soup.find_all("script", attrs={"type": "application/ld+json"}):
        raw = (script.string or script.get_text() or "").strip()
        if not raw:
            continue
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            continue
        if not isinstance(data, dict):
            continue
        types = data.get("@type")
        type_list = types if isinstance(types, list) else [types]
        if "Article" not in type_list:
            continue
        data["dateModified"] = modified
        if not data.get("datePublished"):
            data["datePublished"] = modified
        script.string = json.dumps(data, ensure_ascii=False)
        break
    return str(soup)


def ensure_article_json_ld(
    html: str,
    *,
    title: str,
    description: str,
    slug: str,
    canonical: str,
    image_url: str,
    org_name: str,
    date_published: str | None = None,
    date_modified: str | None = None,
) -> str:
    """Upsert Article JSON-LD with dynamic dates and public image URL."""
    if not canonical:
        raise BlogSeoValidationError(["canonical URL is empty — cannot build JSON-LD"])

    published = date_published or iso_date_today()
    modified = date_modified or published

    soup = BeautifulSoup(html or "", "html.parser")
    article_script = None
    for script in soup.find_all("script", attrs={"type": "application/ld+json"}):
        raw = (script.string or script.get_text() or "").strip()
        if not raw:
            continue
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            continue
        types = data.get("@type") if isinstance(data, dict) else None
        type_list = types if isinstance(types, list) else [types]
        if any(t == "Article" for t in type_list if t):
            article_script = script
            break

    payload = {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": title,
        "description": description,
        "image": [image_url],
        "datePublished": published,
        "dateModified": modified,
        "author": {"@type": "Organization", "name": org_name},
        "publisher": {
            "@type": "Organization",
            "name": org_name,
            "logo": {
                "@type": "ImageObject",
                "url": f"{public_storage_base()}/api/images/{slug}.webp",
            },
        },
        "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": canonical,
        },
        "url": canonical,
    }

    if article_script is not None:
        # Preserve FAQPage scripts; replace Article body only
        article_script.string = json.dumps(payload, ensure_ascii=False)
    else:
        new_tag = soup.new_tag("script", type="application/ld+json")
        new_tag.string = json.dumps(payload, ensure_ascii=False)
        article = soup.find("article")
        if article:
            article.insert_before(new_tag)
        else:
            soup.insert(0, new_tag)

    return str(soup)


def build_seo_head_tags(
    *,
    title: str,
    description: str,
    canonical: str,
    image_url: str,
    site_name: str = SITE_NAME,
) -> str:
    """Required <head> SEO tags — canonical, OG, Twitter. Build fails if canonical empty."""
    if not (canonical or "").strip():
        raise BlogSeoValidationError(["canonical URL is required for <link rel=\"canonical\">"])
    if not (image_url or "").strip() or image_url.lower().startswith("data:"):
        raise BlogSeoValidationError(["og:image / twitter:image must be a public URL, not empty or base64"])

    t = escape(title or "", quote=True)
    d = escape(description or "", quote=True)
    c = escape(canonical.strip(), quote=True)
    img = escape(image_url.strip(), quote=True)
    sn = escape(site_name, quote=True)

    return f"""<link rel="canonical" href="{c}" />
<meta property="og:type" content="article" />
<meta property="og:title" content="{t}" />
<meta property="og:description" content="{d}" />
<meta property="og:image" content="{img}" />
<meta property="og:url" content="{c}" />
<meta property="og:site_name" content="{sn}" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="{t}" />
<meta name="twitter:description" content="{d}" />
<meta name="twitter:image" content="{img}" />"""


def assemble_full_html_document(
    *,
    title: str,
    description: str,
    body_html: str,
    canonical: str,
    image_url: str,
    css: str = "",
    site_name: str = SITE_NAME,
) -> str:
    """Standalone publish/download document with mandatory head tags."""
    head_seo = build_seo_head_tags(
        title=title,
        description=description,
        canonical=canonical,
        image_url=image_url,
        site_name=site_name,
    )
    title_esc = escape(title or "")
    desc_esc = escape(description or "", quote=True)

    # Pull JSON-LD out of body so it can sit in <head>
    soup = BeautifulSoup(body_html or "", "html.parser")
    scripts = []
    for script in list(soup.find_all("script", attrs={"type": "application/ld+json"})):
        scripts.append(str(script))
        script.decompose()
    # Prefer article inner HTML already structured
    article = soup.find("article")
    brand_style = soup.find("style", id="product-brand-palette")
    brand_css = str(brand_style) if brand_style else ""
    if brand_style:
        brand_style.decompose()

    if article:
        inner = article.decode_contents()
    else:
        inner = str(soup)

    json_ld = "\n".join(scripts)

    from app.services.blog_prose_css import FONT_HEAD_LINKS

    doc = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
<title>{title_esc}</title>
<meta name="description" content="{desc_esc}" />
{head_seo}
<meta name="color-scheme" content="light" />
{FONT_HEAD_LINKS}
{brand_css}
<style>
{css}
</style>
{json_ld}
</head>
<body>
<main class="blog-page">
  <article class="prose-blog">
{inner}
  </article>
</main>
</body>
</html>"""
    validate_seo_document(doc, require_full_document=True)
    return doc


def validate_seo_document(html: str, *, require_full_document: bool = False) -> None:
    """Mandatory gate — raises BlogSeoValidationError with exact failing checks."""
    failures: list[str] = []
    text = html or ""

    if _TEMPLATE_SYNTAX_RE.search(text):
        failures.append("Unreplaced template syntax {{...}} or {%...%} found in HTML")

    if _PLACEHOLDER_ATTR_RE.search(text):
        failures.append(
            "Placeholder-style attribute value found (e.g. HERO_IMAGE_SRC or ALL_CAPS) in src=/href=/content="
        )

    if "HERO_IMAGE_SRC" in text:
        failures.append("Unreplaced HERO_IMAGE_SRC placeholder remaining in HTML")

    if _BASE64_IMG_RE.search(text) or re.search(r'src\s*=\s*["\']\s*data:image/', text, re.I):
        failures.append("Base64 data URI found in <img src> — public URL required")

    if _MARKDOWN_URL_ATTR_RE.search(text):
        failures.append(
            "Markdown link syntax found inside HTML href/src/content "
            '(e.g. href="[https://…](https://…)") — use a bare URL'
        )

    soup = BeautifulSoup(text, "html.parser")
    from app.utils.link_sanitizer import looks_like_markdown_url

    for tag in soup.find_all(True):
        for attr in ("href", "src", "content", "data-src", "poster"):
            val = tag.get(attr)
            if isinstance(val, str) and looks_like_markdown_url(val):
                failures.append(
                    f"Markdown URL in <{tag.name} {attr}>: {val[:80]}"
                )
                break

    for img in soup.find_all("img"):
        src = (img.get("src") or "").strip()
        if not src:
            failures.append("Empty <img src>")
        elif src.lower().startswith("data:"):
            failures.append(f"Base64/data URI on <img>: {src[:48]}…")
        elif looks_like_markdown_url(src) or (src.startswith("[") and "](" in src):
            failures.append(f"Markdown syntax in <img src>: {src[:80]}")
        alt = (img.get("alt") or "").strip()
        if "blog-hero-image" in (img.get("class") or []) and (
            not alt or _GENERIC_ALT.match(alt)
        ):
            failures.append(f"Hero image alt is missing or generic: '{alt}'")

    if require_full_document:
        canonical = soup.find("link", attrs={"rel": "canonical"})
        href = (canonical.get("href") if canonical else "") or ""
        if not canonical or not href.strip():
            failures.append("Missing or empty <link rel=\"canonical\">")

        for prop, label in (
            ("og:type", "og:type"),
            ("og:title", "og:title"),
            ("og:description", "og:description"),
            ("og:image", "og:image"),
            ("og:url", "og:url"),
            ("og:site_name", "og:site_name"),
        ):
            tag = soup.find("meta", attrs={"property": prop})
            content = (tag.get("content") if tag else "") or ""
            if not tag or not content.strip():
                failures.append(f"Missing or empty <meta property=\"{label}\">")
            elif prop == "og:image" and content.lower().startswith("data:"):
                failures.append("og:image must not be a base64 data URI")

        for name in ("twitter:card", "twitter:title", "twitter:description", "twitter:image"):
            tag = soup.find("meta", attrs={"name": name})
            content = (tag.get("content") if tag else "") or ""
            if not tag or not content.strip():
                failures.append(f"Missing or empty <meta name=\"{name}\">")
            elif name == "twitter:image" and content.lower().startswith("data:"):
                failures.append("twitter:image must not be a base64 data URI")

        # JSON-LD dates must not look like fixed template placeholders
        for script in soup.find_all("script", attrs={"type": "application/ld+json"}):
            raw = (script.string or script.get_text() or "").strip()
            if not raw:
                continue
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                failures.append("Invalid JSON-LD script (not parseable JSON)")
                continue
            if not isinstance(data, dict):
                continue
            types = data.get("@type")
            type_list = types if isinstance(types, list) else [types]
            if "Article" not in type_list:
                continue
            for key in ("datePublished", "dateModified"):
                val = data.get(key)
                if not val or not isinstance(val, str):
                    failures.append(f"Article JSON-LD missing {key}")
                elif "{{" in val or "YYYY" in val.upper() or val.strip() in ("DATE", "TODAY"):
                    failures.append(f"Article JSON-LD {key} looks hardcoded/placeholder: {val}")
                else:
                    try:
                        date.fromisoformat(val[:10])
                    except ValueError:
                        failures.append(f"Article JSON-LD {key} is not ISO date: {val}")
            image = data.get("image")
            img_url = image[0] if isinstance(image, list) and image else image
            if not img_url or (isinstance(img_url, str) and img_url.lower().startswith("data:")):
                failures.append("Article JSON-LD image must be a public URL")
            main = data.get("mainEntityOfPage") or {}
            main_id = main.get("@id") if isinstance(main, dict) else None
            if not main_id:
                failures.append("Article JSON-LD mainEntityOfPage.@id (canonical) missing")

    if failures:
        logger.error("SEO validation failures:\n" + "\n".join(f"  - {f}" for f in failures))
        raise BlogSeoValidationError(failures)


def finalize_blog_fragment(
    html: str,
    *,
    slug: str,
    title: str,
    description: str,
    primary_keyword: str,
    product: Any = None,
    date_published: str | None = None,
    date_modified: str | None = None,
    image_prompt: str | None = None,
    validate_full_doc_later: bool = True,
) -> str:
    """
    Permanent post-enrichment for stored fragment (JSON-LD + article):
    public hero URL, descriptive alt, dynamic Article JSON-LD, no base64.
    """
    from app.services.product_context import company_label
    from app.services.related_posts import insert_contextual_internal_links
    from app.utils.link_sanitizer import sanitize_markdown_urls_in_html

    # LLM often puts Markdown [url](url) inside href/src — strip before SEO work
    html = sanitize_markdown_urls_in_html(html or "")

    alt = descriptive_hero_alt(primary_keyword, title, image_prompt)
    html = strip_base64_from_images(html, slug, alt)

    # Force public hero URL on hero img
    try:
        image_url = public_hero_image_url(slug, require_file=True)
    except BlogSeoValidationError:
        # During generation the image may be written moments later — allow finalize
        # with require_file=False only if caller regenerates; re-check in validate.
        image_url = public_hero_image_url(slug, require_file=False)

    soup = BeautifulSoup(html or "", "html.parser")
    hero = soup.find("img", class_=lambda c: c and "blog-hero-image" in c) or soup.find("img")
    if hero:
        hero["src"] = image_url
        hero["alt"] = alt
    html = str(soup)

    canonical = canonical_url_for(product, slug)
    org = company_label(product)
    html = ensure_article_json_ld(
        html,
        title=title or primary_keyword,
        description=description or "",
        slug=slug,
        canonical=canonical,
        image_url=image_url,
        org_name=org,
        date_published=date_published,
        date_modified=date_modified,
    )

    html = insert_contextual_internal_links(html, product=product)

    # Fragment-level hard checks (full doc checked at publish/download)
    validate_seo_document(html, require_full_document=False)
    # Also reject empty canonical intent from JSON-LD
    if "mainEntityOfPage" not in html and canonical not in html:
        raise BlogSeoValidationError(["Canonical/mainEntityOfPage missing after finalize"])

    if validate_full_doc_later:
        logger.debug(f"Fragment SEO finalized for {slug} (full-doc gate at publish/download)")
    return html
