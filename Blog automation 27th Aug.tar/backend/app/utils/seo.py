from __future__ import annotations

import re

from app.schemas import SEOMetrics


from app.services.content_archetypes import get_archetype, word_count_in_range
from app.utils.word_count import count_blog_words


def compute_seo_metrics(
    title_tag: str | None,
    meta_description: str | None,
    slug: str | None,
    reading_time: str | None,
    html_content: str | None,
    content_archetype: str | None = "tutorial",
) -> SEOMetrics:
    title_len = len(title_tag or "")
    meta_len = len(meta_description or "")
    html = html_content or ""

    internal_links = len(
        re.findall(r'href=["\']https?://(?:www\.)?hyperpark\.io/', html, re.I)
    )
    external_links = len(
        re.findall(
            r'<a[^>]+href=["\']https?://(?!hyperpark\.io)[^"\']+["\'][^>]*>',
            html,
            re.I,
        )
    )
    has_json_ld = 'type="application/ld+json"' in html or "application/ld+json" in html
    arch = get_archetype(content_archetype)
    wc = count_blog_words(html)

    return SEOMetrics(
        title_tag_length=title_len,
        title_tag_valid=55 <= title_len <= 60,
        meta_description_length=meta_len,
        meta_description_valid=140 <= meta_len <= 160,
        slug=slug,
        reading_time=reading_time,
        word_count=wc,
        word_count_min=arch.min_words,
        word_count_max=arch.max_words,
        word_count_valid=word_count_in_range(wc, arch.id),
        content_archetype=arch.id,
        content_archetype_label=arch.label,
        has_json_ld=has_json_ld,
        internal_links_count=internal_links,
        external_links_count=external_links,
    )
