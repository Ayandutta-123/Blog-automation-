"""Validate SEO anatomy: heading hierarchy, intro, body structure, conclusion."""

from __future__ import annotations

import re

from bs4 import BeautifulSoup, Tag

_INTRO_MIN_WORDS = 80
_INTRO_MAX_WORDS = 180
_MIN_H3_COUNT = 2
_MIN_BODY_H2 = 3


def _count_words(text: str) -> int:
    return len(re.sub(r"\s+", " ", text).strip().split())


def _article_text_between(start: Tag | None, end: Tag | None) -> str:
    if not start:
        return ""
    parts: list[str] = []
    node = start.next_sibling
    while node and node is not end:
        if isinstance(node, Tag):
            if node.name in ("script", "style", "nav"):
                node = node.next_sibling
                continue
            parts.append(node.get_text(" ", strip=True))
        elif str(node).strip():
            parts.append(str(node).strip())
        node = node.next_sibling
    return " ".join(parts)


def validate_seo_structure(html: str, content_archetype: str | None = None) -> list[str]:
    """Return SEO structure issues (empty = passes)."""
    from app.services.content_archetypes import get_archetype

    arch = get_archetype(content_archetype)
    intro_min = 50 if arch.id in ("quick_faq", "news_update") else 80
    intro_max = 120 if arch.id == "quick_faq" else 180
    min_h2 = 2 if arch.id in ("quick_faq", "news_update") else 3
    if arch.id == "listicle":
        min_h2 = 5
    if arch.id == "pillar":
        min_h2 = 5
    min_h3 = 0 if arch.id in ("quick_faq", "listicle") else 1
    if arch.id == "pillar":
        min_h3 = 4
    elif arch.id == "tutorial":
        min_h3 = 2

    issues: list[str] = []
    soup = BeautifulSoup(html, "html.parser")
    article = soup.find("article")
    if not article:
        issues.append("missing <article> wrapper")
        return issues

    h1_tags = article.find_all("h1")
    if len(h1_tags) != 1:
        issues.append("exactly one H1 required")
    elif h1_tags:
        h1 = h1_tags[0]
        first_h2 = h1.find_next("h2")
        intro_text = _article_text_between(h1, first_h2)
        intro_words = _count_words(intro_text)
        if intro_words < intro_min:
            issues.append(
                f"introduction too short ({intro_words} words; target ~{intro_min}–{intro_max})"
            )
        elif intro_words > intro_max:
            issues.append(
                f"introduction too long ({intro_words} words; keep ~{intro_min}–{intro_max})"
            )

    headings = article.find_all(["h1", "h2", "h3", "h4"])
    last_level = 0
    for h in headings:
        if h.find_parent("nav", class_="toc"):
            continue
        level = int(h.name[1])
        if last_level and level > last_level + 1:
            issues.append(f"heading skip: {h.name} after h{last_level}")
        last_level = level

    body_h2s = [
        h
        for h in article.find_all("h2")
        if not h.find_parent("nav", class_="toc")
        and not h.find_parent("section", class_="blog-cta")
        and (h.get("id") or "").lower() not in ("faq", "cta")
        and h.get_text(strip=True).lower() not in ("contents", "table of contents")
    ]
    if len(body_h2s) < min_h2:
        issues.append(f"body needs more H2 sections (min {min_h2} for {arch.label})")

    h3_count = len(
        [
            h
            for h in article.find_all("h3")
            if not h.find_parent("nav") and not h.find_parent("section", class_="blog-cta")
        ]
    )
    if h3_count < min_h3:
        issues.append(f"H3 subtopics required (min {min_h3} for {arch.label})")

    if not article.find(["ul", "ol"]):
        issues.append("bulleted or numbered list required")

    if not article.find(["strong", "b"]):
        issues.append("bold key terminology required")

    has_conclusion = bool(
        article.find(
            "h2",
            id=re.compile(r"conclusion|takeaway|summary", re.I),
        )
        or article.find(
            "h2",
            string=re.compile(r"conclusion|key takeaway|summary", re.I),
        )
    )
    if not has_conclusion:
        issues.append("conclusion section (H2) before CTA")

    return issues
