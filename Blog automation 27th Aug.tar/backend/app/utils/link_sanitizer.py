"""Strip backlinks that are not on the approved whitelist, and verify the survivors are actually live.

Two layers of defense against bad backlinks:
1. Whitelist — only URLs from the curated internal/external source lists may appear at all.
   Anything the model invents (random paths, competitor sites, hallucinated URLs) is unwrapped.
2. Live check — whitelisted URLs are additionally probed over HTTP (cached) before being kept.
   A URL that now 404s / times out / fails to resolve is stripped even if it used to be approved,
   so a stale or typo'd entry in the whitelist can never ship inside a blog post.

Also unwraps Markdown link syntax that LLMs sometimes put inside HTML attributes, e.g.
  src="[https://x](https://x)"  →  src="https://x"
  href="[Label](https://x)"     →  href="https://x"
"""

from __future__ import annotations

import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse, urlunparse

import httpx
from bs4 import BeautifulSoup, NavigableString, Tag
from loguru import logger

from app.services.blog_format import AUTHORITATIVE_EXTERNAL_SOURCES, HYPERPARK_INTERNAL_LINKS

# Full attribute value is a Markdown link: [label](https://...)
_MD_LINK_ATTR_RE = re.compile(
    r"^\s*\[([^\]]*)\]\(\s*(https?://[^)\s]+)\s*\)\s*$",
    re.I,
)
_URL_ATTRS = ("href", "src", "content", "data-src", "poster", "action")

# Status codes that mean "this specific page/resource is gone" — always treated as dead.
_DEAD_STATUS_CODES = {400, 404, 405, 406, 410, 451}
# Status codes typical of bot-protection (Cloudflare/Akamai/WAF) rather than proof the page
# is actually broken for real visitors — we do not strip on these alone, only log them.
_AMBIGUOUS_STATUS_CODES = {401, 403, 429}

_CACHE_TTL_SECONDS = 6 * 60 * 60  # re-check every 6 hours
_CHECK_TIMEOUT = 5.0
_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
)

_cache_lock = threading.Lock()
_live_cache: dict[str, tuple[float, bool]] = {}


def unwrap_markdown_url(value: str) -> str:
    """Turn Markdown link syntax into a bare URL when the whole value is a link.

    Examples:
      "[https://a.com/x](https://a.com/x)" → "https://a.com/x"
      "[OECD report](https://a.com/x)"     → "https://a.com/x"
      "https://a.com/x"                    → unchanged
    """
    raw = (value or "").strip()
    if not raw:
        return ""
    # Peel Markdown wrappers (including nested [url](url) from LLMs)
    for _ in range(4):
        m = _MD_LINK_ATTR_RE.match(raw)
        if m:
            raw = (m.group(2) or "").strip()
            continue
        if raw.startswith("[") and "](" in raw and "http" in raw.lower():
            urls = re.findall(r"\(\s*(https?://[^)\s]+)\s*\)", raw, flags=re.I)
            if urls:
                raw = urls[-1].strip()
                continue
        break
    return raw


def looks_like_markdown_url(value: str) -> bool:
    """True when an attribute value still looks like Markdown link syntax."""
    raw = (value or "").strip()
    if not raw:
        return False
    return bool(_MD_LINK_ATTR_RE.match(raw)) or (
        raw.startswith("[") and "](" in raw and "http" in raw.lower()
    )


def sanitize_markdown_urls_in_html(html: str) -> str:
    """Rewrite Markdown-style URLs inside href/src/content (and similar) to bare URLs."""
    if not html or "[" not in html or "](" not in html:
        return html or ""

    soup = BeautifulSoup(html, "html.parser")
    changed = 0
    for tag in soup.find_all(True):
        for attr in _URL_ATTRS:
            if not tag.has_attr(attr):
                continue
            original = tag.get(attr)
            if not isinstance(original, str):
                continue
            cleaned = unwrap_markdown_url(original)
            if cleaned and cleaned != original:
                tag[attr] = cleaned
                changed += 1

    if changed:
        logger.info("Unwrapped {} Markdown URL attribute(s) in HTML", changed)
        return str(soup)

    # Regex fallback when BeautifulSoup did not rewrite (e.g. odd quoting)
    def _attr_sub(match: re.Match) -> str:
        prefix, quote, value = match.group(1), match.group(2), match.group(3)
        cleaned = unwrap_markdown_url(value)
        return f"{prefix}{quote}{cleaned}{quote}"

    pattern = re.compile(
        r"""((?:src|href|content|data-src|poster|action)\s*=\s*)(["'])([^"']*)\2""",
        re.I,
    )
    out = pattern.sub(_attr_sub, html)
    if out != html:
        logger.info("Unwrapped Markdown URL attribute(s) via regex fallback")
        return out
    return html


def _normalize_url(url: str) -> str:
    url = unwrap_markdown_url(url).strip()
    if not url:
        return ""
    parsed = urlparse(url if "://" in url else f"https://{url}")
    scheme = (parsed.scheme or "https").lower()
    netloc = (parsed.netloc or "").lower()
    path = parsed.path or "/"
    if path != "/" and path.endswith("/"):
        path = path.rstrip("/")
    return urlunparse((scheme, netloc, path, "", "", ""))


def _probe_url(url: str) -> bool:
    """Single live HTTP probe. Fail-closed on real errors, fail-open on bot-block signals."""
    headers = {"User-Agent": _USER_AGENT, "Accept": "text/html,*/*;q=0.8"}
    try:
        with httpx.Client(
            timeout=_CHECK_TIMEOUT, follow_redirects=True, headers=headers, http2=False
        ) as client:
            resp = client.head(url)
            if resp.status_code in _DEAD_STATUS_CODES or resp.status_code >= 500:
                # HEAD is sometimes blocked/misrouted even on live sites — confirm with GET.
                resp = client.get(url)
    except Exception as exc:
        logger.warning(f"Link check errored for {url}: {type(exc).__name__}: {exc}")
        return False

    if resp.status_code < 400:
        return True
    if resp.status_code in _AMBIGUOUS_STATUS_CODES:
        logger.info(
            f"Link check got {resp.status_code} for {url} — likely bot-protection, "
            "keeping it (not proof the page is actually broken)."
        )
        return True
    logger.warning(f"Link check found dead URL ({resp.status_code}): {url}")
    return False


def is_url_live(url: str) -> bool:
    """Cached liveness check for a single URL."""
    normalized = _normalize_url(url)
    if not normalized:
        return False

    now = time.time()
    with _cache_lock:
        cached = _live_cache.get(normalized)
        if cached and (now - cached[0]) < _CACHE_TTL_SECONDS:
            return cached[1]

    alive = _probe_url(normalized)
    with _cache_lock:
        _live_cache[normalized] = (now, alive)
    return alive


def filter_live_links(links: list[tuple[str, str]]) -> list[tuple[str, str]]:
    """Return only the (label, url) pairs that pass a live check, checked in parallel."""
    if not links:
        return []

    unique_urls = list({url for _, url in links})
    with ThreadPoolExecutor(max_workers=min(8, max(1, len(unique_urls)))) as pool:
        results = dict(zip(unique_urls, pool.map(is_url_live, unique_urls)))

    return [(label, url) for label, url in links if results.get(url)]


def _allowed_sets(
    internal_links: list[tuple[str, str]] | None = None,
    product_domain: str | None = None,
    extra_allowed: list[str] | None = None,
) -> tuple[set[str], set[str], str]:
    links = internal_links or list(HYPERPARK_INTERNAL_LINKS)
    allowed_internal = {_normalize_url(url) for _, url in links}
    allowed_external = {_normalize_url(url) for _, url in AUTHORITATIVE_EXTERNAL_SOURCES}
    for url in extra_allowed or []:
        n = _normalize_url(url)
        if n:
            allowed_external.add(n)
    domain = (product_domain or "hyperpark.io").lower().removeprefix("www.")
    return allowed_internal, allowed_external, domain


def _is_anchor(href: str) -> bool:
    return href.startswith("#")


def _is_allowed_href(
    href: str,
    allowed_internal: set[str],
    allowed_external: set[str],
    product_domain: str,
    *,
    require_live: bool = True,
) -> bool:
    if not href or _is_anchor(href):
        return True
    if href.startswith("mailto:") or href.startswith("tel:"):
        return False

    normalized = _normalize_url(href)
    # A product's "internal" link list may legitimately point off-domain (e.g. a Calendly
    # booking link used as the demo CTA) — so membership in either curated list is enough,
    # regardless of which domain the URL happens to be on.
    on_whitelist = normalized in allowed_internal or normalized in allowed_external
    if not on_whitelist:
        return False

    # HARD RULE (all products): even a whitelisted URL must resolve live right now.
    if require_live:
        return is_url_live(normalized)
    return True


def _unwrap_link(anchor: Tag) -> None:
    """Replace anchor with its text content — removes bad backlinks safely."""
    anchor.replace_with(NavigableString(anchor.get_text()))


def sanitize_backlinks(
    html: str,
    internal_links: list[tuple[str, str]] | None = None,
    product_domain: str | None = None,
    *,
    extra_allowed: list[str] | None = None,
) -> tuple[str, list[str]]:
    """
    Remove or unwrap links not on the approved internal / external source lists, or that fail
    a live HTTP check. Dead links are NEVER kept (hard rule for all products).
    Returns (cleaned_html, list of removed hrefs).
    """
    # LLM often emits href="[https://x](https://x)" — normalize before whitelist checks
    html = sanitize_markdown_urls_in_html(html)

    allowed_internal, allowed_external, domain = _allowed_sets(
        internal_links, product_domain, extra_allowed=extra_allowed
    )
    soup = BeautifulSoup(html, "html.parser")
    removed: list[str] = []

    for a in soup.find_all("a", href=True):
        href = unwrap_markdown_url((a.get("href") or "").strip())
        if href != (a.get("href") or "").strip():
            a["href"] = href
        if _is_allowed_href(href, allowed_internal, allowed_external, domain, require_live=True):
            continue
        removed.append(href)
        _unwrap_link(a)

    if removed:
        logger.warning(f"Removed {len(removed)} non-approved/dead backlink(s): {removed[:8]}")
    return str(soup), removed


def approved_external_sources() -> list[tuple[str, str]]:
    return list(AUTHORITATIVE_EXTERNAL_SOURCES)


def approved_internal_links() -> list[tuple[str, str]]:
    return list(HYPERPARK_INTERNAL_LINKS)


def verified_external_sources(
    candidates: list[tuple[str, str]] | None = None,
) -> list[tuple[str, str]]:
    """External sources that currently pass a live check. NEVER returns dead URLs."""
    pool = candidates if candidates is not None else list(AUTHORITATIVE_EXTERNAL_SOURCES)
    return filter_live_links(pool)


def verified_internal_links(links: list[tuple[str, str]] | None = None) -> list[tuple[str, str]]:
    """Internal links that currently pass a live check. NEVER returns dead URLs."""
    candidates = links or list(HYPERPARK_INTERNAL_LINKS)
    return filter_live_links(candidates)
