"""Internal word count for review — never embedded in published HTML."""

from __future__ import annotations

import re

from bs4 import BeautifulSoup


def count_blog_words(html: str) -> int:
    """Count words in visible article body (excludes JSON-LD scripts)."""
    if not html:
        return 0

    soup = BeautifulSoup(html, "html.parser")
    for script in soup.find_all("script"):
        script.decompose()

    article = soup.find("article")
    root = article if article else soup
    text = root.get_text(" ", strip=True)
    text = re.sub(r"\s+", " ", text).strip()
    if not text:
        return 0
    return len(text.split())
