from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from loguru import logger

from app.config import settings

_CONFIGURED = False


def playwright_browsers_dir() -> Path:
    return (Path(settings.storage_root).resolve() / "playwright-browsers").resolve()


def configure_playwright_browsers_path() -> Path:
    """Pin Playwright browsers to storage, or keep an existing Docker path."""
    global _CONFIGURED
    existing = os.environ.get("PLAYWRIGHT_BROWSERS_PATH", "").strip()
    if existing:
        browser_dir = Path(existing).resolve()
        browser_dir.mkdir(parents=True, exist_ok=True)
        _CONFIGURED = True
        return browser_dir
    browser_dir = playwright_browsers_dir()
    browser_dir.mkdir(parents=True, exist_ok=True)
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = str(browser_dir)
    _CONFIGURED = True
    return browser_dir


def chromium_headless_shell_path(browser_dir: Path | None = None) -> Path | None:
    root = browser_dir or playwright_browsers_dir()
    if not root.exists():
        return None
    patterns = (
        "chromium_headless_shell-*/chrome-headless-shell-linux*/chrome-headless-shell",
        "chromium_headless_shell-*/chrome-headless-shell-mac*/chrome-headless-shell",
        "chromium_headless_shell-*/chrome-headless-shell-win*/chrome-headless-shell.exe",
        "chromium-*/chrome-linux*/chrome",
        "chromium-*/chrome-mac*/Chromium.app/Contents/MacOS/Chromium",
        "chromium-*/chrome-win*/chrome.exe",
    )
    for pattern in patterns:
        matches = sorted(p for p in root.glob(pattern) if p.is_file())
        if matches:
            return matches[0]
    return None


def browsers_installed() -> bool:
    configure_playwright_browsers_path()
    return chromium_headless_shell_path() is not None


def install_chromium_browsers() -> None:
    configure_playwright_browsers_path()
    logger.info(f"Installing Playwright Chromium to {playwright_browsers_dir()}")
    subprocess.run(
        [sys.executable, "-m", "playwright", "install", "chromium"],
        check=True,
    )
    if not browsers_installed():
        raise RuntimeError("Playwright install finished but Chromium binary was not found")


def ensure_playwright_browsers() -> bool:
    """Return True when Chromium is available (install if missing)."""
    configure_playwright_browsers_path()
    if browsers_installed():
        return True
    try:
        install_chromium_browsers()
        return browsers_installed()
    except Exception as exc:
        logger.error(f"Failed to install Playwright browsers: {exc}")
        return False
