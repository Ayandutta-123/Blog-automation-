import sys
from pathlib import Path

from loguru import logger

from app.config import settings


def setup_logging() -> None:
    log_dir = Path(settings.storage_root) / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    logger.remove()
    logger.add(
        sys.stderr,
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | "
        "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>",
        level="INFO",
    )
    logger.add(
        str(log_dir / "hyperpark_blog.log"),
        rotation="10 MB",
        retention="30 days",
        level="DEBUG",
    )
