from __future__ import annotations

from pathlib import Path

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    tavily_api_key: str = ""
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-4-5"
    fal_key: str = ""
    fal_image_model: str = "fal-ai/flux-pro/v1.1-ultra"
    teams_webhook_url: str = ""

    storage_root: str = "../storage"
    blog_images_dir: str = "../storage/blog_images"
    blog_html_dir: str = "../storage/blogs/html"
    metadata_excel_path: str = "../storage/blogs/metadata.xlsx"
    # PostgreSQL is the only runtime database. Keep this in environment config
    # so local, staging, and on-prem deployments can use different hosts.
    database_url: str = ""

    api_host: str = "0.0.0.0"
    api_port: int = 8000
    # Deployment-specific origins. Local values belong in backend/.env; on-prem
    # values belong in the root .env consumed by Docker Compose.
    frontend_url: str = ""
    public_base_url: str = ""

    cron_day_of_week: str = "mon"
    cron_hour: int = 9
    cron_minute: int = 0
    cron_timezone: str = "Asia/Kolkata"
    dashboard_username: str = ""
    dashboard_password: str = ""
    topic_selection_mode: str = "hybrid"
    content_archetype: str = "tutorial"
    blog_content_instructions: str = (
        "Always use rich format: data tables, inline SVG or stat-grid graphics, "
        "genuine authoritative backlinks, and a strong demo CTA ending. "
        "Photorealistic hero image context."
    )
    blog_structure_rules: str = ""

    # MinIO / S3-compatible storage for published HTML
    minio_endpoint: str = ""
    minio_access_key: str = ""
    minio_secret_key: str = ""
    minio_bucket: str = ""
    minio_prefix: str = "blogs/html"
    minio_secure: str = "true"
    minio_region: str = ""
    minio_public_base_url: str = ""

    @field_validator("database_url")
    @classmethod
    def require_postgres_database(cls, value: str) -> str:
        url = (value or "").strip()
        if url.startswith("postgres://"):
            url = "postgresql://" + url[len("postgres://") :]
        if not url.startswith(("postgresql://", "postgresql+psycopg2://")):
            raise ValueError(
                "DATABASE_URL must be a PostgreSQL URL. "
                "SQLite is not supported for application runtime storage."
            )
        return url

    def ensure_dirs(self) -> None:
        for path in [
            self.storage_root,
            self.blog_images_dir,
            self.blog_html_dir,
            Path(self.metadata_excel_path).parent,
        ]:
            Path(path).mkdir(parents=True, exist_ok=True)


settings = Settings()
