# HyperPark Autonomous Blog & HITL Automation Engine

Enterprise SEO blog automation system for [HyperPark](https://hyperpark.io/) with dual-channel Human-in-the-Loop review gates (dashboard + MS Teams).

## Architecture

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
│  Next.js UI     │────▶│  FastAPI Backend │────▶│  PostgreSQL     │
│  (localhost:3000)│     │  (localhost:8000)│     │  products/posts │
└─────────────────┘     └────────┬─────────┘     │  config/users    │
                                 │                └─────────────────┘
                    ┌────────────┼────────────┐
                    ▼            ▼            ▼
              Tavily API    Claude 3.5    Fal.ai Flux
              Playwright    Sonnet        (WebP images)
                    │            │            │
                    └────────────┼────────────┘
                                 ▼
                    ┌────────────────────────┐
                    │  MS Teams Webhooks     │
                    │  Excel Ledger (xlsx)   │
                    │  HTML + WebP Storage   │
                    └────────────────────────┘
```

## Workflow Phases

1. **Discovery** — Weekly cron (Mon 09:00) or manual trigger scrapes Tavily + competitor blogs, synthesizes 4 topics via Claude
2. **HITL Gate 1** — Select topic via `/topics` dashboard or Teams Adaptive Card
3. **Generation** — Parallel Claude content + Fal.ai hero image (WebP 1200×630)
4. **HITL Gate 2** — Review preview at `/review` with SEO metrics sidebar; approve/redo/abort
5. **Publish** — Write HTML, append Excel ledger, notify Teams

## Quick Start

### Backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
playwright install chromium
cp .env.example .env        # Add your API keys
# Set DATABASE_URL to your PostgreSQL server before starting
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Frontend

```bash
cd frontend
npm install
cp .env.local.example .env.local
npm run dev
```

Open http://localhost:3000

## Docker Compose (Postgres)

Postgres is the only runtime database. Database rows and uploaded files survive
container rebuilds in stable named volumes:

- `hyperpark_postgres_data` — products, blogs, settings, users and credentials
- `hyperpark_uploads_data` — hero images, PDFs, HTML, logs and Excel files

```bash
cp .env.docker.example .env   # set DASHBOARD_PASSWORD and POSTGRES_PASSWORD
docker compose up -d --build
```

Open http://localhost:8080

Compose points the app at Postgres:

`postgresql://hyperpark:…@postgres:5432/hyperpark`

For normal code-only updates, keep the same `.env` and run:

```bash
docker compose up -d --build
```

Do not run `docker compose down -v` or remove the two named volumes unless you
intend to wipe all data.

### One-time migration from an older SQLite release

Run this only against a new, empty Postgres volume, before starting the app:

```bash
docker compose up -d postgres
docker compose run --rm --entrypoint python --workdir /app/backend \
  -v "$PWD/storage:/legacy:ro" app \
  /app/backend/scripts/migrate_sqlite_to_postgres.py \
  --source /legacy/hyperpark_blog.db
docker compose up -d app
```

Then copy legacy uploaded files into the persistent uploads volume:

```bash
docker run --rm \
  -v "$PWD/storage:/source:ro" \
  -v hyperpark_uploads_data:/destination \
  alpine sh -c "cp -a /source/. /destination/"
```

## Environment Variables

| Variable | Description |
|----------|-------------|
| `TAVILY_API_KEY` | Tavily search API key |
| `ANTHROPIC_API_KEY` | Anthropic Claude API key |
| `FAL_KEY` | Fal.ai API key for image generation |
| `TEAMS_WEBHOOK_URL` | MS Teams Incoming Webhook URL |
| `DATABASE_URL` | Required PostgreSQL connection URL |
| `STORAGE_ROOT` | Local storage root (default: `./storage`) |
| `FRONTEND_URL` | Dashboard URL for Teams card links |
| `PUBLIC_BASE_URL` | Public API URL for image serving |

## Storage Layout

PostgreSQL stores all application records. Non-relational files remain under
`STORAGE_ROOT` and are mounted from `hyperpark_uploads_data` in Compose:

```text
/data/storage/
├── blog_images/{slug}.webp
├── blogs/html/{slug}.html
├── blogs/metadata.xlsx
├── products/{product_id}/...
└── logs/hyperpark_blog.log
```

## Teams Integration (Cloudflare Tunnel)

Route Teams webhook button clicks to your local FastAPI:

```bash
cloudflared tunnel --url http://localhost:8000
```

Configure Adaptive Card `Action.Submit` to POST to:
- `/api/teams/webhook` — unified handler
- `/api/teams/topic-select` — topic selection
- `/api/teams/approve` — approve/redo actions

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/settings` | List scraper settings |
| POST | `/api/settings` | Add keyword/URL |
| GET | `/api/topics/pending` | Posts awaiting topic selection |
| POST | `/api/topics/{id}/select` | Select topic |
| GET | `/api/review/{id}` | Full review with SEO metrics |
| POST | `/api/review/{id}/approve` | Publish to ledger |
| POST | `/api/review/{id}/redo` | Regenerate with feedback |
| POST | `/api/discovery/trigger` | Manual discovery run |

## Brand Colors

- Primary Blue: `#252a61`
- Navy: `#1b1f4a` / `#0a0349`
- Red: `#c1262a`
- Orange: `#ff6002`
