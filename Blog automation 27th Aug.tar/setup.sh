#!/usr/bin/env bash
set -e

ROOT="$(cd "$(dirname "$0")" && pwd)"

echo "=== HyperPark Blog Automation Setup ==="

# Backend
cd "$ROOT/backend"
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
playwright install chromium 2>/dev/null || echo "Run 'playwright install chromium' manually if needed"
[ -f .env ] || cp .env.example .env
mkdir -p ../storage/blog_images ../storage/blogs/html ../storage/logs

# Frontend
cd "$ROOT/frontend"
npm install
[ -f .env.local ] || cp .env.local.example .env.local

echo ""
echo "Setup complete!"
echo "  1. Edit backend/.env with your API keys"
echo "  2. Start backend:  cd backend && source .venv/bin/activate && uvicorn app.main:app --reload"
echo "  3. Start frontend: cd frontend && npm run dev"
