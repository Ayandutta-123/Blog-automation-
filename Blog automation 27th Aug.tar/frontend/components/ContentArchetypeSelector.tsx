"use client";

import { useEffect, useState } from "react";
import { BookOpen, FileQuestion, Layers, List, Loader2, Newspaper } from "lucide-react";
import { cn } from "@/lib/cn";
import { api, ContentArchetypeId, ContentArchetypeInfo } from "@/lib/api";

const ICONS: Record<ContentArchetypeId, React.ElementType> = {
  quick_faq: FileQuestion,
  news_update: Newspaper,
  tutorial: BookOpen,
  listicle: List,
  pillar: Layers,
};

function formatWordRange(min: number, max: number) {
  return `${min.toLocaleString()}–${max.toLocaleString()} words`;
}

export default function ContentArchetypeSelector({
  compact = false,
  variant = "grid",
  value,
  onChange,
  productId,
}: {
  compact?: boolean;
  variant?: "grid" | "chips";
  value?: ContentArchetypeId;
  onChange?: (id: ContentArchetypeId) => void;
  productId?: number | null;
}) {
  const controlled = value !== undefined && onChange !== undefined;
  const [archetype, setArchetype] = useState<ContentArchetypeId>("tutorial");
  const [options, setOptions] = useState<ContentArchetypeInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const active = controlled ? value! : archetype;
  const isChips = variant === "chips" || (compact && variant !== "grid");
  const activeOption = options.find((opt) => opt.id === active);

  useEffect(() => {
    if (!productId) {
      setLoading(true);
      api
        .getContentArchetype()
        .then((r) => {
          setOptions(r.archetypes);
          if (!controlled) setArchetype(r.archetype);
        })
        .catch(console.error)
        .finally(() => setLoading(false));
      return;
    }

    setLoading(true);
    api
      .getProductContentArchetype(productId)
      .then((r) => {
        setOptions(r.archetypes);
        if (!controlled) setArchetype(r.archetype);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [controlled, productId]);

  async function select(next: ContentArchetypeId) {
    if (next === active || saving) return;
    if (controlled) {
      onChange!(next);
      return;
    }
    setSaving(true);
    try {
      const r = productId
        ? await api.setProductContentArchetype(productId, next)
        : await api.setContentArchetype(next);
      setArchetype(r.archetype);
    } catch (e) {
      alert(`Failed to save content archetype: ${e}`);
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-xs text-text-muted">
        <Loader2 className="h-3.5 w-3.5 animate-spin" />
        Loading content archetype...
      </div>
    );
  }

  if (isChips) {
    return (
      <div className="space-y-2">
        {activeOption && (
          <p className="text-xs text-text-secondary">
            Target for this product:{" "}
            <span className="font-semibold text-hyper-navy">
              {formatWordRange(activeOption.min_words, activeOption.max_words)}
            </span>
          </p>
        )}
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-thin">
          {options.map((opt) => {
            const Icon = ICONS[opt.id] || BookOpen;
            const isActive = active === opt.id;
            return (
              <button
                key={opt.id}
                type="button"
                onClick={() => select(opt.id)}
                disabled={saving}
                title={`${opt.intent} · ${formatWordRange(opt.min_words, opt.max_words)}`}
                className={cn(
                  "inline-flex shrink-0 flex-col items-start gap-0.5 rounded-xl border px-3.5 py-2.5 text-left transition-all duration-200 disabled:opacity-50 active:scale-[0.97]",
                  isActive
                    ? "border-hyper-navy bg-hyper-navy text-white shadow-nav-active"
                    : "border-hyper-border/80 bg-white/95 text-text-secondary shadow-soft hover:-translate-y-0.5 hover:border-hyper-primary/35 hover:text-hyper-navy hover:shadow-card"
                )}
              >
                <span className="inline-flex items-center gap-2 text-xs font-medium">
                  <Icon className="h-3.5 w-3.5" />
                  {opt.label}
                </span>
                <span
                  className={cn(
                    "pl-5 text-[10px] font-mono",
                    isActive ? "text-white/85" : "text-text-muted"
                  )}
                >
                  {formatWordRange(opt.min_words, opt.max_words)}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div className={compact ? "" : "rounded-xl border border-hyper-border bg-surface-0 p-4 shadow-card"}>
      {!compact && (
        <p className="mb-3 text-micro uppercase text-text-muted">
          Content Archetype
        </p>
      )}
      <div className={`grid gap-2 ${compact ? "grid-cols-1" : "sm:grid-cols-2"}`}>
        {options.map((opt) => {
          const Icon = ICONS[opt.id] || BookOpen;
          const isActive = active === opt.id;
          return (
            <button
              key={opt.id}
              type="button"
              onClick={() => select(opt.id)}
              disabled={saving}
              title={opt.intent}
              className={cn(
                "flex items-start gap-2 rounded-xl border px-3 py-2.5 text-left transition-all duration-150 disabled:opacity-50",
                isActive
                  ? "border-hyper-primary bg-hyper-primary/5 ring-1 ring-hyper-primary/20"
                  : "border-hyper-border hover:border-hyper-primary/30 hover:bg-surface-1"
              )}
            >
              <Icon
                className={cn(
                  "mt-0.5 h-4 w-4 shrink-0",
                  isActive ? "text-hyper-primary" : "text-text-muted"
                )}
              />
              <div className="min-w-0">
                <p
                  className={cn(
                    "text-xs font-semibold",
                    isActive ? "text-hyper-navy" : "text-text-secondary"
                  )}
                >
                  {opt.label}
                </p>
                <p className="text-xs text-text-muted">
                  {formatWordRange(opt.min_words, opt.max_words)}
                </p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
