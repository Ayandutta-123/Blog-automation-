"use client";

import {
  Activity,
  BarChart2,
  BarChart3,
  CircleDot,
  GitCompare,
  Layers,
  LayoutGrid,
  LineChart,
  Sparkles,
  Workflow,
} from "lucide-react";
import { cn } from "@/lib/cn";
import { ChartTypeId } from "@/lib/api";

export const CHART_TYPE_OPTIONS: {
  id: ChartTypeId;
  label: string;
  hint: string;
  Icon: React.ElementType;
}[] = [
  {
    id: "auto",
    label: "Auto (smart)",
    hint: "Pick from topic content",
    Icon: Sparkles,
  },
  {
    id: "bar",
    label: "Bar",
    hint: "Rising outcome bars",
    Icon: BarChart2,
  },
  {
    id: "line",
    label: "Line",
    hint: "Trend / trajectory",
    Icon: LineChart,
  },
  {
    id: "horizontal_bar",
    label: "Horizontal",
    hint: "Ranked priorities",
    Icon: BarChart3,
  },
  {
    id: "donut",
    label: "Donut",
    hint: "Share / mix",
    Icon: CircleDot,
  },
  {
    id: "area",
    label: "Area",
    hint: "Cumulative gains",
    Icon: Activity,
  },
  {
    id: "funnel",
    label: "Funnel",
    hint: "Stages / conversion",
    Icon: Layers,
  },
  {
    id: "comparison",
    label: "Compare",
    hint: "Before vs after",
    Icon: GitCompare,
  },
  {
    id: "stat_grid",
    label: "Stat cards",
    hint: "KPI grid only",
    Icon: LayoutGrid,
  },
  {
    id: "infographic",
    label: "Infographic",
    hint: "Process + stats",
    Icon: Workflow,
  },
];

export default function ChartTypeSelector({
  value = "auto",
  onChange,
  compact = false,
  disabled = false,
  label = "Chart / graphic type",
}: {
  value?: ChartTypeId;
  onChange?: (id: ChartTypeId) => void;
  compact?: boolean;
  disabled?: boolean;
  label?: string;
}) {
  return (
    <div className={cn("space-y-2", disabled && "opacity-60")}>
      {label ? (
        <p className="text-xs font-semibold text-hyper-navy">{label}</p>
      ) : null}
      <div
        className={cn(
          "flex gap-2 overflow-x-auto pb-1 scrollbar-thin",
          compact ? "flex-nowrap" : "flex-wrap"
        )}
      >
        {CHART_TYPE_OPTIONS.map((opt) => {
          const Icon = opt.Icon;
          const active = value === opt.id;
          return (
            <button
              key={opt.id}
              type="button"
              disabled={disabled || !onChange}
              title={opt.hint}
              onClick={() => onChange?.(opt.id)}
              className={cn(
                "inline-flex shrink-0 items-center gap-1.5 rounded-xl border px-2.5 py-2 text-left transition-all duration-200 disabled:cursor-not-allowed active:scale-[0.97]",
                active
                  ? "border-hyper-primary bg-hyper-primary text-white shadow-sm"
                  : "border-hyper-border bg-white text-text-secondary hover:border-hyper-primary/40 hover:text-hyper-navy"
              )}
            >
              <Icon className="h-3.5 w-3.5 shrink-0" />
              <span className="min-w-0">
                <span className="block text-[11px] font-semibold leading-tight">
                  {opt.label}
                </span>
                {!compact ? (
                  <span
                    className={cn(
                      "block text-[10px] leading-tight",
                      active ? "text-white/80" : "text-text-muted"
                    )}
                  >
                    {opt.hint}
                  </span>
                ) : null}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
