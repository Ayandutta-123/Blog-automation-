import { cn } from "@/lib/cn";
import { HTMLAttributes } from "react";

type BadgeVariant = "default" | "status" | "priority" | "count";

const base =
  "inline-flex items-center gap-1.5 rounded-full font-medium whitespace-nowrap";

const sizes = {
  sm: "px-2 py-0.5 text-xs",
  md: "px-2.5 py-0.5 text-xs",
};

export default function Badge({
  className,
  variant = "default",
  size = "sm",
  dot,
  children,
  ...props
}: HTMLAttributes<HTMLSpanElement> & {
  variant?: BadgeVariant;
  size?: "sm" | "md";
  dot?: boolean;
}) {
  return (
    <span
      className={cn(base, sizes[size], variant === "count" && "tabular-nums", className)}
      {...props}
    >
      {dot && (
        <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-current opacity-80" />
      )}
      {children}
    </span>
  );
}
