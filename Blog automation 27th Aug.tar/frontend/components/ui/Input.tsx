import { cn } from "@/lib/cn";
import { InputHTMLAttributes, TextareaHTMLAttributes, forwardRef } from "react";

export const Input = forwardRef<
  HTMLInputElement,
  InputHTMLAttributes<HTMLInputElement>
>(({ className, ...props }, ref) => (
  <input
    ref={ref}
    className={cn(
      "w-full min-h-11 rounded-xl border border-hyper-border/90 bg-white/90 px-3.5 py-2.5 text-base text-text-primary shadow-soft sm:min-h-0 sm:text-sm",
      "placeholder:text-text-muted transition-all duration-200",
      "hover:border-hyper-primary/25",
      "focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/15 focus:shadow-card",
      "disabled:cursor-not-allowed disabled:opacity-50",
      className
    )}
    {...props}
  />
));
Input.displayName = "Input";

export const Textarea = forwardRef<
  HTMLTextAreaElement,
  TextareaHTMLAttributes<HTMLTextAreaElement>
>(({ className, ...props }, ref) => (
  <textarea
    ref={ref}
    className={cn(
      "w-full min-h-11 rounded-xl border border-hyper-border/90 bg-white/90 px-3.5 py-2.5 text-base text-text-primary shadow-soft sm:min-h-0 sm:text-sm",
      "placeholder:text-text-muted transition-all duration-200",
      "hover:border-hyper-primary/25",
      "focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/15 focus:shadow-card",
      "disabled:cursor-not-allowed disabled:opacity-50",
      className
    )}
    {...props}
  />
));
Textarea.displayName = "Textarea";
