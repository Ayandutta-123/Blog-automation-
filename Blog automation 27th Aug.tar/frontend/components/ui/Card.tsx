import { cn } from "@/lib/cn";
import { HTMLAttributes } from "react";

type CardVariant = "elevated" | "flat" | "interactive";

const variants: Record<CardVariant, string> = {
  elevated:
    "bg-white/95 border border-hyper-border/80 shadow-card backdrop-blur-sm",
  flat: "bg-white/90 border border-hyper-border/80 shadow-soft",
  interactive:
    "bg-white/95 border border-hyper-border/80 shadow-soft transition-all duration-200 ease-out hover:-translate-y-1 hover:border-hyper-primary/25 hover:shadow-elevated",
};

export function Card({
  className,
  variant = "flat",
  ...props
}: HTMLAttributes<HTMLDivElement> & { variant?: CardVariant }) {
  return (
    <div
      className={cn("rounded-2xl", variants[variant], className)}
      {...props}
    />
  );
}

export function CardHeader({
  className,
  ...props
}: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("border-b border-hyper-border/70 px-5 py-4", className)}
      {...props}
    />
  );
}

export function CardBody({
  className,
  ...props
}: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("p-5", className)} {...props} />;
}
