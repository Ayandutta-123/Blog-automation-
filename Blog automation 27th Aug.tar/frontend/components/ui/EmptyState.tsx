import { cn } from "@/lib/cn";
import { LucideIcon } from "lucide-react";

export default function EmptyState({
  icon: Icon,
  title,
  description,
  action,
  className,
}: {
  icon: LucideIcon;
  title: string;
  description?: string;
  action?: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center px-4 py-10 text-center",
        className
      )}
    >
      <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-surface-1 to-surface-2 text-text-muted shadow-soft ring-1 ring-hyper-border/60">
        <Icon className="h-6 w-6" />
      </div>
      <p className="text-sm font-bold tracking-tight text-hyper-navy">{title}</p>
      {description && (
        <p className="mt-1 max-w-[220px] text-xs leading-relaxed text-text-secondary">
          {description}
        </p>
      )}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}
