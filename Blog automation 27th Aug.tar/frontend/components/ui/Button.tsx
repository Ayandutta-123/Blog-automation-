"use client";

import { Loader2 } from "lucide-react";
import { cn } from "@/lib/cn";
import { ButtonHTMLAttributes, forwardRef } from "react";

type Variant = "primary" | "secondary" | "ghost" | "danger" | "orange" | "outline";
type Size = "sm" | "md" | "lg";

const variants: Record<Variant, string> = {
  primary:
    "bg-hyper-navy text-white shadow-[0_1px_2px_rgba(15,23,42,0.18)] hover:bg-[#14183a] hover:shadow-[0_6px_16px_-8px_rgba(27,31,74,0.55)] focus-visible:ring-hyper-primary/30 active:scale-[0.98]",
  secondary:
    "border border-slate-200 bg-white text-slate-700 shadow-[0_1px_2px_rgba(15,23,42,0.04)] hover:border-slate-300 hover:bg-slate-50 hover:text-hyper-navy focus-visible:ring-hyper-primary/20 active:scale-[0.98]",
  ghost:
    "text-slate-600 hover:bg-slate-100 hover:text-hyper-navy focus-visible:ring-hyper-primary/20 active:scale-[0.98]",
  danger:
    "border border-red-200 bg-white text-hyper-red hover:border-red-300 hover:bg-red-50 focus-visible:ring-red-200 active:scale-[0.98]",
  orange:
    "bg-hyper-orange text-white shadow-[0_1px_2px_rgba(255,96,2,0.28)] hover:bg-[#e65600] hover:shadow-[0_8px_18px_-10px_rgba(255,96,2,0.7)] focus-visible:ring-hyper-orange/35 active:scale-[0.98]",
  outline:
    "border border-slate-200 bg-white text-hyper-navy hover:border-hyper-navy/25 hover:bg-slate-50 focus-visible:ring-hyper-primary/20 active:scale-[0.98]",
};

const sizes: Record<Size, string> = {
  sm: "h-10 px-3.5 text-[13px] gap-1.5 rounded-lg sm:h-9 sm:px-3",
  md: "h-11 px-4 text-sm gap-1.5 rounded-lg sm:h-10 sm:px-3.5",
  lg: "h-12 px-5 text-sm gap-2 rounded-xl font-semibold sm:h-11",
};

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
}

const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      className,
      variant = "primary",
      size = "md",
      loading,
      disabled,
      children,
      ...props
    },
    ref
  ) => (
    <button
      ref={ref}
      disabled={disabled || loading}
      className={cn(
        "relative inline-flex items-center justify-center font-medium tracking-[-0.01em]",
        "transition-[background-color,box-shadow,border-color,transform,color] duration-150 ease-out",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-white",
        "disabled:pointer-events-none disabled:opacity-40",
        variants[variant],
        sizes[size],
        loading && "animate-work-pulse",
        className
      )}
      {...props}
    >
      {loading && <Loader2 className="h-4 w-4 animate-spin" />}
      {children}
    </button>
  )
);

Button.displayName = "Button";
export default Button;
