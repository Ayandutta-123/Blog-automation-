import { cn } from "@/lib/cn";

export function Skeleton({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "animate-pulse rounded-lg bg-surface-2",
        className
      )}
    />
  );
}

export function TaskCardSkeleton() {
  return (
    <div className="rounded-xl border border-hyper-border bg-surface-0 p-3">
      <Skeleton className="mb-3 h-28 w-full rounded-lg" />
      <Skeleton className="mb-2 h-4 w-4/5" />
      <Skeleton className="mb-3 h-4 w-3/5" />
      <div className="flex gap-2">
        <Skeleton className="h-5 w-14 rounded-full" />
        <Skeleton className="h-5 w-16 rounded-full" />
      </div>
    </div>
  );
}
