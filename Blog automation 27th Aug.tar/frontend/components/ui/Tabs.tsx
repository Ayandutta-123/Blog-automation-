"use client";

import { cn } from "@/lib/cn";

export function TabList({
  className,
  children,
}: {
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <div
      role="tablist"
      className={cn(
        "flex w-full max-w-full gap-1 overflow-x-auto rounded-2xl border border-hyper-border/80 bg-surface-2/80 p-1.5 shadow-soft backdrop-blur-sm [-webkit-overflow-scrolling:touch] sm:inline-flex sm:w-auto sm:overflow-visible",
        className
      )}
    >
      {children}
    </div>
  );
}

export function Tab({
  active,
  onClick,
  icon: Icon,
  label,
  id,
  description,
  variant = "default",
}: {
  active: boolean;
  onClick: () => void;
  icon?: React.ElementType;
  label: string;
  id: string;
  description?: string;
  variant?: "default" | "settings";
}) {
  if (variant === "settings") {
    return (
      <button
        type="button"
        role="tab"
        id={id}
        aria-selected={active}
        onClick={onClick}
        className={cn(
          "group relative flex min-w-0 flex-1 items-start gap-2.5 rounded-xl px-2.5 py-2.5 text-left",
          "transition-[background-color,box-shadow,transform,color] duration-200 ease-out",
          "sm:min-w-[140px] sm:flex-none sm:gap-3 sm:px-3 sm:py-2.5 lg:min-w-0 lg:w-full",
          active
            ? "bg-white text-hyper-navy shadow-[0_4px_14px_-8px_rgba(27,31,74,0.35)] ring-1 ring-slate-200/90"
            : "text-slate-600 hover:bg-white/80 hover:text-hyper-navy hover:shadow-[0_2px_8px_-6px_rgba(27,31,74,0.2)]"
        )}
      >
        {active && (
          <span className="absolute left-0 top-1/2 hidden h-7 w-[3px] -translate-y-1/2 rounded-r-full bg-hyper-orange shadow-[0_0_8px_rgba(255,96,2,0.45)] lg:block" />
        )}
        {Icon && (
          <span
            className={cn(
              "mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg",
              "transition-[background-color,color,transform] duration-200 ease-out",
              active
                ? "scale-105 bg-hyper-orange/12 text-hyper-orange"
                : "bg-slate-100 text-slate-500 group-hover:scale-[1.02] group-hover:bg-slate-200/80 group-hover:text-hyper-navy"
            )}
          >
            <Icon className="h-4 w-4" />
          </span>
        )}
        <span className="min-w-0 flex-1">
          <span className="block text-[13px] font-semibold tracking-tight">{label}</span>
          {description && (
            <span
              className={cn(
                "mt-0.5 hidden text-[11px] leading-snug sm:block",
                active ? "text-slate-500" : "text-slate-400"
              )}
            >
              {description}
            </span>
          )}
        </span>
      </button>
    );
  }

  return (
    <button
      type="button"
      role="tab"
      id={id}
      aria-selected={active}
      onClick={onClick}
      className={cn(
        "inline-flex min-w-0 flex-1 items-center justify-center gap-1.5 rounded-xl px-2.5 py-2 text-xs font-semibold tracking-tight transition-all duration-200 sm:flex-none sm:px-4 sm:text-sm",
        active
          ? "bg-white text-hyper-navy shadow-soft ring-1 ring-black/[0.03]"
          : "text-text-secondary hover:bg-white/50 hover:text-hyper-navy"
      )}
    >
      {Icon && <Icon className="h-3.5 w-3.5 shrink-0 sm:h-4 sm:w-4" />}
      <span className="truncate">{label}</span>
    </button>
  );
}
