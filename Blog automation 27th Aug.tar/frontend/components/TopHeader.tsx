"use client";

import { Settings, Zap } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import NotificationBell from "./NotificationBell";

const breadcrumbs: Record<string, string> = {
  "/": "Board",
  "/report": "Report",
  "/inbox": "Inbox",
  "/ready": "Ready to use",
  "/settings": "Settings",
};

export default function TopHeader() {
  const pathname = usePathname();
  const pageLabel = breadcrumbs[pathname] || "Board";

  return (
    <>
      {/* Mobile: brand + page title */}
      <header className="sticky top-0 z-20 border-b border-hyper-border/70 bg-white/75 pt-[env(safe-area-inset-top)] backdrop-blur-xl md:hidden">
        <div className="flex h-12 items-center gap-2 px-3">
          <div className="flex min-w-0 flex-1 items-center gap-2">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-hyper-primary to-hyper-navy">
              <Zap className="h-4 w-4 text-hyper-orange" />
            </div>
            <div className="min-w-0">
              <p className="truncate text-xs font-bold text-hyper-navy">blog Automation</p>
              <p className="truncate text-[10px] uppercase tracking-[0.12em] text-text-muted">
                {pageLabel}
              </p>
            </div>
          </div>
          <NotificationBell align="end" />
        </div>
      </header>

      {/* Desktop: breadcrumbs + settings/bell on non-board pages */}
      {pathname !== "/" && (
        <header className="sticky top-0 z-20 hidden border-b border-hyper-border/70 bg-white/75 backdrop-blur-xl md:block">
          <div className="flex h-11 items-center justify-between gap-3 px-4 md:px-6">
            <p className="text-xs text-text-muted">
              <Link
                href="/"
                className="font-medium transition-colors hover:text-hyper-primary"
              >
                Board
              </Link>
              <span className="mx-1.5 text-text-muted/70">/</span>
              <span className="font-semibold text-hyper-navy">{pageLabel}</span>
            </p>
            <div className="flex items-center gap-0.5">
              <Link href="/settings" className="icon-btn" aria-label="Settings">
                <Settings className="h-4 w-4" />
              </Link>
              <NotificationBell align="end" />
            </div>
          </div>
        </header>
      )}
    </>
  );
}
