"use client";

import { Bell } from "lucide-react";
import { useEffect, useRef } from "react";
import { cn } from "@/lib/cn";
import { useNotifications } from "@/contexts/NotificationContext";

export default function NotificationBell({
  align: _align = "end",
}: {
  /** Kept for call-site compatibility; panel position uses the active anchor. */
  align?: "start" | "end";
}) {
  const { unreadCount, open, setOpen, registerAnchor, badgePulse } =
    useNotifications();
  const anchorRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    registerAnchor(anchorRef.current);
  }, [registerAnchor]);

  return (
    <div className="relative" ref={anchorRef}>
      <button
        type="button"
        aria-label="Notifications"
        aria-expanded={open}
        onClick={() => {
          registerAnchor(anchorRef.current);
          setOpen(!open);
        }}
        className={cn(
          "icon-btn relative",
          open && "bg-hyper-primary/[0.08] text-hyper-primary shadow-soft",
          badgePulse && "animate-bell-ring"
        )}
      >
        <Bell
          className={cn(
            "h-4 w-4 transition-transform",
            badgePulse && "text-hyper-orange"
          )}
        />
        {unreadCount > 0 && (
          <span
            className={cn(
              "absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-hyper-red px-1 text-[10px] font-bold text-white shadow-soft ring-2 ring-white",
              badgePulse ? "animate-work-pulse scale-110" : "animate-work-pulse"
            )}
          >
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>
    </div>
  );
}
