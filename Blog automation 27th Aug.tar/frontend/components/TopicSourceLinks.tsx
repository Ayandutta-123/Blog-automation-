"use client";

import { ExternalLink } from "lucide-react";
import type { TopicSourceLink } from "@/lib/topics";
import { cn } from "@/lib/cn";

const SOURCE_TYPE_LABELS: Record<string, string> = {
  tavily: "Industry search",
  competitor: "Competitor page",
  competitor_index: "Competitor page",
  rss: "RSS article",
  rss_feed: "RSS feed",
};

function sourceTypeLabel(type?: string): string {
  if (!type) return "Source";
  return SOURCE_TYPE_LABELS[type] || "Source";
}

export function TopicSourceLinks({
  links,
  compact,
}: {
  links?: TopicSourceLink[];
  compact?: boolean;
}) {
  // Exactly one genuine source per topic (backend enforces this)
  const link = links?.[0];
  if (!link?.url) return null;

  return (
    <div
      className={cn(
        "rounded-lg border-2 border-hyper-orange/35 bg-orange-50/90 ring-1 ring-hyper-orange/15",
        compact ? "px-2.5 py-2" : "px-3 py-2.5"
      )}
    >
      <p className="mb-1.5 text-[10px] font-bold uppercase tracking-wide text-hyper-orange">
        Source link
      </p>
      <a
        href={link.url}
        target="_blank"
        rel="noopener noreferrer"
        className="group flex items-start gap-1.5 text-[11px] leading-snug text-hyper-primary hover:text-hyper-orange"
        title={link.url}
      >
        <ExternalLink className="mt-0.5 h-3.5 w-3.5 shrink-0 text-hyper-orange opacity-90 group-hover:opacity-100" />
        <span className="min-w-0 flex-1">
          <span className="line-clamp-2 font-semibold text-hyper-navy underline decoration-hyper-orange/50 underline-offset-2 group-hover:text-hyper-orange group-hover:decoration-hyper-orange">
            {link.label || link.url}
          </span>
          <span className="mt-0.5 block break-all text-[10px] font-semibold text-hyper-primary/90">
            {sourceTypeLabel(link.source_type)} · {link.url}
          </span>
        </span>
      </a>
    </div>
  );
}
