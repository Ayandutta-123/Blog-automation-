"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import {
  CheckCircle2,
  ExternalLink,
  Link2,
  Loader2,
  Plug,
  Unplug,
} from "lucide-react";
import { api, UbersuggestStatus } from "@/lib/api";
import { useToast } from "@/contexts/ToastContext";
import { useNotifications } from "@/contexts/NotificationContext";
import { cn } from "@/lib/cn";

const DEFAULT_KEYWORD_TOOL = "keyword_suggestions";
const DEFAULT_BACKLINKS_TOOL = "backlinks_overview";

export default function UbersuggestPanel() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const toast = useToast();
  const { notifySaved } = useNotifications();

  const [status, setStatus] = useState<UbersuggestStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [connecting, setConnecting] = useState(false);
  const [disconnecting, setDisconnecting] = useState(false);
  const [savingMapping, setSavingMapping] = useState(false);

  const [keywordTool, setKeywordTool] = useState(DEFAULT_KEYWORD_TOOL);
  const [backlinksTool, setBacklinksTool] = useState(DEFAULT_BACKLINKS_TOOL);

  async function load() {
    try {
      const data = await api.getUbersuggestStatus();
      setStatus(data);
      setKeywordTool(data.keyword_tool || DEFAULT_KEYWORD_TOOL);
      setBacklinksTool(data.backlinks_tool || DEFAULT_BACKLINKS_TOOL);
      if (data.connected && (!data.keyword_tool || !data.backlinks_tool)) {
        try {
          const updated = await api.setUbersuggestMapping({
            keyword_tool: data.keyword_tool || DEFAULT_KEYWORD_TOOL,
            backlinks_tool: data.backlinks_tool || DEFAULT_BACKLINKS_TOOL,
          });
          setStatus(updated);
        } catch {
          /* ignore */
        }
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const flag = searchParams.get("ubersuggest");
    if (flag === "connected") {
      toast.success("Ubersuggest connected", "OAuth handshake completed successfully.");
      notifySaved(
        "Ubersuggest connected",
        "OAuth handshake completed successfully."
      );
      router.replace("/settings");
    } else if (flag === "error") {
      const message = searchParams.get("message") || "Connection failed";
      toast.error("Ubersuggest connection failed", message);
      router.replace("/settings");
    }
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleConnect() {
    setConnecting(true);
    try {
      const data = await api.connectUbersuggest();
      window.location.href = data.authorize_url;
    } catch (e) {
      toast.error("Could not start connection", String(e));
      setConnecting(false);
    }
  }

  async function handleDisconnect() {
    if (!confirm("Disconnect Ubersuggest? You'll need to log in again to reconnect.")) return;
    setDisconnecting(true);
    try {
      await api.disconnectUbersuggest();
      toast.success("Disconnected", "Ubersuggest access revoked locally.");
      await load();
    } catch (e) {
      toast.error("Failed to disconnect", String(e));
    } finally {
      setDisconnecting(false);
    }
  }

  async function handleSaveMapping() {
    setSavingMapping(true);
    try {
      const data = await api.setUbersuggestMapping({
        keyword_tool: keywordTool || null,
        backlinks_tool: backlinksTool || null,
      });
      setStatus(data);
      toast.success("Saved", "Ubersuggest tool preferences updated.");
      notifySaved("Ubersuggest saved", "Tool preferences updated.");
    } catch (e) {
      toast.error("Failed to save", String(e));
    } finally {
      setSavingMapping(false);
    }
  }

  const connected = status?.connected ?? false;

  return (
    <div className="settings-card">
      <div className="settings-accent-bar h-0.5" />
      <div className="settings-card-head">
        <p className="text-micro uppercase text-text-muted">SEO data</p>
        <h2 className="font-display text-h1 text-hyper-navy">Ubersuggest</h2>
        <p className="mt-1 max-w-2xl text-xs text-text-secondary">
          Connect once here. After discovery, each topic card shows an SEO score (volume,
          difficulty, competitor gap). Generation uses a keyword research pack when you select
          a topic.
        </p>
      </div>

      <div className="settings-card-body space-y-5">
        {loading ? (
          <p className="text-sm text-text-muted">Checking connection…</p>
        ) : (
          <>
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-hyper-border bg-surface-1/40 px-4 py-3">
              <div className="flex items-center gap-3">
                <span
                  className={cn(
                    "flex h-9 w-9 items-center justify-center rounded-lg",
                    connected ? "bg-emerald-100 text-emerald-700" : "bg-surface-2 text-text-muted"
                  )}
                >
                  {connected ? <CheckCircle2 className="h-4 w-4" /> : <Plug className="h-4 w-4" />}
                </span>
                <div>
                  <p className="text-sm font-semibold text-hyper-navy">
                    {connected ? "Connected" : "Not connected"}
                  </p>
                  <p className="text-xs text-text-muted">
                    {connected
                      ? "Ready for volume checks on Board topic cards."
                      : "Connect a paid Ubersuggest account to enable SEO lookups."}
                  </p>
                </div>
              </div>
              {connected ? (
                <button
                  type="button"
                  onClick={handleDisconnect}
                  disabled={disconnecting}
                  className="flex items-center gap-1.5 rounded-xl border border-hyper-border px-4 py-2 text-sm font-medium text-hyper-red hover:bg-red-50 disabled:opacity-50"
                >
                  {disconnecting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Unplug className="h-4 w-4" />}
                  Disconnect
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleConnect}
                  disabled={connecting}
                  className="flex items-center gap-1.5 rounded-xl bg-hyper-primary px-4 py-2 text-sm font-medium text-white hover:bg-hyper-navy disabled:cursor-not-allowed disabled:opacity-40"
                >
                  {connecting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Link2 className="h-4 w-4" />}
                  Connect Ubersuggest
                </button>
              )}
            </div>

            {connected && (
              <>
                <div className="rounded-xl border border-hyper-border p-4">
                  <p className="mb-1 text-sm font-medium text-hyper-navy">Defaults for automation</p>
                  <p className="mb-3 text-xs text-text-secondary">
                    Leave these unless you need a different Ubersuggest tool.
                  </p>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <div>
                      <label className="text-xs font-medium text-text-secondary">
                        Keyword research
                      </label>
                      <select
                        value={keywordTool}
                        onChange={(e) => setKeywordTool(e.target.value)}
                        className="mt-1 w-full rounded-xl border border-hyper-border px-3 py-2 text-sm focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/20"
                      >
                        <option value="keyword_suggestions">keyword_suggestions (best on free)</option>
                        <option value="keyword_overview">keyword_overview (3/day on free)</option>
                        <option value="keyword_metrics">keyword_metrics</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-xs font-medium text-text-secondary">Backlinks</label>
                      <select
                        value={backlinksTool}
                        onChange={(e) => setBacklinksTool(e.target.value)}
                        className="mt-1 w-full rounded-xl border border-hyper-border px-3 py-2 text-sm focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/20"
                      >
                        <option value="backlinks_overview">backlinks_overview (recommended)</option>
                        <option value="backlinks">backlinks</option>
                        <option value="linking_domains">linking_domains</option>
                      </select>
                    </div>
                  </div>
                  <div className="mt-3 flex justify-end">
                    <button
                      type="button"
                      onClick={handleSaveMapping}
                      disabled={savingMapping}
                      className="flex items-center gap-1.5 rounded-xl bg-hyper-primary px-4 py-2 text-sm font-medium text-white hover:bg-hyper-navy disabled:cursor-not-allowed disabled:opacity-40"
                    >
                      {savingMapping ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
                      Save
                    </button>
                  </div>
                </div>

                <Link
                  href="/settings/ubersuggest-tools"
                  className="inline-flex items-center gap-1.5 text-xs font-medium text-hyper-primary hover:underline"
                >
                  Browse all tools (advanced)
                  <ExternalLink className="h-3 w-3" />
                </Link>
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}
