import clsx from "clsx";
import Badge from "./ui/Badge";

const styles: Record<string, string> = {
  SCRAPING: "bg-[#eef1fb] text-hyper-primary",
  PENDING_TOPIC: "bg-[#fff4eb] text-[#c44d00]",
  GENERATING: "bg-[#fff4eb] text-hyper-orange",
  PENDING_REVIEW: "bg-[#eef1fb] text-hyper-navy",
  APPROVED: "bg-[#f2f0fa] text-hyper-primary",
  PUBLISHED: "bg-[#eef9f3] text-emerald-700",
  REJECTED: "bg-red-50 text-hyper-red",
};

const labels: Record<string, string> = {
  SCRAPING: "Discovering",
  PENDING_TOPIC: "Select Topic",
  GENERATING: "Generating",
  PENDING_REVIEW: "In Review",
  APPROVED: "Approved",
  PUBLISHED: "Published",
  REJECTED: "Rejected",
};

const pulsing: Record<string, boolean> = {
  SCRAPING: true,
  GENERATING: true,
};

export default function StatusBadge({
  status,
  size = "sm",
}: {
  status: string;
  size?: "sm" | "xs";
}) {
  const isPulsing = pulsing[status];

  return (
    <Badge
      dot={isPulsing}
      className={clsx(
        styles[status] || "bg-slate-100 text-slate-600",
        size === "xs" ? "text-xs" : "text-xs",
        isPulsing && "[&>span:first-child]:animate-pulse-dot"
      )}
    >
      {labels[status] || status}
    </Badge>
  );
}
