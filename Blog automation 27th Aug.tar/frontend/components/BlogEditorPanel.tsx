"use client";

import { useEffect, useRef, useState } from "react";
import { Image as ImageIcon, Pencil, Save, Sparkles, Upload } from "lucide-react";
import { api, BlogPostDetail, ReviewResponse } from "@/lib/api";
import Button from "./ui/Button";
import { Input, Textarea } from "./ui/Input";

export default function BlogEditorPanel({
  postId,
  post,
  imageVersion,
  onSaved,
  onImageUpdated,
}: {
  postId: number;
  post: BlogPostDetail;
  imageVersion: number;
  onSaved: (detail: ReviewResponse) => void;
  onImageUpdated?: (detail: ReviewResponse) => void;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [regenerating, setRegenerating] = useState(false);
  const [regeneratingPrompt, setRegeneratingPrompt] = useState(false);
  const [showPromptBox, setShowPromptBox] = useState(false);
  const [imagePrompt, setImagePrompt] = useState("");

  const [titleTag, setTitleTag] = useState(post.title_tag || "");
  const [metaDescription, setMetaDescription] = useState(post.meta_description || "");
  const [slug, setSlug] = useState(post.slug || "");
  const [topicTitle, setTopicTitle] = useState(post.selected_topic_title || "");
  const [bodyText, setBodyText] = useState(post.body_text || "");

  useEffect(() => {
    setBodyText(post.body_text || "");
  }, [post.body_text]);

  async function handleSave() {
    setSaving(true);
    try {
      const updated = await api.updateReviewPost(postId, {
        title_tag: titleTag,
        meta_description: metaDescription,
        slug,
        selected_topic_title: topicTitle,
        body_text: bodyText,
      });
      onSaved(updated);
    } catch (e) {
      alert(`Save failed: ${e}`);
    } finally {
      setSaving(false);
    }
  }

  async function handleUpload(file: File) {
    setUploading(true);
    try {
      const updated = await api.uploadHeroImage(postId, file);
      if (onImageUpdated) {
        onImageUpdated(updated);
      } else {
        onSaved(updated);
      }
    } catch (e) {
      alert(`Upload failed: ${e}`);
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  async function applyRegeneratedImage() {
    const updated = await api.getReviewPost(postId);
    if (onImageUpdated) {
      onImageUpdated(updated);
    } else {
      onSaved(updated);
    }
  }

  async function handleRegenerate() {
    setRegenerating(true);
    try {
      await api.regenerateHeroImage(postId);
      await applyRegeneratedImage();
    } catch (e) {
      alert(`Regenerate failed: ${e}`);
    } finally {
      setRegenerating(false);
    }
  }

  async function handleRegenerateWithPrompt() {
    if (!imagePrompt.trim()) {
      alert("Enter an image prompt first.");
      return;
    }
    setRegeneratingPrompt(true);
    try {
      await api.regenerateHeroImage(postId, imagePrompt.trim());
      await applyRegeneratedImage();
      setShowPromptBox(false);
    } catch (e) {
      alert(`Regenerate with prompt failed: ${e}`);
    } finally {
      setRegeneratingPrompt(false);
    }
  }

  const busy = uploading || regenerating || regeneratingPrompt;

  return (
    <div className="space-y-6">
      <section className="rounded-xl border border-hyper-border bg-surface-0 p-4 shadow-sm">
        <h3 className="mb-3 text-micro uppercase text-text-muted">Hero Image</h3>
        {post.slug ? (
          <div className="mb-4 overflow-hidden rounded-xl border border-hyper-border">
            <img
              key={`hero-${imageVersion}`}
              src={api.imageUrl(post.slug, imageVersion)}
              alt="Hero preview"
              className="h-48 w-full object-cover"
            />
          </div>
        ) : (
          <div className="mb-4 flex h-32 items-center justify-center rounded-xl border border-dashed border-hyper-border text-slate-400">
            <ImageIcon className="mr-2 h-5 w-5" />
            Save a slug first to attach an image
          </div>
        )}
        <div className="flex flex-wrap gap-2">
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleUpload(f);
            }}
          />
          <Button
            variant="secondary"
            size="sm"
            onClick={() => fileRef.current?.click()}
            disabled={busy || !post.slug}
            loading={uploading}
          >
            {!uploading && <Upload className="h-4 w-4" />}
            Upload Image
          </Button>
          <Button
            variant="secondary"
            size="sm"
            onClick={handleRegenerate}
            disabled={busy || !post.slug}
            loading={regenerating}
          >
            {!regenerating && <Sparkles className="h-4 w-4" />}
            AI Regenerate
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowPromptBox((v) => !v)}
            disabled={busy || !post.slug}
          >
            <Pencil className="h-4 w-4" />
            AI with prompt
          </Button>
        </div>

        {showPromptBox && (
          <div className="mt-3 rounded-xl border border-hyper-border bg-surface-1 p-3">
            <p className="mb-2 text-xs font-medium text-text-secondary">
              Describe the hero image you want
            </p>
            <Textarea
              value={imagePrompt}
              onChange={(e) => setImagePrompt(e.target.value)}
              rows={3}
              placeholder="e.g. Aerial view of a modern parking garage at dusk, ANPR cameras visible, cinematic lighting…"
            />
            <div className="mt-2 flex flex-wrap gap-2">
              <Button
                variant="orange"
                size="sm"
                onClick={handleRegenerateWithPrompt}
                disabled={busy || !imagePrompt.trim()}
                loading={regeneratingPrompt}
              >
                {!regeneratingPrompt && <Sparkles className="h-4 w-4" />}
                Generate with prompt
              </Button>
              <Button
                variant="ghost"
                size="sm"
                disabled={busy}
                onClick={() => setShowPromptBox(false)}
              >
                Cancel
              </Button>
            </div>
          </div>
        )}

        <p className="mt-2 text-[11px] text-slate-400">
          Upload any JPG/PNG/WebP — auto-resized to 1200×630 WebP. AI Regenerate uses the topic;
          AI with prompt lets you describe a new image.
        </p>
      </section>

      <section className="rounded-xl border border-hyper-border bg-surface-0 p-4 shadow-sm">
        <h3 className="mb-3 text-micro uppercase text-text-muted">SEO & Metadata</h3>
        <div className="space-y-3">
          <Field label="Title tag" hint={`${titleTag.length}/60 chars`}>
            <Input value={titleTag} onChange={(e) => setTitleTag(e.target.value)} />
          </Field>
          <Field label="Meta description" hint={`${metaDescription.length}/160 chars`}>
            <Textarea
              value={metaDescription}
              onChange={(e) => setMetaDescription(e.target.value)}
              rows={2}
            />
          </Field>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="URL slug">
              <Input
                value={slug}
                onChange={(e) => setSlug(e.target.value)}
                className="font-mono"
              />
            </Field>
            <Field label="Topic title">
              <Input value={topicTitle} onChange={(e) => setTopicTitle(e.target.value)} />
            </Field>
          </div>
        </div>
      </section>

      <section className="rounded-xl border border-hyper-border bg-surface-0 p-4 shadow-sm">
        <h3 className="mb-3 text-micro uppercase text-text-muted">Article Text</h3>
        <Textarea
          value={bodyText}
          onChange={(e) => setBodyText(e.target.value)}
          rows={16}
          className="leading-relaxed"
        />
        <p className="mt-2 text-xs text-text-muted">
          Edit headings and paragraphs as plain text. Tables, charts, CTA, and links are preserved
          automatically.
        </p>
      </section>

      <div className="flex justify-end gap-2">
        <Button onClick={handleSave} disabled={saving} loading={saving}>
          {!saving && <Save className="h-4 w-4" />}
          Save Changes
        </Button>
      </div>
    </div>
  );
}

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <div className="mb-1 flex items-center justify-between">
        <span className="text-xs font-medium text-text-secondary">{label}</span>
        {hint && <span className="font-mono text-xs text-text-muted">{hint}</span>}
      </div>
      {children}
    </label>
  );
}
