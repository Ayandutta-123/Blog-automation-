"use client";

import { useEffect, useState, type CSSProperties } from "react";
import { createPortal } from "react-dom";
import { Download, ImageIcon, Loader2, RefreshCw, X } from "lucide-react";
import {
  api,
  BlogPostDetail,
  BlogPostSummary,
  Product,
} from "@/lib/api";
import { downloadPublishedHtml, downloadPublishedImage } from "@/lib/blogDownload";
import { preparePreviewHtml } from "@/lib/blogPreview";
import { brandPaletteCssVars } from "@/lib/blogProseCss";
import {
  DEFAULT_BRAND_PALETTE,
  normalizeBrandPalette,
} from "@/lib/brandPalette";
import { formatDateTime, getPostTitle } from "@/lib/status";
import Button from "@/components/ui/Button";
import { useToast } from "@/contexts/ToastContext";

/**
 * Full-page published blog reader — works for any product.
 * Used from Board Published cards and Ready to use.
 */
export default function PublishedBlogReader({
  postId,
  summary,
  onClose,
}: {
  postId: number;
  summary?: BlogPostSummary | null;
  onClose: () => void;
}) {
  const [mounted, setMounted] = useState(false);
  const [detail, setDetail] = useState<BlogPostDetail | null>(null);
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState<"html" | "image" | null>(null);
  const [republishing, setRepublishing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { success, error: toastError } = useToast();

  useEffect(() => {
    setMounted(true);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      setError(null);
      try {
        const res = await api.getReviewPost(postId);
        if (cancelled) return;
        setDetail(res.post);
        const products = await api.getProducts();
        if (cancelled) return;
        const match =
          (res.post.product_id != null
            ? products.find((p) => p.id === res.post.product_id)
            : null) || products[0] || null;
        setProduct(match);
      } catch (e) {
        if (!cancelled) {
          setError(e instanceof Error ? e.message : String(e));
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    void load();
    return () => {
      cancelled = true;
    };
  }, [postId]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const display = detail || summary;
  const when =
    (detail?.published_at ||
      summary?.published_at ||
      detail?.created_at ||
      summary?.created_at) ?? "";
  const serial = detail?.publish_serial ?? summary?.publish_serial;
  const productName = detail?.product_name || summary?.product_name || product?.name;
  const palette = normalizeBrandPalette(
    product?.brand_palette || DEFAULT_BRAND_PALETTE
  );
  const previewHtml =
    detail?.html_content && detail.slug
      ? preparePreviewHtml(detail.html_content, detail.slug, 0)
      : detail?.html_content || "";

  async function handleDownloadHtml() {
    if (!detail) return;
    setDownloading("html");
    try {
      await downloadPublishedHtml({
        post: detail,
        product,
        brandPalette: product?.brand_palette,
      });
    } catch (e) {
      alert(String(e));
    } finally {
      setDownloading(null);
    }
  }

  async function handleDownloadImage() {
    if (!detail?.slug) {
      alert("No hero image for this post.");
      return;
    }
    setDownloading("image");
    try {
      await downloadPublishedImage(detail.slug);
    } catch (e) {
      alert(String(e));
    } finally {
      setDownloading(null);
    }
  }

  async function handleRepublish() {
    if (republishing || !detail) return;
    const title = getPostTitle(detail);
    const ok = window.confirm(
      `Republish “${title}”?\n\nRe-uploads to every destination set for this product (MinIO and/or WordPress). If WP was deleted, Republish creates it again. Serial stays the same.`
    );
    if (!ok) return;
    setRepublishing(true);
    try {
      const res = await api.republishPost(detail.id);
      success("Republished", res.message || "Blog was pushed live again.");
    } catch (err) {
      const msg = String(err);
      if (/override_allowed|word count/i.test(msg)) {
        const force = window.confirm(
          `${msg}\n\nForce republish with word-count override?`
        );
        if (force) {
          try {
            const res = await api.republishPost(detail.id, {
              override_word_count: true,
            });
            success("Republished", res.message || "Blog was pushed live again.");
            return;
          } catch (err2) {
            toastError("Republish failed", String(err2));
            return;
          }
        }
      }
      toastError("Republish failed", msg);
    } finally {
      setRepublishing(false);
    }
  }

  if (!mounted) return null;

  return createPortal(
    <div
      className="fixed inset-0 z-[120] flex flex-col bg-white"
      role="dialog"
      aria-modal="true"
      aria-label="Published blog — full page"
    >
      <div className="settings-accent-bar h-1 shrink-0" />
      <header className="relative z-[130] flex shrink-0 flex-col gap-3 border-b border-hyper-border/80 bg-white px-4 py-3 sm:flex-row sm:items-start sm:justify-between sm:px-6 sm:py-4">
        <div className="min-w-0 flex-1 pr-0 sm:pr-4">
          <p className="text-[11px] font-bold uppercase tracking-wide text-emerald-700">
            Published
            {serial != null ? ` · Serial #${serial}` : ""}
            {productName ? ` · ${productName}` : ""}
          </p>
          <h1 className="mt-1 line-clamp-2 font-display text-lg font-bold tracking-tight text-hyper-navy sm:text-xl md:text-2xl">
            {display ? getPostTitle(display) : "Loading…"}
          </h1>
          {when && (
            <p className="mt-1 text-xs font-medium text-slate-600 sm:text-sm">
              {formatDateTime(when)}
              {detail?.reading_time || summary?.reading_time
                ? ` · ${detail?.reading_time || summary?.reading_time}`
                : ""}
            </p>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-2 pr-0 sm:pr-0">
          <Button
            variant="orange"
            size="sm"
            onClick={handleRepublish}
            disabled={loading || !detail?.html_content || !detail?.slug || republishing || !!downloading}
            loading={republishing}
            className="min-h-10 sm:min-h-0"
            title="Re-upload if deleted from MinIO or WordPress"
          >
            <RefreshCw className="h-4 w-4" />
            <span className="sm:hidden">Republish</span>
            <span className="hidden sm:inline">Republish</span>
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleDownloadHtml}
            disabled={loading || !detail?.html_content || downloading === "html" || republishing}
            loading={downloading === "html"}
            className="min-h-10 sm:min-h-0"
          >
            <Download className="h-4 w-4" />
            <span className="sm:hidden">HTML</span>
            <span className="hidden sm:inline">Download HTML</span>
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleDownloadImage}
            disabled={loading || !detail?.slug || downloading === "image" || republishing}
            loading={downloading === "image"}
            className="min-h-10 sm:min-h-0"
          >
            <ImageIcon className="h-4 w-4" />
            <span className="sm:hidden">Image</span>
            <span className="hidden sm:inline">Download image</span>
          </Button>
          <button
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onClose();
            }}
            className="ml-auto inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-hyper-border bg-white text-slate-700 shadow-soft hover:bg-slate-50 hover:text-hyper-navy sm:ml-0 sm:h-9 sm:w-9"
            aria-label="Close full page"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </header>

      <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain bg-surface-1/40">
        {loading ? (
          <div className="flex items-center justify-center gap-2 py-28 text-sm font-medium text-slate-600">
            <Loader2 className="h-5 w-5 animate-spin text-hyper-orange" />
            Loading full blog…
          </div>
        ) : error ? (
          <p className="px-6 py-28 text-center text-sm font-medium text-hyper-red">
            {error}
          </p>
        ) : detail?.html_content ? (
          <div className="mx-auto w-full max-w-[80rem] px-4 py-6 sm:px-8 sm:py-10 lg:px-12">
            <article
              className="prose-blog prose-blog-reading w-full max-w-none rounded-2xl border border-hyper-border/60 bg-white px-4 py-6 shadow-soft sm:px-8 sm:py-10 lg:px-12"
              style={brandPaletteCssVars(palette) as CSSProperties}
              dangerouslySetInnerHTML={{ __html: previewHtml }}
            />
          </div>
        ) : (
          <p className="py-28 text-center text-sm font-medium text-slate-600">
            No HTML content found for this post.
          </p>
        )}
      </div>
    </div>,
    document.body
  );
}
