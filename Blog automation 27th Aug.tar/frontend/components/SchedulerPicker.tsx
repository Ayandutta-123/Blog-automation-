"use client";

import { useMemo, useState } from "react";
import { Calendar, Clock, Globe, Plus, Trash2 } from "lucide-react";
import { cn } from "@/lib/cn";
import Button from "@/components/ui/Button";

const WEEKDAYS = [
  { id: "mon", label: "Mon", full: "Monday" },
  { id: "tue", label: "Tue", full: "Tuesday" },
  { id: "wed", label: "Wed", full: "Wednesday" },
  { id: "thu", label: "Thu", full: "Thursday" },
  { id: "fri", label: "Fri", full: "Friday" },
  { id: "sat", label: "Sat", full: "Saturday" },
  { id: "sun", label: "Sun", full: "Sunday" },
];

export const TIMEZONE_OPTIONS = [
  { value: "Asia/Kolkata", label: "IST — Asia/Kolkata (UTC+5:30)" },
  { value: "UTC", label: "UTC" },
  { value: "Asia/Dubai", label: "GST — Asia/Dubai (UTC+4)" },
  { value: "Asia/Singapore", label: "SGT — Asia/Singapore (UTC+8)" },
  { value: "Europe/London", label: "London — Europe/London" },
  { value: "Europe/Berlin", label: "Berlin — Europe/Berlin" },
  { value: "America/New_York", label: "Eastern — America/New_York" },
  { value: "America/Chicago", label: "Central — America/Chicago" },
  { value: "America/Los_Angeles", label: "Pacific — America/Los_Angeles" },
  { value: "Australia/Sydney", label: "Sydney — Australia/Sydney" },
];

export type ScheduleSlot = {
  id: string;
  day_of_week: string;
  hour: number;
  minute: number;
};

export type ScheduleValues = {
  discovery_schedules: ScheduleSlot[];
  cron_timezone: string;
  schedule_enabled: boolean;
  // legacy mirrors (kept in sync with first slot)
  cron_day_of_week: string;
  cron_hour: number;
  cron_minute: number;
};

function newSlotId() {
  return `s-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
}

function formatTime(hour: number, minute: number) {
  const period = hour >= 12 ? "PM" : "AM";
  const h12 = hour % 12 === 0 ? 12 : hour % 12;
  return `${String(h12).padStart(2, "0")}:${String(minute).padStart(2, "0")} ${period}`;
}

function dayLabel(id: string) {
  return WEEKDAYS.find((d) => d.id === id)?.full || id;
}

export default function SchedulerPicker({
  values,
  productName,
  onChange,
}: {
  values: ScheduleValues;
  productName?: string;
  onChange: (patch: Partial<ScheduleValues>) => void;
}) {
  const slots = values.discovery_schedules?.length
    ? values.discovery_schedules
    : [
        {
          id: "default",
          day_of_week: values.cron_day_of_week || "mon",
          hour: values.cron_hour ?? 9,
          minute: values.cron_minute ?? 0,
        },
      ];

  const [activeId, setActiveId] = useState(slots[0]?.id || "default");
  const active = slots.find((s) => s.id === activeId) || slots[0];

  const timezoneLabel = useMemo(() => {
    return (
      TIMEZONE_OPTIONS.find((z) => z.value === values.cron_timezone)?.label ||
      values.cron_timezone
    );
  }, [values.cron_timezone]);

  function emitSlots(next: ScheduleSlot[]) {
    const first = next[0];
    onChange({
      discovery_schedules: next,
      cron_day_of_week: first?.day_of_week || "mon",
      cron_hour: first?.hour ?? 9,
      cron_minute: first?.minute ?? 0,
    });
  }

  function updateActive(patch: Partial<ScheduleSlot>) {
    if (!active) return;
    const next = slots.map((s) => (s.id === active.id ? { ...s, ...patch } : s));
    emitSlots(next);
  }

  function addSlot() {
    const slot: ScheduleSlot = {
      id: newSlotId(),
      day_of_week: "wed",
      hour: 14,
      minute: 0,
    };
    const next = [...slots, slot].slice(0, 14);
    emitSlots(next);
    setActiveId(slot.id);
  }

  function removeSlot(id: string) {
    if (slots.length <= 1) return;
    const next = slots.filter((s) => s.id !== id);
    emitSlots(next);
    if (activeId === id) setActiveId(next[0].id);
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-sm text-text-secondary">
          <Globe className="h-4 w-4 text-hyper-primary" />
          <label className="sr-only" htmlFor="schedule-timezone">
            Time zone
          </label>
          <select
            id="schedule-timezone"
            value={values.cron_timezone}
            onChange={(e) => onChange({ cron_timezone: e.target.value })}
            className="rounded-lg border border-hyper-border bg-surface-0 px-3 py-2 text-sm font-medium text-hyper-navy focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/20"
          >
            {TIMEZONE_OPTIONS.map((z) => (
              <option key={z.value} value={z.value}>
                {z.label}
              </option>
            ))}
            {!TIMEZONE_OPTIONS.some((z) => z.value === values.cron_timezone) && (
              <option value={values.cron_timezone}>{values.cron_timezone}</option>
            )}
          </select>
        </div>
        <label className="inline-flex cursor-pointer items-center gap-2 text-sm font-medium text-hyper-navy">
          <input
            type="checkbox"
            checked={values.schedule_enabled}
            onChange={(e) => onChange({ schedule_enabled: e.target.checked })}
            className="h-4 w-4 rounded border-hyper-border text-hyper-primary focus:ring-hyper-primary"
          />
          Auto-run enabled
        </label>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_1.1fr]">
        <div className="rounded-xl border border-hyper-border bg-surface-0 p-4">
          <div className="mb-3 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-hyper-primary" />
              <p className="text-sm font-semibold text-hyper-navy">Schedule slots</p>
            </div>
            <Button type="button" size="sm" variant="outline" onClick={addSlot}>
              <Plus className="h-3.5 w-3.5" />
              Add day/time
            </Button>
          </div>
          <ul className="space-y-2">
            {slots.map((slot) => {
              const selected = slot.id === active?.id;
              return (
                <li key={slot.id}>
                  <div
                    className={cn(
                      "flex items-center gap-2 rounded-xl border px-3 py-2 transition",
                      selected
                        ? "border-hyper-primary bg-hyper-primary/5"
                        : "border-hyper-border hover:border-hyper-primary/30"
                    )}
                  >
                    <button
                      type="button"
                      className="min-w-0 flex-1 text-left"
                      onClick={() => setActiveId(slot.id)}
                    >
                      <p className="text-sm font-semibold text-hyper-navy">
                        {dayLabel(slot.day_of_week)}
                      </p>
                      <p className="font-mono text-xs text-text-muted">
                        {formatTime(slot.hour, slot.minute)}
                      </p>
                    </button>
                    <button
                      type="button"
                      disabled={slots.length <= 1}
                      onClick={() => removeSlot(slot.id)}
                      className="rounded-lg p-1.5 text-text-muted hover:bg-red-50 hover:text-hyper-red disabled:opacity-40"
                      aria-label="Remove schedule"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>

        {active && (
          <div className="rounded-xl border border-hyper-border bg-surface-0 p-4">
            <div className="mb-3 flex items-center gap-2">
              <Clock className="h-4 w-4 text-hyper-primary" />
              <p className="text-sm font-semibold text-hyper-navy">Edit selected slot</p>
            </div>
            <p className="mb-3 text-xs text-text-muted">
              Every week on{" "}
              <span className="font-semibold text-hyper-navy">
                {dayLabel(active.day_of_week)}
              </span>{" "}
              at{" "}
              <span className="font-semibold text-hyper-navy">
                {formatTime(active.hour, active.minute)}
              </span>
            </p>
            <div className="mb-4 flex flex-wrap gap-1.5">
              {WEEKDAYS.map((d) => (
                <button
                  key={d.id}
                  type="button"
                  onClick={() => updateActive({ day_of_week: d.id })}
                  className={cn(
                    "flex h-9 w-9 items-center justify-center rounded-full text-xs font-semibold transition",
                    active.day_of_week === d.id
                      ? "bg-hyper-navy text-white"
                      : "bg-surface-1 text-text-secondary hover:bg-hyper-primary/10 hover:text-hyper-primary"
                  )}
                >
                  {d.label[0]}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <label className="text-xs font-medium text-text-muted">
                Hour (0–23)
                <input
                  type="number"
                  min={0}
                  max={23}
                  value={active.hour}
                  onChange={(e) =>
                    updateActive({
                      hour: Math.max(0, Math.min(23, Number(e.target.value) || 0)),
                    })
                  }
                  className="mt-1 w-full rounded-lg border border-hyper-border px-3 py-2 text-sm text-hyper-navy"
                />
              </label>
              <label className="text-xs font-medium text-text-muted">
                Minute (0–59)
                <input
                  type="number"
                  min={0}
                  max={59}
                  step={5}
                  value={active.minute}
                  onChange={(e) =>
                    updateActive({
                      minute: Math.max(0, Math.min(59, Number(e.target.value) || 0)),
                    })
                  }
                  className="mt-1 w-full rounded-lg border border-hyper-border px-3 py-2 text-sm text-hyper-navy"
                />
              </label>
            </div>
          </div>
        )}
      </div>

      <div className="rounded-xl border border-dashed border-hyper-border bg-surface-1/60 px-4 py-3 text-sm">
        <p className="font-semibold text-hyper-navy">
          {slots.length} weekly run{slots.length === 1 ? "" : "s"} · {timezoneLabel}
        </p>
        <p className="mt-1 text-xs text-text-muted">
          {slots
            .map((s) => `${dayLabel(s.day_of_week)} ${formatTime(s.hour, s.minute)}`)
            .join(" · ")}
          {productName ? ` · ${productName}` : ""}
        </p>
        <p className="mt-2 text-xs text-hyper-orange">
          Save this product to register the cron job(s) on the server.
        </p>
      </div>
    </div>
  );
}
