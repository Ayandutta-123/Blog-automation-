"use client";

import { TrendingUp } from "lucide-react";
import type { BlogTopic } from "@/lib/topics";
import { cn } from "@/lib/cn";

function formatVolume(n: number | null | undefined): string {
  if (n == null || n <= 0) return "—";
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(n >= 10_000 ? 0 : 1)}K`;
  return n.toLocaleString();
}

function recommendationLabel(rec?: string | null): string {
  switch (rec) {
    case "strong_pick":
      return "Strong pick";
    case "good":
      return "Good";
    case "moderate":
      return "Moderate";
    case "weak":
      return "Weak";
    default:
      return "Scored";
  }
}

function recommendationClass(rec?: string | null): string {
  switch (rec) {
    case "strong_pick":
      return "bg-emerald-600 text-white";
    case "good":
      return "bg-sky-600 text-white";
    case "moderate":
      return "bg-amber-500 text-white";
    case "weak":
      return "bg-slate-400 text-white";
    default:
      return "bg-hyper-primary/15 text-hyper-navy";
  }
}

export function TopicSeoScoreBadge({
  topic,
  compact,
}: {
  topic: BlogTopic;
  compact?: boolean;
}) {
  const score = topic.seo_score;
  if (score == null) return null;

  const signals = topic.seo_signals;
  const volume = signals?.search_volume;
  const difficulty = signals?.seo_difficulty;

  return (
    <div
      className={cn(
        "rounded-xl border border-hyper-primary/20 bg-gradient-to-br from-hyper-primary/8 to-surface-0",
        compact ? "px-2.5 py-2" : "px-3 py-2.5"
      )}
    >
      <div className="flex flex-wrap items-center gap-2">
        <span
          className={cn(
            "inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[10px] font-bold tabular-nums",
            recommendationClass(topic.recommendation)
          )}
        >
          <TrendingUp className="h-3 w-3" />
          SEO {Math.round(score)}
        </span>
        <span className="text-[10px] font-medium text-text-muted">
          {recommendationLabel(topic.recommendation)}
        </span>
        {topic.recommended ? (
          <span className="rounded-md bg-hyper-orange/15 px-1.5 py-0.5 text-[10px] font-semibold text-hyper-orange">
            Recommended
          </span>
        ) : null}
      </div>
      <div className="mt-2 grid grid-cols-3 gap-1.5 text-center">
        <div>
          <p className="text-[9px] uppercase text-text-muted">Volume</p>
          <p className="text-[11px] font-semibold tabular-nums text-hyper-navy">
            {formatVolume(volume)}
          </p>
        </div>
        <div>
          <p className="text-[9px] uppercase text-text-muted">Difficulty</p>
          <p className="text-[11px] font-semibold tabular-nums text-hyper-navy">
            {difficulty != null ? Math.round(difficulty) : "—"}
          </p>
        </div>
        <div>
          <p className="text-[9px] uppercase text-text-muted">Competitors</p>
          <p className="text-[11px] font-semibold tabular-nums text-hyper-navy">
            {signals?.competitor_matches ?? "—"}
          </p>
        </div>
      </div>
      {!compact && topic.seo_why && topic.seo_why.length > 0 ? (
        <ul className="mt-2 space-y-0.5 border-t border-hyper-border/60 pt-2">
          {topic.seo_why.slice(0, 2).map((line) => (
            <li key={line} className="text-[10px] leading-snug text-text-secondary">
              • {line}
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}
