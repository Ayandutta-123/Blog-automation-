"use client";

import { MessageSquare, Paperclip, RefreshCw } from "lucide-react";
import { BlogPostSummary, api } from "@/lib/api";
import { formatDate, getPostTitle, getPriority } from "@/lib/status";
import { cn } from "@/lib/cn";
import StatusBadge from "./StatusBadge";
import Badge from "./ui/Badge";
import Button from "./ui/Button";

export default function TaskCard({
  post,
  onClick,
  onRetry,
}: {
  post: BlogPostSummary;
  onClick: () => void;
  onRetry?: () => void;
}) {
  const priority = getPriority(post.status);
  const hasImage = !!post.slug;
  const isDiscovering = post.status === "SCRAPING" && !post.last_error;
  const isGenerating = post.status === "GENERATING" && !post.last_error;
  const isFailed =
    post.status === "REJECTED" ||
    (!!post.last_error &&
      (post.status === "SCRAPING" || post.status === "GENERATING"));
  const comments = post.comment_count ?? 0;
  const retryLabel =
    post.status === "GENERATING" ? "Retry generation" : "Retry discovery";

  return (
    <div
      className={cn(
        "group w-full overflow-hidden rounded-2xl border bg-white/95 text-left shadow-soft transition-all duration-200 ease-out",
        "hover:-translate-y-1 hover:border-hyper-primary/25 hover:shadow-elevated",
        isFailed
          ? "border-l-[3px] border-l-hyper-red border-hyper-border/80"
          : "border-hyper-border/80",
        (isDiscovering || isGenerating) && "animate-work-pulse"
      )}
    >
      <button type="button" onClick={onClick} className="w-full p-3 text-left">
        {hasImage && (
          <div className="relative mb-3 overflow-hidden rounded-xl bg-hyper-navy/5 ring-1 ring-black/[0.03]">
            <img
              src={api.imageUrl(post.slug!)}
              alt=""
              className="aspect-video w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = "none";
              }}
            />
            <div className="pointer-events-none absolute inset-x-0 bottom-0 h-14 bg-gradient-to-t from-hyper-navy/45 to-transparent" />
          </div>
        )}

        <h3 className="mb-2 line-clamp-2 text-h3 leading-snug tracking-tight text-hyper-navy">
          {getPostTitle(post)}
        </h3>

        <div className="mb-3 flex flex-wrap gap-1.5">
          <Badge className={cn(priority.color, "text-xs")}>
            {priority.label}
          </Badge>
          <StatusBadge status={post.status} size="xs" />
          {isDiscovering && (
            <Badge className="bg-[#eef1fb] text-hyper-primary text-xs" dot>
              Running
            </Badge>
          )}
          {isGenerating && (
            <Badge className="bg-[#fff4eb] text-hyper-orange text-xs" dot>
              Writing
            </Badge>
          )}
        </div>

        {post.topics_count ? (
          <p className="mb-2 text-xs text-text-secondary">
            {post.topics_count} topic{post.topics_count > 1 ? "s" : ""} found
          </p>
        ) : null}

        {post.product_name && (
          <p className="mb-2 text-xs font-semibold text-hyper-primary">
            {post.product_name}
          </p>
        )}

        {isFailed && post.last_error && (
          <p className="mb-2 line-clamp-2 text-xs text-hyper-red">
            {post.last_error}
          </p>
        )}

        {isFailed && (
          <Badge className="mb-2 bg-red-50 text-hyper-red text-xs">Needs retry</Badge>
        )}

        <div className="flex items-center justify-between text-xs text-text-muted">
          <span className="font-mono">{formatDate(post.created_at)}</span>
          <div className="flex items-center gap-2.5">
            <span className="flex items-center gap-0.5">
              <MessageSquare className="h-3 w-3" />
              {comments}
            </span>
            {hasImage && (
              <span className="flex items-center gap-0.5">
                <Paperclip className="h-3 w-3" />1
              </span>
            )}
          </div>
        </div>

        <div className="mt-2.5 flex items-center justify-between">
          <div className="flex h-6 w-6 items-center justify-center rounded-lg bg-gradient-to-br from-hyper-primary to-hyper-navy text-[10px] font-bold text-white shadow-soft">
            HP
          </div>
        </div>
      </button>

      {onRetry && (
        <div className="border-t border-hyper-border/70 px-3 py-2">
          <Button
            variant="ghost"
            size="sm"
            className="h-8 w-full"
            onClick={(e) => {
              e.stopPropagation();
              onRetry();
            }}
          >
            <RefreshCw className="h-3 w-3" />
            {retryLabel}
          </Button>
        </div>
      )}
    </div>
  );
}
