"use client";

import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { createPortal } from "react-dom";
import {
  Calendar,
  CheckCircle2,
  Circle,
  Download,
  ExternalLink,
  Eye,
  FileText,
  Flag,
  Hash,
  Loader2,
  MessageSquare,
  Pencil,
  RefreshCw,
  AlertTriangle,
  BarChart2,
  Send,
  Sparkles,
  Tag,
  Trash2,
  User,
  Wrench,
  X,
} from "lucide-react";
import {
  api,
  BlogPostDetail,
  ChartTypeId,
  ContentArchetypeId,
  ReviewResponse,
  TopicSelectionMode,
} from "@/lib/api";
import BlogEditorPanel from "./BlogEditorPanel";
import ChartTypeSelector from "./ChartTypeSelector";
import ContentArchetypeSelector from "./ContentArchetypeSelector";
import { ManualKeywordCheck, TopicKeywordCheck } from "./KeywordVolumeCheck";
import { TopicSeoScoreBadge } from "./TopicSeoScore";
import { TopicSourceLinks } from "./TopicSourceLinks";
import {
  buildDownloadHtmlDoc,
  downloadHeroImageUrl,
  preparePreviewHtml,
  replaceHeroSrc,
} from "@/lib/blogPreview";
import { brandPaletteCssVars } from "@/lib/blogProseCss";
import {
  BrandPalette,
  DEFAULT_BRAND_PALETTE,
  normalizeBrandPalette,
} from "@/lib/brandPalette";
import { formatDate, formatDateTime, getPostTitle, getPriority } from "@/lib/status";
import { extractTopPicks, normalizeTopicGroups, TOPIC_SOURCE_META } from "@/lib/topics";
import StatusBadge from "./StatusBadge";
import Button from "./ui/Button";
import { Textarea } from "./ui/Input";
import { Tab, TabList } from "./ui/Tabs";
import Badge from "./ui/Badge";
import { cn } from "@/lib/cn";
import { useNotifications } from "@/contexts/NotificationContext";
import { useToast } from "@/contexts/ToastContext";

type Detail = BlogPostDetail | ReviewResponse;

function isReview(d: Detail): d is ReviewResponse {
  return "seo_metrics" in d;
}

export default function TaskDetailModal({
  postId,
  detail: initialDetail,
  onClose,
}: {
  postId: number;
  detail: Detail;
  onClose: () => void;
}) {
  const { success, error: toastError } = useToast();
  const { refresh: refreshNotifications } = useNotifications();
  const [liveDetail, setLiveDetail] = useState<Detail>(initialDetail);
  const post = isReview(liveDetail) ? liveDetail.post : liveDetail;
  const seo = isReview(liveDetail) ? liveDetail.seo_metrics : null;

  const [customTopic, setCustomTopic] = useState("");
  const [feedback, setFeedback] = useState("");
  const [loading, setLoading] = useState(false);
  const [busyAction, setBusyAction] = useState<string | null>(null);
  const [busyLabel, setBusyLabel] = useState<string | null>(null);
  const [topicMode, setTopicMode] = useState<TopicSelectionMode>("hybrid");
  const [selectedArchetype, setSelectedArchetype] = useState<ContentArchetypeId>("tutorial");
  const [reviewTab, setReviewTab] = useState<"overview" | "preview" | "edit">("preview");
  const [imageVersion, setImageVersion] = useState(0);
  const [brandPalette, setBrandPalette] = useState<BrandPalette>(DEFAULT_BRAND_PALETTE);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  async function runWithBusyState(
    action: string,
    label: string,
    fn: () => Promise<void>
  ) {
    setBusyAction(action);
    setBusyLabel(label);
    setLoading(true);
    const prevTitle = document.title;
    document.title = `Working… ${label}`;
    try {
      await fn();
      await refreshNotifications();
    } finally {
      document.title = prevTitle;
      setLoading(false);
      setBusyAction(null);
      setBusyLabel(null);
    }
  }

  const priority = getPriority(post.status);
  const isTopicGate = post.status === "PENDING_TOPIC";
  const isDiscovering = post.status === "SCRAPING";
  const isGenerating = post.status === "GENERATING";
  const isPublished = post.status === "PUBLISHED";
  const isReviewGate =
    post.status === "PENDING_REVIEW" || post.status === "APPROVED";
  const showBlogContent =
    (isReviewGate || isPublished) && !!post.html_content;
  const canApprove =
    isReviewGate && !!post.html_content && !!post.slug;
  const wordCountOutOfRange = seo?.word_count_valid === false;
  const topicGroups = normalizeTopicGroups(post.scraped_topics_json);
  const topPicks = extractTopPicks(post.scraped_topics_json);
  const flattenCount = TOPIC_SOURCE_META.reduce(
    (sum, meta) => sum + topicGroups[meta.key].length,
    0
  );
  const topicScrollRef = useRef<HTMLDivElement | null>(null);
  const topicCardRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const [highlightTopic, setHighlightTopic] = useState<string | null>(null);
  const [chartsPrompt, setChartsPrompt] = useState<
    | { kind: "topic"; title: string; custom: boolean }
    | { kind: "auto" }
    | null
  >(null);
  const [selectedChartType, setSelectedChartType] = useState<ChartTypeId>(
    () => (post.chart_type as ChartTypeId) || "auto"
  );

  useEffect(() => {
    if (post.chart_type) {
      setSelectedChartType(post.chart_type as ChartTypeId);
    }
  }, [post.chart_type, post.id]);

  function topicKey(source: string | undefined, title: string) {
    return `${source || "unknown"}::${title}`;
  }

  function scrollToTopic(title: string, source?: string) {
    // Prefer exact source match; fall back to first title match
    let el: HTMLDivElement | null = null;
    if (source) {
      el = topicCardRefs.current[topicKey(source, title)] || null;
    }
    if (!el) {
      el =
        Object.entries(topicCardRefs.current).find(([k]) =>
          k.endsWith(`::${title}`)
        )?.[1] || null;
    }
    if (!el) return;
    setHighlightTopic(title);
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    window.setTimeout(() => setHighlightTopic((cur) => (cur === title ? null : cur)), 2800);
  }

  useEffect(() => {
    // Mode is per-product — resolve from this post's product (falls back to active product)
    api
      .getTopicMode(post.product_id ?? undefined)
      .then((r) => setTopicMode(r.mode))
      .catch(console.error);
    api.getContentArchetype().then((r) => {
      if (post.content_archetype) {
        setSelectedArchetype(post.content_archetype);
      } else {
        setSelectedArchetype(r.archetype);
      }
    }).catch(console.error);
  }, [post.content_archetype, post.product_id]);

  useEffect(() => {
    let cancelled = false;
    async function loadPalette() {
      try {
        const products = await api.getProducts();
        const match =
          (post.product_id != null
            ? products.find((p) => p.id === post.product_id)
            : null) ||
          products.find((p) => p.is_active) ||
          products[0];
        if (!cancelled && match) {
          setBrandPalette(normalizeBrandPalette(match.brand_palette));
        }
      } catch (e) {
        console.error(e);
      }
    }
    loadPalette();
    return () => {
      cancelled = true;
    };
  }, [post.product_id]);

  const checklist = useMemo(
    () =>
      buildLiveSeoChecklist(
        post.html_content || "",
        seo,
        !!post.slug,
        post.include_charts
      ),
    [post.html_content, post.slug, post.include_charts, seo]
  );

  const chartsOn =
    post.include_charts === true ||
    (post.include_charts !== false &&
      /<svg[\s>]|stat-(grid|card)|blog-chart/i.test(post.html_content || ""));

  useEffect(() => {
    if (!isGenerating && post.status !== "PENDING_REVIEW") return;
    if (!isGenerating && post.html_content) return;

    const poll = setInterval(async () => {
      try {
        const d = await api.getReviewPost(postId);
        setLiveDetail(d);
        if (d.post.status === "PENDING_REVIEW" && d.post.html_content) {
          clearInterval(poll);
        }
      } catch (e) {
        console.error(e);
      }
    }, 3000);

    return () => clearInterval(poll);
  }, [isGenerating, post.status, post.html_content, postId]);

  async function handleSelectTopic(title: string, custom = false) {
    setChartsPrompt({ kind: "topic", title, custom });
    window.requestAnimationFrame(() => {
      document.getElementById("charts-prompt")?.scrollIntoView({ behavior: "smooth", block: "center" });
    });
  }

  async function handleAutoSelect() {
    setChartsPrompt({ kind: "auto" });
    window.requestAnimationFrame(() => {
      document.getElementById("charts-prompt")?.scrollIntoView({ behavior: "smooth", block: "center" });
    });
  }

  async function confirmChartsChoice(includeCharts: boolean) {
    if (!chartsPrompt) return;
    setLoading(true);
    try {
      if (chartsPrompt.kind === "auto") {
        await api.autoSelectTopic(
          postId,
          includeCharts,
          selectedArchetype,
          includeCharts ? selectedChartType : undefined
        );
      } else {
        await api.selectTopic(
          postId,
          chartsPrompt.title,
          chartsPrompt.custom,
          selectedArchetype,
          includeCharts,
          includeCharts ? selectedChartType : undefined
        );
      }
      onClose();
    } catch (e) {
      alert(`Error: ${e}`);
    } finally {
      setLoading(false);
    }
  }

  async function handleApprove() {
    if (wordCountOutOfRange && seo) {
      const wc = seo.word_count?.toLocaleString() ?? "?";
      const range = `${seo.word_count_min.toLocaleString()}–${seo.word_count_max.toLocaleString()}`;
      const label = seo.content_archetype_label || "this archetype";
      const proceed = window.confirm(
        `Word count is outside the filter (${wc} words; ${label} allows ${range}).\n\n` +
          `Recommended: do not publish yet — use Revision prompt to shorten or expand the draft.\n\n` +
          `Click OK only if you still want a manual override and publish anyway.`
      );
      if (!proceed) {
        toastError(
          "Publish cancelled",
          `Fix length with Revision prompt (${range} words for ${label}), then approve again.`
        );
        return;
      }
    }
    setLoading(true);
    try {
      const res = await api.approvePost(postId, {
        override_word_count: Boolean(wordCountOutOfRange),
      });
      success(
        wordCountOutOfRange ? "Published with override" : "Published",
        res.message || "Blog published successfully"
      );
      onClose();
    } catch (e) {
      toastError("Publish failed", String(e).replace(/^Error:\s*/i, ""));
    } finally {
      setLoading(false);
    }
  }

  async function handleRedo() {
    if (!feedback.trim()) return;
    setLoading(true);
    try {
      await api.redoPost(postId, feedback.trim());
      success("Revision sent", "Regenerating the blog with your prompt…");
      setFeedback("");
      onClose();
    } catch (e) {
      toastError("Could not send prompt", String(e));
    } finally {
      setLoading(false);
    }
  }

  async function handleAbort() {
    if (
      !confirm(
        "Abort this run? It will be removed completely and you can start fresh with Run discovery."
      )
    ) {
      return;
    }
    try {
      await runWithBusyState("abort", "Aborting run", async () => {
        await api.abortPost(postId);
        success("Abort finished", "Run removed. Check the bell for confirmation.");
        onClose();
      });
    } catch (e) {
      toastError("Abort failed", String(e));
    }
  }

  function lastPipelineError(): string | null {
    const history = post.feedback_history || [];
    for (let i = history.length - 1; i >= 0; i--) {
      const entry = history[i] as { type?: string; feedback?: string };
      if (entry.type === "error" && entry.feedback) return entry.feedback;
    }
    return post.last_error || null;
  }

  async function handleRetryDiscovery() {
    setLoading(true);
    try {
      await api.retryDiscovery(postId);
      onClose();
    } catch (e) {
      alert(`Retry failed: ${e}`);
    } finally {
      setLoading(false);
    }
  }

  async function handleRetryGeneration() {
    setLoading(true);
    try {
      await api.retryGeneration(postId);
      onClose();
    } catch (e) {
      alert(`Retry failed: ${e}`);
    } finally {
      setLoading(false);
    }
  }

  async function downloadHtml() {
    if (!post.html_content) return;
    const title = post.title_tag || post.selected_topic_title || `post-${postId}`;
    const slug = post.slug || `post-${postId}`;
    // Prefer public MinIO/CDN image URL so the downloaded file keeps working offline
    const storedImage = (post.image_url || "").trim();
    const imageUrl =
      /^https?:\/\//i.test(storedImage) && !/^data:/i.test(storedImage)
        ? storedImage
        : post.slug
          ? downloadHeroImageUrl(post.slug, imageVersion).replace(/\?v=\d+$/, "")
          : "";
    const website =
      (await api.getProducts().then((list) => {
        const match =
          (post.product_id != null
            ? list.find((p) => p.id === post.product_id)
            : null) || list.find((p) => p.is_default) || list[0];
        return (match?.website_url || "https://hyperthings.ai").replace(/\/$/, "");
      }).catch(() => "https://hyperthings.ai"));
    const canonicalUrl = `${website}/blog/${slug}`;
    let body = post.html_content;
    if (imageUrl) {
      body = replaceHeroSrc(body, imageUrl);
    }
    try {
      const doc = buildDownloadHtmlDoc({
        title,
        description: post.meta_description || "",
        bodyHtml: body,
        brandPalette,
        canonicalUrl,
        imageUrl: imageUrl || canonicalUrl,
        siteName: "Hyperthings.ai",
      });
      const blob = new Blob([doc], { type: "text/html;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${slug}.html`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      alert(`Download blocked (SEO rules): ${e}`);
    }
  }

  async function downloadImage() {
    if (!post.slug) {
      alert("No hero image yet for this post.");
      return;
    }
    try {
      const res = await fetch(api.imageUrl(post.slug, imageVersion));
      if (!res.ok) throw new Error(`Image download failed (${res.status})`);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${post.slug}.webp`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      alert(String(e));
    }
  }

  function handleEditorSaved(d: ReviewResponse) {
    setLiveDetail(d);
    setImageVersion((v) => v + 1);
    setReviewTab("preview");
  }

  function handleImageUpdated(d: ReviewResponse) {
    setLiveDetail(d);
    setImageVersion((v) => v + 1);
  }

  async function handleFixCta() {
    try {
      await runWithBusyState("fix-cta", "Fixing CTA", async () => {
        const d = await api.repairBlogCta(postId);
        setLiveDetail(d);
        success("CTA fixed — ready", "Updated. A bell notification was saved if you leave this tab.");
        setReviewTab("preview");
      });
    } catch (e) {
      toastError("CTA fix failed", String(e));
    }
  }

  async function handleAddFaq() {
    try {
      await runWithBusyState("add-faq", "Adding FAQ", async () => {
        const d = await api.addBlogFaq(postId);
        setLiveDetail(d);
        success("FAQ added — ready", "Updated. Check the bell anytime for confirmation.");
        setReviewTab("preview");
      });
    } catch (e) {
      toastError("Add FAQ failed", String(e));
    }
  }

  async function handleToggleCharts() {
    const next = !chartsOn;
    try {
      await runWithBusyState(
        "charts",
        next ? "Adding charts" : "Removing charts",
        async () => {
          const d = await api.setBlogCharts(
            postId,
            next,
            next ? selectedChartType : undefined
          );
          setLiveDetail(d);
          success(
            next ? "Charts added — ready" : "Charts removed — ready",
            next
              ? `Applied «${selectedChartType}» charts to this draft.`
              : "Charts were removed from this draft."
          );
          setReviewTab("preview");
        }
      );
    } catch (e) {
      toastError("Charts update failed", String(e));
    }
  }

  async function handleChartTypeChange(nextType: ChartTypeId) {
    setSelectedChartType(nextType);
    try {
      await runWithBusyState("charts", "Updating chart type", async () => {
        const d = await api.setBlogCharts(postId, true, nextType);
        setLiveDetail(d);
        success("Chart type updated", `Switched visuals to «${nextType}».`);
        setReviewTab("preview");
      });
    } catch (e) {
      toastError("Chart type update failed", String(e));
    }
  }

  async function handleRepairFormat() {
    try {
      await runWithBusyState("repair-format", "Repairing format", async () => {
        const d = await api.repairBlogFormat(postId);
        setLiveDetail(d);
        setImageVersion((v) => v + 1);
        success(
          "Format repaired — ready",
          "Updated. A bell notification was saved if you leave this tab."
        );
        setReviewTab("preview");
      });
    } catch (e) {
      toastError("Repair failed", String(e));
    }
  }

  const checklistDone = checklist.filter((c) => c.done).length;
  const checklistPct = checklist.length
    ? Math.round((checklistDone / checklist.length) * 100)
    : 0;
  const useSplitLayout =
    isReviewGate && reviewTab === "overview" && !!post.html_content;
  // Full-bleed only for review Preview/Edit tabs — published keeps metadata + article together
  const isPreviewReading =
    isReviewGate && reviewTab === "preview" && !!post.html_content;
  const isEditReading = isReviewGate && reviewTab === "edit" && !!post.html_content;
  const isFullBleedReading = isPreviewReading || isEditReading;
  const pipelineError = lastPipelineError();
  const discoveryFailed = isDiscovering && !!pipelineError;
  const generationFailed = isGenerating && !!pipelineError;

  if (!mounted) return null;

  return createPortal(
    <div
      className={cn(
        "fixed inset-0 z-[100] flex bg-hyper-dark/60 backdrop-blur-md",
        isFullBleedReading
          ? "items-stretch justify-center p-0 sm:items-center sm:p-2"
          : "items-end justify-center p-0 sm:items-center sm:p-4"
      )}
    >
      <div
        className={cn(
          "relative z-[101] flex w-full animate-modal-in flex-col overflow-hidden border border-white/20 bg-white shadow-elevated",
          isFullBleedReading
            ? "h-[100dvh] max-h-[100dvh] max-w-none rounded-none sm:h-[min(98dvh,100%)] sm:max-h-[98dvh] sm:rounded-2xl"
            : "h-[min(100dvh,100%)] max-h-[100dvh] max-w-6xl rounded-t-2xl sm:h-[min(96dvh,960px)] sm:max-h-[96dvh] sm:rounded-3xl xl:max-w-7xl"
        )}
      >
        <div className="settings-accent-bar h-1 shrink-0" />
        <div className="flex shrink-0 flex-col gap-3 border-b border-hyper-border/70 bg-gradient-to-b from-white to-surface-1/40 px-4 py-3 sm:flex-row sm:items-start sm:justify-between sm:gap-4 sm:px-6 sm:py-4">
          <div className="min-w-0 flex-1 pr-0 sm:pr-4">
            <p className="text-micro uppercase tracking-[0.14em] text-text-muted">
              {isPublished
                ? `Published${post.publish_serial != null ? ` · Serial #${post.publish_serial}` : ""}`
                : `Post #${postId}`}
            </p>
            <h2 className="mt-1 line-clamp-2 font-display text-lg font-bold tracking-tight text-hyper-navy sm:text-h1">
              {getPostTitle(post)}
            </h2>
            {isPublished && (
              <p className="mt-1 text-xs font-medium text-slate-600">
                {formatDateTime(post.published_at || post.created_at)}
                {post.reading_time ? ` · ${post.reading_time}` : ""}
              </p>
            )}
          </div>
          <div className="flex w-full shrink-0 flex-wrap items-center justify-start gap-2 sm:w-auto sm:max-w-[58%] sm:justify-end">
            <Button variant="secondary" size="sm" onClick={onClose} className="min-h-10 sm:min-h-0">
              {isPublished ? "Close" : "Cancel"}
            </Button>
            {(showBlogContent || isGenerating) && post.html_content && (
              <Button
                variant="outline"
                size="sm"
                onClick={downloadHtml}
                disabled={loading}
                className="min-h-10 sm:min-h-0"
              >
                <Download className="h-4 w-4" />
                <span className="sm:hidden">HTML</span>
                <span className="hidden sm:inline">Download HTML</span>
              </Button>
            )}
            {(showBlogContent || isGenerating) && post.slug && (
              <Button
                variant="outline"
                size="sm"
                onClick={downloadImage}
                disabled={loading}
                className="min-h-10 sm:min-h-0"
              >
                <Download className="h-4 w-4" />
                <span className="sm:hidden">Image</span>
                <span className="hidden sm:inline">Download image</span>
              </Button>
            )}
            {canApprove && (
              <Button
                variant="outline"
                size="sm"
                disabled={loading}
                loading={loading}
                className="min-h-10 sm:min-h-0"
                onClick={async () => {
                  setLoading(true);
                  try {
                    const res = await api.notifyReviewTeams(postId);
                    alert(res.message);
                  } catch (e) {
                    alert(`Teams send failed: ${e}`);
                  } finally {
                    setLoading(false);
                  }
                }}
              >
                <span className="sm:hidden">Teams</span>
                <span className="hidden sm:inline">Send to Teams</span>
              </Button>
            )}
            {canApprove && (
              <Button
                variant="orange"
                size="sm"
                disabled={loading}
                loading={loading}
                onClick={handleApprove}
                className="min-h-10 w-full sm:w-auto sm:min-h-0"
                title={
                  wordCountOutOfRange
                    ? "Word count out of range — you’ll be asked to confirm a manual override"
                    : "Approve and publish this blog"
                }
              >
                Approve & Publish
                {wordCountOutOfRange ? "…" : ""}
              </Button>
            )}
            {isReviewGate && post.html_content && reviewTab !== "edit" && (
              <Button
                variant="secondary"
                size="sm"
                onClick={() => setReviewTab("edit")}
                className="min-h-10 sm:min-h-0"
              >
                <Pencil className="h-4 w-4" />
                Edit
              </Button>
            )}
            <button
              type="button"
              onClick={onClose}
              disabled={loading}
              className="icon-btn ml-auto sm:ml-0"
              aria-label="Close"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {busyLabel && (
          <div
            className="flex shrink-0 items-center gap-2.5 border-b border-hyper-orange/25 bg-hyper-orange/[0.08] px-4 py-2.5 text-sm text-hyper-navy sm:px-6"
            role="status"
            aria-live="polite"
          >
            <Loader2 className="h-4 w-4 shrink-0 animate-spin text-hyper-orange" />
            <div className="min-w-0">
              <p className="font-semibold">{busyLabel}…</p>
              <p className="text-[11px] text-text-secondary">
                Stay on this tab or leave — you’ll get a bell notification when it’s ready.
              </p>
            </div>
          </div>
        )}

        <div
          className={cn(
            "flex min-h-0 flex-1 flex-col",
            isFullBleedReading ? "overflow-hidden" : "overflow-hidden"
          )}
        >
          <div
            ref={topicScrollRef}
            className={cn(
              "min-h-0 flex-1",
              useSplitLayout
                ? "overflow-hidden px-3 py-4 sm:px-6 lg:grid lg:grid-cols-[1fr_280px] lg:gap-6"
                : isFullBleedReading
                  ? "flex flex-col overflow-hidden"
                  : "overflow-y-auto px-3 py-4 sm:px-6"
            )}
          >
          <div
            className={cn(
              "min-h-0",
              useSplitLayout && "flex flex-col overflow-y-auto lg:pr-2",
              // flex-1 + min-h-0 so Preview/Edit scroll panes get a capped height
              isFullBleedReading && "flex min-h-0 flex-1 flex-col"
            )}
          >
          {!isFullBleedReading && (
          <div className="mb-6 grid gap-3 sm:grid-cols-2">
            <PropertyRow icon={Tag} label="Label">
              <StatusBadge status={post.status} />
            </PropertyRow>
            <PropertyRow icon={Calendar} label={isPublished ? "Published" : "Due Date"}>
              <span className="text-sm text-slate-700">
                {isPublished
                  ? formatDateTime(post.published_at || post.created_at)
                  : formatDate(post.created_at)}
              </span>
            </PropertyRow>
            {isPublished && post.publish_serial != null && (
              <PropertyRow icon={Hash} label="Serial">
                <span className="text-sm font-semibold text-hyper-navy">
                  #{post.publish_serial}
                </span>
              </PropertyRow>
            )}
            {isPublished && post.minio_object && (
              <PropertyRow icon={FileText} label="MinIO">
                <span className="break-all font-mono text-[11px] text-slate-600">
                  {post.minio_object}
                </span>
              </PropertyRow>
            )}
            <PropertyRow icon={Flag} label="Priority">
              <Badge className={cn(priority.color, "text-xs")}>
                {priority.label}
              </Badge>
            </PropertyRow>
            <PropertyRow icon={FileText} label="Status">
              <span className="text-sm font-medium text-hyper-primary">
                {post.status.replace(/_/g, " ")}
              </span>
            </PropertyRow>
            <PropertyRow icon={User} label="Assignee">
              <div className="flex items-center gap-2">
                <div className="flex h-7 w-7 items-center justify-center rounded-full bg-hyper-primary text-[10px] font-bold text-white">
                  HP
                </div>
                <span className="text-sm text-slate-700">HyperPark Admin</span>
              </div>
            </PropertyRow>
            {seo && isReviewGate && (
              <PropertyRow icon={Hash} label="Word Count">
                <div>
                  <span
                    className={cn(
                      "text-sm font-semibold",
                      seo.word_count_valid ? "text-hyper-navy" : "text-hyper-red"
                    )}
                  >
                    {seo.word_count?.toLocaleString() ?? "—"} words
                  </span>
                  <span
                    className={cn(
                      "ml-2 text-[11px]",
                      seo.word_count_valid ? "text-slate-400" : "font-medium text-amber-700"
                    )}
                  >
                    Strict limit: {seo.word_count_min.toLocaleString()}–{seo.word_count_max.toLocaleString()} (
                    {seo.content_archetype_label})
                    {!seo.word_count_valid
                      ? " — out of range (revision recommended; override available)"
                      : ""}
                  </span>
                </div>
              </PropertyRow>
            )}
            {isReviewGate && seo && (
              <PropertyRow icon={FileText} label="Archetype">
                <span className="text-sm text-slate-700">{seo.content_archetype_label}</span>
              </PropertyRow>
            )}
          </div>
          )}
          {seo && isReviewGate && seo.word_count_valid === false && !isFullBleedReading && (
            <div className="mb-6 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-950">
              <strong className="font-semibold">Word count outside archetype filter.</strong>{" "}
              Prefer fixing with Revision prompt (e.g. “Shorten to under {seo.word_count_max} words
              for {seo.content_archetype_label}”), then Send. Approve & Publish is still available —
              clicking it warns you first; confirm only if you want a manual override.
            </div>
          )}

          {(discoveryFailed || generationFailed) && pipelineError && (
            <div className="mb-6 rounded-xl border border-red-200 bg-red-50 px-4 py-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-hyper-red" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-hyper-red">
                    {discoveryFailed ? "Discovery failed" : "Generation failed"}
                  </p>
                  <p className="mt-1 break-words text-sm text-red-900/90">{pipelineError}</p>
                  <p className="mt-2 text-xs text-red-800/80">
                    This post stays on the same stage until you Retry or Abort. It will not
                    restart from the beginning automatically.
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {discoveryFailed && (
                      <Button
                        size="sm"
                        disabled={loading}
                        loading={loading}
                        onClick={handleRetryDiscovery}
                      >
                        <RefreshCw className="h-4 w-4" />
                        Retry discovery
                      </Button>
                    )}
                    {generationFailed && (
                      <Button
                        size="sm"
                        disabled={loading}
                        loading={loading}
                        onClick={handleRetryGeneration}
                      >
                        <RefreshCw className="h-4 w-4" />
                        Retry generation
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      disabled={loading}
                      onClick={handleAbort}
                    >
                      Abort &amp; remove
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {isReviewGate && post.html_content && (
            <div
              className={cn(
                "shrink-0",
                isFullBleedReading
                  ? "border-b border-hyper-border px-5 py-3 sm:px-6"
                  : "mb-6"
              )}
            >
              <TabList className="flex w-full max-w-full overflow-x-auto [-webkit-overflow-scrolling:touch] sm:w-auto sm:overflow-visible">
                {(
                  [
                    { id: "overview" as const, label: "Overview", icon: FileText },
                    { id: "preview" as const, label: "Preview", icon: Eye },
                    { id: "edit" as const, label: "Edit", icon: Pencil },
                  ] as const
                ).map(({ id, label, icon: Icon }) => (
                  <Tab
                    key={id}
                    id={`tab-${id}`}
                    label={label}
                    icon={Icon}
                    active={reviewTab === id}
                    onClick={() => setReviewTab(id)}
                  />
                ))}
              </TabList>
            </div>
          )}

          {isPublished && post.html_content && (
            <div className="mb-4">
              <p className="text-xs font-semibold uppercase tracking-wider text-emerald-700">
                Published blog
                {post.publish_serial != null ? ` · Serial #${post.publish_serial}` : ""}
              </p>
              <p className="mt-1 text-xs text-text-secondary">
                Full article below — also listed under Ready to use for this product.
              </p>
            </div>
          )}

          {isGenerating && (
            <section className="mb-6 rounded-xl border border-indigo-100 bg-indigo-50 p-4">
              <div className="flex items-center gap-2 text-sm font-medium text-indigo-800">
                <Loader2 className="h-4 w-4 animate-spin" />
                Generating content & hero image
              </div>
              <p className="mt-2 text-xs text-indigo-700">
                Writing the SEO blog post and creating the hero image.
                This can take 2–4 minutes. This dialog refreshes automatically.
              </p>
            </section>
          )}

          {isDiscovering && (
            <section className="mb-6 rounded-xl border border-blue-100 bg-blue-50 p-4">
              <div className="flex items-center gap-2 text-sm font-medium text-blue-800">
                <Loader2 className="h-4 w-4 animate-spin" />
                Discovery in progress
              </div>
              <p className="mt-2 text-xs text-blue-700">
                Scraping industry sources and synthesizing topics. This can take
                2–5 minutes. The board refreshes automatically — you can close
                this dialog.
              </p>
            </section>
          )}

          {/* Topic selection (HITL Gate 1) */}
          {isTopicGate && (
            <section className="mb-6">
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    Select Topic — HITL Gate 1
                  </h3>
                  <p className="mt-1 text-xs text-text-secondary">
                    Topics are ranked by SEO score (volume, difficulty, competitor gap). Pick one
                    or use auto-select for the highest score.
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  {(topicMode === "hybrid" || topicMode === "auto") && (
                    <Button
                      size="sm"
                      variant="orange"
                      onClick={handleAutoSelect}
                      disabled={loading || flattenCount === 0}
                      loading={loading}
                    >
                      <Sparkles className="h-3.5 w-3.5" />
                      Run auto-select
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="danger"
                    disabled={loading}
                    onClick={handleAbort}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    Abort run
                  </Button>
                </div>
              </div>
              <div className="mb-5">
                <ContentArchetypeSelector
                  compact
                  value={selectedArchetype}
                  onChange={setSelectedArchetype}
                />
              </div>

              {chartsPrompt ? (
                <div id="charts-prompt" className="mb-5 rounded-2xl border border-hyper-orange/40 bg-orange-50/80 p-4 shadow-sm">
                  <div className="flex items-start gap-3">
                    <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-white text-hyper-orange shadow-soft">
                      <BarChart2 className="h-4 w-4" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-hyper-navy">
                        Include charts in this blog?
                      </p>
                      <p className="mt-1 text-xs leading-snug text-text-secondary">
                        {chartsPrompt.kind === "auto"
                          ? "The highest-SEO topic will be used. Choose whether to include charts, and which graphic style to use."
                          : "Topic selected. Choose charts on/off and the graphic style. You can still change this after generation."}
                      </p>
                      <div className="mt-3">
                        <ChartTypeSelector
                          compact
                          value={selectedChartType}
                          onChange={setSelectedChartType}
                          disabled={loading}
                        />
                      </div>
                      <div className="mt-3 flex flex-wrap gap-2">
                        <Button
                          size="sm"
                          variant="orange"
                          disabled={loading}
                          loading={loading}
                          onClick={() => confirmChartsChoice(true)}
                        >
                          Yes, include charts
                        </Button>
                        <Button
                          size="sm"
                          variant="secondary"
                          disabled={loading}
                          onClick={() => confirmChartsChoice(false)}
                        >
                          No charts
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          disabled={loading}
                          onClick={() => setChartsPrompt(null)}
                        >
                          Back
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ) : null}

              {flattenCount === 0 ? (
                <p className="rounded-xl border border-dashed border-hyper-border px-4 py-8 text-center text-sm text-text-muted">
                  No topics yet for this run. Close this dialog and wait for discovery to finish,
                  or start a new discovery.
                </p>
              ) : (
                <div className="space-y-6">
                  {topPicks.length > 0 ? (
                    <div className="overflow-hidden rounded-xl border border-amber-200/80 shadow-sm">
                      <div className="bg-gradient-to-r from-amber-500 via-hyper-orange to-hyper-primary px-4 py-2.5">
                        <h4 className="text-sm font-bold tracking-tight text-white">
                          Top SEO picks this run
                        </h4>
                        <p className="text-[11px] text-white/90">
                          Click a pick to jump to that topic below, or Select it from here.
                        </p>
                      </div>
                      <div className="space-y-2 bg-gradient-to-b from-amber-50 to-orange-50/40 p-4">
                        {topPicks.map((pick) => (
                          <div
                            key={pick.title}
                            className="flex flex-col gap-2 rounded-lg border border-amber-100 bg-white/90 px-3 py-2.5 shadow-sm sm:flex-row sm:items-center"
                          >
                            <button
                              type="button"
                              className="flex min-w-0 flex-1 items-start gap-2 text-left"
                              onClick={() => scrollToTopic(pick.title, pick.source)}
                            >
                              <span className="inline-flex min-w-[2rem] items-center justify-center rounded-md bg-gradient-to-br from-amber-500 to-hyper-orange px-2 py-0.5 text-[11px] font-bold tabular-nums text-white">
                                {pick.seo_score != null ? Math.round(pick.seo_score) : "—"}
                              </span>
                              <span className="min-w-0 flex-1 text-[11px] font-medium leading-snug text-hyper-navy hover:text-hyper-orange">
                                {pick.title}
                                <span className="mt-0.5 block text-[10px] font-semibold text-hyper-primary">
                                  Jump to topic ↓
                                </span>
                              </span>
                            </button>
                            <div className="flex flex-wrap items-center gap-2 sm:justify-end">
                              {pick.source_links?.[0] ? (
                                <a
                                  href={pick.source_links[0].url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center gap-1 rounded-md border-2 border-hyper-orange/40 bg-orange-50 px-2.5 py-1.5 text-[10px] font-bold text-hyper-orange hover:bg-hyper-orange hover:text-white"
                                >
                                  <ExternalLink className="h-3 w-3" />
                                  Source
                                </a>
                              ) : null}
                              <Button
                                size="sm"
                                onClick={() => handleSelectTopic(pick.title)}
                                disabled={loading}
                                loading={loading}
                              >
                                Select
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : null}
                  {TOPIC_SOURCE_META.map((meta) => {
                    const items = topicGroups[meta.key];
                    return (
                      <div key={meta.key} id={`topic-group-${meta.key}`}>
                        <div className="mb-3 flex items-end justify-between gap-2">
                          <div>
                            <h4 className="font-display text-sm font-semibold text-hyper-navy">
                              {meta.label}
                            </h4>
                            <p className="text-xs text-text-muted">{meta.subtitle}</p>
                          </div>
                          <span
                            className={cn(
                              "rounded-full px-2.5 py-0.5 text-[11px] font-semibold tabular-nums",
                              meta.countClass
                            )}
                          >
                            {items.length} topic{items.length === 1 ? "" : "s"}
                          </span>
                        </div>
                        {items.length === 0 ? (
                          <p className="rounded-xl border border-dashed border-hyper-border px-3 py-4 text-xs text-text-muted">
                            No topics from this source. Add{" "}
                            {meta.key === "industry_keywords"
                              ? "keywords"
                              : meta.key === "competitor_urls"
                                ? "competitor URLs"
                                : "RSS feeds"}{" "}
                            in Settings → Products, then run discovery again.
                          </p>
                        ) : (
                          <div className="grid gap-3 sm:grid-cols-2">
                            {items.map((topic, i) => (
                              <div
                                key={`${meta.key}-${i}-${topic.title}`}
                                ref={(node) => {
                                  topicCardRefs.current[topicKey(meta.key, topic.title)] = node;
                                }}
                                className={cn(
                                  "rounded-xl border p-4 transition",
                                  highlightTopic === topic.title
                                    ? "border-hyper-orange bg-orange-50/80 shadow-glow ring-2 ring-hyper-orange/30"
                                    : "border-hyper-border hover:border-hyper-primary/40"
                                )}
                              >
                                <span
                                  className={cn(
                                    "mb-2 inline-block rounded-md px-2 py-0.5 text-[10px] font-semibold",
                                    meta.badgeClass
                                  )}
                                >
                                  {meta.badge} · {i + 1}
                                </span>
                                <h4 className="mb-1 text-sm font-semibold text-hyper-navy">
                                  {topic.title}
                                </h4>
                                <p className="mb-3 text-xs text-slate-500 line-clamp-3">
                                  {topic.description}
                                </p>
                                {topic.primary_keyword ? (
                                  <p className="mb-2 font-mono text-[10px] text-text-muted">
                                    kw: {topic.primary_keyword}
                                  </p>
                                ) : null}
                                {topic.source_links && topic.source_links.length > 0 ? (
                                  <div className="mb-3">
                                    <TopicSourceLinks links={topic.source_links} compact />
                                  </div>
                                ) : (
                                  <p className="mb-3 rounded-md border border-amber-200 bg-amber-50 px-2 py-1.5 text-[10px] font-medium text-amber-900">
                                    No source URL — run discovery again to refresh sources.
                                  </p>
                                )}
                                {topic.seo_score != null ? (
                                  <div className="mb-3">
                                    <TopicSeoScoreBadge topic={topic} compact />
                                  </div>
                                ) : null}
                                <div className="mb-3">
                                  <TopicKeywordCheck
                                    keyword={topic.primary_keyword || topic.title}
                                  />
                                </div>
                                <Button
                                  size="sm"
                                  className="w-full"
                                  onClick={() => handleSelectTopic(topic.title)}
                                  disabled={loading}
                                  loading={loading}
                                >
                                  Select This Topic
                                </Button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

              {(topicMode === "manual" || topicMode === "hybrid") && (
                <div className="mt-6 space-y-4">
                  <ManualKeywordCheck />
                  <div className="rounded-xl border border-hyper-border p-4">
                  <p className="mb-2 text-sm font-medium text-hyper-navy">
                    Custom Human Idea
                  </p>
                  <p className="mb-3 text-xs text-text-muted">
                    Skip the suggestions and write your own topic command.
                  </p>
                  <Textarea
                    value={customTopic}
                    onChange={(e) => setCustomTopic(e.target.value)}
                    placeholder="Enter your custom blog topic..."
                    rows={2}
                    className="mb-3"
                  />
                  <Button
                    variant="orange"
                    onClick={() => handleSelectTopic(customTopic, true)}
                    disabled={loading || !customTopic.trim()}
                    loading={loading}
                  >
                    Submit Custom Topic
                  </Button>
                  </div>
                </div>
              )}

              <div className="sticky bottom-0 mt-6 flex flex-wrap items-center justify-between gap-2 border-t border-hyper-border bg-white/95 py-3 backdrop-blur-sm">
                <p className="text-[11px] text-text-muted">
                  Abort removes this run. Run auto-select picks the highest SEO score.
                </p>
                <div className="flex flex-wrap gap-2">
                  {(topicMode === "hybrid" || topicMode === "auto") && (
                    <Button
                      variant="orange"
                      size="sm"
                      onClick={handleAutoSelect}
                      disabled={loading || flattenCount === 0}
                      loading={loading}
                    >
                      <Sparkles className="h-3.5 w-3.5" />
                      Run auto-select
                    </Button>
                  )}
                  <Button
                    variant="danger"
                    size="sm"
                    disabled={loading}
                    onClick={handleAbort}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    Abort &amp; remove run
                  </Button>
                </div>
              </div>
            </section>
          )}

          {/* Review / Published: Preview — full landscape webpage */}
          {showBlogContent && (isPublished || reviewTab === "preview") && post.html_content && (
            <section
              className={cn(
                "flex min-h-0 flex-col bg-white",
                isPublished
                  ? "mb-6 max-h-[min(70dvh,720px)] overflow-hidden rounded-xl border border-hyper-border/70 shadow-soft"
                  : "flex-1"
              )}
            >
              <div className="flex shrink-0 items-center justify-between gap-3 border-b border-hyper-border/60 bg-surface-1/80 px-4 py-2 sm:px-6">
                <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                  {isPublished ? "Published blog" : "Blog preview"}
                </p>
                <p className="truncate text-xs text-slate-400">
                  Full webpage layout · laptop & mobile · matches Download HTML
                </p>
              </div>
              {isReviewGate ? (
                <div className="shrink-0 space-y-3 border-b border-hyper-orange/30 bg-orange-50/70 px-4 py-3 sm:px-6">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="text-xs font-semibold text-hyper-navy">
                      Chart / graphic type — pick one to apply to this draft
                    </p>
                    <Button
                      size="sm"
                      variant={chartsOn ? "orange" : "outline"}
                      disabled={loading}
                      loading={busyAction === "charts"}
                      onClick={handleToggleCharts}
                    >
                      <BarChart2 className="h-3.5 w-3.5" />
                      {chartsOn ? "Charts on" : "Add charts"}
                    </Button>
                  </div>
                  <ChartTypeSelector
                    compact
                    label=""
                    value={selectedChartType}
                    onChange={handleChartTypeChange}
                    disabled={loading || busyAction === "charts"}
                  />
                </div>
              ) : null}
              <div className="blog-preview-scroll min-h-0 flex-1 overflow-y-auto overscroll-contain bg-white">
                <div className="blog-preview-page mx-auto w-full max-w-[72rem] px-4 py-6 sm:px-8 sm:py-8 lg:px-12 lg:py-10 xl:max-w-[80rem]">
                  <article
                    key={`preview-${imageVersion}-${post.chart_type || "auto"}-${chartsOn ? "on" : "off"}-${(post.html_content || "").length}`}
                    className="prose-blog prose-blog-reading w-full max-w-none bg-white"
                    style={brandPaletteCssVars(brandPalette) as CSSProperties}
                    dangerouslySetInnerHTML={{
                      __html: post.slug
                        ? preparePreviewHtml(post.html_content, post.slug, imageVersion)
                        : post.html_content,
                    }}
                  />
                </div>
              </div>
            </section>
          )}

          {/* Review: Edit tab */}
          {isReviewGate && reviewTab === "edit" && post.html_content && (
            <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4 sm:px-6">
              <BlogEditorPanel
                key={`${postId}-${imageVersion}-${post.slug}`}
                postId={postId}
                post={post}
                imageVersion={imageVersion}
                onSaved={handleEditorSaved}
                onImageUpdated={handleImageUpdated}
              />
            </div>
          )}

          {/* Generating only: draft preview */}
          {isGenerating && post.html_content && (
            <section className="mb-6">
              <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400">
                Draft in progress
              </h3>
              <div className="max-h-[min(70dvh,720px)] overflow-y-auto rounded-2xl border border-hyper-border/70 bg-white p-4 sm:p-8 lg:px-12">
                <div
                  className="prose-blog prose-blog-reading mx-auto w-full max-w-[72rem]"
                  style={brandPaletteCssVars(brandPalette) as CSSProperties}
                  dangerouslySetInnerHTML={{ __html: post.html_content }}
                />
              </div>
            </section>
          )}

          {(isGenerating || isDiscovering) && post.slug && (
            <section className="mb-6">
              <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400">
                Attachments
              </h3>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div className="overflow-hidden rounded-xl border border-hyper-border">
                  <img
                    src={api.imageUrl(post.slug, imageVersion)}
                    alt="Hero"
                    className="h-24 w-full object-cover"
                  />
                  <div className="p-2">
                    <p className="truncate text-[11px] font-medium text-slate-700">
                      {post.slug}.webp
                    </p>
                    <p className="text-[10px] text-slate-400">Hero · WebP</p>
                  </div>
                </div>
              </div>
            </section>
          )}

          {isGenerating && !post.html_content && post.meta_description && (
            <section className="mb-6">
              <h3 className="mb-3 text-xs font-semibold uppercase tracking-wider text-slate-400">
                Description
              </h3>
              <p className="rounded-xl border border-hyper-border bg-hyper-canvas p-4 text-sm text-slate-600">
                {post.meta_description}
              </p>
            </section>
          )}

          {/* SEO checklist only when not split (mobile / narrow) — prompt is always at bottom */}
          {isReviewGate && seo && reviewTab === "overview" && !useSplitLayout && (
            <ChecklistSection
              checklist={checklist}
              checklistPct={checklistPct}
              checklistDone={checklistDone}
            />
          )}
          </div>

          {useSplitLayout && (
            <aside className="hidden min-h-0 overflow-y-auto lg:block lg:border-l lg:border-hyper-border lg:pl-6">
              {seo && (
                <ChecklistSection
                  checklist={checklist}
                  checklistPct={checklistPct}
                  checklistDone={checklistDone}
                  compact
                />
              )}
            </aside>
          )}
          </div>

          {/* Full-width revision prompt pinned at bottom (landscape + all overview) */}
          {isReviewGate && reviewTab === "overview" && (
            <div className="shrink-0 border-t border-hyper-border bg-[#f8f9fc] px-4 py-3 sm:px-6">
              <RevisionPromptPanel
                feedback={feedback}
                setFeedback={setFeedback}
                loading={loading}
                busyAction={busyAction}
                history={post.feedback_history || []}
                onSend={handleRedo}
                onFixCta={handleFixCta}
                onAddFaq={handleAddFaq}
                chartsOn={chartsOn}
                chartType={selectedChartType}
                onChartTypeChange={handleChartTypeChange}
                onToggleCharts={handleToggleCharts}
                onRepairFormat={handleRepairFormat}
                onAbort={handleAbort}
                wide
              />
            </div>
          )}
        </div>
      </div>
    </div>,
    document.body
  );
}

function PropertyRow({
  icon: Icon,
  label,
  children,
}: {
  icon: React.ElementType;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-3 rounded-xl border border-hyper-border bg-surface-1 px-3 py-2.5">
      <Icon className="h-4 w-4 shrink-0 text-text-muted" />
      <div className="min-w-0 flex-1">
        <p className="text-xs text-text-muted">{label}</p>
        <div className="mt-0.5">{children}</div>
      </div>
    </div>
  );
}

type SeoCheckItem = { id: number; label: string; done: boolean; detail?: string };

function countIntroWords(html: string): number {
  const parts = html.split(/<\/h1>/i);
  if (parts.length < 2) return 0;
  let chunk = parts[1].split(/<h2\b/i)[0] || "";
  chunk = chunk.replace(/<script[\s\S]*?<\/script>/gi, "");
  chunk = chunk.replace(/<nav\b[^>]*class=["'][^"']*\btoc\b[^"']*["'][\s\S]*?<\/nav>/gi, "");
  chunk = chunk.replace(/<img\b[^>]*>/gi, "");
  chunk = chunk.replace(/<[^>]+>/g, " ");
  return chunk.trim().split(/\s+/).filter(Boolean).length;
}

function buildLiveSeoChecklist(
  html: string,
  seo: ReviewResponse["seo_metrics"] | null,
  hasHero: boolean,
  includeCharts?: boolean | null
): SeoCheckItem[] {
  if (!seo) return [];

  const hasTable = /<table[\s>]/i.test(html);
  const hasGraphic = /<svg[\s>]/i.test(html) || /stat-(grid|card)/i.test(html);
  const hasCta = /id=["']cta["']|class=["'][^"']*blog-cta/i.test(html);
  const h1Count = (html.match(/<h1[\s>]/gi) || []).length;
  const h3Count = (html.match(/<h3[\s>]/gi) || []).length;
  const hasList = /<ul[\s>]|<ol[\s>]/i.test(html);
  const hasBold = /<strong[\s>]|<b[\s>]/i.test(html);
  const hasConclusion =
    /id=["'](conclusion|key-takeaways|summary)["']/i.test(html) ||
    /<h2[^>]*>[^<]*(conclusion|key takeaway|takeaways)/i.test(html);
  const introWords = countIntroWords(html);
  const introOk = introWords >= 80 && introWords <= 180;
  const wordLabel = `Word count ${seo.word_count_min.toLocaleString()}–${seo.word_count_max.toLocaleString()} (strict)`;

  return [
    {
      id: 14,
      label: wordLabel,
      done: !!seo.word_count_valid,
      detail: `${(seo.word_count ?? 0).toLocaleString()} words${
        seo.word_count_valid ? "" : " — out of range (override available)"
      }`,
    },
    { id: 1, label: "Title tag 55–60 chars", done: !!seo.title_tag_valid },
    { id: 2, label: "Meta description 140–160 chars", done: !!seo.meta_description_valid },
    { id: 3, label: "Single H1 (mirrors title)", done: h1Count === 1 },
    {
      id: 4,
      label: "Intro 100–150 words (Hook + BLUF)",
      done: introOk,
      detail: `${introWords} words detected`,
    },
    { id: 5, label: "H3 subtopics under H2 sections", done: h3Count >= 2 },
    { id: 6, label: "Lists and bold key terms", done: hasList && hasBold },
    { id: 7, label: "Data table (mid-body)", done: hasTable },
    includeCharts === false
      ? {
          id: 8,
          label: "Chart or stat graphics",
          done: true,
          detail: "Skipped — charts off for this post",
        }
      : { id: 8, label: "Chart or stat graphics", done: hasGraphic },
    { id: 9, label: "Conclusion before CTA", done: hasConclusion },
    {
      id: 10,
      label: "Internal backlinks (min 3)",
      done: (seo.internal_links_count ?? 0) >= 3,
      detail: `${seo.internal_links_count ?? 0} found`,
    },
    {
      id: 11,
      label: "External authoritative links (min 2)",
      done: (seo.external_links_count ?? 0) >= 2,
      detail: `${seo.external_links_count ?? 0} found`,
    },
    { id: 12, label: "Closing CTA section", done: hasCta },
    { id: 13, label: "JSON-LD schema present", done: !!seo.has_json_ld },
    { id: 15, label: "Hero image attached", done: hasHero },
  ];
}

function ChecklistSection({
  checklist,
  checklistPct,
  checklistDone,
  compact = false,
}: {
  checklist: SeoCheckItem[];
  checklistPct: number;
  checklistDone: number;
  compact?: boolean;
}) {
  return (
    <section className="mb-6">
      <div className="mb-1 flex items-center justify-between gap-2">
        <h3 className="text-micro uppercase text-text-muted">SEO Checklist</h3>
        <span className="font-mono text-xs font-semibold text-hyper-primary">
          {checklistPct}%
        </span>
      </div>
      <p className="mb-3 text-[11px] text-text-muted">
        Live from article content — updates after Fix CTA, Repair Format, or redo
      </p>
      <div className="mb-3 h-2 overflow-hidden rounded-full bg-surface-2">
        <div
          className="h-full rounded-full bg-gradient-to-r from-hyper-primary to-hyper-orange transition-all duration-300"
          style={{ width: `${checklistPct}%` }}
        />
      </div>
      <p className="mb-3 text-xs text-text-secondary">
        {checklistDone} of {checklist.length} checks passing
      </p>
      <div className={cn("space-y-2", compact && "max-h-64 overflow-y-auto pr-1")}>
        {checklist.map((item) => (
          <div
            key={item.id}
            className={cn(
              "flex items-start gap-3 rounded-xl border px-3 py-2",
              item.done
                ? "border-emerald-100 bg-emerald-50/60"
                : "border-amber-100 bg-amber-50/40"
            )}
          >
            {item.done ? (
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
            ) : (
              <Circle className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" />
            )}
            <div className="min-w-0 flex-1">
              <p
                className={cn(
                  "text-xs leading-snug",
                  item.done ? "text-emerald-900" : "text-text-primary"
                )}
              >
                {item.label}
              </p>
              {item.detail && (
                <p className="mt-0.5 text-[10px] text-text-muted">{item.detail}</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function RevisionPromptPanel({
  feedback,
  setFeedback,
  loading,
  busyAction,
  history,
  onSend,
  onFixCta,
  onAddFaq,
  chartsOn = false,
  chartType = "auto",
  onChartTypeChange,
  onToggleCharts,
  onRepairFormat,
  onAbort,
  compact = false,
  wide = false,
}: {
  feedback: string;
  setFeedback: (v: string) => void;
  loading: boolean;
  busyAction?: string | null;
  history: { feedback: string; timestamp: string; type?: string }[];
  onSend: () => void;
  onFixCta: () => void;
  onAddFaq: () => void;
  chartsOn?: boolean;
  chartType?: ChartTypeId;
  onChartTypeChange?: (id: ChartTypeId) => void;
  onToggleCharts?: () => void;
  onRepairFormat: () => void;
  onAbort: () => void;
  compact?: boolean;
  wide?: boolean;
}) {
  const visibleHistory = history.filter((fb) => (fb as { type?: string }).type !== "system");
  const is = (action: string) => busyAction === action;

  return (
    <section
      className={cn(
        "rounded-2xl border border-hyper-border bg-white p-3 sm:p-4",
        !wide && "mb-2 bg-gradient-to-b from-[#f8f9fc] to-white"
      )}
    >
      <div
        className={cn(
          "gap-4",
          wide ? "lg:grid lg:grid-cols-[minmax(0,1fr)_auto] lg:items-start" : "block"
        )}
      >
        <div className="min-w-0">
          <div className="mb-2 flex items-start gap-2">
            <MessageSquare className="mt-0.5 h-4 w-4 shrink-0 text-hyper-primary" />
            <div>
              <h3 className="font-display text-sm font-semibold text-hyper-navy">
                Revision prompt
              </h3>
              <p className="mt-0.5 text-[11px] leading-snug text-text-muted">
                Tell the AI what to change, then press Send. FAQ stays off unless you click Add FAQ.
              </p>
            </div>
          </div>

          {visibleHistory.length > 0 && (
            <div
              className={cn(
                "mb-2 flex gap-2 overflow-x-auto pb-1",
                wide ? "max-h-16" : compact ? "max-h-28 flex-col space-y-2 overflow-y-auto" : "max-h-36 flex-col space-y-2 overflow-y-auto"
              )}
            >
              {visibleHistory.slice(-wide ? 4 : 6).map((fb, i) => (
                <div
                  key={`${fb.timestamp}-${i}`}
                  className={cn(
                    "rounded-lg bg-surface-1 px-3 py-2",
                    wide && "min-w-[12rem] max-w-[16rem] shrink-0"
                  )}
                >
                  <p className="text-[10px] text-text-muted">
                    {(fb as { type?: string }).type === "error" ? "Error" : "You"} ·{" "}
                    {new Date(fb.timestamp).toLocaleString()}
                  </p>
                  <p className="mt-0.5 line-clamp-2 text-xs text-text-primary">{fb.feedback}</p>
                </div>
              ))}
            </div>
          )}

          <div className="space-y-2">
            <Textarea
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              onKeyDown={(e) => {
                if ((e.metaKey || e.ctrlKey) && e.key === "Enter" && feedback.trim() && !loading) {
                  e.preventDefault();
                  onSend();
                }
              }}
              placeholder="e.g. Shorten intro, add a comparison table, stronger CTA…"
              rows={wide ? 2 : compact ? 3 : 4}
              className="w-full resize-y"
            />
            <div className="flex items-center justify-between gap-3">
              <p className="text-[10px] text-text-muted">⌘/Ctrl + Enter to send</p>
              <Button
                variant="orange"
                size="sm"
                className="shrink-0 px-4"
                disabled={loading || !feedback.trim()}
                loading={loading}
                onClick={onSend}
                aria-label="Send revision prompt"
              >
                <Send className="h-4 w-4" />
                Send
              </Button>
            </div>
          </div>
        </div>

        <div
          className={cn(
            "flex flex-wrap gap-2",
            wide
              ? "mt-3 border-t border-hyper-border pt-3 lg:mt-0 lg:w-44 lg:flex-col lg:border-l lg:border-t-0 lg:pl-4 lg:pt-0"
              : "mt-3 border-t border-hyper-border pt-3"
          )}
        >
          <Button
            variant="outline"
            size="sm"
            disabled={loading}
            loading={is("fix-cta")}
            onClick={onFixCta}
            className={wide ? "lg:w-full lg:justify-start" : undefined}
          >
            <Wrench className="h-3.5 w-3.5" />
            {is("fix-cta") ? "Fixing CTA…" : "Fix CTA"}
          </Button>
          <Button
            variant="outline"
            size="sm"
            disabled={loading}
            loading={is("add-faq")}
            onClick={onAddFaq}
            className={wide ? "lg:w-full lg:justify-start" : undefined}
          >
            <FileText className="h-3.5 w-3.5" />
            {is("add-faq") ? "Adding FAQ…" : "Add FAQ"}
          </Button>
          {onToggleCharts ? (
            <Button
              variant={chartsOn ? "orange" : "outline"}
              size="sm"
              disabled={loading}
              loading={is("charts")}
              onClick={onToggleCharts}
              className={wide ? "lg:w-full lg:justify-start" : undefined}
            >
              <BarChart2 className="h-3.5 w-3.5" />
              {is("charts")
                ? chartsOn
                  ? "Removing charts…"
                  : "Adding charts…"
                : chartsOn
                  ? "Charts on"
                  : "Add charts"}
            </Button>
          ) : null}
          {onChartTypeChange ? (
            <div className={cn("w-full", wide ? "lg:col-span-1" : "")}>
              <ChartTypeSelector
                compact
                label={chartsOn ? "Change chart type" : "Chart type (when adding)"}
                value={chartType}
                onChange={onChartTypeChange}
                disabled={loading || is("charts")}
              />
            </div>
          ) : null}
          <Button
            variant="secondary"
            size="sm"
            disabled={loading}
            loading={is("repair-format")}
            onClick={onRepairFormat}
            className={wide ? "lg:w-full lg:justify-start" : undefined}
          >
            <Sparkles className="h-3.5 w-3.5" />
            {is("repair-format") ? "Repairing…" : "Repair Format"}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            disabled={loading}
            loading={is("abort")}
            onClick={onAbort}
            className={wide ? "lg:w-full lg:justify-start" : undefined}
          >
            {is("abort") ? "Aborting…" : "Abort"}
          </Button>
        </div>
      </div>
    </section>
  );
}
