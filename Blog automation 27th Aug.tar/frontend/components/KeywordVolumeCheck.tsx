"use client";

import { useState } from "react";
import { Loader2, Search, TrendingUp } from "lucide-react";
import { api, KeywordVolumeMetrics } from "@/lib/api";
import { cn } from "@/lib/cn";

export type KeywordMetrics = {
  keyword: string;
  search_volume: number | null;
  cpc: number | null;
  seo_difficulty: number | null;
  paid_difficulty: number | null;
  source_tool?: string | null;
};

function fromApi(m: KeywordVolumeMetrics): KeywordMetrics {
  return {
    keyword: m.keyword || "",
    search_volume: m.search_volume ?? null,
    cpc: m.cpc ?? null,
    seo_difficulty: m.seo_difficulty ?? null,
    paid_difficulty: m.paid_difficulty ?? null,
    source_tool: m.source_tool,
  };
}

function formatVolume(n: number | null): string {
  if (n == null) return "—";
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(n >= 10_000 ? 0 : 1)}K`;
  return n.toLocaleString();
}

function formatCpc(n: number | null): string {
  if (n == null) return "—";
  return `$${n.toFixed(2)}`;
}

function difficultyTone(n: number | null): string {
  if (n == null) return "text-text-muted";
  if (n < 30) return "text-emerald-700";
  if (n < 60) return "text-amber-700";
  return "text-hyper-red";
}

export function KeywordMetricsCard({
  metrics,
  compact,
}: {
  metrics: KeywordMetrics;
  compact?: boolean;
}) {
  const difficulty =
    metrics.seo_difficulty != null
      ? metrics.seo_difficulty
      : metrics.paid_difficulty;

  return (
    <div
      className={cn(
        "rounded-xl border border-hyper-primary/15 bg-hyper-primary/5",
        compact ? "px-3 py-2" : "px-3 py-3"
      )}
    >
      {!compact && metrics.keyword ? (
        <p className="mb-2 truncate text-[11px] font-medium text-hyper-navy">
          {metrics.keyword}
        </p>
      ) : null}
      <div className="grid grid-cols-3 gap-2">
        <Metric
          label="Volume"
          value={formatVolume(metrics.search_volume)}
          hint="/mo"
          compact={compact}
        />
        <Metric label="CPC" value={formatCpc(metrics.cpc)} compact={compact} />
        <Metric
          label="Difficulty"
          value={difficulty != null ? String(Math.round(difficulty)) : "—"}
          valueClass={difficultyTone(difficulty)}
          compact={compact}
        />
      </div>
      {metrics.source_tool ? (
        <p className="mt-1.5 text-[10px] text-text-muted">via {metrics.source_tool}</p>
      ) : null}
    </div>
  );
}

function Metric({
  label,
  value,
  hint,
  valueClass,
  compact,
}: {
  label: string;
  value: string;
  hint?: string;
  valueClass?: string;
  compact?: boolean;
}) {
  return (
    <div>
      <p className="text-[10px] font-medium uppercase tracking-wide text-text-muted">
        {label}
      </p>
      <p
        className={cn(
          "font-semibold tabular-nums text-hyper-navy",
          compact ? "text-sm" : "text-base",
          valueClass
        )}
      >
        {value}
        {hint ? (
          <span className="ml-0.5 text-[10px] font-normal text-text-muted">{hint}</span>
        ) : null}
      </p>
    </div>
  );
}

async function fetchMetrics(keyword: string): Promise<KeywordMetrics> {
  const data = await api.checkUbersuggestKeyword(keyword);
  return fromApi(data);
}

function friendlyError(e: unknown): string {
  const msg = String(e);
  if (msg.includes("Failed to fetch") || msg.includes("NetworkError")) {
    return "Backend unreachable. Is the API running on port 8000?";
  }
  if (msg.toLowerCase().includes("not connected") || msg.includes("409")) {
    return "Connect Ubersuggest in Settings → Integrations first.";
  }
  if (msg.toLowerCase().includes("daily") && msg.toLowerCase().includes("limit")) {
    return "Ubersuggest free plan daily limit reached. Upgrade or try again tomorrow.";
  }
  return msg.replace(/^Error:\s*/i, "");
}

/** Inline check button for a topic card. */
export function TopicKeywordCheck({ keyword }: { keyword: string }) {
  const [loading, setLoading] = useState(false);
  const [metrics, setMetrics] = useState<KeywordMetrics | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function run() {
    const kw = keyword.trim();
    if (!kw) return;
    setLoading(true);
    setError(null);
    setMetrics(null);
    try {
      setMetrics(await fetchMetrics(kw));
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-2">
      <button
        type="button"
        onClick={run}
        disabled={loading || !keyword.trim()}
        className="inline-flex w-full items-center justify-center gap-1.5 rounded-lg border border-hyper-border bg-surface-0 px-2.5 py-1.5 text-[11px] font-medium text-hyper-navy transition hover:border-hyper-primary/40 hover:bg-hyper-primary/5 disabled:cursor-not-allowed disabled:opacity-40"
      >
        {loading ? (
          <Loader2 className="h-3 w-3 animate-spin" />
        ) : (
          <TrendingUp className="h-3 w-3 text-hyper-primary" />
        )}
        {metrics ? "Refresh volume" : "Check volume"}
      </button>
      {error && (
        <p className="rounded-lg border border-amber-200 bg-amber-50 px-2 py-1.5 text-[11px] text-amber-900">
          {error}
        </p>
      )}
      {metrics && !error && <KeywordMetricsCard metrics={metrics} compact />}
    </div>
  );
}

/** Manual keyword check for custom topics on the board. */
export function ManualKeywordCheck() {
  const [keyword, setKeyword] = useState("");
  const [loading, setLoading] = useState(false);
  const [metrics, setMetrics] = useState<KeywordMetrics | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function run() {
    const kw = keyword.trim();
    if (!kw) return;
    setLoading(true);
    setError(null);
    setMetrics(null);
    try {
      setMetrics(await fetchMetrics(kw));
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="rounded-xl border border-dashed border-hyper-border bg-surface-1/40 p-4">
      <div className="mb-2 flex items-center gap-2">
        <Search className="h-3.5 w-3.5 text-hyper-primary" />
        <p className="text-sm font-medium text-hyper-navy">Check keyword volume</p>
      </div>
      <p className="mb-3 text-xs text-text-muted">
        Optional — look up search volume / difficulty before you pick or write a topic.
      </p>
      <div className="flex flex-wrap gap-2">
        <input
          type="text"
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") run();
          }}
          placeholder="e.g. ANPR parking"
          className="min-w-[160px] flex-1 rounded-xl border border-hyper-border bg-surface-0 px-3 py-2 text-sm focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/20"
        />
        <button
          type="button"
          onClick={run}
          disabled={loading || !keyword.trim()}
          className="inline-flex items-center gap-1.5 rounded-xl bg-hyper-navy px-4 py-2 text-sm font-medium text-white hover:bg-hyper-primary disabled:cursor-not-allowed disabled:opacity-40"
        >
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
          Check
        </button>
      </div>
      {error && (
        <p className="mt-2 rounded-lg border border-amber-200 bg-amber-50 px-2.5 py-1.5 text-[11px] text-amber-900">
          {error}
        </p>
      )}
      {metrics && (
        <div className="mt-3">
          <KeywordMetricsCard metrics={metrics} />
        </div>
      )}
    </div>
  );
}
