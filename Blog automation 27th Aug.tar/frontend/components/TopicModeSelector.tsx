"use client";

import { useState } from "react";
import { Loader2, Sparkles, UserCheck, Users } from "lucide-react";
import { cn } from "@/lib/cn";
import { TopicSelectionMode } from "@/lib/api";

const MODES: {
  id: TopicSelectionMode;
  label: string;
  description: string;
  icon: React.ElementType;
}[] = [
  {
    id: "manual",
    label: "Manual",
    description: "No auto-run. You start discovery, pick the topic, then approve publish — each step has its own button.",
    icon: UserCheck,
  },
  {
    id: "auto",
    label: "Auto",
    description: "At the scheduled time: discover → pick best SEO-volume topic (Ubersuggest) → write blog → notify Teams.",
    icon: Sparkles,
  },
  {
    id: "hybrid",
    label: "Both",
    description: "At the scheduled time: discover + send topics to Teams, then wait here for you to pick a topic and approve publish.",
    icon: Users,
  },
];

export { MODES as TOPIC_SELECTION_MODES };

type Props = {
  /** Current mode for this product */
  value: TopicSelectionMode | null | undefined;
  onChange: (mode: TopicSelectionMode) => void | Promise<void>;
  disabled?: boolean;
  compact?: boolean;
  /** Show helper copy under the control */
  showHint?: boolean;
  className?: string;
};

export default function TopicModeSelector({
  value,
  onChange,
  disabled = false,
  compact = false,
  showHint = false,
  className,
}: Props) {
  const [saving, setSaving] = useState(false);
  const mode = value ?? null;

  async function select(next: TopicSelectionMode) {
    if (next === mode || saving || disabled) return;
    setSaving(true);
    try {
      await onChange(next);
    } finally {
      setSaving(false);
    }
  }

  const controls = (
    <div
      className={cn(
        "inline-flex rounded-lg border border-hyper-border bg-surface-0 p-0.5",
        className
      )}
      role="radiogroup"
      aria-label="Automation mode"
    >
      {MODES.map((m) => {
        const active = mode === m.id;
        return (
          <button
            key={m.id}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => select(m.id)}
            disabled={saving || disabled}
            title={m.description}
            className={cn(
              "rounded-md px-3 py-1.5 text-xs font-medium transition-all duration-150 disabled:opacity-50",
              active
                ? "bg-hyper-primary text-white shadow-sm"
                : "text-text-secondary hover:text-hyper-navy"
            )}
          >
            {m.label}
          </button>
        );
      })}
      {saving && (
        <span className="flex items-center px-2">
          <Loader2 className="h-3.5 w-3.5 animate-spin text-text-muted" />
        </span>
      )}
    </div>
  );

  if (compact) {
    return (
      <div className="space-y-1.5">
        {controls}
        {!mode && (
          <p className="text-[11px] font-medium text-amber-700">
            Select Manual, Auto, or Both for this product
          </p>
        )}
        {showHint && mode && (
          <p className="text-[11px] leading-snug text-text-muted">
            {MODES.find((m) => m.id === mode)?.description}
          </p>
        )}
      </div>
    );
  }

  return (
    <div className={cn("space-y-2.5", className)}>
      <div className="grid gap-2.5 sm:grid-cols-3">
        {MODES.map((m) => {
          const Icon = m.icon;
          const active = mode === m.id;
          return (
            <button
              key={m.id}
              type="button"
              onClick={() => select(m.id)}
              disabled={saving || disabled}
              title={m.description}
              className={cn(
                "relative flex flex-col items-start gap-2 rounded-2xl border px-3.5 py-3.5 text-left transition-all duration-200 disabled:opacity-50 active:scale-[0.97]",
                active
                  ? "border-hyper-navy bg-hyper-navy text-white shadow-nav-active"
                  : "border-hyper-border/80 bg-white/95 text-text-secondary shadow-soft hover:-translate-y-0.5 hover:border-hyper-primary/35 hover:shadow-card"
              )}
            >
              <span
                className={cn(
                  "flex h-8 w-8 items-center justify-center rounded-xl transition-transform duration-200",
                  active ? "bg-white/12 text-hyper-orange" : "bg-surface-1 text-hyper-primary group-hover:scale-105"
                )}
              >
                <Icon className="h-4 w-4" />
              </span>
              <div className="min-w-0">
                <p className={cn("text-sm font-semibold", active ? "text-white" : "text-hyper-navy")}>
                  {m.label}
                </p>
                <p
                  className={cn(
                    "mt-1 text-[11px] leading-snug",
                    active ? "text-white/70" : "text-text-muted"
                  )}
                >
                  {m.description}
                </p>
              </div>
            </button>
          );
        })}
      </div>
      {!mode && (
        <p className="text-[11px] font-medium text-amber-700">
          Choose one mode before relying on scheduled runs for this product.
        </p>
      )}
    </div>
  );
}
