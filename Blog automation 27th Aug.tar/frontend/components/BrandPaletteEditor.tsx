"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Check,
  Copy,
  Info,
  Loader2,
  Palette,
  Plus,
  RotateCcw,
  Save,
  Trash2,
} from "lucide-react";
import {
  BRAND_PALETTE_SLOTS,
  BrandColorEntry,
  BrandPalette,
  BrandPaletteKey,
  DEFAULT_BRAND_PALETTE,
  allPaletteSwatches,
  createCustomColor,
  normalizeBrandPalette,
  normalizeHex,
} from "@/lib/brandPalette";
import { api, BrandPaletteBatch } from "@/lib/api";
import Button from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { cn } from "@/lib/cn";
import { useToast } from "@/contexts/ToastContext";

type Props = {
  value: BrandPalette;
  onChange: (palette: BrandPalette) => void;
  productName?: string;
};

/** Hex field that keeps draft text while typing; commits only valid #RRGGBB. */
function HexInput({
  value,
  onCommit,
  ariaLabel,
  className,
}: {
  value: string;
  onCommit: (hex: string) => void;
  ariaLabel: string;
  className?: string;
}) {
  const [draft, setDraft] = useState(value);

  useEffect(() => {
    setDraft(value);
  }, [value]);

  return (
    <Input
      value={draft}
      onChange={(e) => {
        const next = e.target.value;
        setDraft(next);
        const normalized = normalizeHex(next);
        if (normalized) onCommit(normalized);
      }}
      onBlur={() => {
        const normalized = normalizeHex(draft);
        if (normalized) {
          onCommit(normalized);
          setDraft(normalized);
        } else {
          setDraft(value);
        }
      }}
      placeholder="#252a61"
      className={cn(
        "font-mono text-xs uppercase",
        !normalizeHex(draft) && draft.trim() && "border-red-300 focus:border-red-400",
        className
      )}
      spellCheck={false}
      aria-label={ariaLabel}
    />
  );
}

function ColorRow({
  label,
  hint,
  color,
  onChange,
  onCopy,
  onLabelChange,
  onRemove,
  labelEditable = false,
}: {
  label: string;
  hint: string;
  color: string;
  onChange: (hex: string) => void;
  onCopy: (hex: string) => void;
  onLabelChange?: (label: string) => void;
  onRemove?: () => void;
  labelEditable?: boolean;
}) {
  const safeColor = normalizeHex(color) ?? "#252a61";

  return (
    <div className="group flex flex-col gap-3 rounded-xl border border-transparent px-2 py-2 transition hover:border-hyper-border hover:bg-surface-1/80 sm:flex-row sm:items-center sm:gap-3">
      <div className="flex min-w-0 flex-1 items-center gap-3">
        <label
          className="relative h-10 w-10 shrink-0 cursor-pointer overflow-hidden rounded-xl shadow-sm ring-1 ring-black/10 transition group-hover:ring-hyper-primary/30"
          title={`Pick ${label.toLowerCase()} color`}
        >
          <span className="absolute inset-0" style={{ backgroundColor: safeColor }} aria-hidden />
          <input
            type="color"
            value={safeColor}
            onChange={(e) => {
              const next = normalizeHex(e.target.value);
              if (next) onChange(next);
            }}
            className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
            aria-label={`${label} color picker`}
          />
        </label>

        <div className="min-w-0 flex-1">
          {labelEditable && onLabelChange ? (
            <Input
              value={label}
              onChange={(e) => onLabelChange(e.target.value)}
              placeholder="Color name"
              className="h-8 text-sm font-medium"
            />
          ) : (
            <p className="text-sm font-medium text-hyper-navy">{label}</p>
          )}
          <p className="text-xs text-text-muted">{hint}</p>
        </div>
      </div>

      <div className="flex items-center gap-2 pl-[3.25rem] sm:pl-0">
        <HexInput
          value={safeColor}
          onCommit={onChange}
          ariaLabel={`${label} hex`}
          className="h-9 w-[7.5rem]"
        />
        <button
          type="button"
          onClick={() => onCopy(safeColor)}
          className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-hyper-border text-text-muted transition hover:border-hyper-primary/30 hover:text-hyper-primary"
          aria-label={`Copy ${label} hex`}
        >
          <Copy className="h-3.5 w-3.5" />
        </button>
        {onRemove && (
          <button
            type="button"
            onClick={onRemove}
            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-hyper-border text-text-muted transition hover:border-red-200 hover:bg-red-50 hover:text-hyper-red"
            aria-label={`Remove ${label}`}
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        )}
      </div>
    </div>
  );
}

function coreColorsMatch(
  a: Pick<BrandPalette, BrandPaletteKey>,
  b: Pick<BrandPalette, BrandPaletteKey>
) {
  return BRAND_PALETTE_SLOTS.every((slot) => a[slot.key] === b[slot.key]);
}

export default function BrandPaletteEditor({ value, onChange, productName }: Props) {
  const toast = useToast();
  const palette = normalizeBrandPalette(value);
  const swatches = allPaletteSwatches(palette);
  const [copied, setCopied] = useState<string | null>(null);
  const [batches, setBatches] = useState<BrandPaletteBatch[]>([]);
  const [loadingBatches, setLoadingBatches] = useState(true);
  const [savingBatch, setSavingBatch] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [batchName, setBatchName] = useState("");
  const [showSaveForm, setShowSaveForm] = useState(false);

  const loadBatches = useCallback(async () => {
    setLoadingBatches(true);
    try {
      const res = await api.getBrandPaletteBatches();
      setBatches(res.batches || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingBatches(false);
    }
  }, []);

  useEffect(() => {
    loadBatches();
  }, [loadBatches]);

  function commitPalette(next: BrandPalette) {
    onChange(normalizeBrandPalette(next));
  }

  function updateSlot(key: BrandPaletteKey, hex: string) {
    const normalized = normalizeHex(hex);
    if (!normalized) return;
    commitPalette({ ...palette, [key]: normalized });
  }

  function applyBatch(batch: BrandPaletteBatch) {
    commitPalette({
      ...palette,
      primary: batch.colors.primary,
      navy: batch.colors.navy,
      accent: batch.colors.accent,
      cta: batch.colors.cta,
      link: batch.colors.link,
    });
    toast.success("Palette applied", `"${batch.name}" applied to this product`);
  }

  function resetToDefault() {
    commitPalette({
      ...DEFAULT_BRAND_PALETTE,
      custom: palette.custom,
    });
  }

  function addCustomColor() {
    commitPalette({
      ...palette,
      custom: [
        ...palette.custom,
        createCustomColor(`Custom ${palette.custom.length + 1}`, "#64748b"),
      ],
    });
  }

  function updateCustomColor(id: string, patch: Partial<BrandColorEntry>) {
    const nextCustom = palette.custom.map((entry) => {
      if (entry.id !== id) return entry;
      const merged = { ...entry, ...patch };
      if (patch.hex !== undefined) {
        const normalized = normalizeHex(patch.hex);
        if (!normalized) return entry;
        merged.hex = normalized;
      }
      if (patch.label !== undefined) {
        merged.label = patch.label.trim().slice(0, 64) || entry.label;
      }
      return merged;
    });
    commitPalette({ ...palette, custom: nextCustom });
  }

  function deleteCustomColor(id: string) {
    commitPalette({
      ...palette,
      custom: palette.custom.filter((entry) => entry.id !== id),
    });
  }

  async function saveAsNewBatch() {
    const name = batchName.trim();
    if (!name) {
      toast.error("Name required", "Enter a name for this color batch");
      return;
    }
    setSavingBatch(true);
    try {
      const created = await api.createBrandPaletteBatch({
        name,
        colors: {
          primary: palette.primary,
          navy: palette.navy,
          accent: palette.accent,
          cta: palette.cta,
          link: palette.link,
        },
      });
      setBatches((prev) => [...prev, created]);
      setBatchName("");
      setShowSaveForm(false);
      toast.success("Batch saved", `"${created.name}" is available for all products`);
    } catch (e) {
      toast.error("Save failed", e instanceof Error ? e.message : String(e));
    } finally {
      setSavingBatch(false);
    }
  }

  async function removeBatch(batch: BrandPaletteBatch) {
    if (batch.builtin && batch.id === "hyperpark") {
      toast.error("Cannot delete", "The default HyperPark palette cannot be removed");
      return;
    }
    if (!confirm(`Delete palette batch "${batch.name}"? This removes it for all products.`)) {
      return;
    }
    setDeletingId(batch.id);
    try {
      const res = await api.deleteBrandPaletteBatch(batch.id);
      setBatches(res.batches || []);
      toast.success("Batch deleted", `"${batch.name}" removed`);
    } catch (e) {
      toast.error("Delete failed", e instanceof Error ? e.message : String(e));
    } finally {
      setDeletingId(null);
    }
  }

  async function copyHex(hex: string) {
    try {
      await navigator.clipboard.writeText(hex);
      setCopied(hex);
      window.setTimeout(() => setCopied(null), 1500);
    } catch {
      /* ignore */
    }
  }

  const activeBatchId =
    batches.find((b) => coreColorsMatch(palette, b.colors))?.id ?? null;

  return (
    <div className="space-y-6">
      {/* Palette batch chooser */}
      <section className="rounded-2xl border border-hyper-border bg-surface-1/30 p-3 sm:p-4">
        <div className="mb-3 flex flex-wrap items-start justify-between gap-2 px-1">
          <div>
            <h4 className="text-sm font-semibold text-hyper-navy">Choose a color batch</h4>
            <p className="mt-0.5 text-xs text-text-muted">
              Apply a saved 5-color set (Primary, Navy, Accent, CTA, Links) to this product. Create
              new batches anytime — they are stored on the server for every product.
            </p>
          </div>
          <Button
            type="button"
            variant="orange"
            size="sm"
            onClick={() => setShowSaveForm((v) => !v)}
          >
            <Plus className="h-3.5 w-3.5" />
            New batch
          </Button>
        </div>

        {showSaveForm && (
          <div className="mb-3 flex flex-col gap-2 rounded-xl border border-hyper-orange/25 bg-white p-3 sm:flex-row sm:items-end">
            <label className="min-w-0 flex-1">
              <span className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-text-muted">
                Batch name
              </span>
              <Input
                value={batchName}
                onChange={(e) => setBatchName(e.target.value)}
                placeholder="e.g. Smart Parking Blue"
              />
            </label>
            <Button
              type="button"
              variant="primary"
              size="sm"
              loading={savingBatch}
              disabled={savingBatch || !batchName.trim()}
              onClick={saveAsNewBatch}
              className="btn-sheen relative overflow-hidden"
            >
              <Save className="h-3.5 w-3.5" />
              Save current colors
            </Button>
          </div>
        )}

        {loadingBatches ? (
          <div className="flex items-center gap-2 px-1 py-4 text-sm text-text-muted">
            <Loader2 className="h-4 w-4 animate-spin" />
            Loading palette batches…
          </div>
        ) : (
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {batches.map((batch) => {
              const active = activeBatchId === batch.id;
              return (
                <div
                  key={batch.id}
                  className={cn(
                    "overflow-hidden rounded-xl border transition",
                    active
                      ? "border-hyper-orange/40 ring-1 ring-hyper-orange/25 shadow-sm"
                      : "border-hyper-border bg-white hover:border-hyper-navy/20"
                  )}
                >
                  <button
                    type="button"
                    onClick={() => applyBatch(batch)}
                    className="block w-full text-left"
                  >
                    <div className="flex h-8">
                      {BRAND_PALETTE_SLOTS.map((slot) => (
                        <span
                          key={slot.key}
                          className="flex-1"
                          style={{ backgroundColor: batch.colors[slot.key] }}
                          title={`${slot.label}: ${batch.colors[slot.key]}`}
                        />
                      ))}
                    </div>
                    <div className="flex items-start justify-between gap-2 px-3 py-2.5">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-hyper-navy">
                          {batch.name}
                        </p>
                        <p className="mt-0.5 font-mono text-[10px] uppercase text-text-muted">
                          {batch.colors.primary} · {batch.colors.accent}
                        </p>
                      </div>
                      {active && (
                        <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-medium text-emerald-700">
                          <Check className="h-3 w-3" />
                          Active
                        </span>
                      )}
                    </div>
                  </button>
                  {!(batch.builtin && batch.id === "hyperpark") && (
                    <div className="border-t border-hyper-border/70 px-2 py-1.5">
                      <button
                        type="button"
                        onClick={() => removeBatch(batch)}
                        disabled={deletingId === batch.id}
                        className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-medium text-text-muted transition hover:bg-red-50 hover:text-hyper-red disabled:opacity-50"
                      >
                        {deletingId === batch.id ? (
                          <Loader2 className="h-3 w-3 animate-spin" />
                        ) : (
                          <Trash2 className="h-3 w-3" />
                        )}
                        Delete batch
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Live preview */}
      <div className="overflow-hidden rounded-2xl border border-hyper-primary/15 bg-gradient-to-br from-surface-0 via-surface-1 to-hyper-primary/5">
        <div className="flex h-16 sm:h-20">
          {BRAND_PALETTE_SLOTS.map((slot) => (
            <div
              key={slot.key}
              className="relative flex-1 transition-all"
              style={{ backgroundColor: palette[slot.key] }}
              title={`${slot.label}: ${palette[slot.key]}`}
            />
          ))}
          {palette.custom.map((entry) => (
            <div
              key={entry.id}
              className="flex-1 border-l border-white/20"
              style={{ backgroundColor: entry.hex }}
              title={`${entry.label}: ${entry.hex}`}
            />
          ))}
        </div>

        <div className="border-t border-hyper-border/60 bg-surface-0/80 px-4 py-4 backdrop-blur-sm sm:px-5">
          <div className="mb-1 flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-hyper-primary/10 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-hyper-primary">
              Live preview
            </span>
            {activeBatchId && (
              <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-0.5 text-[10px] font-medium text-emerald-700">
                <Check className="h-3 w-3" />
                {batches.find((b) => b.id === activeBatchId)?.name || "Saved batch"}
              </span>
            )}
          </div>
          <p className="text-sm text-text-secondary">
            {productName
              ? `Brand colors for ${productName} — blogs use these exact hex codes for headings, charts, CTAs, and links.`
              : "Blogs use these exact hex codes for headings, charts, CTAs, and links."}
          </p>

          <div className="mt-3 flex flex-wrap gap-2">
            {swatches.map((swatch) => (
              <button
                key={`${swatch.label}-${swatch.hex}`}
                type="button"
                onClick={() => copyHex(swatch.hex)}
                className="inline-flex items-center gap-2 rounded-lg border border-hyper-border bg-surface-0 px-2.5 py-1.5 text-left transition hover:border-hyper-primary/30 hover:shadow-sm"
                title="Click to copy hex"
              >
                <span
                  className="h-4 w-4 shrink-0 rounded-md ring-1 ring-black/10"
                  style={{ backgroundColor: swatch.hex }}
                />
                <span className="text-[11px] font-medium text-hyper-navy">{swatch.label}</span>
                <span className="font-mono text-[10px] uppercase text-text-muted">
                  {copied === swatch.hex ? "Copied!" : swatch.hex}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Fine-tune list — core + custom in the same format */}
      <section className="rounded-2xl border border-hyper-border bg-surface-1/30 p-3 sm:p-4">
        <div className="mb-3 flex flex-wrap items-start justify-between gap-2 px-2">
          <div className="flex items-start gap-2">
            <Palette className="mt-0.5 h-4 w-4 shrink-0 text-hyper-primary" />
            <div>
              <h4 className="text-sm font-semibold text-hyper-navy">Product brand colors</h4>
              <p className="text-xs text-text-muted">
                Fine-tune hex codes for this product, then optionally save them as a new batch for
                reuse.
              </p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button type="button" variant="ghost" size="sm" onClick={resetToDefault}>
              <RotateCcw className="h-3.5 w-3.5" />
              Reset core
            </Button>
            <Button type="button" variant="outline" size="sm" onClick={addCustomColor}>
              <Plus className="h-3.5 w-3.5" />
              Add color
            </Button>
          </div>
        </div>

        <div className="divide-y divide-hyper-border/60">
          {BRAND_PALETTE_SLOTS.map((slot) => (
            <ColorRow
              key={slot.key}
              label={slot.label}
              hint={slot.description}
              color={palette[slot.key]}
              onChange={(hex) => updateSlot(slot.key, hex)}
              onCopy={copyHex}
            />
          ))}

          {palette.custom.map((entry, index) => (
            <ColorRow
              key={entry.id}
              label={entry.label}
              hint={`Extra brand color ${index + 1} · used in charts & graphics`}
              color={entry.hex}
              onChange={(hex) => updateCustomColor(entry.id, { hex })}
              onCopy={copyHex}
              labelEditable
              onLabelChange={(label) => updateCustomColor(entry.id, { label })}
              onRemove={() => deleteCustomColor(entry.id)}
            />
          ))}
        </div>

        {palette.custom.length === 0 && (
          <button
            type="button"
            onClick={addCustomColor}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-hyper-border bg-surface-0/60 px-4 py-3 text-sm text-text-secondary transition hover:border-hyper-primary/40 hover:text-hyper-navy"
          >
            <Plus className="h-4 w-4" />
            Add another color to this list
          </button>
        )}
      </section>

      <div className="flex items-start gap-2 rounded-xl border border-hyper-primary/10 bg-hyper-primary/[0.04] px-3.5 py-3 text-xs text-text-secondary">
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-hyper-primary" />
        <p>
          Click <strong className="text-hyper-navy">Save product</strong> to store colors on this
          product. Use <strong className="text-hyper-navy">New batch</strong> to save the current
          5-color set on the server so every product can choose it.
        </p>
      </div>
    </div>
  );
}
