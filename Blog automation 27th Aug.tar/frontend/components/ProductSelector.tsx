"use client";

import { useCallback, useEffect, useState } from "react";
import { Box, ChevronDown, ExternalLink, FileText, Loader2, Settings2 } from "lucide-react";
import Link from "next/link";
import { cn } from "@/lib/cn";
import { api, Product } from "@/lib/api";

const STORAGE_KEY = "hyperpark_active_product_id";

function modeLabel(mode?: string | null) {
  if (mode === "auto") return "Auto";
  if (mode === "hybrid") return "Both";
  return "Manual";
}

export default function ProductSelector({
  variant = "dropdown",
  onChange,
}: {
  variant?: "dropdown" | "cards";
  onChange?: (productId: number, product: Product | null) => void;
}) {
  const [products, setProducts] = useState<Product[]>([]);
  const [activeId, setActiveId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const activeProduct = products.find((p) => p.id === activeId) ?? null;

  const syncActiveProduct = useCallback(
    async (silent = false) => {
      if (!silent) setLoading(true);
      try {
        const [list, active] = await Promise.all([
          api.getProducts(),
          api.getActiveProduct(),
        ]);
        setProducts(list);
        const id = active.product_id;
        setActiveId((prev) => {
          if (prev === id) return prev;
          queueMicrotask(() => onChange?.(id, active.product));
          return id;
        });
        localStorage.setItem(STORAGE_KEY, String(id));
      } catch {
        const stored = localStorage.getItem(STORAGE_KEY);
        const list = await api.getProducts().catch(() => []);
        setProducts(list);
        if (stored && /^\d+$/.test(stored)) {
          const id = Number(stored);
          setActiveId((prev) => {
            if (prev === id) return prev;
            queueMicrotask(
              () => onChange?.(id, list.find((p) => p.id === id) ?? null)
            );
            return id;
          });
        }
      } finally {
        if (!silent) setLoading(false);
      }
    },
    [onChange]
  );

  useEffect(() => {
    syncActiveProduct();
  }, [syncActiveProduct]);

  useEffect(() => {
    const onFocus = () => syncActiveProduct(true);
    window.addEventListener("focus", onFocus);
    return () => window.removeEventListener("focus", onFocus);
  }, [syncActiveProduct]);

  async function select(productId: number) {
    if (productId === activeId || saving) return;
    setSaving(true);
    try {
      const res = await api.setActiveProduct(productId);
      setActiveId(res.product_id);
      setProducts((prev) => {
        const exists = prev.some((p) => p.id === res.product.id);
        if (exists) {
          return prev.map((p) => (p.id === res.product.id ? res.product : p));
        }
        return [...prev, res.product];
      });
      localStorage.setItem(STORAGE_KEY, String(res.product_id));
      onChange?.(res.product_id, res.product);
    } catch (e) {
      alert(`Failed to save product selection: ${e}`);
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-xs text-text-muted">
        <Loader2 className="h-3.5 w-3.5 animate-spin" />
        Loading products...
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <p className="text-xs text-text-muted">
        No products yet.{" "}
        <Link href="/settings" className="font-medium text-hyper-primary hover:underline">
          Add one in Settings
        </Link>
      </p>
    );
  }

  if (variant === "dropdown") {
    return (
      <div className="flex flex-col gap-3 lg:flex-row lg:items-stretch lg:gap-4">
        <div className="w-full max-w-xs shrink-0">
          <label
            htmlFor="product-line-select"
            className="mb-1.5 block text-micro uppercase tracking-wider text-text-muted"
          >
            Product line
          </label>
          <div className="relative">
            <Box className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-hyper-primary" />
            <select
              id="product-line-select"
              value={activeId ?? ""}
              onChange={(e) => select(Number(e.target.value))}
              disabled={saving}
              className={cn(
                "h-11 w-full appearance-none rounded-xl border border-hyper-border/80 bg-white/95 py-2.5 pl-10 pr-10 text-sm font-semibold text-hyper-navy shadow-soft",
                "transition-all duration-200 hover:border-hyper-primary/30 focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/15 focus:shadow-card",
                "disabled:cursor-not-allowed disabled:opacity-60"
              )}
            >
              {products.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
            {saving ? (
              <Loader2 className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-text-muted" />
            ) : (
              <ChevronDown className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-text-muted" />
            )}
          </div>
        </div>

        {activeProduct && (
          <div className="relative min-w-0 flex-1 overflow-hidden rounded-2xl border border-hyper-border/70 bg-gradient-to-br from-white via-white to-hyper-primary/[0.05] px-4 py-3.5 shadow-soft">
            <div className="pointer-events-none absolute -right-8 -top-8 h-24 w-24 rounded-full bg-hyper-orange/12 blur-2xl" />
            <div className="relative flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="truncate text-sm font-bold tracking-tight text-hyper-navy">
                    {activeProduct.company_name}
                  </p>
                  <span className="inline-flex items-center rounded-lg bg-hyper-navy/[0.06] px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-hyper-navy">
                    {modeLabel(activeProduct.topic_selection_mode)}
                  </span>
                </div>
                <p className="mt-1 line-clamp-1 text-xs text-text-secondary">
                  {activeProduct.description || "No description set for this product."}
                </p>
                <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-text-muted">
                  <a
                    href={activeProduct.website_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 font-mono transition-colors hover:text-hyper-primary"
                  >
                    {activeProduct.website_url.replace(/^https?:\/\//, "")}
                    <ExternalLink className="h-3 w-3" />
                  </a>
                  {activeProduct.has_pdf && (
                    <span className="inline-flex items-center gap-1 font-medium text-emerald-700">
                      <FileText className="h-3 w-3" />
                      PDF indexed
                    </span>
                  )}
                </div>
              </div>
              <Link
                href="/settings"
                className="inline-flex h-8 shrink-0 items-center gap-1.5 rounded-xl border border-hyper-border/80 bg-white px-2.5 text-xs font-semibold text-hyper-navy shadow-soft transition-all duration-200 hover:-translate-y-0.5 hover:border-hyper-primary/40 hover:bg-hyper-primary/5 hover:text-hyper-primary hover:shadow-card"
              >
                <Settings2 className="h-3.5 w-3.5" />
                Edit in Settings
              </Link>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-hyper-border bg-white p-4 shadow-sm">
      <p className="mb-3 text-micro uppercase tracking-wider text-text-muted">Active product</p>
      <div className="grid gap-2 sm:grid-cols-2">
        {products.map((p) => {
          const active = activeId === p.id;
          return (
            <button
              key={p.id}
              type="button"
              onClick={() => select(p.id)}
              disabled={saving}
              className={cn(
                "rounded-xl border px-3 py-2.5 text-left transition-all duration-150 disabled:opacity-50",
                active
                  ? "border-hyper-primary bg-hyper-primary/5 ring-1 ring-hyper-primary/20"
                  : "border-hyper-border hover:border-hyper-primary/30 hover:bg-surface-1"
              )}
            >
              <div className="flex items-center justify-between gap-2">
                <p className="text-sm font-semibold text-hyper-navy">{p.name}</p>
                <span className="text-[10px] font-semibold uppercase text-text-muted">
                  {modeLabel(p.topic_selection_mode)}
                </span>
              </div>
              <p className="text-xs text-text-muted">{p.company_name}</p>
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function getStoredActiveProductId(): number | null {
  if (typeof window === "undefined") return null;
  const raw = localStorage.getItem(STORAGE_KEY);
  return raw && /^\d+$/.test(raw) ? Number(raw) : null;
}
