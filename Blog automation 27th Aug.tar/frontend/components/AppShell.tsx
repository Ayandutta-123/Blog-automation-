"use client";

import { useEffect } from "react";
import { usePathname, useRouter } from "next/navigation";
import { NotificationProvider } from "@/contexts/NotificationContext";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { ToastProvider } from "@/contexts/ToastContext";
import NotificationPanel from "./NotificationPanel";
import Sidebar from "./Sidebar";
import TopHeader from "./TopHeader";
import MobileBottomNav from "./MobileBottomNav";

function AppShellInner({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { isAuthenticated, loading } = useAuth();
  const isLogin = pathname === "/login";

  useEffect(() => {
    if (loading) return;
    if (!isAuthenticated && !isLogin) {
      router.replace("/login");
    }
    if (isAuthenticated && isLogin) {
      router.replace("/");
    }
  }, [isAuthenticated, isLogin, loading, router]);

  if (isLogin) {
    return <>{children}</>;
  }

  if (loading) {
    return (
      <div className="app-canvas flex min-h-[100dvh] flex-col items-center justify-center gap-3">
        <div className="h-10 w-10 animate-work-pulse rounded-2xl bg-gradient-to-br from-hyper-primary to-hyper-navy shadow-nav-active" />
        <p className="animate-fade-in text-sm font-medium text-text-secondary">
          Loading workspace…
        </p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <NotificationProvider>
      <div className="flex h-[100dvh] overflow-hidden app-canvas">
        <Sidebar />
        <div className="flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden">
          <TopHeader />
          <main className="relative z-0 min-h-0 flex-1 overflow-x-hidden overflow-y-auto pb-[calc(4.25rem+env(safe-area-inset-bottom))] md:pb-0">
            {children}
          </main>
        </div>
      </div>
      <MobileBottomNav />
      <NotificationPanel />
    </NotificationProvider>
  );
}

export default function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <AuthProvider>
      <ToastProvider>
        <AppShellInner>{children}</AppShellInner>
      </ToastProvider>
    </AuthProvider>
  );
}
