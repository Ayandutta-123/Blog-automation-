"use client";

import {
  AlertTriangle,
  CheckCircle2,
  Eye,
  FileText,
  X,
} from "lucide-react";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { cn } from "@/lib/cn";
import { NotificationItem } from "@/lib/api";
import { useNotifications } from "@/contexts/NotificationContext";
import { formatDate } from "@/lib/status";

function iconFor(type: NotificationItem["type"]) {
  switch (type) {
    case "error":
      return AlertTriangle;
    case "published":
      return CheckCircle2;
    case "review_required":
      return Eye;
    default:
      return FileText;
  }
}

function severityStyles(severity: NotificationItem["severity"]) {
  switch (severity) {
    case "error":
      return "bg-red-50 text-red-700";
    case "success":
      return "bg-emerald-50 text-emerald-700";
    default:
      return "bg-amber-50 text-amber-700";
  }
}

function bannerStyles(severity: NotificationItem["severity"]) {
  switch (severity) {
    case "error":
      return "border-red-200 bg-red-50 text-red-800";
    case "success":
      return "border-emerald-200 bg-emerald-50 text-emerald-800";
    default:
      return "border-amber-200 bg-amber-50 text-amber-900";
  }
}

/** Single shared dropdown — mount once in AppShell. */
export default function NotificationPanel() {
  const {
    items,
    unreadCount,
    loading,
    open,
    setOpen,
    markRead,
    markAllRead,
    clearAll,
    isRead,
    banner,
    dismissBanner,
    anchorEl,
  } = useNotifications();
  const panelRef = useRef<HTMLDivElement>(null);
  const [coords, setCoords] = useState<{
    top: number;
    left: number;
    maxHeight: number;
    mobileSheet: boolean;
  } | null>(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!open || !anchorEl) {
      setCoords(null);
      return;
    }
    function place() {
      if (!anchorEl) return;
      const mobileSheet = window.innerWidth < 768;
      const width = Math.min(352, window.innerWidth - 16);
      const rect = anchorEl.getBoundingClientRect();
      const bottomNav = mobileSheet ? 72 : 16;
      if (mobileSheet) {
        const top = Math.max(8, Math.min(rect.bottom + 8, window.innerHeight * 0.12));
        const maxHeight = Math.max(220, window.innerHeight - top - bottomNav - 8);
        setCoords({
          top,
          left: 8,
          maxHeight,
          mobileSheet: true,
        });
        return;
      }
      let left = rect.left;
      left = Math.max(8, Math.min(left, window.innerWidth - width - 8));
      const top = Math.min(rect.bottom + 8, window.innerHeight - 48);
      const maxHeight = Math.max(200, window.innerHeight - top - 16);
      setCoords({ top, left, maxHeight, mobileSheet: false });
    }
    place();
    window.addEventListener("resize", place);
    window.addEventListener("scroll", place, true);
    return () => {
      window.removeEventListener("resize", place);
      window.removeEventListener("scroll", place, true);
    };
  }, [open, anchorEl]);

  useEffect(() => {
    if (!open) return;
    function onPointerDown(e: MouseEvent) {
      const t = e.target as Node;
      if (anchorEl?.contains(t) || panelRef.current?.contains(t)) return;
      setOpen(false);
    }
    document.addEventListener("mousedown", onPointerDown);
    return () => document.removeEventListener("mousedown", onPointerDown);
  }, [open, setOpen, anchorEl]);

  if (!mounted || !open || !coords) return null;

  return createPortal(
    <div
      ref={panelRef}
      role="dialog"
      aria-label="Notifications"
      className={cn(
        "fixed z-[200] animate-modal-in overflow-hidden border border-hyper-border/70 bg-white/95 shadow-elevated backdrop-blur-xl",
        coords.mobileSheet
          ? "inset-x-2 rounded-2xl"
          : "w-[min(22rem,calc(100vw-1rem))] rounded-2xl"
      )}
      style={{
        top: coords.top,
        left: coords.mobileSheet ? undefined : coords.left,
        maxHeight: coords.maxHeight,
      }}
    >
      {banner && (
        <div
          className={cn(
            "animate-fade-in flex items-start gap-2 border-b px-4 py-3 text-sm",
            bannerStyles(banner.severity)
          )}
        >
          {banner.severity === "error" ? (
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
          ) : (
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
          )}
          <div className="min-w-0 flex-1">
            <p className="font-semibold">{banner.title}</p>
            <p className="mt-0.5 line-clamp-2 text-xs opacity-90">{banner.message}</p>
          </div>
          <button
            type="button"
            onClick={dismissBanner}
            className="rounded p-0.5 opacity-70 hover:opacity-100"
            aria-label="Dismiss banner"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      <div className="flex items-center justify-between border-b border-hyper-border/70 px-4 py-3">
        <div>
          <p className="font-display text-sm font-bold tracking-tight text-hyper-navy">
            Notifications
          </p>
          <p className="text-xs text-text-muted">
            {unreadCount > 0 ? `${unreadCount} unread` : "You're all caught up"}
          </p>
        </div>
        <div className="flex flex-wrap items-center justify-end gap-1">
          {unreadCount > 0 && (
            <button
              type="button"
              onClick={markAllRead}
              className="rounded-lg px-2 py-1 text-xs font-medium text-hyper-primary hover:bg-hyper-primary/5"
            >
              Mark all read
            </button>
          )}
          {items.length > 0 && (
            <button
              type="button"
              onClick={() => {
                if (
                  !confirm(
                    "Clear all notifications from the bell? New events will still appear."
                  )
                ) {
                  return;
                }
                clearAll();
              }}
              className="rounded-lg px-2 py-1 text-xs font-medium text-text-secondary hover:bg-red-50 hover:text-hyper-red"
            >
              Clear all
            </button>
          )}
          <button
            type="button"
            onClick={() => setOpen(false)}
            className="rounded-lg p-1 text-text-muted hover:bg-surface-1"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div
        className="overflow-y-auto"
        style={{ maxHeight: Math.max(160, coords.maxHeight - (banner ? 140 : 72)) }}
      >
        {loading && items.length === 0 ? (
          <p className="px-4 py-8 text-center text-sm text-text-muted">
            Loading notifications...
          </p>
        ) : items.length === 0 ? (
          <p className="px-4 py-8 text-center text-sm text-text-muted">
            No notifications yet
          </p>
        ) : (
          <ul className="divide-y divide-hyper-border">
            {items.map((item) => {
              const Icon = iconFor(item.type);
              const read = isRead(item.id);
              return (
                <li key={item.id}>
                  <Link
                    href={item.post_id ? `/?post=${item.post_id}` : "/inbox"}
                    onClick={() => {
                      markRead(item.id);
                      setOpen(false);
                    }}
                    className={cn(
                      "flex gap-3 px-4 py-3 transition hover:bg-surface-1",
                      !read && "bg-hyper-primary/[0.04]"
                    )}
                  >
                    <div
                      className={cn(
                        "mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full",
                        severityStyles(item.severity)
                      )}
                    >
                      <Icon className="h-4 w-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p
                        className={cn(
                          "truncate text-sm",
                          read
                            ? "font-medium text-text-secondary"
                            : "font-semibold text-hyper-navy"
                        )}
                      >
                        {item.title}
                      </p>
                      <p className="mt-0.5 line-clamp-2 text-xs text-text-secondary">
                        {item.message}
                      </p>
                      <p className="mt-1 font-mono text-xs text-text-muted">
                        {formatDate(item.timestamp)}
                      </p>
                    </div>
                    {!read && (
                      <span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-hyper-primary" />
                    )}
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      <div className="border-t border-hyper-border px-4 py-2">
        <Link
          href="/inbox"
          onClick={() => setOpen(false)}
          className="block rounded-lg py-2 text-center text-xs font-medium text-hyper-primary hover:bg-hyper-primary/5"
        >
          View inbox
        </Link>
      </div>
    </div>,
    document.body
  );
}
