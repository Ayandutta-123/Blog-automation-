"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  BarChart3,
  Inbox,
  LayoutGrid,
  PackageCheck,
  Settings,
  Zap,
} from "lucide-react";
import { cn } from "@/lib/cn";
import { useNotifications } from "@/contexts/NotificationContext";

const navItems = [
  { href: "/", label: "Board", icon: LayoutGrid },
  { href: "/report", label: "Report", icon: BarChart3 },
  { href: "/inbox", label: "Inbox", icon: Inbox, badge: true },
  { href: "/ready", label: "Ready to use", icon: PackageCheck },
  { href: "/settings", label: "Settings", icon: Settings },
];

export default function Sidebar() {
  const pathname = usePathname();
  const { items } = useNotifications();
  const inboxCount = items.filter(
    (item) => item.type === "topic_selection" || item.type === "review_required"
  ).length;

  return (
    <aside className="app-sidebar sticky top-0 hidden h-[100dvh] w-60 shrink-0 flex-col border-r border-hyper-border/80 md:flex lg:w-[248px]">
      <div className="shrink-0 border-b border-hyper-border/60 px-3 py-4 lg:px-4">
        <div className="flex items-center gap-2.5">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-hyper-primary to-hyper-navy shadow-nav-active ring-1 ring-white/10 transition-transform duration-300 hover:scale-105">
            <Zap className="h-5 w-5 text-hyper-orange" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate font-display text-sm font-bold tracking-tight text-hyper-navy">
              blog Automation
            </p>
            <p className="truncate text-micro uppercase tracking-[0.14em] text-text-muted">
              Content pipeline
            </p>
          </div>
        </div>
      </div>

      <nav className="min-h-0 flex-1 space-y-1 overflow-y-auto px-3 py-1">
        <p className="px-3 pb-2 text-micro uppercase tracking-[0.14em] text-text-muted">
          Navigation
        </p>
        {navItems.map(({ href, label, icon: Icon, badge }) => {
          const active =
            href === "/" ? pathname === "/" : pathname.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "group relative flex h-11 items-center gap-3 rounded-xl px-3 text-sm font-semibold tracking-tight transition-all duration-200",
                active
                  ? "bg-white text-hyper-primary shadow-soft ring-1 ring-hyper-primary/10"
                  : "text-text-secondary hover:bg-white/70 hover:text-hyper-navy hover:shadow-soft"
              )}
            >
              {active && (
                <span className="absolute left-0 top-1/2 h-7 w-1 -translate-y-1/2 rounded-r-full bg-gradient-to-b from-hyper-orange to-hyper-primary" />
              )}
              <Icon
                className={cn(
                  "h-4 w-4 shrink-0 transition-transform duration-200",
                  active ? "text-hyper-orange" : "group-hover:scale-110"
                )}
              />
              <span className="flex-1">{label}</span>
              {badge && inboxCount > 0 && (
                <span
                  className={cn(
                    "rounded-full px-2 py-0.5 text-[11px] font-bold tabular-nums shadow-soft",
                    active
                      ? "bg-hyper-primary text-white"
                      : "bg-hyper-red text-white"
                  )}
                >
                  {inboxCount > 9 ? "9+" : inboxCount}
                </span>
              )}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
