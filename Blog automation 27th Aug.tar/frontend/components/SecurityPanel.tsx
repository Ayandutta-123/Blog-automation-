"use client";

import { useState } from "react";
import { Eye, EyeOff, LogOut, Save, Shield } from "lucide-react";
import { api } from "@/lib/api";
import { useAuth } from "@/contexts/AuthContext";
import { useNotifications } from "@/contexts/NotificationContext";
import Button from "@/components/ui/Button";
import { Input } from "@/components/ui/Input";
import { cn } from "@/lib/cn";

function PasswordField({
  label,
  value,
  onChange,
  show,
  onToggleShow,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  show: boolean;
  onToggleShow: () => void;
  placeholder: string;
}) {
  return (
    <label className="block">
      <span className="settings-field-label">{label}</span>
      <div className="relative">
        <Input
          type={show ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="pr-10"
          autoComplete="off"
        />
        <button
          type="button"
          onClick={onToggleShow}
          className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-text-muted hover:bg-surface-1 hover:text-hyper-primary"
          aria-label={show ? "Hide password" : "Show password"}
        >
          {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </button>
      </div>
    </label>
  );
}

export default function SecurityPanel() {
  const { logout, role } = useAuth();
  const { notifySaved } = useNotifications();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNext, setShowNext] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(
    null
  );

  const [createUsername, setCreateUsername] = useState("");
  const [createPassword, setCreatePassword] = useState("");
  const [createConfirm, setCreateConfirm] = useState("");
  const [createRole, setCreateRole] = useState<"admin" | "user">("user");
  const [creating, setCreating] = useState(false);
  const [createMessage, setCreateMessage] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  async function handleCreateUser() {
    if (createPassword.length < 8) {
      setCreateMessage({
        type: "error",
        text: "Password must be at least 8 characters.",
      });
      return;
    }
    if (!createUsername.trim()) {
      setCreateMessage({ type: "error", text: "Username is required." });
      return;
    }
    if (createPassword !== createConfirm) {
      setCreateMessage({ type: "error", text: "Passwords do not match." });
      return;
    }
    setCreating(true);
    setCreateMessage(null);
    try {
      const res = await api.createUser({
        username: createUsername.trim(),
        password: createPassword,
        role: createRole,
      });
      setCreateMessage({ type: "success", text: `Created ${res.username}.` });
      setCreateUsername("");
      setCreatePassword("");
      setCreateConfirm("");
    } catch (e) {
      setCreateMessage({
        type: "error",
        text: e instanceof Error ? e.message : "Failed to create user",
      });
    } finally {
      setCreating(false);
    }
  }

  async function handleChangePassword() {
    if (next.length < 8) {
      setMessage({ type: "error", text: "New password must be at least 8 characters." });
      return;
    }
    if (next !== confirm) {
      setMessage({ type: "error", text: "New passwords do not match." });
      return;
    }
    setSaving(true);
    setMessage(null);
    try {
      const res = await api.changePassword(current, next);
      setMessage({ type: "success", text: res.message });
      setCurrent("");
      setNext("");
      setConfirm("");
      notifySaved("Password updated", res.message || "Dashboard password was changed.");
    } catch (e) {
      setMessage({
        type: "error",
        text: e instanceof Error ? e.message : "Failed to update password",
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="settings-stack">
      {role === "admin" && (
        <div className="settings-card">
          <div className="settings-card-body space-y-4">
          <div className="flex items-start gap-3">
            <span className="settings-intro-icon">
              <Shield className="h-4 w-4" />
            </span>
            <div>
              <h3 className="text-sm font-semibold text-hyper-navy md:text-base">
                Create user
              </h3>
              <p className="mt-0.5 text-xs text-text-secondary">
                Admin-only: add a new dashboard login (userid + password).
              </p>
            </div>
          </div>

          {createMessage && (
            <div
              className={cn(
                "settings-alert",
                createMessage.type === "success"
                  ? "border-emerald-200 bg-emerald-50 text-emerald-800"
                  : "border-red-200 bg-red-50 text-red-800"
              )}
            >
              <span
                className={cn(
                  "settings-alert-dot",
                  createMessage.type === "success" ? "bg-emerald-500" : "bg-red-500"
                )}
              />
              {createMessage.text}
            </div>
          )}

          <div className="space-y-3">
            <label className="block">
              <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-text-muted">
                Username
              </span>
              <Input
                value={createUsername}
                onChange={(e) => setCreateUsername(e.target.value)}
                placeholder="e.g. ayan"
                autoComplete="off"
              />
            </label>

            <label className="block">
              <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-text-muted">
                Password
              </span>
              <Input
                type="password"
                value={createPassword}
                onChange={(e) => setCreatePassword(e.target.value)}
                placeholder="At least 8 characters"
                autoComplete="new-password"
              />
            </label>

            <label className="block">
              <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-text-muted">
                Confirm password
              </span>
              <Input
                type="password"
                value={createConfirm}
                onChange={(e) => setCreateConfirm(e.target.value)}
                placeholder="Repeat password"
                autoComplete="new-password"
              />
            </label>

            <label className="block">
              <span className="settings-field-label">Role</span>
              <div className="settings-option-group">
                <Button
                  type="button"
                  variant={createRole === "user" ? "orange" : "secondary"}
                  size="sm"
                  onClick={() => setCreateRole("user")}
                >
                  User
                </Button>
                <Button
                  type="button"
                  variant={createRole === "admin" ? "orange" : "secondary"}
                  size="sm"
                  onClick={() => setCreateRole("admin")}
                >
                  Admin
                </Button>
              </div>
            </label>

            <div className="settings-btn-row pt-1">
              <Button
                type="button"
                variant="orange"
                className="settings-btn-row-primary btn-sheen relative overflow-hidden"
                onClick={handleCreateUser}
                loading={creating}
                disabled={
                  creating ||
                  !createUsername.trim() ||
                  !createPassword ||
                  !createConfirm ||
                  createPassword !== createConfirm
                }
              >
                Create user
              </Button>
            </div>
          </div>
          </div>
        </div>
      )}

      <div className="settings-intro">
        <div className="relative flex items-start gap-3.5 pl-1">
          <span className="settings-intro-icon">
            <Shield className="h-4 w-4" />
          </span>
          <div>
            <p className="text-sm font-semibold text-hyper-navy">Dashboard security</p>
            <p className="mt-1 max-w-2xl text-xs leading-relaxed text-text-secondary md:text-sm">
              Sign-in requires a username and password. Credentials are stored server-side only.
              Failed attempts are rate-limited. Change your password below when needed.
            </p>
          </div>
        </div>
      </div>

      {message && (
        <div
          className={cn(
            "settings-alert",
            message.type === "success"
              ? "border-emerald-200 bg-emerald-50 text-emerald-800"
              : "border-red-200 bg-red-50 text-red-800"
          )}
        >
          <span
            className={cn(
              "settings-alert-dot",
              message.type === "success" ? "bg-emerald-500" : "bg-red-500"
            )}
          />
          {message.text}
        </div>
      )}

      <div className="settings-card">
        <div className="settings-card-head">
          <h3 className="text-sm font-semibold text-hyper-navy md:text-base">Change password</h3>
          <p className="mt-0.5 text-xs text-text-secondary">
            Use at least 8 characters. Your password is stored securely on the server.
          </p>
        </div>
        <div className="settings-card-body space-y-4">
        <PasswordField
          label="Current password"
          value={current}
          onChange={setCurrent}
          show={showCurrent}
          onToggleShow={() => setShowCurrent((v) => !v)}
          placeholder="Enter current password"
        />
        <PasswordField
          label="New password"
          value={next}
          onChange={setNext}
          show={showNext}
          onToggleShow={() => setShowNext((v) => !v)}
          placeholder="At least 8 characters"
        />
        <PasswordField
          label="Confirm new password"
          value={confirm}
          onChange={setConfirm}
          show={showConfirm}
          onToggleShow={() => setShowConfirm((v) => !v)}
          placeholder="Repeat new password"
        />
        <div className="settings-btn-row pt-2">
          <Button
            type="button"
            variant="orange"
            className="settings-btn-row-primary btn-sheen relative overflow-hidden"
            onClick={handleChangePassword}
            loading={saving}
            disabled={saving || !current || !next || !confirm}
          >
            <Save className="h-4 w-4" />
            Update password
          </Button>
          <Button
            type="button"
            variant="secondary"
            onClick={() => logout().then(() => window.location.assign("/login"))}
          >
            <LogOut className="h-4 w-4" />
            Sign out
          </Button>
        </div>
        </div>
      </div>
    </div>
  );
}
