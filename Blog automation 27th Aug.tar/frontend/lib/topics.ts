export type TopicSource =
  | "industry_keywords"
  | "competitor_urls"
  | "rss_feeds";

export type TopicSourceLink = {
  label: string;
  url: string;
  source_type?: string;
};

export interface BlogTopic {
  title: string;
  description: string;
  primary_keyword: string;
  source?: TopicSource;
  source_links?: TopicSourceLink[];
  seo_score?: number;
  recommendation?: "strong_pick" | "good" | "moderate" | "weak";
  recommended?: boolean;
  seo_rank?: number;
  seo_signals?: {
    search_volume?: number | null;
    seo_difficulty?: number | null;
    cpc?: number | null;
    competitor_matches?: number;
    competitor_gap_score?: number;
    ubersuggest_connected?: boolean;
    source_tool?: string | null;
  };
  seo_why?: string[];
}

export interface TopicTopPick {
  title: string;
  primary_keyword?: string;
  seo_score?: number;
  recommendation?: string;
  source?: TopicSource;
  source_links?: TopicSourceLink[];
}

export type TopicGroupsPayload = {
  version?: number;
  groups?: TopicGroups;
  top_picks?: TopicTopPick[];
};

export type TopicGroups = Record<TopicSource, BlogTopic[]>;

export const TOPIC_SOURCE_META: {
  key: TopicSource;
  label: string;
  subtitle: string;
  /** Short badge label on topic cards */
  badge: string;
  /** Tailwind classes for the category badge */
  badgeClass: string;
  countClass: string;
}[] = [
  {
    key: "industry_keywords",
    label: "Industry / Keywords",
    subtitle: "From Tavily keyword & trend search",
    badge: "Industry",
    badgeClass: "bg-sky-600 text-white",
    countClass: "bg-sky-100 text-sky-800",
  },
  {
    key: "competitor_urls",
    label: "Competitor blog pages",
    subtitle: "From Playwright HTML scrapes",
    badge: "Competitor",
    badgeClass: "bg-violet-600 text-white",
    countClass: "bg-violet-100 text-violet-800",
  },
  {
    key: "rss_feeds",
    label: "RSS feeds",
    subtitle: "From free XML feed parsing",
    badge: "RSS",
    badgeClass: "bg-amber-500 text-white",
    countClass: "bg-amber-100 text-amber-900",
  },
];

const EMPTY_GROUPS: TopicGroups = {
  industry_keywords: [],
  competitor_urls: [],
  rss_feeds: [],
};

function asTopic(raw: unknown, source: TopicSource): BlogTopic | null {
  if (!raw || typeof raw !== "object") return null;
  const t = raw as Record<string, unknown>;
  const title = String(t.title || "").trim();
  if (!title) return null;
  const topic: BlogTopic = {
    title,
    description: String(t.description || "").trim(),
    primary_keyword: String(t.primary_keyword || "").trim(),
    source,
  };
  if (typeof t.seo_score === "number") topic.seo_score = t.seo_score;
  if (typeof t.recommendation === "string") {
    topic.recommendation = t.recommendation as BlogTopic["recommendation"];
  }
  if (typeof t.recommended === "boolean") topic.recommended = t.recommended;
  if (typeof t.seo_rank === "number") topic.seo_rank = t.seo_rank;
  if (t.seo_signals && typeof t.seo_signals === "object") {
    topic.seo_signals = t.seo_signals as BlogTopic["seo_signals"];
  }
  if (Array.isArray(t.seo_why)) {
    topic.seo_why = t.seo_why.map((x) => String(x));
  }
  if (Array.isArray(t.source_links)) {
    topic.source_links = t.source_links.flatMap((x) => {
      if (!x || typeof x !== "object") return [];
      const item = x as Record<string, unknown>;
      const url = String(item.url || "").trim();
      if (!url.startsWith("http")) return [];
      const link: TopicSourceLink = {
        label: String(item.label || item.title || url).trim(),
        url,
      };
      if (item.source_type) link.source_type = String(item.source_type);
      return [link];
    });
  }
  return topic;
}

function coerceSource(value: unknown): TopicSource {
  const raw = String(value || "")
    .trim()
    .toLowerCase();
  if (raw.includes("rss") || raw.includes("feed")) return "rss_feeds";
  if (raw.includes("competitor") || raw.includes("html")) return "competitor_urls";
  return "industry_keywords";
}

/** Normalize legacy flat lists or v2 `{ version, groups }` payloads. */
export function normalizeTopicGroups(raw: unknown): TopicGroups {
  const groups: TopicGroups = {
    industry_keywords: [],
    competitor_urls: [],
    rss_feeds: [],
  };

  if (!raw) return groups;

  if (Array.isArray(raw)) {
    for (const item of raw) {
      const source =
        item && typeof item === "object" && "source" in item
          ? coerceSource((item as BlogTopic).source)
          : "industry_keywords";
      const topic = asTopic(item, source);
      if (topic) groups[source].push(topic);
    }
    return groups;
  }

  if (typeof raw === "object") {
    const obj = raw as Record<string, unknown>;
    const nested =
      obj.groups && typeof obj.groups === "object"
        ? (obj.groups as Record<string, unknown>)
        : obj;

    for (const meta of TOPIC_SOURCE_META) {
      const list = nested[meta.key];
      if (!Array.isArray(list)) continue;
      groups[meta.key] = list
        .map((item) => asTopic(item, meta.key))
        .filter((t): t is BlogTopic => !!t);
    }

    if (
      !groups.industry_keywords.length &&
      !groups.competitor_urls.length &&
      !groups.rss_feeds.length &&
      Array.isArray(obj.topics)
    ) {
      for (const item of obj.topics) {
        const source =
          item && typeof item === "object" && "source" in (item as object)
            ? coerceSource((item as BlogTopic).source)
            : "industry_keywords";
        const topic = asTopic(item, source);
        if (topic) groups[source].push(topic);
      }
    }
  }

  return groups;
}

export function flattenTopicGroups(raw: unknown): BlogTopic[] {
  const groups = normalizeTopicGroups(raw);
  return TOPIC_SOURCE_META.flatMap((m) => groups[m.key]);
}

export function countTopics(raw: unknown): number {
  return flattenTopicGroups(raw).length;
}

export function emptyTopicGroups(): TopicGroups {
  return { ...EMPTY_GROUPS, industry_keywords: [], competitor_urls: [], rss_feeds: [] };
}

export function extractTopPicks(raw: unknown): TopicTopPick[] {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return [];
  const picks = (raw as TopicGroupsPayload).top_picks;
  return Array.isArray(picks) ? picks : [];
}
