import { BlogPostSummary } from "./api";

export type KanbanColumn = "discovery" | "topics" | "review" | "published";

export const KANBAN_COLUMNS: {
  id: KanbanColumn;
  title: string;
  subtitle: string;
  statuses: string[];
  headerBg: string;
  accentBorder: string;
  emptyIcon?: string;
}[] = [
  {
    id: "discovery",
    title: "Discovery",
    subtitle: "Scraping & synthesis",
    statuses: ["SCRAPING"],
    headerBg: "bg-[#eef1fb]",
    accentBorder: "border-l-hyper-primary",
  },
  {
    id: "topics",
    title: "Topic Selection",
    subtitle: "HITL Gate 1",
    statuses: ["PENDING_TOPIC"],
    headerBg: "bg-[#fff4eb]",
    accentBorder: "border-l-hyper-orange",
  },
  {
    id: "review",
    title: "Review",
    subtitle: "Generation & HITL Gate 2",
    statuses: ["GENERATING", "PENDING_REVIEW", "APPROVED"],
    headerBg: "bg-[#f2f0fa]",
    accentBorder: "border-l-[#6d64a8]",
  },
  {
    id: "published",
    title: "Published",
    subtitle: "Live on ledger",
    statuses: ["PUBLISHED"],
    headerBg: "bg-[#eef9f3]",
    accentBorder: "border-l-emerald-500",
  },
];

export function getColumnForStatus(status: string): KanbanColumn {
  for (const col of KANBAN_COLUMNS) {
    if (col.statuses.includes(status)) return col.id;
  }
  return "discovery";
}

export const STATUS_LABELS: Record<string, string> = {
  SCRAPING: "Discovering",
  PENDING_TOPIC: "Topic selection",
  GENERATING: "Generating",
  PENDING_REVIEW: "In review",
  APPROVED: "Approved",
  PUBLISHED: "Published",
  REJECTED: "Rejected",
};

export const REPORT_STATUSES = [
  "SCRAPING",
  "PENDING_TOPIC",
  "GENERATING",
  "PENDING_REVIEW",
  "APPROVED",
  "PUBLISHED",
  "REJECTED",
] as const;

export function getColumnMeta(status: string) {
  return KANBAN_COLUMNS.find((c) => c.id === getColumnForStatus(status));
}

export function getPostTitle(post: BlogPostSummary): string {
  if (post.status === "PENDING_TOPIC" || post.status === "SCRAPING") {
    if (post.selected_topic_title) return post.selected_topic_title;
    return post.status === "SCRAPING"
      ? `Discovery run #${post.id}`
      : `Topic selection #${post.id}`;
  }
  return (
    post.title_tag ||
    post.selected_topic_title ||
    `Blog Post #${post.id}`
  );
}

export function getPriority(status: string): {
  label: string;
  color: string;
} {
  switch (status) {
    case "PENDING_REVIEW":
      return { label: "High", color: "bg-red-50 text-hyper-red" };
    case "GENERATING":
      return { label: "Medium", color: "bg-blue-50 text-blue-700" };
    case "PENDING_TOPIC":
      return { label: "Medium", color: "bg-orange-50 text-hyper-orange" };
    case "SCRAPING":
      return { label: "Low", color: "bg-slate-100 text-slate-600" };
    case "PUBLISHED":
      return { label: "Done", color: "bg-emerald-50 text-emerald-700" };
    case "REJECTED":
      return { label: "Failed", color: "bg-red-50 text-hyper-red" };
    default:
      return { label: "Normal", color: "bg-slate-100 text-slate-600" };
  }
}

export function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

export function formatDateTime(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });
}
