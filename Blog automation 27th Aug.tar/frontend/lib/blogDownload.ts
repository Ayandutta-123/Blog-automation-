import { api, BlogPostDetail, BrandPalette, Product } from "@/lib/api";
import { buildDownloadHtmlDoc, downloadHeroImageUrl, replaceHeroSrc } from "@/lib/blogPreview";
import { DEFAULT_BRAND_PALETTE, normalizeBrandPalette } from "@/lib/brandPalette";

function siteFromProduct(product: Product | null | undefined): string {
  return (product?.website_url || "https://hyperthings.ai").replace(/\/$/, "");
}

export async function downloadPublishedHtml(opts: {
  post: BlogPostDetail;
  product?: Product | null;
  brandPalette?: BrandPalette | null;
}): Promise<void> {
  const { post } = opts;
  if (!post.html_content) {
    throw new Error("This post has no HTML content to download.");
  }
  const title = post.title_tag || post.selected_topic_title || `post-${post.id}`;
  const slug = post.slug || `post-${post.id}`;
  // Prefer stored public MinIO/CDN URL so downloaded HTML keeps working offline
  const storedImage = (post.image_url || "").trim();
  const imageUrl =
    /^https?:\/\//i.test(storedImage) && !/^data:/i.test(storedImage)
      ? storedImage
      : post.slug
        ? downloadHeroImageUrl(post.slug)
        : "";

  let product = opts.product;
  if (!product) {
    const list = await api.getProducts();
    product =
      (post.product_id != null
        ? list.find((p) => p.id === post.product_id)
        : null) || list[0] || null;
  }

  const canonicalUrl = `${siteFromProduct(product)}/blog/${slug}`;
  let body = post.html_content;
  if (imageUrl) {
    body = replaceHeroSrc(body, imageUrl);
  }

  const palette = normalizeBrandPalette(
    opts.brandPalette || product?.brand_palette || DEFAULT_BRAND_PALETTE
  );

  const doc = buildDownloadHtmlDoc({
    title,
    description: post.meta_description || "",
    bodyHtml: body,
    brandPalette: palette,
    canonicalUrl,
    imageUrl: imageUrl || canonicalUrl,
    siteName: "Hyperthings.ai",
  });

  const blob = new Blob([doc], { type: "text/html;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${slug}.html`;
  a.click();
  URL.revokeObjectURL(url);
}

export async function downloadPublishedImage(slug: string): Promise<void> {
  if (!slug) {
    throw new Error("No hero image for this post.");
  }
  const res = await fetch(api.imageUrl(slug));
  if (!res.ok) throw new Error(`Image download failed (${res.status})`);
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${slug}.webp`;
  a.click();
  URL.revokeObjectURL(url);
}
