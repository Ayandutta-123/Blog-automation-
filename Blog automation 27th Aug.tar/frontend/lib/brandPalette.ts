export type BrandColorEntry = {
  id: string;
  label: string;
  hex: string;
};

export type BrandPalette = {
  primary: string;
  navy: string;
  accent: string;
  cta: string;
  link: string;
  custom: BrandColorEntry[];
};

export type BrandPaletteKey = "primary" | "navy" | "accent" | "cta" | "link";

export const DEFAULT_BRAND_PALETTE: BrandPalette = {
  primary: "#252a61",
  navy: "#1b1f4a",
  accent: "#ff6002",
  cta: "#c1262a",
  link: "#1d4ed8",
  custom: [],
};

export const BRAND_PALETTE_SLOTS: {
  key: BrandPaletteKey;
  label: string;
  description: string;
}[] = [
  { key: "primary", label: "Primary", description: "Main brand color · headings" },
  { key: "navy", label: "Navy", description: "Dark backgrounds · table headers" },
  { key: "accent", label: "Charts / Accent", description: "Chart bars, stats & highlights" },
  { key: "cta", label: "CTA", description: "CTA button & call-to-action" },
  { key: "link", label: "Links", description: "Hyperlinks & source citations (bold)" },
];

export type BrandPalettePreset = {
  id: string;
  name: string;
  colors: Omit<BrandPalette, "custom">;
};

/** First preset is the only fixed default; all others (and every slot) are fully editable. */
export const BRAND_PALETTE_PRESETS: BrandPalettePreset[] = [
  {
    id: "hyperpark",
    name: "Default · Navy & Orange",
    colors: {
      primary: "#252a61",
      navy: "#1b1f4a",
      accent: "#ff6002",
      cta: "#c1262a",
      link: "#1d4ed8",
    },
  },
  {
    id: "ocean",
    name: "Ocean Blue",
    colors: {
      primary: "#0ea5e9",
      navy: "#0c4a6e",
      accent: "#38bdf8",
      cta: "#0284c7",
      link: "#0369a1",
    },
  },
  {
    id: "forest",
    name: "Forest Green",
    colors: {
      primary: "#166534",
      navy: "#14532d",
      accent: "#22c55e",
      cta: "#15803d",
      link: "#15803d",
    },
  },
  {
    id: "slate",
    name: "Enterprise Slate",
    colors: {
      primary: "#475569",
      navy: "#1e293b",
      accent: "#94a3b8",
      cta: "#334155",
      link: "#2563eb",
    },
  },
  {
    id: "purple",
    name: "SaaS Purple",
    colors: {
      primary: "#6366f1",
      navy: "#312e81",
      accent: "#a78bfa",
      cta: "#4f46e5",
      link: "#4f46e5",
    },
  },
  {
    id: "crimson",
    name: "Crimson",
    colors: {
      primary: "#b91c1c",
      navy: "#7f1d1d",
      accent: "#f87171",
      cta: "#dc2626",
      link: "#b91c1c",
    },
  },
];

const HEX_RE = /^#[0-9A-Fa-f]{6}$/;

export function normalizeHex(value: string): string | null {
  const trimmed = value.trim();
  const withHash = trimmed.startsWith("#") ? trimmed : `#${trimmed}`;
  if (!HEX_RE.test(withHash)) return null;
  return withHash.toLowerCase();
}

function normalizeCustomColors(raw: unknown): BrandColorEntry[] {
  if (!Array.isArray(raw)) return [];
  const colors: BrandColorEntry[] = [];
  for (const item of raw) {
    if (!item || typeof item !== "object") continue;
    const record = item as Record<string, unknown>;
    const hex = typeof record.hex === "string" ? normalizeHex(record.hex) : null;
    if (!hex) continue;
    const label =
      typeof record.label === "string" && record.label.trim()
        ? record.label.trim().slice(0, 64)
        : "Custom";
    const id =
      typeof record.id === "string" && record.id.trim()
        ? record.id.trim().slice(0, 32)
        : `custom-${colors.length + 1}`;
    colors.push({ id, label, hex });
  }
  return colors;
}

export function normalizeBrandPalette(
  raw?: Partial<BrandPalette> | null
): BrandPalette {
  const palette: BrandPalette = {
    ...DEFAULT_BRAND_PALETTE,
    custom: [],
  };
  if (!raw) return palette;

  for (const slot of BRAND_PALETTE_SLOTS) {
    const value = raw[slot.key];
    const normalized = value ? normalizeHex(value) : null;
    if (normalized) palette[slot.key] = normalized;
  }
  palette.custom = normalizeCustomColors(raw.custom);
  return palette;
}

export function createCustomColor(label = "Custom", hex = "#64748b"): BrandColorEntry {
  return {
    id: `c${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`.slice(0, 32),
    label,
    hex: normalizeHex(hex) ?? "#64748b",
  };
}

export function allPaletteSwatches(palette: BrandPalette): { label: string; hex: string }[] {
  const normalized = normalizeBrandPalette(palette);
  const core = BRAND_PALETTE_SLOTS.map((slot) => ({
    label: slot.label,
    hex: normalized[slot.key],
  }));
  const extra = normalized.custom.map((entry) => ({
    label: entry.label,
    hex: entry.hex,
  }));
  return [...core, ...extra];
}

export function hexToRgb(hex: string): [number, number, number] | null {
  const normalized = normalizeHex(hex);
  if (!normalized) return null;
  const value = normalized.slice(1);
  return [
    parseInt(value.slice(0, 2), 16),
    parseInt(value.slice(2, 4), 16),
    parseInt(value.slice(4, 6), 16),
  ];
}
