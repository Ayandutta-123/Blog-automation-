import KanbanBoard from "@/components/KanbanBoard";
import { Suspense } from "react";

export default function HomePage() {
  return (
    <Suspense fallback={<div className="p-6 text-slate-400">Loading board...</div>}>
      <KanbanBoard />
    </Suspense>
  );
}
