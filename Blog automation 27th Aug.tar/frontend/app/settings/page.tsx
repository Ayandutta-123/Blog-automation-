"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Box, KeyRound, Settings2, Shield } from "lucide-react";
import IntegrationsPanel from "@/components/IntegrationsPanel";
import ProductsPanel from "@/components/ProductsPanel";
import SecurityPanel from "@/components/SecurityPanel";
import UbersuggestPanel from "@/components/UbersuggestPanel";
import WordPressPanel from "@/components/WordPressPanel";
import GoogleBloggerPanel from "@/components/GoogleBloggerPanel";
import { Tab } from "@/components/ui/Tabs";
import { cn } from "@/lib/cn";

type TabId = "products" | "integrations" | "security";

const NAV_ITEMS: {
  id: TabId;
  label: string;
  description: string;
  icon: React.ElementType;
}[] = [
  {
    id: "products",
    label: "Products",
    description: "Profiles, automation & scrapers",
    icon: Box,
  },
  {
    id: "integrations",
    label: "Integrations",
    description: "API keys & content rules",
    icon: KeyRound,
  },
  {
    id: "security",
    label: "Security",
    description: "Password & sign out",
    icon: Shield,
  },
];

const TAB_META: Record<
  TabId,
  { eyebrow: string; title: string; blurb: string }
> = {
  products: {
    eyebrow: "Product workspace",
    title: "Product lines",
    blurb: "Configure automation mode, brand palette, schedules, and discovery targets per product.",
  },
  integrations: {
    eyebrow: "Connections",
    title: "Integrations",
    blurb: "Connect search, AI content, image generation, WordPress, Teams, and editorial rules that power every run.",
  },
  security: {
    eyebrow: "Access control",
    title: "Security",
    blurb: "Update your dashboard password and end the current session securely.",
  },
};

function parseTab(raw: string | null): TabId {
  if (raw === "integrations" || raw === "security" || raw === "products") return raw;
  return "products";
}

export default function SettingsPage() {
  return (
    <Suspense fallback={<div className="p-6 text-slate-400">Loading settings…</div>}>
      <SettingsPageInner />
    </Suspense>
  );
}

function SettingsPageInner() {
  const searchParams = useSearchParams();
  const [tab, setTab] = useState<TabId>(() => parseTab(searchParams.get("tab")));
  const meta = TAB_META[tab];

  useEffect(() => {
    setTab(parseTab(searchParams.get("tab")));
  }, [searchParams]);

  function selectTab(next: TabId) {
    setTab(next);
    const url = new URL(window.location.href);
    url.searchParams.set("tab", next);
    window.history.replaceState({}, "", url.toString());
  }

  return (
    <div className="settings-page min-h-full">
      <header className="settings-page-header">
        <div className="mx-auto flex w-full max-w-6xl flex-col gap-5 px-4 py-6 sm:px-6 md:flex-row md:items-end md:justify-between md:px-8 md:py-7">
          <div className="min-w-0 max-w-2xl">
            <p className="mb-2 inline-flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-hyper-orange">
              <Settings2 className="h-3.5 w-3.5" />
              Workspace
            </p>
            <h1 className="font-display text-[1.65rem] font-semibold tracking-tight text-hyper-navy sm:text-3xl">
              Settings
            </h1>
            <p className="mt-1.5 max-w-xl text-sm leading-relaxed text-slate-500">
              Product lines, integrations, and access — one place to run the content pipeline.
            </p>
          </div>

          <div className="settings-mobile-nav grid w-full grid-cols-3 gap-0.5 md:w-auto md:min-w-[300px] lg:hidden">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const active = tab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => selectTab(item.id)}
                  className={cn("settings-mobile-tab", active && "is-active")}
                >
                  <Icon className={cn("settings-mobile-tab-icon h-4 w-4 shrink-0")} />
                  <span className="w-full truncate text-[10px] font-semibold sm:text-[11px]">
                    {item.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </header>

      <div className="mx-auto w-full max-w-6xl px-4 py-6 sm:px-6 md:px-8 md:py-8">
        <div className="flex flex-col gap-6 lg:flex-row lg:gap-8">
          <aside className="hidden lg:sticky lg:top-4 lg:block lg:w-[240px] lg:shrink-0 lg:self-start">
            <p className="mb-2 px-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-400">
              Sections
            </p>
            <div
              role="tablist"
              aria-label="Settings sections"
              className="settings-sidebar flex flex-col gap-0.5"
            >
              {NAV_ITEMS.map((item) => (
                <Tab
                  key={item.id}
                  id={`tab-${item.id}`}
                  label={item.label}
                  description={item.description}
                  icon={item.icon}
                  active={tab === item.id}
                  variant="settings"
                  onClick={() => selectTab(item.id)}
                />
              ))}
            </div>
            <p className="mt-3 hidden px-1 text-[11px] leading-relaxed text-slate-400 lg:block">
              Changes apply <span className="font-medium text-slate-600">per product</span> unless
              noted. Save before leaving.
            </p>
          </aside>

          <div className="min-w-0 flex-1">
            <div className="mb-5 flex items-start justify-between gap-4">
              <div className="settings-panel-enter">
                <p className="settings-meta-eyebrow">{meta.eyebrow}</p>
                <h2 className="mt-1 font-display text-xl font-semibold tracking-tight text-hyper-navy sm:text-2xl">
                  {meta.title}
                </h2>
                <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-slate-500">
                  {meta.blurb}
                </p>
              </div>
            </div>

            <div className="settings-shell">
              <div className="settings-shell-accent" />
              <div key={tab} className="settings-panel-enter p-4 sm:p-5 md:p-6 lg:p-7">
                {tab === "products" ? (
                  <ProductsPanel />
                ) : tab === "integrations" ? (
                  <div className="settings-stack">
                    <Suspense fallback={null}>
                      <UbersuggestPanel />
                    </Suspense>
                    <WordPressPanel />
                    <GoogleBloggerPanel />
                    <IntegrationsPanel />
                  </div>
                ) : (
                  <SecurityPanel />
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
