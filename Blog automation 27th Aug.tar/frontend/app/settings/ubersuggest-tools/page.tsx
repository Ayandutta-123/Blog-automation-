"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  ChevronDown,
  ChevronRight,
  Loader2,
  Play,
} from "lucide-react";
import { api, UbersuggestTool } from "@/lib/api";

export default function UbersuggestToolsPage() {
  const [tools, setTools] = useState<UbersuggestTool[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [testTool, setTestTool] = useState("");
  const [testArgs, setTestArgs] = useState("{}");
  const [testResult, setTestResult] = useState<string | null>(null);
  const [testError, setTestError] = useState<string | null>(null);
  const [testing, setTesting] = useState(false);

  async function loadTools() {
    setLoading(true);
    setError(null);
    try {
      const data = await api.getUbersuggestTools();
      setTools(data.tools);
    } catch (e) {
      setError(String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadTools();
  }, []);

  async function handleRunTest() {
    setTesting(true);
    setTestResult(null);
    setTestError(null);
    try {
      const args = testArgs.trim() ? JSON.parse(testArgs) : {};
      const data = await api.callUbersuggestTool(testTool, args);
      setTestResult(JSON.stringify(data.result, null, 2));
    } catch (e) {
      setTestError(String(e));
    } finally {
      setTesting(false);
    }
  }

  function toggleExpand(name: string) {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name);
      else next.add(name);
      return next;
    });
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-8 md:px-8">
      <Link
        href="/settings"
        className="mb-6 inline-flex items-center gap-1.5 text-sm font-medium text-hyper-primary hover:underline"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Settings
      </Link>

      <h1 className="font-display text-2xl font-bold text-hyper-navy">
        Ubersuggest tools
      </h1>
      <p className="mt-2 max-w-2xl text-sm text-text-secondary">
        Full catalog of MCP tools from your connected Ubersuggest account. This is for
        debugging and exploration — day-to-day use happens via keyword volume and
        backlink checks in the automation pipeline, not this list.
      </p>

      <div className="mt-6 space-y-5">
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium text-hyper-navy">
            {tools ? `${tools.length} tools` : "Tools"}
          </p>
          <button
            type="button"
            onClick={loadTools}
            disabled={loading}
            className="text-xs font-medium text-hyper-primary hover:underline disabled:opacity-50"
          >
            {loading ? "Loading…" : "Refresh"}
          </button>
        </div>

        {error && (
          <p className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-800">
            {error}
          </p>
        )}

        {loading && !tools && (
          <p className="text-sm text-text-muted">Loading tools from Ubersuggest…</p>
        )}

        {tools && tools.length > 0 && (
          <div className="divide-y divide-hyper-border overflow-hidden rounded-2xl border border-hyper-border bg-surface-0">
            {tools.map((t) => (
              <div key={t.name} className="px-4 py-3">
                <button
                  type="button"
                  onClick={() => toggleExpand(t.name)}
                  className="flex w-full items-start gap-2 text-left"
                >
                  {expanded.has(t.name) ? (
                    <ChevronDown className="mt-0.5 h-3.5 w-3.5 shrink-0 text-text-muted" />
                  ) : (
                    <ChevronRight className="mt-0.5 h-3.5 w-3.5 shrink-0 text-text-muted" />
                  )}
                  <span>
                    <span className="font-mono text-sm font-medium text-hyper-navy">
                      {t.name}
                    </span>
                    {t.description && (
                      <span className="mt-0.5 block text-xs text-text-secondary">
                        {t.description}
                      </span>
                    )}
                  </span>
                </button>
                {expanded.has(t.name) && t.input_schema && (
                  <pre className="mt-2 overflow-x-auto rounded-lg bg-surface-2 p-2 text-[11px] text-text-secondary">
                    {JSON.stringify(t.input_schema, null, 2)}
                  </pre>
                )}
              </div>
            ))}
          </div>
        )}

        {tools && tools.length > 0 && (
          <div className="rounded-2xl border border-hyper-border bg-surface-0 p-5">
            <p className="mb-2 text-sm font-medium text-hyper-navy">Test a tool</p>
            <select
              value={testTool}
              onChange={(e) => setTestTool(e.target.value)}
              className="w-full rounded-xl border border-hyper-border px-3 py-2 text-sm focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/20"
            >
              <option value="">Select a tool…</option>
              {tools.map((t) => (
                <option key={t.name} value={t.name}>
                  {t.name}
                </option>
              ))}
            </select>
            <textarea
              value={testArgs}
              onChange={(e) => setTestArgs(e.target.value)}
              rows={3}
              placeholder='{"keyword": "smart parking"}'
              className="mt-2 w-full rounded-xl border border-hyper-border px-3 py-2 font-mono text-xs focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/20"
            />
            <div className="mt-2 flex justify-end">
              <button
                type="button"
                onClick={handleRunTest}
                disabled={testing || !testTool}
                className="flex items-center gap-1.5 rounded-xl bg-hyper-primary px-4 py-2 text-sm font-medium text-white hover:bg-hyper-navy disabled:cursor-not-allowed disabled:opacity-40"
              >
                {testing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
                Run
              </button>
            </div>
            {testError && (
              <p className="mt-2 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-800">
                {testError}
              </p>
            )}
            {testResult && (
              <pre className="mt-2 max-h-80 overflow-auto rounded-lg bg-surface-2 p-3 text-[11px] text-text-secondary">
                {testResult}
              </pre>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
