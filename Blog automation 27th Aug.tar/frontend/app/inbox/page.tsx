"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowRight, FileText, CheckSquare, Inbox } from "lucide-react";
import { api, BlogPostSummary } from "@/lib/api";
import { getPostTitle, formatDate } from "@/lib/status";
import StatusBadge from "@/components/StatusBadge";
import { Card, CardBody, CardHeader } from "@/components/ui/Card";
import EmptyState from "@/components/ui/EmptyState";
import { Skeleton } from "@/components/ui/Skeleton";

export default function InboxPage() {
  const [topics, setTopics] = useState<BlogPostSummary[]>([]);
  const [reviews, setReviews] = useState<BlogPostSummary[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([api.getPendingTopics(), api.getPendingReviews()])
      .then(([t, r]) => {
        setTopics(t);
        setReviews(r);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const totalPending = topics.length + reviews.length;

  return (
    <div className="mx-auto max-w-4xl px-4 py-6 md:px-6">
      <div className="animate-fade-up">
        <p className="text-micro uppercase tracking-[0.16em] text-text-muted">Attention</p>
        <h1 className="mt-1 font-display text-2xl tracking-tight text-hyper-navy sm:text-display">Inbox</h1>
        <p className="mt-1.5 text-sm font-medium text-text-secondary">
          Items requiring your attention across HITL gates
          {!loading && totalPending > 0 && (
            <span className="ml-2 rounded-xl bg-hyper-primary/10 px-2.5 py-0.5 text-xs font-bold text-hyper-primary shadow-soft">
              {totalPending} pending
            </span>
          )}
        </p>
      </div>

      {loading ? (
        <div className="mt-6 space-y-4">
          <Skeleton className="h-48 w-full rounded-2xl" />
          <Skeleton className="h-48 w-full rounded-2xl" />
        </div>
      ) : (
        <div className="stagger-in mt-6 space-y-6">
          <InboxSection
            title="Topic Selection"
            icon={FileText}
            items={topics}
            emptyTitle="No topics pending"
            emptyDescription="Topics appear here after discovery completes"
          />
          <InboxSection
            title="Content Review"
            icon={CheckSquare}
            items={reviews}
            emptyTitle="No posts pending review"
            emptyDescription="Generated posts land here for editorial sign-off"
          />
        </div>
      )}
    </div>
  );
}

function InboxSection({
  title,
  icon: Icon,
  items,
  emptyTitle,
  emptyDescription,
}: {
  title: string;
  icon: React.ElementType;
  items: BlogPostSummary[];
  emptyTitle: string;
  emptyDescription: string;
}) {
  return (
    <Card variant="elevated">
      <CardHeader className="flex items-center gap-2">
        <Icon className="h-4 w-4 text-hyper-primary" />
        <h2 className="font-display text-h2 text-hyper-navy">{title}</h2>
        <span className="ml-auto rounded-full bg-hyper-primary/10 px-2.5 py-0.5 text-xs font-semibold text-hyper-primary tabular-nums">
          {items.length}
        </span>
      </CardHeader>
      {items.length === 0 ? (
        <EmptyState icon={Inbox} title={emptyTitle} description={emptyDescription} />
      ) : (
        <ul className="divide-y divide-hyper-border">
          {items.map((item) => (
            <li key={item.id}>
              <Link
                href={`/?post=${item.id}`}
                className="group flex items-start gap-3 px-4 py-4 transition hover:bg-surface-1 sm:items-center sm:gap-4 sm:px-5"
              >
                <div className="min-w-0 flex-1">
                  <p className="line-clamp-2 font-medium text-hyper-navy group-hover:text-hyper-primary sm:truncate sm:line-clamp-none">
                    {getPostTitle(item)}
                  </p>
                  <div className="mt-1.5 flex flex-wrap items-center gap-2 sm:mt-0.5">
                    <p className="font-mono text-xs text-text-muted">
                      {formatDate(item.created_at)}
                    </p>
                    <span className="sm:hidden">
                      <StatusBadge status={item.status} />
                    </span>
                  </div>
                </div>
                <span className="hidden shrink-0 sm:inline-flex">
                  <StatusBadge status={item.status} />
                </span>
                <ArrowRight className="mt-1 h-4 w-4 shrink-0 text-text-muted transition group-hover:translate-x-0.5 group-hover:text-hyper-primary sm:mt-0" />
              </Link>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}
