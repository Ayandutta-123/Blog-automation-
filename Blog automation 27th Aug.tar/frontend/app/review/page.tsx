import { redirect } from "next/navigation";

export default function ReviewRedirect({
  searchParams,
}: {
  searchParams?: { post?: string };
}) {
  const postId = searchParams?.post;
  if (postId) {
    redirect(`/?post=${postId}`);
  }
  redirect("/");
}
