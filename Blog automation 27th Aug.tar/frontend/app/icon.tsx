import { ImageResponse } from "next/og";

export const size = { width: 32, height: 32 };
export const contentType = "image/png";

/** Serves /favicon.ico via Next metadata conventions. */
export default function Icon() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "#1b1f4a",
          borderRadius: 8,
          color: "#fff",
          fontSize: 18,
          fontWeight: 700,
        }}
      >
        B
      </div>
    ),
    size
  );
}
