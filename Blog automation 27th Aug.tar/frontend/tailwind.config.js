/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        hyper: {
          primary: "#252a61",
          navy: "#1b1f4a",
          dark: "#0a0349",
          red: "#c1262a",
          orange: "#ff6002",
          surface: "#e8eaf4",
          sidebar: "#f4f5fa",
          canvas: "#f8f9fc",
          border: "#e8eaef",
        },
        surface: {
          0: "#ffffff",
          1: "#f5f6fb",
          2: "#eceef6",
        },
        text: {
          primary: "#0f172a",
          secondary: "#64748b",
          muted: "#94a3b8",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "system-ui", "sans-serif"],
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "ui-monospace", "monospace"],
      },
      fontSize: {
        display: ["2rem", { lineHeight: "1.2", letterSpacing: "-0.02em", fontWeight: "700" }],
        h1: ["1.5rem", { lineHeight: "1.3", fontWeight: "700" }],
        h2: ["1.125rem", { lineHeight: "1.4", fontWeight: "600" }],
        h3: ["0.9375rem", { lineHeight: "1.45", fontWeight: "600" }],
        body: ["0.875rem", { lineHeight: "1.6", fontWeight: "400" }],
        small: ["0.75rem", { lineHeight: "1.5", fontWeight: "500" }],
        micro: ["0.6875rem", { lineHeight: "1.4", fontWeight: "500", letterSpacing: "0.05em" }],
      },
      boxShadow: {
        card: "0 4px 20px rgba(27, 31, 74, 0.06)",
        elevated: "0 16px 40px -18px rgba(27, 31, 74, 0.28)",
        soft: "0 2px 10px rgba(27, 31, 74, 0.04)",
        glow: "0 10px 28px -12px rgba(255, 96, 2, 0.55)",
        "nav-active": "0 8px 20px -12px rgba(37, 42, 97, 0.45)",
      },
      borderRadius: {
        "2xl": "16px",
        "3xl": "20px",
      },
      transitionDuration: {
        DEFAULT: "200ms",
      },
      keyframes: {
        "modal-in": {
          from: { opacity: "0", transform: "scale(0.97) translateY(8px)" },
          to: { opacity: "1", transform: "scale(1) translateY(0)" },
        },
        "fade-up": {
          from: { opacity: "0", transform: "translateY(10px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
        "fade-in": {
          from: { opacity: "0" },
          to: { opacity: "1" },
        },
        "slide-in": {
          from: { opacity: "0", transform: "translateX(-6px)" },
          to: { opacity: "1", transform: "translateX(0)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
        pulseDot: {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.35" },
        },
        "work-pulse": {
          "0%, 100%": { boxShadow: "0 0 0 0 rgba(255, 96, 2, 0.35)" },
          "70%": { boxShadow: "0 0 0 10px rgba(255, 96, 2, 0)" },
        },
        "bell-ring": {
          "0%, 100%": { transform: "rotate(0deg)" },
          "15%": { transform: "rotate(14deg)" },
          "30%": { transform: "rotate(-12deg)" },
          "45%": { transform: "rotate(10deg)" },
          "60%": { transform: "rotate(-6deg)" },
          "75%": { transform: "rotate(3deg)" },
        },
      },
      animation: {
        "modal-in": "modal-in 240ms cubic-bezier(0.16, 1, 0.3, 1)",
        "fade-up": "fade-up 420ms cubic-bezier(0.16, 1, 0.3, 1) both",
        "fade-in": "fade-in 320ms ease-out both",
        "slide-in": "slide-in 280ms ease-out both",
        shimmer: "shimmer 1.8s linear infinite",
        "pulse-dot": "pulseDot 1.5s ease-in-out infinite",
        "work-pulse": "work-pulse 1.8s ease-out infinite",
        "bell-ring": "bell-ring 700ms ease-in-out",
      },
    },
  },
  plugins: [],
};
