"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { api, NotificationItem } from "@/lib/api";

const READ_KEY = "hyperpark-read-notifications";
const DISMISSED_KEY = "hyperpark-dismissed-notifications";
const POLL_MS = 5000;
const MAX_DISMISSED = 300;

function loadIdSet(key: string): Set<string> {
  if (typeof window === "undefined") return new Set();
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return new Set();
    return new Set(JSON.parse(raw) as string[]);
  } catch {
    return new Set();
  }
}

function saveIdSet(key: string, ids: Set<string>, max = MAX_DISMISSED) {
  const arr = Array.from(ids);
  const trimmed = arr.length > max ? arr.slice(arr.length - max) : arr;
  localStorage.setItem(key, JSON.stringify(trimmed));
}

function playNotificationTone(kind: "success" | "error" | "action" = "action") {
  if (typeof window === "undefined") return;
  try {
    const Ctx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    const now = ctx.currentTime;
    const master = ctx.createGain();
    master.gain.setValueAtTime(0.0001, now);
    master.gain.exponentialRampToValueAtTime(0.08, now + 0.02);
    master.gain.exponentialRampToValueAtTime(0.0001, now + 0.35);
    master.connect(ctx.destination);

    const freqs =
      kind === "error"
        ? [220, 180]
        : kind === "success"
          ? [660, 880]
          : [520, 690];

    freqs.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      osc.type = "sine";
      osc.frequency.value = freq;
      osc.connect(master);
      osc.start(now + i * 0.08);
      osc.stop(now + 0.28 + i * 0.08);
    });
    window.setTimeout(() => void ctx.close(), 500);
  } catch {
    /* autoplay / unsupported — ignore */
  }
}

type BannerState = {
  id: string;
  title: string;
  message: string;
  severity: NotificationItem["severity"];
} | null;

type NotificationContextValue = {
  items: NotificationItem[];
  unreadCount: number;
  loading: boolean;
  open: boolean;
  setOpen: (open: boolean) => void;
  refresh: () => Promise<void>;
  markRead: (id: string) => void;
  markAllRead: () => void;
  /** Remove every message from the bell (they stay cleared on refresh). */
  clearAll: () => void;
  isRead: (id: string) => boolean;
  /** Instant bell badge + feed entry + sound + banner. */
  notifySaved: (title: string, message?: string) => void;
  /** Instant error in the bell + banner. */
  notifyError: (title: string, message?: string) => void;
  /** Transient top-of-panel banner. */
  banner: BannerState;
  dismissBanner: () => void;
  /** Pulse the bell badge briefly. */
  badgePulse: boolean;
  /** Anchor element that opened the panel (for positioning a single shared portal). */
  registerAnchor: (el: HTMLElement | null) => void;
  anchorEl: HTMLElement | null;
};

const NotificationContext = createContext<NotificationContextValue | null>(null);

export function NotificationProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [readIds, setReadIds] = useState<Set<string>>(() => loadIdSet(READ_KEY));
  const [dismissedIds, setDismissedIds] = useState<Set<string>>(() =>
    loadIdSet(DISMISSED_KEY)
  );
  const dismissedRef = useRef(dismissedIds);
  dismissedRef.current = dismissedIds;
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [banner, setBanner] = useState<BannerState>(null);
  const [badgePulse, setBadgePulse] = useState(false);
  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);
  const knownIds = useRef<Set<string>>(new Set());
  const hydrated = useRef(false);
  const bannerTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const registerAnchor = useCallback((el: HTMLElement | null) => {
    if (el) setAnchorEl(el);
  }, []);

  const showBanner = useCallback((item: NotificationItem) => {
    setBanner({
      id: item.id,
      title: item.title,
      message: item.message,
      severity: item.severity,
    });
    setBadgePulse(true);
    window.setTimeout(() => setBadgePulse(false), 1800);
    if (bannerTimer.current) clearTimeout(bannerTimer.current);
    bannerTimer.current = setTimeout(() => setBanner(null), 4500);
  }, []);

  const dismissBanner = useCallback(() => {
    setBanner(null);
    if (bannerTimer.current) clearTimeout(bannerTimer.current);
  }, []);

  const refresh = useCallback(async () => {
    try {
      const data = await api.getNotifications();
      const dismissed = dismissedRef.current;
      const nextItems = (data.items || []).filter((i) => !dismissed.has(i.id));
      setItems((prev) => {
        const locals = prev.filter(
          (i) =>
            (i.id.startsWith("local-saved-") || i.id.startsWith("local-error-")) &&
            !dismissed.has(i.id)
        );
        const seen = new Set(nextItems.map((i) => `${i.title}::${i.message}`));
        const keepLocals = locals.filter(
          (l) => !seen.has(`${l.title}::${l.message}`)
        );
        return [...keepLocals, ...nextItems].slice(0, 60);
      });

      // Sound + banner for newly arrived server events (after first hydrate)
      if (hydrated.current) {
        const fresh = nextItems.filter((i) => !knownIds.current.has(i.id));
        if (fresh.length > 0) {
          const top = fresh[0];
          playNotificationTone(
            top.severity === "error"
              ? "error"
              : top.severity === "success"
                ? "success"
                : "action"
          );
          showBanner(top);
        }
      }
      for (const i of nextItems) knownIds.current.add(i.id);
      hydrated.current = true;
    } catch {
      /* ignore transient network errors */
    } finally {
      setLoading(false);
    }
  }, [showBanner]);

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, POLL_MS);
    return () => clearInterval(id);
  }, [refresh]);

  const markRead = useCallback((id: string) => {
    setReadIds((prev) => {
      if (prev.has(id)) return prev;
      const next = new Set(prev);
      next.add(id);
      saveIdSet(READ_KEY, next);
      return next;
    });
  }, []);

  const markAllRead = useCallback(() => {
    setReadIds((prev) => {
      const next = new Set(prev);
      for (const item of items) next.add(item.id);
      saveIdSet(READ_KEY, next);
      return next;
    });
  }, [items]);

  const clearAll = useCallback(() => {
    setDismissedIds((prev) => {
      const next = new Set(prev);
      for (const item of items) next.add(item.id);
      saveIdSet(DISMISSED_KEY, next);
      dismissedRef.current = next;
      return next;
    });
    setReadIds((prev) => {
      const next = new Set(prev);
      for (const item of items) next.add(item.id);
      saveIdSet(READ_KEY, next);
      return next;
    });
    setItems([]);
    setBanner(null);
    if (bannerTimer.current) clearTimeout(bannerTimer.current);
  }, [items]);

  const isRead = useCallback((id: string) => readIds.has(id), [readIds]);

  const notifySaved = useCallback(
    (title: string, message = "Changes were saved successfully.") => {
      const item: NotificationItem = {
        id: `local-saved-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        type: "published",
        post_id: 0,
        title,
        message,
        timestamp: new Date().toISOString(),
        severity: "success",
      };
      knownIds.current.add(item.id);
      setItems((prev) => [item, ...prev].slice(0, 60));
      playNotificationTone("success");
      showBanner(item);
      setOpen(true);
      void refresh();
    },
    [refresh, showBanner]
  );

  const notifyError = useCallback(
    (title: string, message = "Something went wrong.") => {
      const item: NotificationItem = {
        id: `local-error-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        type: "error",
        post_id: 0,
        title,
        message,
        timestamp: new Date().toISOString(),
        severity: "error",
      };
      knownIds.current.add(item.id);
      setItems((prev) => [item, ...prev].slice(0, 60));
      playNotificationTone("error");
      showBanner(item);
      setOpen(true);
      void refresh();
    },
    [refresh, showBanner]
  );

  const unreadCount = useMemo(
    () => items.filter((item) => !readIds.has(item.id)).length,
    [items, readIds]
  );

  const value = useMemo(
    () => ({
      items,
      unreadCount,
      loading,
      open,
      setOpen,
      refresh,
      markRead,
      markAllRead,
      clearAll,
      isRead,
      notifySaved,
      notifyError,
      banner,
      dismissBanner,
      badgePulse,
      registerAnchor,
      anchorEl,
    }),
    [
      items,
      unreadCount,
      loading,
      open,
      refresh,
      markRead,
      markAllRead,
      clearAll,
      isRead,
      notifySaved,
      notifyError,
      banner,
      dismissBanner,
      badgePulse,
      registerAnchor,
      anchorEl,
    ]
  );

  return (
    <NotificationContext.Provider value={value}>
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  const ctx = useContext(NotificationContext);
  if (!ctx) {
    throw new Error("useNotifications must be used within NotificationProvider");
  }
  return ctx;
}
