"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { api } from "@/lib/api";

const TOKEN_KEY = "blog_automation_token";

type AuthContextValue = {
  isAuthenticated: boolean;
  loading: boolean;
  role: "admin" | "user" | null;
  username: string | null;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const [role, setRole] = useState<"admin" | "user" | null>(null);
  const [username, setUsername] = useState<string | null>(null);

  const checkSession = useCallback(async () => {
    const token = localStorage.getItem(TOKEN_KEY);
    if (!token) {
      setIsAuthenticated(false);
      setRole(null);
      setUsername(null);
      setLoading(false);
      return;
    }
    try {
      const res = await api.getSession();
      if (res.authenticated) {
        setIsAuthenticated(true);
        setRole(res.role === "admin" || res.role === "user" ? res.role : null);
        setUsername(res.username ?? null);
      } else {
        // Server explicitly rejected the session (logout / expired)
        localStorage.removeItem(TOKEN_KEY);
        setIsAuthenticated(false);
        setRole(null);
        setUsername(null);
      }
    } catch {
      // Network/server blip — keep local token; do not force re-login
      setIsAuthenticated(true);
      setRole(null);
      setUsername(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    checkSession();
  }, [checkSession]);

  const login = useCallback(async (username: string, password: string) => {
    const res = await api.login(username, password);
    localStorage.setItem(TOKEN_KEY, res.token);
    setIsAuthenticated(true);
    try {
      const session = await api.getSession();
      setRole(
        session.role === "admin" || session.role === "user" ? session.role : null
      );
      setUsername(session.username ?? null);
    } catch {
      setRole(null);
      setUsername(username);
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      await api.logout();
    } catch {
      /* ignore */
    }
    localStorage.removeItem(TOKEN_KEY);
    setIsAuthenticated(false);
    setRole(null);
    setUsername(null);
  }, []);

  const value = useMemo(
    () => ({ isAuthenticated, loading, role, username, login, logout }),
    [isAuthenticated, loading, role, username, login, logout]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return ctx;
}

export function getAuthToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem(TOKEN_KEY);
}
