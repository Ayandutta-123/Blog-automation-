"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";
import { CheckCircle2, X, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/cn";

export type ToastKind = "success" | "error" | "info";

type ToastItem = {
  id: string;
  kind: ToastKind;
  title: string;
  message?: string;
};

type ToastContextValue = {
  toast: (kind: ToastKind, title: string, message?: string) => void;
  success: (title: string, message?: string) => void;
  error: (title: string, message?: string) => void;
};

const ToastContext = createContext<ToastContextValue | null>(null);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const dismiss = useCallback((id: string) => {
    setItems((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const toast = useCallback(
    (kind: ToastKind, title: string, message?: string) => {
      const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      setItems((prev) => [...prev.slice(-4), { id, kind, title, message }]);
      const ms = kind === "error" ? 10000 : 4500;
      window.setTimeout(() => dismiss(id), ms);
    },
    [dismiss]
  );

  const value = useMemo(
    () => ({
      toast,
      success: (title: string, message?: string) => toast("success", title, message),
      error: (title: string, message?: string) => toast("error", title, message),
    }),
    [toast]
  );

  return (
    <ToastContext.Provider value={value}>
      {children}
      {mounted
        ? createPortal(
            <div className="pointer-events-none fixed bottom-[calc(4.75rem+env(safe-area-inset-bottom))] right-3 z-[9999] flex w-[min(24rem,calc(100vw-1.5rem))] flex-col gap-2 md:bottom-4 md:right-4">
              {items.map((item) => (
                <div
                  key={item.id}
                  className={cn(
                    "pointer-events-auto flex items-start gap-3 rounded-xl border px-4 py-3 shadow-elevated animate-modal-in",
                    item.kind === "success" &&
                      "border-emerald-300 bg-emerald-50 text-emerald-950",
                    item.kind === "error" && "border-red-300 bg-red-50 text-red-950",
                    item.kind === "info" && "border-hyper-border bg-white text-hyper-navy"
                  )}
                  role="status"
                >
                  {item.kind === "error" ? (
                    <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" />
                  ) : (
                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold">{item.title}</p>
                    {item.message ? (
                      <p className="mt-0.5 text-xs font-medium opacity-90">{item.message}</p>
                    ) : null}
                  </div>
                  <button
                    type="button"
                    className="rounded-md p-1 opacity-60 hover:opacity-100"
                    onClick={() => dismiss(item.id)}
                    aria-label="Dismiss"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>,
            document.body
          )
        : null}
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) {
    throw new Error("useToast must be used within ToastProvider");
  }
  return ctx;
}
