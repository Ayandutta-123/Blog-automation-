/**
 * API origin for browser requests.
 * Empty string = same-origin (all-in-one Docker / nginx).
 * Dev default: http://localhost:8000
 */
export function apiBase(): string {
  return process.env.NEXT_PUBLIC_API_URL === undefined
    ? "http://localhost:8000"
    : process.env.NEXT_PUBLIC_API_URL;
}

/** Absolute or same-origin URL for a backend path like `/api/images/x.webp`. */
export function apiUrl(path: string): string {
  const base = apiBase();
  const p = path.startsWith("/") ? path : `/${path}`;
  return `${base}${p}`;
}

/**
 * Fully-qualified http(s) URL for a backend path.
 * Needed for standalone downloaded HTML (relative `/api/...` only works in-app).
 */
export function absoluteApiUrl(path: string): string {
  const url = apiUrl(path);
  if (/^https?:\/\//i.test(url)) return url;
  const pathOnly = url.startsWith("/") ? url : `/${url}`;
  if (typeof window !== "undefined" && window.location?.origin) {
    return new URL(pathOnly, window.location.origin).href;
  }
  return pathOnly;
}

/**
 * Rewrite insecure/local absolute API URLs to same-origin paths on HTTPS pages.
 * Fixes mixed-content when DB still has http://localhost:8000/...
 */
export function safePublicUrl(url: string | null | undefined): string {
  if (!url) return "";
  if (url.startsWith("data:") || url.startsWith("blob:")) return url;
  try {
    const origin =
      typeof window !== "undefined" ? window.location.origin : "http://localhost";
    const u = new URL(url, origin);
    const isLocal = u.hostname === "localhost" || u.hostname === "127.0.0.1";
    const onHttps =
      typeof window !== "undefined" && window.location.protocol === "https:";
    if (isLocal || (onHttps && u.protocol === "http:" && u.pathname.startsWith("/api/"))) {
      return `${u.pathname}${u.search}`;
    }
    return u.toString();
  } catch {
    return url;
  }
}
