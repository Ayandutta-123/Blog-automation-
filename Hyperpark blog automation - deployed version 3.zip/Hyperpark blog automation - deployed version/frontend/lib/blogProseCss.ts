import {
  BrandPalette,
  DEFAULT_BRAND_PALETTE,
  normalizeBrandPalette,
} from "./brandPalette";

const BLOG_PROSE_CSS_TEMPLATE = `
__BRAND_ROOT__

*, *::before, *::after { box-sizing: border-box; }

html {
  -webkit-text-size-adjust: 100%;
  scroll-behavior: smooth;
}

body {
  margin: 0;
  min-height: 100vh;
  width: 100%;
  background: #ffffff;
  color: var(--text-primary);
  font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
  -webkit-font-smoothing: antialiased;
  text-align: left;
}

.blog-page {
  width: 100%;
  min-height: 100vh;
  display: block;
  padding: 0;
  background: #ffffff;
}

.prose-blog {
  width: 100%;
  max-width: var(--content-max);
  margin: 0 auto;
  padding: var(--page-pad-y) var(--page-pad-x) clamp(3rem, 7vw, 5rem);
  background: #fff;
  min-height: 100vh;
  border-radius: 0;
  box-shadow: none;
  text-align: left;
}

/* Flatten nested wrappers from generated HTML */
.prose-blog article,
.prose-blog > article {
  display: block;
  width: 100%;
  max-width: none;
  margin: 0;
  padding: 0;
}

/* One column: every block shares the same left/right edges */
.prose-blog > *,
.prose-blog article > * {
  max-width: 100%;
  margin-left: 0;
  margin-right: 0;
  text-align: left;
}

.prose-blog h1,
.prose-blog h2,
.prose-blog h3,
.prose-blog h4 {
  font-family: "DM Sans", Inter, system-ui, sans-serif;
  overflow-wrap: anywhere;
  text-align: left;
  width: 100%;
  max-width: 100%;
}

.prose-blog h1 {
  margin: 0 0 1rem;
  font-size: clamp(1.5rem, 4vw, 2.1rem);
  line-height: 1.25;
  font-weight: 700;
  color: var(--hyper-navy);
}

.prose-blog h2 {
  margin: 1.75rem 0 0.65rem;
  font-size: clamp(1.15rem, 2.5vw, 1.4rem);
  font-weight: 600;
  color: var(--hyper-primary);
}

.prose-blog h3 {
  margin: 1.15rem 0 0.45rem;
  font-size: clamp(1rem, 2vw, 1.15rem);
  font-weight: 600;
  color: var(--hyper-navy);
}

.prose-blog p {
  margin: 0 0 1rem;
  line-height: 1.7;
  font-size: 1.05rem;
  color: #475569;
  width: 100%;
  max-width: 100%;
  text-align: left;
}

.prose-blog a {
  color: var(--hyper-link, var(--hyper-red));
  text-decoration: underline;
}

.prose-blog a:hover {
  color: var(--hyper-orange);
}

.prose-blog ul,
.prose-blog ol:not(.toc-list) {
  margin: 0 0 1rem;
  padding-left: 1.35rem;
  width: 100%;
  max-width: 100%;
  text-align: left;
}

.prose-blog ul { list-style-type: disc; }
.prose-blog ol:not(.toc-list) { list-style-type: decimal; }

.prose-blog li {
  margin-bottom: 0.35rem;
  line-height: 1.55;
  color: #475569;
  text-align: left;
}

.prose-blog nav.toc {
  margin: 1.25rem 0 1.75rem;
  width: 100%;
  max-width: 100%;
  border-radius: 1rem;
  border: 1px solid var(--hyper-border);
  background: linear-gradient(180deg, #f8fafc 0%, #ffffff 100%);
  padding: 1rem 1.15rem 1.1rem;
  font-size: 0.9rem;
  box-shadow: 0 1px 2px rgba(27, 31, 74, 0.04);
}

.prose-blog nav.toc h2 {
  margin-top: 0;
  margin-bottom: 0.85rem;
  font-size: 0.7rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: #64748b;
}

.prose-blog nav.toc ol.toc-list,
.prose-blog nav.toc ul {
  margin: 0;
  padding: 0;
  list-style: none;
  max-width: none;
}

.prose-blog nav.toc li { margin: 0; color: inherit; }

.prose-blog nav.toc li + li {
  border-top: 1px solid #eef2f7;
}

.prose-blog nav.toc a {
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
  padding: 0.6rem 0.15rem;
  color: var(--hyper-navy);
  text-decoration: none;
  font-weight: 600;
  line-height: 1.35;
  text-align: left;
}

.prose-blog nav.toc a:hover {
  color: var(--hyper-primary);
}

.prose-blog nav.toc .toc-num {
  flex-shrink: 0;
  min-width: 1.6rem;
  font-size: 0.7rem;
  font-weight: 700;
  letter-spacing: 0.04em;
  color: var(--hyper-orange);
  font-variant-numeric: tabular-nums;
  padding-top: 0.1rem;
}

.prose-blog nav.toc .toc-label { flex: 1; }

.prose-blog .table-wrap {
  width: 100%;
  max-width: 100%;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
}

.prose-blog table.blog-table,
.prose-blog table {
  margin: 1.15rem 0;
  width: 100%;
  max-width: 100%;
  border-collapse: collapse;
  font-size: 0.9rem;
}

.prose-blog table th,
.prose-blog table td {
  border: 1px solid var(--hyper-border);
  padding: 0.55rem 0.8rem;
  text-align: left;
}

.prose-blog table th {
  background-color: var(--hyper-navy);
  color: #fff;
  font-weight: 600;
}

.prose-blog table tr:nth-child(even) td {
  background-color: var(--hyper-canvas);
}

.prose-blog .stat-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(min(100%, 140px), 1fr));
  gap: 0.85rem;
  margin: 1.15rem 0;
  width: 100%;
  max-width: 100%;
}

.prose-blog .stat-card {
  border-radius: 0.75rem;
  border: 1px solid var(--hyper-border);
  background: #fff;
  padding: 0.9rem;
  text-align: center;
}

.prose-blog .stat-card,
.prose-blog .stat-card * {
  text-align: center;
}

.prose-blog .stat-card strong,
.prose-blog .stat-number {
  display: block;
  font-size: clamp(1.15rem, 2vw, 1.45rem);
  color: var(--hyper-orange);
}

.prose-blog .blog-cta {
  margin-top: 2rem;
  width: 100%;
  max-width: 100%;
  border-radius: 1rem;
  background: linear-gradient(135deg, var(--hyper-navy), var(--hyper-primary));
  color: #fff;
  padding: clamp(1.15rem, 2.5vw, 1.75rem);
}

.prose-blog .blog-cta h2,
.prose-blog .blog-cta p,
.prose-blog .blog-cta li {
  color: #fff;
  max-width: none;
}

.prose-blog .blog-cta a { color: #fff; }

.prose-blog .blog-cta .cta-button {
  display: inline-block;
  margin-top: 0.65rem;
  border-radius: 0.5rem;
  background: var(--hyper-cta, var(--hyper-orange));
  padding: 0.6rem 1.1rem;
  font-weight: 600;
  text-decoration: none;
}

.prose-blog svg {
  max-width: 100%;
  height: auto;
  margin: 1rem 0;
}

.prose-blog .source-list {
  margin: 0.75rem 0 1rem;
  padding-left: 1.25rem;
  list-style: disc;
  font-size: 0.875rem;
}

.prose-blog .blog-chart figcaption {
  margin-top: 0.35rem;
  font-size: 0.75rem;
  color: #64748b;
  text-align: center;
}

.prose-blog img {
  margin: 0.75rem 0 1.5rem;
  border-radius: clamp(0.5rem, 1vw, 0.85rem);
  width: 100%;
  max-width: 100%;
  height: auto;
  display: block;
  object-fit: cover;
}

/* Fixed hero banner height — applies to every blog (preview + download HTML) */
.prose-blog .blog-hero-image {
  margin: 0.5rem 0 1.35rem;
  width: 100%;
  max-width: 100%;
  height: clamp(200px, 30vw, 360px);
  max-height: 360px;
  aspect-ratio: auto;
  object-fit: cover;
  object-position: center;
  display: block;
  border-radius: clamp(0.5rem, 1vw, 0.85rem);
}

@media (max-width: 640px) {
  .blog-page {
    padding: 0;
  }

  .prose-blog {
    padding: 1.25rem 1rem 2.5rem;
    border-radius: 0;
    min-height: 100dvh;
  }

  .prose-blog h1 {
    font-size: clamp(1.35rem, 6vw, 1.75rem);
  }

  .prose-blog nav.toc {
    padding: 0.85rem 0.9rem;
  }

  .prose-blog table th,
  .prose-blog table td {
    padding: 0.45rem 0.55rem;
  }
}

@media (min-width: 1024px) {
  .prose-blog {
    padding-left: clamp(2rem, 6vw, 4rem);
    padding-right: clamp(2rem, 6vw, 4rem);
  }
}
`.trim();

/**
 * Standalone CSS for downloaded blog HTML.
 * Pass a product brand palette so colors match Settings → Brand colors.
 */
export function buildBlogProseCss(
  palette?: Partial<BrandPalette> | null
): string {
  const p = normalizeBrandPalette(palette ?? DEFAULT_BRAND_PALETTE);
  return BLOG_PROSE_CSS_TEMPLATE.replace(
    "__BRAND_ROOT__",
    `:root {
  --hyper-primary: ${p.primary};
  --hyper-navy: ${p.navy};
  --hyper-dark: ${p.navy};
  --hyper-red: ${p.cta};
  --hyper-cta: ${p.cta};
  --hyper-orange: ${p.accent};
  --hyper-accent: ${p.accent};
  --hyper-link: ${p.link};
  --hyper-surface: #e8eaf4;
  --hyper-sidebar: #f4f5fa;
  --hyper-canvas: #f8f9fc;
  --hyper-border: #e8eaef;
  --surface-0: #ffffff;
  --surface-1: #f8f9fc;
  --text-primary: #0f172a;
  --text-secondary: #64748b;
  --text-muted: #94a3b8;
  --content-max: min(80rem, 100%);
  --page-pad-x: clamp(1rem, 5vw, 4rem);
  --page-pad-y: clamp(1.5rem, 4vw, 3.25rem);
}`
  );
}

/** Default (Navy & Orange) prose CSS — used when no product palette is supplied. */
export const BLOG_PROSE_CSS = buildBlogProseCss(DEFAULT_BRAND_PALETTE);

/** CSS custom properties for live Preview theming (inline on article). */
export function brandPaletteCssVars(
  palette?: Partial<BrandPalette> | null
): Record<string, string> {
  const p = normalizeBrandPalette(palette ?? DEFAULT_BRAND_PALETTE);
  return {
    "--hyper-primary": p.primary,
    "--hyper-navy": p.navy,
    "--hyper-dark": p.navy,
    "--hyper-red": p.cta,
    "--hyper-cta": p.cta,
    "--hyper-orange": p.accent,
    "--hyper-accent": p.accent,
    "--hyper-link": p.link,
  };
}
