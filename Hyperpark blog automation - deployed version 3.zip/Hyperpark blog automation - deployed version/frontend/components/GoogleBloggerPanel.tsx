"use client";

import { useCallback, useEffect, useState } from "react";
import {
  AlertTriangle,
  BookOpen,
  CheckCircle2,
  Eye,
  EyeOff,
  Loader2,
  LogOut,
  Plug,
  Unplug,
} from "lucide-react";
import { api, GoogleAccountStatus, Product } from "@/lib/api";
import { useToast } from "@/contexts/ToastContext";
import { useNotifications } from "@/contexts/NotificationContext";
import Button from "@/components/ui/Button";
import { cn } from "@/lib/cn";

export default function GoogleBloggerPanel() {
  const toast = useToast();
  const { notifySaved, notifyError, refresh } = useNotifications();
  const [products, setProducts] = useState<Product[]>([]);
  const [accounts, setAccounts] = useState<GoogleAccountStatus[]>([]);
  const [productId, setProductId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<"connect" | "test" | "logout" | null>(null);
  const [feedback, setFeedback] = useState<{
    kind: "success" | "error";
    title: string;
    message: string;
  } | null>(null);

  const [blogId, setBlogId] = useState("");
  const [accessToken, setAccessToken] = useState("");
  const [refreshToken, setRefreshToken] = useState("");
  const [clientId, setClientId] = useState("");
  const [clientSecret, setClientSecret] = useState("");
  const [showAccess, setShowAccess] = useState(false);
  const [showSecret, setShowSecret] = useState(false);
  const [isDraft, setIsDraft] = useState(false);

  const active = accounts.find((a) => a.product_id === productId) ?? null;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [prods, list] = await Promise.all([
        api.getProducts(),
        api.getGoogleAccounts(),
      ]);
      setProducts(prods);
      setAccounts(list);
      setProductId((prev) => {
        if (prev && prods.some((p) => p.id === prev)) return prev;
        const stored = localStorage.getItem("hyperpark_active_product_id");
        if (stored && /^\d+$/.test(stored) && prods.some((p) => p.id === Number(stored))) {
          return Number(stored);
        }
        return prods[0]?.id ?? null;
      });
    } catch (e) {
      console.error(e);
      setFeedback({
        kind: "error",
        title: "Could not load Google Blogger settings",
        message: String(e).replace(/^Error:\s*/i, ""),
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    if (!active) {
      setBlogId("");
      setAccessToken("");
      setRefreshToken("");
      setClientId("");
      setClientSecret("");
      setIsDraft(false);
      return;
    }
    setBlogId(active.blog_id || "");
    setAccessToken("");
    setRefreshToken("");
    setClientId("");
    setClientSecret("");
    setIsDraft(Boolean(active.is_draft));
  }, [active?.product_id, active?.connected, active?.blog_id, active?.is_draft]);

  function showResult(kind: "success" | "error", title: string, message: string) {
    setFeedback({ kind, title, message });
    if (kind === "success") {
      toast.success(title, message);
      notifySaved(title, message);
    } else {
      toast.error(title, message);
      notifyError(title, message);
    }
    void refresh();
  }

  async function handleConnect() {
    if (productId == null) return;
    if (!blogId.trim() || !accessToken.trim()) {
      showResult(
        "error",
        "Missing fields",
        "Blog ID and OAuth access token are required."
      );
      return;
    }
    setBusy("connect");
    setFeedback(null);
    try {
      const status = await api.connectGoogle(productId, {
        blog_id: blogId.trim(),
        access_token: accessToken.trim(),
        refresh_token: refreshToken.trim() || undefined,
        client_id: clientId.trim() || undefined,
        client_secret: clientSecret.trim() || undefined,
        is_draft: isDraft,
      });
      setAccounts((prev) =>
        prev.map((a) => (a.product_id === productId ? status : a))
      );
      setAccessToken("");
      setRefreshToken("");
      setClientSecret("");
      showResult(
        "success",
        "Google Blogger connected",
        `${status.blog_name || status.blog_id}${status.blog_url ? ` · ${status.blog_url}` : ""}`
      );
    } catch (e) {
      showResult(
        "error",
        "Google Blogger connect failed",
        String(e).replace(/^Error:\s*/i, "")
      );
    } finally {
      setBusy(null);
    }
  }

  async function handleTest() {
    if (productId == null) return;
    if (!blogId.trim() || !accessToken.trim()) {
      showResult(
        "error",
        "Missing fields",
        "Enter blog ID and access token to test."
      );
      return;
    }
    setBusy("test");
    setFeedback(null);
    try {
      const res = await api.testGoogle(productId, {
        blog_id: blogId.trim(),
        access_token: accessToken.trim(),
        refresh_token: refreshToken.trim() || undefined,
        client_id: clientId.trim() || undefined,
        client_secret: clientSecret.trim() || undefined,
      });
      showResult(
        "success",
        "Google Blogger OK",
        `${res.blog_name || res.blog_id}${res.blog_url ? ` · ${res.blog_url}` : ""}`
      );
    } catch (e) {
      showResult(
        "error",
        "Google Blogger test failed",
        String(e).replace(/^Error:\s*/i, "")
      );
    } finally {
      setBusy(null);
    }
  }

  async function handleLogout() {
    if (productId == null) return;
    if (
      !confirm(
        "Disconnect Google Blogger for this product? Credentials will be removed."
      )
    ) {
      return;
    }
    setBusy("logout");
    setFeedback(null);
    try {
      const status = await api.logoutGoogle(productId);
      setAccounts((prev) =>
        prev.map((a) => (a.product_id === productId ? status : a))
      );
      setAccessToken("");
      setRefreshToken("");
      setClientSecret("");
      showResult(
        "success",
        "Google Blogger disconnected",
        "Credentials cleared for this product."
      );
    } catch (e) {
      showResult("error", "Logout failed", String(e).replace(/^Error:\s*/i, ""));
    } finally {
      setBusy(null);
    }
  }

  return (
    <section className="overflow-hidden rounded-2xl border border-hyper-border/80 bg-white shadow-soft">
      <div className="border-b border-hyper-border/70 bg-gradient-to-r from-slate-50 to-white px-5 py-4 sm:px-6">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="mb-1 inline-flex items-center gap-2 text-hyper-navy">
              <BookOpen className="h-4 w-4 text-hyper-orange" />
              <h2 className="font-display text-base font-bold">Google Blogger</h2>
            </div>
            <p className="max-w-xl text-sm text-slate-600">
              Connect a Blogger blog per product with an OAuth access token that has the
              Blogger scope. Optional refresh token keeps publishing working after expiry.
            </p>
          </div>
          {active?.connected ? (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700 ring-1 ring-emerald-100">
              <CheckCircle2 className="h-3.5 w-3.5" />
              Connected
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-600">
              <Unplug className="h-3.5 w-3.5" />
              Not connected
            </span>
          )}
        </div>
      </div>

      <div className="space-y-5 px-5 py-5 sm:px-6">
        {feedback && (
          <div
            className={cn(
              "flex items-start gap-3 rounded-xl border px-4 py-3 text-sm",
              feedback.kind === "success"
                ? "border-emerald-200 bg-emerald-50 text-emerald-950"
                : "border-red-200 bg-red-50 text-red-950"
            )}
            role="alert"
          >
            {feedback.kind === "success" ? (
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
            ) : (
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" />
            )}
            <div className="min-w-0">
              <p className="font-semibold">{feedback.title}</p>
              <p className="mt-0.5 text-xs font-medium opacity-90">{feedback.message}</p>
            </div>
          </div>
        )}

        <label className="block">
          <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
            Product account
          </span>
          <select
            value={productId ?? ""}
            disabled={loading || products.length === 0}
            onChange={(e) => {
              setProductId(Number(e.target.value));
              setFeedback(null);
            }}
            className="h-11 w-full rounded-xl border border-hyper-border/80 bg-white px-3.5 text-sm font-semibold text-hyper-navy shadow-soft focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/15"
          >
            {products.length === 0 ? (
              <option value="">No products yet</option>
            ) : (
              products.map((p) => {
                const st = accounts.find((a) => a.product_id === p.id);
                return (
                  <option key={p.id} value={p.id}>
                    {p.name}
                    {st?.connected ? " · connected" : " · not connected"}
                  </option>
                );
              })
            )}
          </select>
        </label>

        {loading ? (
          <div className="flex items-center gap-2 py-6 text-sm text-slate-600">
            <Loader2 className="h-4 w-4 animate-spin" />
            Loading Google Blogger accounts…
          </div>
        ) : (
          <>
            {active?.connected && (
              <div className="rounded-xl border border-emerald-100 bg-emerald-50/80 px-4 py-3 text-sm text-emerald-900">
                <p className="font-semibold">
                  {active.blog_name || active.blog_id}
                  {active.blog_url ? (
                    <span className="ml-2 font-normal text-emerald-800/80">
                      {active.blog_url}
                    </span>
                  ) : null}
                </p>
                <p className="mt-0.5 text-xs text-emerald-800/80">
                  Connected{" "}
                  {active.connected_at
                    ? new Date(active.connected_at).toLocaleString()
                    : ""}
                  {" · "}
                  New posts will be created as{" "}
                  <strong>{active.is_draft ? "draft" : "live"}</strong>
                  {active.has_refresh_token ? " · refresh token saved" : ""}.
                </p>
              </div>
            )}

            <div className="grid gap-4 sm:grid-cols-2">
              <label className="block sm:col-span-2">
                <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Blog ID
                </span>
                <input
                  type="text"
                  value={blogId}
                  onChange={(e) => setBlogId(e.target.value)}
                  placeholder="Numeric Blogger blog ID"
                  className="h-11 w-full rounded-xl border border-hyper-border/80 px-3.5 text-sm text-hyper-navy shadow-soft focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/15"
                  autoComplete="off"
                />
              </label>
              <label className="block sm:col-span-2">
                <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Access token
                </span>
                <div className="relative">
                  <input
                    type={showAccess ? "text" : "password"}
                    value={accessToken}
                    onChange={(e) => setAccessToken(e.target.value)}
                    placeholder={
                      active?.has_token
                        ? "•••••••• (enter new to replace)"
                        : "OAuth access token (scope: blogger)"
                    }
                    className="h-11 w-full rounded-xl border border-hyper-border/80 px-3.5 pr-11 text-sm text-hyper-navy shadow-soft focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/15"
                    autoComplete="off"
                  />
                  <button
                    type="button"
                    onClick={() => setShowAccess((v) => !v)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-2 text-slate-500 hover:bg-slate-100 hover:text-hyper-navy"
                    aria-label={showAccess ? "Hide token" : "Show token"}
                  >
                    {showAccess ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </label>
              <label className="block sm:col-span-2">
                <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Refresh token (optional)
                </span>
                <input
                  type="password"
                  value={refreshToken}
                  onChange={(e) => setRefreshToken(e.target.value)}
                  placeholder={
                    active?.has_refresh_token
                      ? "•••••••• (enter new to replace)"
                      : "Optional — keeps access token fresh"
                  }
                  className="h-11 w-full rounded-xl border border-hyper-border/80 px-3.5 text-sm text-hyper-navy shadow-soft focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/15"
                  autoComplete="off"
                />
              </label>
              <label className="block">
                <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                  OAuth client ID (optional)
                </span>
                <input
                  type="text"
                  value={clientId}
                  onChange={(e) => setClientId(e.target.value)}
                  placeholder="Required with refresh token"
                  className="h-11 w-full rounded-xl border border-hyper-border/80 px-3.5 text-sm text-hyper-navy shadow-soft focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/15"
                  autoComplete="off"
                />
              </label>
              <label className="block">
                <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                  OAuth client secret (optional)
                </span>
                <div className="relative">
                  <input
                    type={showSecret ? "text" : "password"}
                    value={clientSecret}
                    onChange={(e) => setClientSecret(e.target.value)}
                    placeholder="Required with refresh token"
                    className="h-11 w-full rounded-xl border border-hyper-border/80 px-3.5 pr-11 text-sm text-hyper-navy shadow-soft focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/15"
                    autoComplete="off"
                  />
                  <button
                    type="button"
                    onClick={() => setShowSecret((v) => !v)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-2 text-slate-500 hover:bg-slate-100 hover:text-hyper-navy"
                    aria-label={showSecret ? "Hide secret" : "Show secret"}
                  >
                    {showSecret ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </label>
            </div>

            <label className="flex cursor-pointer items-center gap-2.5 text-sm text-slate-700">
              <input
                type="checkbox"
                checked={isDraft}
                onChange={(e) => setIsDraft(e.target.checked)}
                className="h-4 w-4 rounded border-hyper-border text-hyper-primary focus:ring-hyper-primary/30"
              />
              Save as draft on Blogger (unchecked = publish live)
            </label>

            <p className="text-xs leading-relaxed text-slate-500">
              Get a token via{" "}
              <a
                href="https://developers.google.com/oauthplayground/"
                target="_blank"
                rel="noreferrer"
                className="font-semibold text-hyper-primary hover:underline"
              >
                OAuth Playground
              </a>{" "}
              with scope{" "}
              <code className="rounded bg-slate-100 px-1 py-0.5 text-[10px]">
                https://www.googleapis.com/auth/blogger
              </code>
              . Blog ID is in Blogger settings or the blog URL after{" "}
              <code className="rounded bg-slate-100 px-1 py-0.5 text-[10px]">/blogs/</code>.
            </p>

            <div className="flex flex-wrap gap-2">
              <Button
                variant="orange"
                size="sm"
                onClick={handleConnect}
                disabled={busy != null || productId == null}
                loading={busy === "connect"}
              >
                <Plug className="h-4 w-4" />
                {active?.connected ? "Update & connect" : "Connect"}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleTest}
                disabled={busy != null || productId == null}
                loading={busy === "test"}
              >
                Test connection
              </Button>
              {active?.connected && (
                <Button
                  variant="danger"
                  size="sm"
                  onClick={handleLogout}
                  disabled={busy != null}
                  loading={busy === "logout"}
                >
                  <LogOut className="h-4 w-4" />
                  Logout
                </Button>
              )}
            </div>

            {accounts.some((a) => a.connected) && (
              <div className="rounded-xl border border-hyper-border/70 bg-slate-50 px-4 py-3">
                <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">
                  Connected accounts
                </p>
                <ul className="space-y-1.5">
                  {accounts
                    .filter((a) => a.connected)
                    .map((a) => (
                      <li
                        key={a.product_id}
                        className={cn(
                          "flex flex-wrap items-center justify-between gap-2 text-sm",
                          a.product_id === productId && "font-semibold text-hyper-navy"
                        )}
                      >
                        <span className="text-slate-700">
                          {a.product_name}
                          <span className="ml-2 font-normal text-slate-500">
                            {a.blog_name || a.blog_id}
                          </span>
                        </span>
                        <button
                          type="button"
                          className="text-xs font-semibold text-hyper-primary hover:underline"
                          onClick={() => setProductId(a.product_id)}
                        >
                          Manage
                        </button>
                      </li>
                    ))}
                </ul>
              </div>
            )}
          </>
        )}
      </div>
    </section>
  );
}
