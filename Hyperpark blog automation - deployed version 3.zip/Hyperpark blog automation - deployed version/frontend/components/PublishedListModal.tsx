"use client";

import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { CalendarClock, ChevronRight, Hash, Inbox, X } from "lucide-react";
import { api, BlogPostSummary } from "@/lib/api";
import { formatDateTime, getPostTitle } from "@/lib/status";
import EmptyState from "@/components/ui/EmptyState";
import { Skeleton } from "@/components/ui/Skeleton";
import { cn } from "@/lib/cn";

/**
 * Popup listing every published blog for the active product.
 * Click a row → open full-page reader (parent handles that).
 */
export default function PublishedListModal({
  productId,
  productName,
  onClose,
  onOpenPost,
}: {
  productId: number | null;
  productName?: string | null;
  onClose: () => void;
  onOpenPost: (post: BlogPostSummary) => void;
}) {
  const [mounted, setMounted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [posts, setPosts] = useState<BlogPostSummary[]>([]);

  useEffect(() => {
    setMounted(true);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      if (productId == null) {
        setPosts([]);
        setLoading(false);
        return;
      }
      setLoading(true);
      try {
        const list = await api.getPosts(productId, "PUBLISHED");
        if (!cancelled) setPosts(list);
      } catch (e) {
        console.error(e);
        if (!cancelled) setPosts([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    void load();
    return () => {
      cancelled = true;
    };
  }, [productId]);

  if (!mounted) return null;

  return createPortal(
    <div
      className="fixed inset-0 z-[110] flex items-end justify-center bg-hyper-dark/55 p-0 backdrop-blur-sm sm:items-center sm:p-4"
      onClick={onClose}
      role="presentation"
    >
      <div
        className="relative flex h-[min(92dvh,720px)] w-full max-w-2xl animate-modal-in flex-col overflow-hidden rounded-t-3xl border border-white/20 bg-white shadow-elevated sm:rounded-3xl"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-label="Published blogs"
      >
        <div className="settings-accent-bar h-1 shrink-0" />
        <div className="flex shrink-0 items-start justify-between gap-3 border-b border-hyper-border/70 px-5 py-4 sm:px-6">
          <div className="min-w-0">
            <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-emerald-700">
              Published · Live on ledger
            </p>
            <h2 className="mt-1 font-display text-lg font-bold tracking-tight text-hyper-navy sm:text-xl">
              {productName ? `${productName} blogs` : "All published blogs"}
            </h2>
            <p className="mt-1 text-xs text-text-secondary">
              {loading
                ? "Loading…"
                : `${posts.length} published post${posts.length === 1 ? "" : "s"} · click to open full page`}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-hyper-border bg-white text-slate-700 shadow-soft hover:bg-slate-50"
            aria-label="Close published list"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto">
          {loading ? (
            <div className="space-y-2 p-4">
              <Skeleton className="h-16 w-full rounded-xl" />
              <Skeleton className="h-16 w-full rounded-xl" />
              <Skeleton className="h-16 w-full rounded-xl" />
            </div>
          ) : posts.length === 0 ? (
            <div className="p-6">
              <EmptyState
                icon={Inbox}
                title="No published blogs yet"
                description="Approve & publish a post for this product — it will appear here."
              />
            </div>
          ) : (
            <ul className="divide-y divide-hyper-border/70">
              {posts.map((post) => {
                const when = post.published_at || post.created_at;
                return (
                  <li key={post.id}>
                    <button
                      type="button"
                      onClick={() => onOpenPost(post)}
                      className={cn(
                        "flex w-full items-center gap-3 px-5 py-3.5 text-left transition hover:bg-emerald-50/60 sm:px-6"
                      )}
                    >
                      <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-50 font-mono text-sm font-bold text-emerald-800 ring-1 ring-emerald-100">
                        <Hash className="mr-0.5 h-3 w-3" />
                        {post.publish_serial ?? "—"}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block line-clamp-2 font-display text-sm font-bold text-hyper-navy">
                          {getPostTitle(post)}
                        </span>
                        <span className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] font-medium text-slate-600">
                          <span className="inline-flex items-center gap-1">
                            <CalendarClock className="h-3 w-3 text-emerald-600" />
                            {formatDateTime(when)}
                          </span>
                          {post.reading_time ? (
                            <span>· {post.reading_time}</span>
                          ) : null}
                        </span>
                      </span>
                      <ChevronRight className="h-4 w-4 shrink-0 text-slate-400" />
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </div>
    </div>,
    document.body
  );
}
