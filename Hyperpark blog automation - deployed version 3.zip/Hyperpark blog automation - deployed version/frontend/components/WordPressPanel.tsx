"use client";

import { useCallback, useEffect, useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  Eye,
  EyeOff,
  Globe,
  Loader2,
  LogOut,
  Plug,
  Unplug,
} from "lucide-react";
import { api, Product, WordPressAccountStatus } from "@/lib/api";
import { useToast } from "@/contexts/ToastContext";
import { useNotifications } from "@/contexts/NotificationContext";
import Button from "@/components/ui/Button";
import { cn } from "@/lib/cn";

function normalizeSiteUrlInput(raw: string): string {
  let value = raw.trim();
  if (!value) return "";
  if (!/^https?:\/\//i.test(value)) value = `https://${value}`;
  value = value.replace(/\/wp-admin\/?.*$/i, "");
  value = value.replace(/\/wp-login\.php.*$/i, "");
  try {
    const u = new URL(value);
    return `${u.protocol}//${u.host}`;
  } catch {
    return value.replace(/\/+$/, "");
  }
}

export default function WordPressPanel() {
  const toast = useToast();
  const { notifySaved, notifyError, refresh } = useNotifications();
  const [products, setProducts] = useState<Product[]>([]);
  const [accounts, setAccounts] = useState<WordPressAccountStatus[]>([]);
  const [productId, setProductId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<"connect" | "test" | "logout" | null>(null);
  const [feedback, setFeedback] = useState<{
    kind: "success" | "error";
    title: string;
    message: string;
  } | null>(null);

  const [siteUrl, setSiteUrl] = useState("");
  const [username, setUsername] = useState("");
  const [appPassword, setAppPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [autoPublish, setAutoPublish] = useState(true);

  const active = accounts.find((a) => a.product_id === productId) ?? null;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [prods, list] = await Promise.all([
        api.getProducts(),
        api.getWordPressAccounts(),
      ]);
      setProducts(prods);
      setAccounts(list);
      setProductId((prev) => {
        if (prev && prods.some((p) => p.id === prev)) return prev;
        const stored = localStorage.getItem("hyperpark_active_product_id");
        if (stored && /^\d+$/.test(stored) && prods.some((p) => p.id === Number(stored))) {
          return Number(stored);
        }
        return prods[0]?.id ?? null;
      });
    } catch (e) {
      console.error(e);
      setFeedback({
        kind: "error",
        title: "Could not load WordPress settings",
        message: String(e).replace(/^Error:\s*/i, ""),
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    if (!active) {
      setSiteUrl("");
      setUsername("");
      setAppPassword("");
      setAutoPublish(true);
      return;
    }
    setSiteUrl(active.site_url || "");
    setUsername(active.username || "");
    setAppPassword("");
    setAutoPublish(active.auto_publish !== false);
  }, [active?.product_id, active?.connected, active?.site_url, active?.username, active?.auto_publish]);

  function showResult(kind: "success" | "error", title: string, message: string) {
    setFeedback({ kind, title, message });
    if (kind === "success") {
      toast.success(title, message);
      notifySaved(title, message);
    } else {
      toast.error(title, message);
      notifyError(title, message);
    }
    void refresh();
  }

  async function handleConnect() {
    if (productId == null) return;
    const cleanedUrl = normalizeSiteUrlInput(siteUrl);
    setSiteUrl(cleanedUrl);
    if (!cleanedUrl || !username.trim() || !appPassword.trim()) {
      showResult(
        "error",
        "Missing fields",
        "Site URL, username, and application password are required."
      );
      return;
    }
    setBusy("connect");
    setFeedback(null);
    try {
      const status = await api.connectWordPress(productId, {
        site_url: cleanedUrl,
        username: username.trim(),
        app_password: appPassword.trim(),
        auto_publish: autoPublish,
        post_status: autoPublish ? "publish" : "draft",
      });
      setAccounts((prev) =>
        prev.map((a) => (a.product_id === productId ? status : a))
      );
      setAppPassword("");
      showResult(
        "success",
        "WordPress connected",
        `${status.site_url} · ${status.display_name || status.username}`
      );
    } catch (e) {
      showResult("error", "WordPress connect failed", String(e).replace(/^Error:\s*/i, ""));
    } finally {
      setBusy(null);
    }
  }

  async function handleTest() {
    if (productId == null) return;
    const cleanedUrl = normalizeSiteUrlInput(siteUrl);
    setSiteUrl(cleanedUrl);
    if (!cleanedUrl || !username.trim() || !appPassword.trim()) {
      showResult(
        "error",
        "Missing fields",
        "Enter site URL, username, and application password to test."
      );
      return;
    }
    setBusy("test");
    setFeedback(null);
    try {
      const res = await api.testWordPress(productId, {
        site_url: cleanedUrl,
        username: username.trim(),
        app_password: appPassword.trim(),
      });
      showResult(
        "success",
        "WordPress login OK",
        `${res.display_name || res.username} on ${res.site_url}`
      );
    } catch (e) {
      showResult("error", "WordPress test failed", String(e).replace(/^Error:\s*/i, ""));
    } finally {
      setBusy(null);
    }
  }

  async function handleLogout() {
    if (productId == null) return;
    if (!confirm("Disconnect WordPress for this product? Credentials will be removed.")) {
      return;
    }
    setBusy("logout");
    setFeedback(null);
    try {
      const status = await api.logoutWordPress(productId);
      setAccounts((prev) =>
        prev.map((a) => (a.product_id === productId ? status : a))
      );
      setAppPassword("");
      showResult("success", "WordPress disconnected", "Credentials cleared for this product.");
    } catch (e) {
      showResult("error", "Logout failed", String(e).replace(/^Error:\s*/i, ""));
    } finally {
      setBusy(null);
    }
  }

  return (
    <section className="overflow-hidden rounded-2xl border border-hyper-border/80 bg-white shadow-soft">
      <div className="border-b border-hyper-border/70 bg-gradient-to-r from-slate-50 to-white px-5 py-4 sm:px-6">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="mb-1 inline-flex items-center gap-2 text-hyper-navy">
              <Globe className="h-4 w-4 text-hyper-orange" />
              <h2 className="font-display text-base font-bold">WordPress</h2>
            </div>
            <p className="max-w-xl text-sm text-slate-600">
              Connect a WordPress site per product. If your host blocks API Basic auth
              (common), we fall back to a secure cookie login using your wp-admin password.
            </p>
          </div>
          {active?.connected ? (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700 ring-1 ring-emerald-100">
              <CheckCircle2 className="h-3.5 w-3.5" />
              Connected
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-600">
              <Unplug className="h-3.5 w-3.5" />
              Not connected
            </span>
          )}
        </div>
      </div>

      <div className="space-y-5 px-5 py-5 sm:px-6">
        {feedback && (
          <div
            className={cn(
              "flex items-start gap-3 rounded-xl border px-4 py-3 text-sm",
              feedback.kind === "success"
                ? "border-emerald-200 bg-emerald-50 text-emerald-950"
                : "border-red-200 bg-red-50 text-red-950"
            )}
            role="alert"
          >
            {feedback.kind === "success" ? (
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
            ) : (
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-red-600" />
            )}
            <div className="min-w-0">
              <p className="font-semibold">{feedback.title}</p>
              <p className="mt-0.5 text-xs font-medium opacity-90">{feedback.message}</p>
            </div>
          </div>
        )}

        <label className="block">
          <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
            Product account
          </span>
          <select
            value={productId ?? ""}
            disabled={loading || products.length === 0}
            onChange={(e) => {
              setProductId(Number(e.target.value));
              setFeedback(null);
            }}
            className="h-11 w-full rounded-xl border border-hyper-border/80 bg-white px-3.5 text-sm font-semibold text-hyper-navy shadow-soft focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/15"
          >
            {products.length === 0 ? (
              <option value="">No products yet</option>
            ) : (
              products.map((p) => {
                const st = accounts.find((a) => a.product_id === p.id);
                return (
                  <option key={p.id} value={p.id}>
                    {p.name}
                    {st?.connected ? " · connected" : " · not connected"}
                  </option>
                );
              })
            )}
          </select>
        </label>

        {loading ? (
          <div className="flex items-center gap-2 py-6 text-sm text-slate-600">
            <Loader2 className="h-4 w-4 animate-spin" />
            Loading WordPress accounts…
          </div>
        ) : (
          <>
            {active?.connected && (
              <div className="rounded-xl border border-emerald-100 bg-emerald-50/80 px-4 py-3 text-sm text-emerald-900">
                <p className="font-semibold">
                  {active.display_name || active.username} · {active.site_url}
                </p>
                <p className="mt-0.5 text-xs text-emerald-800/80">
                  Connected{" "}
                  {active.connected_at
                    ? new Date(active.connected_at).toLocaleString()
                    : ""}
                  {" · "}
                  New posts will be created as{" "}
                  <strong>{active.post_status || "publish"}</strong>.
                </p>
              </div>
            )}

            <div className="grid gap-4 sm:grid-cols-2">
              <label className="block sm:col-span-2">
                <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Site URL
                </span>
                <input
                  type="url"
                  value={siteUrl}
                  onChange={(e) => setSiteUrl(e.target.value)}
                  onBlur={() => setSiteUrl((v) => normalizeSiteUrlInput(v) || v)}
                  placeholder="https://hyperthings.ai"
                  className="h-11 w-full rounded-xl border border-hyper-border/80 px-3.5 text-sm text-hyper-navy shadow-soft focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/15"
                  autoComplete="url"
                />
                <span className="mt-1 block text-[11px] font-medium text-slate-500">
                  Use the site root only (e.g. https://hyperthings.ai) — not /wp-admin/
                </span>
              </label>
              <label className="block">
                <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Username
                </span>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="WordPress username or email"
                  className="h-11 w-full rounded-xl border border-hyper-border/80 px-3.5 text-sm text-hyper-navy shadow-soft focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/15"
                  autoComplete="username"
                />
              </label>
              <label className="block">
                <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slate-500">
                  Password
                </span>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={appPassword}
                    onChange={(e) => setAppPassword(e.target.value)}
                    placeholder={
                      active?.has_password
                        ? "•••••••• (enter new to replace)"
                        : "wp-admin password or Application Password"
                    }
                    className="h-11 w-full rounded-xl border border-hyper-border/80 px-3.5 pr-11 text-sm text-hyper-navy shadow-soft focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/15"
                    autoComplete="current-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-2 text-slate-500 hover:bg-slate-100 hover:text-hyper-navy"
                    aria-label={showPassword ? "Hide password" : "Show password"}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </label>
            </div>

            <label className="flex cursor-pointer items-center gap-2.5 text-sm text-slate-700">
              <input
                type="checkbox"
                checked={autoPublish}
                onChange={(e) => setAutoPublish(e.target.checked)}
                className="h-4 w-4 rounded border-hyper-border text-hyper-primary focus:ring-hyper-primary/30"
              />
              Publish immediately (unchecked = save as draft on WordPress)
            </label>

            <p className="text-xs leading-relaxed text-slate-500">
              <strong>Site URL:</strong> https://hyperthings.ai (not /wp-admin/).{" "}
              <strong>Username:</strong> your WordPress login (email often works).{" "}
              <strong>Password:</strong> use your normal wp-admin password first. If that
              works, you’re connected. Application Passwords only work when the host passes
              the Authorization header through to PHP.
            </p>

            <div className="flex flex-wrap gap-2">
              <Button
                variant="orange"
                size="sm"
                onClick={handleConnect}
                disabled={busy != null || productId == null}
                loading={busy === "connect"}
              >
                <Plug className="h-4 w-4" />
                {active?.connected ? "Update & connect" : "Connect"}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleTest}
                disabled={busy != null || productId == null}
                loading={busy === "test"}
              >
                Test login
              </Button>
              {active?.connected && (
                <Button
                  variant="danger"
                  size="sm"
                  onClick={handleLogout}
                  disabled={busy != null}
                  loading={busy === "logout"}
                >
                  <LogOut className="h-4 w-4" />
                  Logout
                </Button>
              )}
            </div>

            {accounts.some((a) => a.connected) && (
              <div className="rounded-xl border border-hyper-border/70 bg-slate-50 px-4 py-3">
                <p className="mb-2 text-xs font-bold uppercase tracking-wide text-slate-500">
                  Connected accounts
                </p>
                <ul className="space-y-1.5">
                  {accounts
                    .filter((a) => a.connected)
                    .map((a) => (
                      <li
                        key={a.product_id}
                        className={cn(
                          "flex flex-wrap items-center justify-between gap-2 text-sm",
                          a.product_id === productId && "font-semibold text-hyper-navy"
                        )}
                      >
                        <span className="text-slate-700">
                          {a.product_name}
                          <span className="ml-2 font-normal text-slate-500">
                            {a.site_url}
                          </span>
                        </span>
                        <button
                          type="button"
                          className="text-xs font-semibold text-hyper-primary hover:underline"
                          onClick={() => setProductId(a.product_id)}
                        >
                          Manage
                        </button>
                      </li>
                    ))}
                </ul>
              </div>
            )}
          </>
        )}
      </div>
    </section>
  );
}
