"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  BarChart3,
  Inbox,
  LayoutGrid,
  PackageCheck,
  Settings,
} from "lucide-react";
import { cn } from "@/lib/cn";
import { useNotifications } from "@/contexts/NotificationContext";

const navItems = [
  { href: "/", label: "Board", icon: LayoutGrid },
  { href: "/report", label: "Report", icon: BarChart3 },
  { href: "/inbox", label: "Inbox", icon: Inbox, badge: true },
  { href: "/ready", label: "Ready", icon: PackageCheck },
  { href: "/settings", label: "Settings", icon: Settings },
];

export default function MobileBottomNav() {
  const pathname = usePathname();
  const { items } = useNotifications();
  const inboxCount = items.filter(
    (item) => item.type === "topic_selection" || item.type === "review_required"
  ).length;

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-40 border-t border-hyper-border/80 bg-white/95 pb-[env(safe-area-inset-bottom)] shadow-[0_-8px_24px_-16px_rgba(27,31,74,0.35)] backdrop-blur-xl md:hidden"
      aria-label="Primary"
    >
      <ul className="mx-auto flex max-w-lg items-stretch justify-between gap-0.5 px-1 pt-1">
        {navItems.map(({ href, label, icon: Icon, badge }) => {
          const active =
            href === "/" ? pathname === "/" : pathname.startsWith(href);
          return (
            <li key={href} className="min-w-0 flex-1">
              <Link
                href={href}
                className={cn(
                  "relative flex min-h-[3.25rem] flex-col items-center justify-center gap-0.5 rounded-xl px-1 py-1.5 text-[10px] font-semibold tracking-tight transition-colors",
                  active
                    ? "text-hyper-primary"
                    : "text-text-muted hover:text-hyper-navy"
                )}
              >
                <span className="relative">
                  <Icon
                    className={cn(
                      "h-5 w-5",
                      active ? "text-hyper-orange" : "text-current"
                    )}
                  />
                  {badge && inboxCount > 0 && (
                    <span className="absolute -right-2.5 -top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-hyper-red px-1 text-[9px] font-bold text-white">
                      {inboxCount > 9 ? "9+" : inboxCount}
                    </span>
                  )}
                </span>
                <span className="truncate">{label}</span>
                {active && (
                  <span className="absolute inset-x-3 top-0 h-0.5 rounded-full bg-hyper-orange" />
                )}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
