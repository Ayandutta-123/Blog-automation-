"use client";

import { Loader2 } from "lucide-react";
import { cn } from "@/lib/cn";
import { ButtonHTMLAttributes, forwardRef } from "react";

type Variant = "primary" | "secondary" | "ghost" | "danger" | "orange" | "outline";
type Size = "sm" | "md" | "lg";

const variants: Record<Variant, string> = {
  primary:
    "btn-sheen bg-hyper-primary text-white shadow-soft hover:bg-hyper-navy hover:shadow-nav-active focus-visible:ring-hyper-primary/35 active:scale-[0.97]",
  secondary:
    "border border-hyper-border/90 bg-white/90 text-slate-700 shadow-soft backdrop-blur-sm hover:border-hyper-primary/30 hover:bg-white hover:text-hyper-navy hover:shadow-card focus-visible:ring-hyper-primary/30 active:scale-[0.97]",
  ghost:
    "text-slate-600 hover:bg-hyper-primary/[0.06] hover:text-hyper-navy focus-visible:ring-hyper-primary/25 active:scale-[0.98]",
  danger:
    "border border-red-200/90 bg-white text-hyper-red shadow-soft hover:border-hyper-red/40 hover:bg-red-50 focus-visible:ring-red-200 active:scale-[0.97]",
  orange:
    "btn-sheen bg-gradient-to-b from-[#ff7a2e] to-hyper-orange text-white shadow-glow hover:brightness-105 hover:shadow-[0_14px_32px_-12px_rgba(255,96,2,0.65)] focus-visible:ring-hyper-orange/35 active:scale-[0.97]",
  outline:
    "border border-hyper-primary/35 bg-white/80 text-hyper-primary shadow-soft hover:border-hyper-primary hover:bg-hyper-primary/[0.05] focus-visible:ring-hyper-primary/30 active:scale-[0.97]",
};

const sizes: Record<Size, string> = {
  sm: "h-10 px-3.5 text-xs gap-1.5 rounded-xl sm:h-8",
  md: "h-11 px-4 text-sm gap-2 rounded-xl sm:h-10",
  lg: "h-12 px-5 text-sm gap-2 rounded-xl font-semibold sm:h-11",
};

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
}

const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      className,
      variant = "primary",
      size = "md",
      loading,
      disabled,
      children,
      ...props
    },
    ref
  ) => (
    <button
      ref={ref}
      disabled={disabled || loading}
      className={cn(
        "relative inline-flex items-center justify-center overflow-hidden font-semibold tracking-tight",
        "transition-all duration-200 ease-out",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-surface-1",
        "disabled:pointer-events-none disabled:opacity-45",
        variants[variant],
        sizes[size],
        loading && "animate-work-pulse",
        className
      )}
      {...props}
    >
      {loading && <Loader2 className="h-4 w-4 animate-spin" />}
      {children}
    </button>
  )
);

Button.displayName = "Button";
export default Button;
