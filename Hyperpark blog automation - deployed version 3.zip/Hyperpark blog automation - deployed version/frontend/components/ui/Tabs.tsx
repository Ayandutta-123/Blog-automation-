"use client";

import { cn } from "@/lib/cn";

export function TabList({
  className,
  children,
}: {
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <div
      role="tablist"
      className={cn(
        "flex w-full max-w-full gap-1 overflow-x-auto rounded-2xl border border-hyper-border/80 bg-surface-2/80 p-1.5 shadow-soft backdrop-blur-sm [-webkit-overflow-scrolling:touch] sm:inline-flex sm:w-auto sm:overflow-visible",
        className
      )}
    >
      {children}
    </div>
  );
}

export function Tab({
  active,
  onClick,
  icon: Icon,
  label,
  id,
  description,
  variant = "default",
}: {
  active: boolean;
  onClick: () => void;
  icon?: React.ElementType;
  label: string;
  id: string;
  description?: string;
  variant?: "default" | "settings";
}) {
  if (variant === "settings") {
    return (
      <button
        type="button"
        role="tab"
        id={id}
        aria-selected={active}
        onClick={onClick}
        className={cn(
          "group flex min-w-0 flex-1 items-start gap-2.5 rounded-xl px-2.5 py-2.5 text-left transition-all duration-200 ease-out sm:min-w-[140px] sm:flex-none sm:gap-3 sm:px-3.5 sm:py-3 lg:min-w-0 lg:w-full",
          active
            ? "settings-nav-active bg-hyper-navy text-white shadow-nav-active"
            : "text-text-secondary hover:bg-white/80 hover:text-hyper-navy hover:shadow-soft"
        )}
      >
        {Icon && (
          <span
            className={cn(
              "mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl transition-all duration-200",
              active
                ? "bg-white/15 text-hyper-orange ring-1 ring-white/10"
                : "bg-surface-2 text-hyper-primary group-hover:bg-hyper-primary/10 group-hover:scale-105"
            )}
          >
            <Icon className="h-4 w-4" />
          </span>
        )}
        <span className="min-w-0 flex-1">
          <span className="block text-sm font-semibold tracking-tight">{label}</span>
          {description && (
            <span
              className={cn(
                "mt-0.5 hidden text-xs leading-snug sm:block",
                active ? "text-white/70" : "text-text-muted"
              )}
            >
              {description}
            </span>
          )}
        </span>
      </button>
    );
  }

  return (
    <button
      type="button"
      role="tab"
      id={id}
      aria-selected={active}
      onClick={onClick}
      className={cn(
        "inline-flex min-w-0 flex-1 items-center justify-center gap-1.5 rounded-xl px-2.5 py-2 text-xs font-semibold tracking-tight transition-all duration-200 sm:flex-none sm:px-4 sm:text-sm",
        active
          ? "bg-white text-hyper-navy shadow-soft ring-1 ring-black/[0.03]"
          : "text-text-secondary hover:bg-white/50 hover:text-hyper-navy"
      )}
    >
      {Icon && <Icon className="h-3.5 w-3.5 shrink-0 sm:h-4 sm:w-4" />}
      <span className="truncate">{label}</span>
    </button>
  );
}
