#!/bin/sh
set -eu

mkdir -p /data/storage/blog_images /data/storage/blogs/html /data/storage/logs
chown -R app:app /data/storage 2>/dev/null || true

# Backend (SQLite + APScheduler → single worker only)
cd /app/backend
uvicorn app.main:app --host 127.0.0.1 --port 8000 --workers 1 --proxy-headers &
BACKEND_PID=$!

# Frontend (Next.js standalone)
cd /app/frontend
HOSTNAME=127.0.0.1 PORT=3000 node server.js &
FRONTEND_PID=$!

# Edge proxy (single public port)
nginx -g "daemon off;" &
NGINX_PID=$!

shutdown() {
  echo "Shutting down..."
  kill -TERM "$BACKEND_PID" "$FRONTEND_PID" "$NGINX_PID" 2>/dev/null || true
  wait "$BACKEND_PID" "$FRONTEND_PID" "$NGINX_PID" 2>/dev/null || true
}
trap shutdown INT TERM

# Exit if any child dies
while kill -0 "$BACKEND_PID" 2>/dev/null \
   && kill -0 "$FRONTEND_PID" 2>/dev/null \
   && kill -0 "$NGINX_PID" 2>/dev/null; do
  sleep 2
done

echo "A process exited unexpectedly" >&2
shutdown
exit 1
