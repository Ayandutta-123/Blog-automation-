from __future__ import annotations

from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import RedirectResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.config import settings as app_settings
from app.database import get_db
from app.services import ubersuggest as us
from app.services.runtime_config import get_config_value

router = APIRouter(prefix="/api/integrations/ubersuggest", tags=["ubersuggest"])


def _callback_url() -> str:
    base = (app_settings.public_base_url or "http://localhost:8000").rstrip("/")
    return f"{base}/api/integrations/ubersuggest/callback"


def _frontend_settings_url() -> str:
    base = (app_settings.frontend_url or "http://localhost:3000").rstrip("/")
    return f"{base}/settings"


class ConnectResponse(BaseModel):
    authorize_url: str


class ToolInfo(BaseModel):
    name: str
    description: Optional[str] = None
    input_schema: Optional[dict[str, Any]] = None


class ToolsResponse(BaseModel):
    tools: list[ToolInfo]


class CallToolRequest(BaseModel):
    name: str
    arguments: dict[str, Any] = {}


class MappingRequest(BaseModel):
    keyword_tool: Optional[str] = None
    backlinks_tool: Optional[str] = None


class StatusResponse(BaseModel):
    connected: bool
    connected_at: Optional[str] = None
    keyword_tool: Optional[str] = None
    backlinks_tool: Optional[str] = None


class KeywordCheckRequest(BaseModel):
    keyword: str
    language: str = "en"
    loc_id: int = 2840


class KeywordMetricsResponse(BaseModel):
    ok: bool = True
    keyword: str
    search_volume: Optional[float] = None
    cpc: Optional[float] = None
    seo_difficulty: Optional[float] = None
    paid_difficulty: Optional[float] = None
    competition: Optional[float] = None
    source_tool: Optional[str] = None


@router.get("/status", response_model=StatusResponse)
def status(db: Session = Depends(get_db)):
    return us.connection_status(db)


@router.post("/connect", response_model=ConnectResponse)
def connect(db: Session = Depends(get_db)):
    try:
        url = us.build_authorize_url(db, _callback_url())
    except us.UbersuggestError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    return ConnectResponse(authorize_url=url)


@router.get("/callback")
def callback(
    code: Optional[str] = Query(default=None),
    state: Optional[str] = Query(default=None),
    error: Optional[str] = Query(default=None),
    error_description: Optional[str] = Query(default=None),
    db: Session = Depends(get_db),
):
    frontend = _frontend_settings_url()
    if error:
        return RedirectResponse(
            f"{frontend}?ubersuggest=error&message={error_description or error}"
        )
    if not code or not state:
        return RedirectResponse(f"{frontend}?ubersuggest=error&message=missing_code")
    try:
        us.exchange_code_for_token(db, code, state)
    except us.UbersuggestError as exc:
        return RedirectResponse(f"{frontend}?ubersuggest=error&message={exc}")
    return RedirectResponse(f"{frontend}?ubersuggest=connected")


@router.post("/disconnect")
def disconnect(db: Session = Depends(get_db)):
    us.disconnect(db)
    return {"ok": True}


@router.get("/tools", response_model=ToolsResponse)
def tools(db: Session = Depends(get_db)):
    try:
        raw = us.list_tools(db)
    except us.UbersuggestNotConnected as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except us.UbersuggestError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    return ToolsResponse(
        tools=[
            ToolInfo(
                name=t.get("name", ""),
                description=t.get("description"),
                input_schema=t.get("inputSchema"),
            )
            for t in raw
        ]
    )


@router.post("/call")
def call_tool(payload: CallToolRequest, db: Session = Depends(get_db)):
    try:
        result = us.call_tool(db, payload.name, payload.arguments)
    except us.UbersuggestNotConnected as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except us.UbersuggestError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    return {"result": result}


@router.put("/mapping", response_model=StatusResponse)
def set_mapping(payload: MappingRequest, db: Session = Depends(get_db)):
    us.set_tool_mapping(db, payload.keyword_tool, payload.backlinks_tool)
    return us.connection_status(db)


@router.post("/keyword-check", response_model=KeywordMetricsResponse)
def keyword_check(payload: KeywordCheckRequest, db: Session = Depends(get_db)):
    try:
        metrics = us.lookup_keyword(
            db,
            payload.keyword,
            language=payload.language or "en",
            loc_id=payload.loc_id or 2840,
        )
    except us.UbersuggestNotConnected as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except us.UbersuggestError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    return KeywordMetricsResponse(**metrics)
