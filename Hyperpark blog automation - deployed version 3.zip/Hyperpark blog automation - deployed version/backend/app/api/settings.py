from __future__ import annotations

from typing import List, Optional

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import ScraperCategory, ScraperSettings
from app.schemas import ScraperSettingCreate, ScraperSettingResponse, ScraperSettingUpdate
from app.services.notification_service import emit_notification

router = APIRouter(prefix="/api/settings", tags=["settings"])


@router.get("", response_model=List[ScraperSettingResponse])
def list_settings(
    category: Optional[ScraperCategory] = None,
    product_id: Optional[int] = None,
    db: Session = Depends(get_db),
):
    query = db.query(ScraperSettings)
    if category:
        query = query.filter(ScraperSettings.category == category)
    if product_id is not None:
        query = query.filter(ScraperSettings.product_id == product_id)
    return query.order_by(ScraperSettings.id).all()


@router.post("", response_model=ScraperSettingResponse, status_code=201)
def create_setting(payload: ScraperSettingCreate, db: Session = Depends(get_db)):
    value = payload.value.strip()
    if payload.category == ScraperCategory.RSS_FEED:
        from app.services.scraper import normalize_rss_feed_url

        value = normalize_rss_feed_url(value)
    setting = ScraperSettings(
        category=payload.category,
        value=value,
        added_by=payload.added_by,
        is_active=True,
        product_id=payload.product_id,
    )
    db.add(setting)
    db.commit()
    db.refresh(setting)
    label = {
        ScraperCategory.INDUSTRY_KEYWORD: "Keyword",
        ScraperCategory.COMPETITOR_URL: "Competitor URL",
        ScraperCategory.RSS_FEED: "RSS feed",
    }.get(setting.category, "Scraper target")
    emit_notification(
        db,
        type="published",
        title=f"{label} saved",
        message=f'Added "{setting.value}" to scraper targets.',
        severity="success",
    )
    return setting


@router.patch("/{setting_id}", response_model=ScraperSettingResponse)
def update_setting(
    setting_id: int,
    payload: ScraperSettingUpdate,
    db: Session = Depends(get_db),
):
    setting = db.query(ScraperSettings).filter(ScraperSettings.id == setting_id).first()
    if not setting:
        raise HTTPException(status_code=404, detail="Setting not found")
    if payload.value is not None:
        value = payload.value.strip()
        if setting.category == ScraperCategory.RSS_FEED:
            from app.services.scraper import normalize_rss_feed_url

            value = normalize_rss_feed_url(value)
        setting.value = value
    if payload.is_active is not None:
        setting.is_active = payload.is_active
    db.commit()
    db.refresh(setting)
    return setting


@router.delete("/{setting_id}", status_code=204)
def delete_setting(setting_id: int, db: Session = Depends(get_db)):
    setting = db.query(ScraperSettings).filter(ScraperSettings.id == setting_id).first()
    if not setting:
        raise HTTPException(status_code=404, detail="Setting not found")
    db.delete(setting)
    db.commit()
