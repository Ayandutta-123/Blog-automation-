from __future__ import annotations

import enum
from datetime import datetime, timezone
from typing import Any, Optional

from sqlalchemy import JSON, Boolean, DateTime, Enum, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


class ScraperCategory(str, enum.Enum):
    INDUSTRY_KEYWORD = "INDUSTRY_KEYWORD"
    COMPETITOR_URL = "COMPETITOR_URL"
    RSS_FEED = "RSS_FEED"


class BlogStatus(str, enum.Enum):
    SCRAPING = "SCRAPING"
    PENDING_TOPIC = "PENDING_TOPIC"
    GENERATING = "GENERATING"
    PENDING_REVIEW = "PENDING_REVIEW"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    PUBLISHED = "PUBLISHED"


class Product(Base):
    """Company product line — drives prompts, CTAs, and discovery context."""

    __tablename__ = "products"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    company_name: Mapped[str] = mapped_column(String(128), default="HyperPark")
    website_url: Mapped[str] = mapped_column(String(512), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    brand_context: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    brand_palette_json: Mapped[Optional[Any]] = mapped_column(JSON, nullable=True)
    internal_links_json: Mapped[Optional[Any]] = mapped_column(JSON, nullable=True)
    pdf_filename: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    pdf_extracted_text: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_default: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    cron_day_of_week: Mapped[str] = mapped_column(String(8), default="mon")
    cron_hour: Mapped[int] = mapped_column(Integer, default=9)
    cron_minute: Mapped[int] = mapped_column(Integer, default=0)
    cron_timezone: Mapped[str] = mapped_column(String(64), default="Asia/Kolkata")
    schedule_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    discovery_schedules_json: Mapped[Optional[Any]] = mapped_column(JSON, nullable=True)
    pdfs_json: Mapped[Optional[Any]] = mapped_column(JSON, nullable=True)
    content_archetype: Mapped[str] = mapped_column(String(32), default="tutorial")
    # manual | auto | hybrid ("Both") — controls per-product discovery automation
    topic_selection_mode: Mapped[str] = mapped_column(String(16), default="manual")
    wordpress_json: Mapped[Optional[Any]] = mapped_column(JSON, nullable=True)
    google_json: Mapped[Optional[Any]] = mapped_column(JSON, nullable=True)
    # Public Google Sheet (or Apps Script web app) for published-blog metadata ledger
    google_sheet_url: Mapped[Optional[str]] = mapped_column(String(1024), nullable=True)
    slug: Mapped[Optional[str]] = mapped_column(String(128), unique=True, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc)
    )


class AppNotification(Base):
    """Persistent in-app notification feed."""

    __tablename__ = "app_notifications"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    type: Mapped[str] = mapped_column(String(64), nullable=False)
    title: Mapped[str] = mapped_column(String(256), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False, default="")
    severity: Mapped[str] = mapped_column(String(32), default="action")
    post_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc)
    )


class ScraperSettings(Base):
    __tablename__ = "scraper_settings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    product_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("products.id"), nullable=True
    )
    category: Mapped[ScraperCategory] = mapped_column(Enum(ScraperCategory), nullable=False)
    value: Mapped[str] = mapped_column(String(512), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    added_by: Mapped[str] = mapped_column(String(128), default="Admin")


class BlogPost(Base):
    __tablename__ = "blog_posts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    product_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("products.id"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc)
    )
    published_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    publish_serial: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    status: Mapped[BlogStatus] = mapped_column(
        Enum(BlogStatus), default=BlogStatus.SCRAPING
    )
    scraped_topics_json: Mapped[Optional[Any]] = mapped_column(JSON, nullable=True)
    discovery_snapshot_json: Mapped[Optional[Any]] = mapped_column(JSON, nullable=True)
    research_pack_json: Mapped[Optional[Any]] = mapped_column(JSON, nullable=True)
    selected_topic_title: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    slug: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    title_tag: Mapped[Optional[str]] = mapped_column(String(128), nullable=True)
    meta_description: Mapped[Optional[str]] = mapped_column(String(256), nullable=True)
    reading_time: Mapped[Optional[str]] = mapped_column(String(32), nullable=True)
    html_content: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    image_url: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    final_html_path: Mapped[Optional[str]] = mapped_column(String(512), nullable=True)
    feedback_history: Mapped[Optional[Any]] = mapped_column(JSON, default=list)
    content_archetype: Mapped[Optional[str]] = mapped_column(String(32), default="tutorial")


class AppConfig(Base):
    """Dynamic key-value store for API keys and integration settings."""

    __tablename__ = "app_config"

    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[str] = mapped_column(Text, nullable=False, default="")
    is_secret: Mapped[bool] = mapped_column(Boolean, default=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
    )


class DashboardRole(str, enum.Enum):
    ADMIN = "admin"
    USER = "user"


class DashboardUser(Base):
    """Dashboard users for multi-user email/password login (internal tool)."""

    __tablename__ = "dashboard_users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String(256), nullable=False)
    role: Mapped[DashboardRole] = mapped_column(
        Enum(DashboardRole), default=DashboardRole.USER, nullable=False
    )
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=lambda: datetime.now(timezone.utc)
    )
