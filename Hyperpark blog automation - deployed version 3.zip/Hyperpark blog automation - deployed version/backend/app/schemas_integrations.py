from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field

from app.services.runtime_config import CONFIG_REGISTRY


class IntegrationFieldResponse(BaseModel):
    key: str
    label: str
    description: str
    group: str
    secret: bool
    is_set: bool
    source: str
    is_placeholder: bool = False
    value: Optional[str] = None
    masked_value: Optional[str] = None


class IntegrationKeyUpdate(BaseModel):
    value: str = Field(..., min_length=1)


class IntegrationsResponse(BaseModel):
    fields: list[IntegrationFieldResponse]
    groups: list[str]


class IntegrationsUpdateRequest(BaseModel):
    tavily_api_key: Optional[str] = Field(None, description="Leave null to keep unchanged")
    anthropic_api_key: Optional[str] = None
    fal_key: Optional[str] = None
    teams_webhook_url: Optional[str] = None
    frontend_url: Optional[str] = None
    public_base_url: Optional[str] = None

    def to_updates(self) -> dict[str, Optional[str]]:
        return self.model_dump(exclude_unset=True)


INTEGRATION_GROUPS = sorted({f["group"] for f in CONFIG_REGISTRY})
