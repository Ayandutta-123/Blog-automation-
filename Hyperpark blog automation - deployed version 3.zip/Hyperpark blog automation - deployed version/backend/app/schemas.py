from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from app.models import BlogStatus, ScraperCategory


class ScraperSettingCreate(BaseModel):
    category: ScraperCategory
    value: str = Field(..., min_length=1, max_length=512)
    added_by: str = "Admin"
    product_id: Optional[int] = None


class ScraperSettingUpdate(BaseModel):
    value: Optional[str] = None
    is_active: Optional[bool] = None


class ScraperSettingResponse(BaseModel):
    id: int
    category: ScraperCategory
    value: str
    is_active: bool
    added_by: str
    product_id: Optional[int] = None

    model_config = {"from_attributes": True}


class TopicOption(BaseModel):
    title: str
    description: str
    primary_keyword: str


class TopicSelectRequest(BaseModel):
    topic_title: str
    custom: bool = False
    content_archetype: Optional[str] = None


class TeamsTopicSelectPayload(BaseModel):
    blog_post_id: int
    topic_title: str
    action: str = "select_topic"


class RedoRequest(BaseModel):
    feedback: str = Field(..., min_length=1)


class BlogPostEditRequest(BaseModel):
    title_tag: Optional[str] = None
    meta_description: Optional[str] = None
    slug: Optional[str] = None
    selected_topic_title: Optional[str] = None
    body_text: Optional[str] = None


class BlogPostSummary(BaseModel):
    id: int
    created_at: datetime
    published_at: Optional[datetime] = None
    publish_serial: Optional[int] = None
    status: BlogStatus
    selected_topic_title: Optional[str] = None
    slug: Optional[str] = None
    title_tag: Optional[str] = None
    meta_description: Optional[str] = None
    reading_time: Optional[str] = None
    image_url: Optional[str] = None
    topics_count: int = 0
    comment_count: int = 0
    last_error: Optional[str] = None
    content_archetype: Optional[str] = "tutorial"
    product_id: Optional[int] = None
    product_name: Optional[str] = None
    minio_object: Optional[str] = None

    model_config = {"from_attributes": True}


class BlogPostDetail(BlogPostSummary):
    scraped_topics_json: Optional[Any] = None
    discovery_snapshot_json: Optional[Any] = None
    research_pack_json: Optional[Any] = None
    html_content: Optional[str] = None
    body_text: Optional[str] = None
    final_html_path: Optional[str] = None
    feedback_history: Optional[List[Dict[str, Any]]] = None


class SEOMetrics(BaseModel):
    title_tag_length: int
    title_tag_valid: bool
    meta_description_length: int
    meta_description_valid: bool
    slug: Optional[str]
    reading_time: Optional[str]
    word_count: int = 0
    word_count_min: int = 1200
    word_count_max: int = 1800
    word_count_valid: bool = False
    content_archetype: str = "tutorial"
    content_archetype_label: str = "Standard Tutorials & How-Tos"
    has_json_ld: bool
    internal_links_count: int
    external_links_count: int


class ReviewResponse(BaseModel):
    post: BlogPostDetail
    seo_metrics: SEOMetrics


class NotificationItem(BaseModel):
    id: str
    type: str
    post_id: int
    title: str
    message: str
    timestamp: str
    severity: str


class NotificationCounts(BaseModel):
    total: int
    action: int
    error: int
    success: int


class NotificationsResponse(BaseModel):
    items: List[NotificationItem]
    counts: NotificationCounts
