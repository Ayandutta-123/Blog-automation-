from __future__ import annotations

import json
import re
from typing import Any, Literal

import anthropic
from loguru import logger

from app.services.llm import anthropic_api_key_configured, create_claude_message
from app.services.runtime_config import get_config_value
from app.utils.retry import with_retry

TopicSource = Literal["industry_keywords", "competitor_urls", "rss_feeds"]

SOURCE_KEYS: tuple[TopicSource, ...] = (
    "industry_keywords",
    "competitor_urls",
    "rss_feeds",
)

SOURCE_LABELS = {
    "industry_keywords": "Industry keywords (Tavily search)",
    "competitor_urls": "Competitor blog pages (HTML scrape)",
    "rss_feeds": "RSS feeds",
}

MIN_PER_SOURCE = 5
MAX_PER_SOURCE = 10
TARGET_PER_SOURCE = 7


def empty_topic_groups() -> dict[str, list[dict[str, str]]]:
    return {key: [] for key in SOURCE_KEYS}


def normalize_topic_groups(raw: Any) -> dict[str, list[dict[str, str]]]:
    """Accept v2 grouped payload or legacy flat list; return groups dict."""
    groups = empty_topic_groups()
    if not raw:
        return groups

    if isinstance(raw, dict):
        nested = raw.get("groups") if isinstance(raw.get("groups"), dict) else raw
        for key in SOURCE_KEYS:
            items = nested.get(key) or []
            if isinstance(items, list):
                groups[key] = [_normalize_topic(t, key) for t in items if isinstance(t, dict)]
        # Flat list nested under topics with source field
        flat = raw.get("topics")
        if isinstance(flat, list) and not any(groups.values()):
            for t in flat:
                if not isinstance(t, dict):
                    continue
                source = _coerce_source(t.get("source"))
                groups[source].append(_normalize_topic(t, source))
        return groups

    if isinstance(raw, list):
        # Legacy: treat all as industry_keywords so UI still works
        for t in raw:
            if isinstance(t, dict):
                source = _coerce_source(t.get("source")) if t.get("source") else "industry_keywords"
                groups[source].append(_normalize_topic(t, source))
    return groups


def flatten_topics(raw: Any) -> list[dict[str, str]]:
    groups = normalize_topic_groups(raw)
    out: list[dict[str, str]] = []
    for key in SOURCE_KEYS:
        out.extend(groups[key])
    return out


def topics_count(raw: Any) -> int:
    return len(flatten_topics(raw))


def pack_topic_groups(groups: dict[str, list[dict[str, str]]]) -> dict[str, Any]:
    cleaned = empty_topic_groups()
    for key in SOURCE_KEYS:
        cleaned[key] = [
            _normalize_topic(t, key) for t in (groups.get(key) or []) if isinstance(t, dict)
        ][:MAX_PER_SOURCE]
    return {"version": 2, "groups": cleaned}


def _coerce_source(value: Any) -> TopicSource:
    raw = str(value or "").strip().lower()
    aliases = {
        "industry": "industry_keywords",
        "industry_keyword": "industry_keywords",
        "industry_keywords": "industry_keywords",
        "keyword": "industry_keywords",
        "keywords": "industry_keywords",
        "tavily": "industry_keywords",
        "competitor": "competitor_urls",
        "competitors": "competitor_urls",
        "competitor_url": "competitor_urls",
        "competitor_urls": "competitor_urls",
        "html": "competitor_urls",
        "rss": "rss_feeds",
        "rss_feed": "rss_feeds",
        "rss_feeds": "rss_feeds",
        "feed": "rss_feeds",
    }
    return aliases.get(raw, "industry_keywords")  # type: ignore[return-value]


def _normalize_topic(topic: dict[str, Any], source: TopicSource) -> dict[str, str]:
    base: dict[str, Any] = {
        "title": str(topic.get("title") or "").strip(),
        "description": str(topic.get("description") or "").strip(),
        "primary_keyword": str(topic.get("primary_keyword") or "").strip(),
        "source": source,
    }
    for key in (
        "seo_score",
        "recommendation",
        "seo_signals",
        "seo_why",
        "recommended",
        "seo_rank",
        "source_links",
        "source_url",
    ):
        if key in topic:
            base[key] = topic[key]
    return base


def _tokenize(text: str) -> set[str]:
    return {t for t in re.findall(r"[a-z0-9]{3,}", (text or "").lower()) if len(t) >= 3}


def _normalize_source_link(raw: Any, source_type: str) -> dict[str, str] | None:
    if not isinstance(raw, dict):
        return None
    url = str(raw.get("url") or "").strip()
    if not url.startswith(("http://", "https://")):
        return None
    label = str(raw.get("label") or raw.get("title") or url).strip()[:120]
    return {"label": label or url, "url": url, "source_type": source_type}


def _collect_discovery_links(
    discovery_data: dict[str, Any],
    source: TopicSource,
) -> list[dict[str, str]]:
    """Flatten verifiable URLs from raw discovery data for a source group.

    Competitor group: ONLY the configured competitor URLs (never child/random links).
    Industry / RSS: real result or article URLs from that discovery run.
    """
    links: list[dict[str, str]] = []
    seen: set[str] = set()

    def add(label: str, url: str, source_type: str) -> None:
        url = (url or "").strip()
        if not url.startswith(("http://", "https://")) or url in seen:
            return
        seen.add(url)
        links.append(
            {
                "label": (label or url).strip()[:120],
                "url": url,
                "source_type": source_type,
            }
        )

    if source == "industry_keywords":
        for block in discovery_data.get("industry_trends") or []:
            keyword = str(block.get("keyword") or "Industry search")
            for result in block.get("results") or []:
                add(
                    str(result.get("title") or keyword),
                    str(result.get("url") or ""),
                    "tavily",
                )
    elif source == "competitor_urls":
        # Fixed rule for all products: only the configured competitor page itself
        for block in discovery_data.get("competitor_articles") or []:
            parent = str(block.get("source_url") or "").strip()
            if not parent:
                continue
            label = (
                str(block.get("page_title") or "").strip()
                or "Competitor page"
            )
            add(label, parent, "competitor")
    elif source == "rss_feeds":
        for block in discovery_data.get("rss_articles") or []:
            for article in block.get("articles") or []:
                add(
                    str(article.get("title") or "RSS article"),
                    str(article.get("url") or ""),
                    "rss",
                )
            # Fallback: feed URL itself when article links are missing
            feed_url = str(
                block.get("source_url") or block.get("requested_url") or ""
            ).strip()
            if feed_url:
                add(
                    str(block.get("feed_title") or "RSS feed"),
                    feed_url,
                    "rss_feed",
                )
    return links


def _relevance_score(topic: dict[str, Any], link: dict[str, str]) -> int:
    tokens = _tokenize(
        " ".join(
            [
                str(topic.get("title") or ""),
                str(topic.get("primary_keyword") or ""),
                str(topic.get("description") or ""),
            ]
        )
    )
    if not tokens:
        return 0
    hay = f"{link.get('label', '')} {link.get('url', '')}".lower()
    return sum(1 for t in tokens if t in hay)


def _pick_single_source_link(
    topic: dict[str, Any],
    pool: list[dict[str, str]],
    source: TopicSource,
) -> dict[str, str] | None:
    """Choose exactly one genuine discovery URL that best matches the topic."""
    if not pool:
        return None

    # Prefer model-provided URL only if it exists in the discovery pool
    candidates: list[dict[str, str]] = []
    for raw in topic.get("source_links") or []:
        link = _normalize_source_link(raw, source)
        if link:
            candidates.append(link)
    source_url = str(topic.get("source_url") or "").strip()
    if source_url.startswith(("http://", "https://")):
        candidates.insert(
            0,
            {
                "label": str(topic.get("title") or source_url)[:120],
                "url": source_url,
                "source_type": source,
            },
        )

    pool_by_url = {p["url"]: p for p in pool}
    for cand in candidates:
        matched = pool_by_url.get(cand["url"])
        if matched:
            return matched

    # Prefer strongest title/keyword overlap when available
    ranked = sorted(
        ((_relevance_score(topic, link), link) for link in pool),
        key=lambda x: x[0],
        reverse=True,
    )
    if ranked and ranked[0][0] > 0:
        return ranked[0][1]

    # Mandatory for all products: every topic gets exactly one genuine discovery URL.
    # Round-robin by title so topics spread across available sources.
    idx = abs(hash(str(topic.get("title") or ""))) % len(pool)
    return pool[idx]


def attach_source_links_to_topics(
    topics_payload: dict[str, Any],
    discovery_data: dict[str, Any],
    *,
    max_links: int = 1,
) -> dict[str, Any]:
    """Attach exactly ONE genuine source URL per topic (fixed for all products)."""
    _ = max_links  # always 1 — kept for call-site compatibility
    groups = normalize_topic_groups(topics_payload)
    for source in SOURCE_KEYS:
        pool = _collect_discovery_links(discovery_data, source)
        for topic in groups.get(source) or []:
            picked = _pick_single_source_link(topic, pool, source)
            topic["source_links"] = [picked] if picked else []
            if picked:
                topic["source_url"] = picked["url"]
            elif "source_url" in topic:
                topic.pop("source_url", None)

    packed = pack_topic_groups(groups)

    # Keep top_picks (SEO) and sync each pick's single source_link from its topic card
    flat_by_title = {
        str(t.get("title") or ""): t
        for key in SOURCE_KEYS
        for t in (groups.get(key) or [])
        if t.get("title")
    }
    raw_picks = []
    if isinstance(topics_payload, dict):
        raw_picks = list(topics_payload.get("top_picks") or [])
    refreshed: list[dict[str, Any]] = []
    for pick in raw_picks:
        if not isinstance(pick, dict):
            continue
        title = str(pick.get("title") or "")
        match = flat_by_title.get(title)
        if match:
            refreshed.append(
                {
                    **pick,
                    "source": match.get("source") or pick.get("source"),
                    "source_links": list(match.get("source_links") or []),
                }
            )
        else:
            refreshed.append(pick)
    if refreshed:
        packed["top_picks"] = refreshed

    return packed


def _compact_industry(data: list[dict[str, Any]]) -> list[dict[str, Any]]:
    compact = []
    for item in data[:8]:
        compact.append(
            {
                "keyword": item.get("keyword", ""),
                "answer": (item.get("answer") or "")[:400],
                "results": [
                    {
                        "title": r.get("title", ""),
                        "url": r.get("url", ""),
                        "content": (r.get("content") or "")[:220],
                    }
                    for r in (item.get("results") or [])[:4]
                ],
            }
        )
    return compact


def _compact_competitor(data: list[dict[str, Any]]) -> list[dict[str, Any]]:
    compact = []
    for item in data[:8]:
        compact.append(
            {
                "source_url": item.get("source_url", ""),
                "page_title": item.get("page_title", ""),
                "excerpt": (item.get("excerpt") or "")[:500],
                "headings": list(item.get("headings") or [])[:10],
                "error": item.get("error"),
                # Single self-reference only — never third-party child links
                "articles": [
                    {
                        "title": a.get("title", ""),
                        "url": a.get("url", ""),
                        "summary": (a.get("summary") or "")[:220],
                    }
                    for a in (item.get("articles") or [])[:1]
                    if (a.get("url") or "") == (item.get("source_url") or "")
                ],
            }
        )
    return compact


def _compact_rss(data: list[dict[str, Any]]) -> list[dict[str, Any]]:
    compact = []
    for item in data[:8]:
        compact.append(
            {
                "source_url": item.get("source_url") or item.get("requested_url", ""),
                "feed_title": item.get("feed_title", ""),
                "error": item.get("error"),
                "articles": [
                    {
                        "title": a.get("title", ""),
                        "url": a.get("url", ""),
                        "summary": (a.get("summary") or "")[:220],
                        "published": a.get("published", ""),
                    }
                    for a in (item.get("articles") or [])[:10]
                ],
            }
        )
    return compact


def _placeholder_groups() -> dict[str, list[dict[str, str]]]:
    industry = [
        {
            "title": "How Smart Parking Automation Reduces Revenue Leakage in Enterprise Facilities",
            "description": "Explore ANPR and IoT-driven access control strategies that eliminate manual ticketing gaps.",
            "primary_keyword": "smart parking automation",
            "source": "industry_keywords",
        },
        {
            "title": "ANPR Access Control: The Enterprise Guide to Ticketless Parking",
            "description": "A comprehensive look at license plate recognition for hospitals, malls, and corporate campuses.",
            "primary_keyword": "ANPR access control",
            "source": "industry_keywords",
        },
        {
            "title": "EV Charging Mobility Hubs: Integrating Parking with Sustainable Infrastructure",
            "description": "How facility managers can deploy EV-ready parking with minimal capex using agnostic IoT platforms.",
            "primary_keyword": "EV charging mobility hubs",
            "source": "industry_keywords",
        },
        {
            "title": "Digital Valet Management for Premium Enterprise Experiences",
            "description": "Transform valet operations with QR-based workflows and real-time vehicle tracking.",
            "primary_keyword": "digital valet management",
            "source": "industry_keywords",
        },
        {
            "title": "Zero-Touch Visitor Parking: QR Access for Corporate Campuses",
            "description": "Design frictionless visitor flows without ticket printers or attendant bottlenecks.",
            "primary_keyword": "ticketless visitor parking",
            "source": "industry_keywords",
        },
    ]
    competitor = [
        {
            "title": "What Competitor Parking Blogs Miss About Revenue Protection",
            "description": "Counter generic competitor narratives with concrete ANPR and IoT leakage prevention angles.",
            "primary_keyword": "parking revenue protection",
            "source": "competitor_urls",
        },
        {
            "title": "Beyond Occupancy Dashboards: Operational Outcomes Enterprises Need",
            "description": "Differentiate from competitor blog themes focused only on occupancy visualisations.",
            "primary_keyword": "parking operations analytics",
            "source": "competitor_urls",
        },
        {
            "title": "Hardware-Agnostic Parking Tech vs Locked Vendor Stacks",
            "description": "Position open IoT platforms against competitor hardware lock-in messaging.",
            "primary_keyword": "hardware agnostic parking",
            "source": "competitor_urls",
        },
        {
            "title": "From Access Control News to Enterprise Parking ROI Stories",
            "description": "Turn competitor access-control headlines into buyer-focused ROI narratives.",
            "primary_keyword": "parking ROI case study",
            "source": "competitor_urls",
        },
        {
            "title": "Hospital and Mall Parking Experiences Competitors Under-Serve",
            "description": "Target vertical pains that competitor blog pages rarely cover in depth.",
            "primary_keyword": "hospital parking automation",
            "source": "competitor_urls",
        },
    ]
    rss = [
        {
            "title": "Industry Feed Roundup: Parking Automation Trends Worth a Deep Dive",
            "description": "Curate actionable angles inspired by recent industry RSS headlines.",
            "primary_keyword": "parking automation trends",
            "source": "rss_feeds",
        },
        {
            "title": "From News Alert to Playbook: Turning Mobility Headlines into Guides",
            "description": "Convert fast-moving RSS coverage into evergreen enterprise how-to content.",
            "primary_keyword": "urban mobility playbook",
            "source": "rss_feeds",
        },
        {
            "title": "What This Week's Parking Tech Feeds Signal for Facility Leaders",
            "description": "Synthesize feed chatter into decision-ready questions for operators.",
            "primary_keyword": "parking tech news",
            "source": "rss_feeds",
        },
        {
            "title": "RSS-Inspired Checklist: Future-Proofing Enterprise Parking Stacks",
            "description": "Build a practical checklist from recurring themes across parking RSS feeds.",
            "primary_keyword": "enterprise parking checklist",
            "source": "rss_feeds",
        },
        {
            "title": "Smart City Feed Signals: Where Parking and EV Infrastructure Meet",
            "description": "Bridge RSS smart-city and EV stories into parking operator action items.",
            "primary_keyword": "EV parking infrastructure",
            "source": "rss_feeds",
        },
    ]
    return {
        "industry_keywords": industry,
        "competitor_urls": competitor,
        "rss_feeds": rss,
    }


def _clamp_group(items: list[dict[str, str]], source: TopicSource) -> list[dict[str, str]]:
    cleaned = [
        _normalize_topic(t, source)
        for t in items
        if isinstance(t, dict) and str(t.get("title") or "").strip()
    ]
    return cleaned[:MAX_PER_SOURCE]


@with_retry(max_attempts=3, base_delay=2.0)
def synthesize_topics(
    discovery_data: dict[str, Any],
    product: "Product | None" = None,
) -> dict[str, Any]:
    """Return packed topic groups (5–10 topics per discovery source)."""
    from app.models import Product
    from app.services.product_context import build_cmo_system_prompt, company_label

    company = company_label(product)
    industry = _compact_industry(discovery_data.get("industry_trends") or [])
    competitors = _compact_competitor(discovery_data.get("competitor_articles") or [])
    rss = _compact_rss(discovery_data.get("rss_articles") or [])

    if not anthropic_api_key_configured():
        logger.warning("Anthropic API key not configured; returning placeholder topic groups")
        return pack_topic_groups(_placeholder_groups())

    api_key = get_config_value("anthropic_api_key")
    client = anthropic.Anthropic(api_key=api_key)

    user_message = f"""Based on the discovery data below, generate blog topics for {company}.

CRITICAL RULES:
- Produce THREE separate groups of topics, one per discovery source.
- Aim for {TARGET_PER_SOURCE} topics per group (minimum {MIN_PER_SOURCE}, maximum {MAX_PER_SOURCE}).
- If a source has little or no usable data, still invent strong SEO topics clearly inspired by that source type
  (industry keyword research vs competitor blog gaps vs RSS/news angles) — do not leave a group empty.
- Topics across groups must not duplicate titles.
- Each topic MUST include title, description, primary_keyword, and exactly ONE source_url.
- source_url (REQUIRED): the single genuine URL from the discovery data below that this topic was taken from.
  - industry_keywords → pick one Tavily result URL whose title/content the topic is based on
  - competitor_urls → pick ONE of the configured competitor source_url values only (never invent other domains)
  - rss_feeds → pick one RSS article URL the topic is based on
  Do NOT invent URLs. Do NOT return multiple source links.
- HARDCODED: titles must be clickbait-style and content-true (curiosity + stakes + specific outcome).
  Avoid bland labels like "X Guide 2024". Prefer hooks executives would click.

Return ONLY valid JSON (no markdown fences) with this exact structure:
{{
  "groups": {{
    "industry_keywords": [
      {{
        "title": "Compelling blog title (60-80 chars)",
        "description": "2-3 sentence description of the article angle and value",
        "primary_keyword": "main SEO keyword phrase",
        "source_url": "https://exact-url-from-discovery-data"
      }}
    ],
    "competitor_urls": [ /* same shape — source_url must be a configured competitor source_url */ ],
    "rss_feeds": [ /* same shape */ ]
  }}
}}

INDUSTRY KEYWORD / TRENDS DATA (Tavily):
{json.dumps(industry, indent=2)}

COMPETITOR PAGES (ONLY these configured URLs were scraped — use source_url as the topic source):
{json.dumps(competitors, indent=2)}

RSS FEED ARTICLES:
{json.dumps(rss, indent=2)}
"""

    response = create_claude_message(
        client,
        max_tokens=8192,
        system=build_cmo_system_prompt(product),
        messages=[{"role": "user", "content": user_message}],
    )

    raw = (getattr(response.content[0], "text", None) or "").strip()
    if not raw:
        raise ValueError("Claude returned empty topic synthesis response")
    if raw.startswith("```"):
        raw = raw.split("\n", 1)[1].rsplit("```", 1)[0].strip()

    parsed = json.loads(raw)
    groups = normalize_topic_groups(parsed)

    for key in SOURCE_KEYS:
        groups[key] = _clamp_group(groups[key], key)
        if len(groups[key]) < MIN_PER_SOURCE:
            logger.warning(
                f"Topic group '{key}' returned {len(groups[key])} topics (expected ≥{MIN_PER_SOURCE})"
            )

    packed = pack_topic_groups(groups)
    packed = attach_source_links_to_topics(packed, discovery_data)
    total = topics_count(packed)
    logger.info(
        "Synthesized topics: "
        + ", ".join(f"{k}={len(groups[k])}" for k in SOURCE_KEYS)
        + f" (total={total})"
    )
    return packed
