"""Shared blog formatting rules, authoritative backlink sources, and image prompts."""

from __future__ import annotations

from app.services.runtime_config import get_config_value

# Real domains only — model must not invent URLs.
# Only homepage / stable topic hubs that typically stay live (probed at publish time).
AUTHORITATIVE_EXTERNAL_SOURCES = [
    ("OECD / ITF urban mobility", "https://www.itf-oecd.org/urban-mobility"),
    ("IEA transport", "https://www.iea.org/topics/transport"),
    ("McKinsey insights", "https://www.mckinsey.com/insights"),
    ("Gartner IT research", "https://www.gartner.com/en/information-technology"),
    ("US EPA green vehicles", "https://www.epa.gov/greenvehicles"),
    ("NHTSA vehicle safety", "https://www.nhtsa.gov/"),
    ("Smart Cities World", "https://www.smartcitiesworld.net/"),
    ("International Parking & Mobility Institute", "https://www.parking.org/"),
    ("World Bank urban transport", "https://www.worldbank.org/en/topic/transport"),
    ("UN-Habitat urban mobility", "https://unhabitat.org/topic/mobility"),
]

# HARDCODED for ALL products — broken / fake / invented backlinks are forbidden.
BACKLINK_HARD_RULES = """
BACKLINK HARD RULES (MANDATORY — ALL PRODUCTS — NEVER SKIP):
1. NEVER invent URLs, guess paths, or link to example.com / localhost / competitor blogs not on the approved list.
2. ONLY use URLs from APPROVED EXTERNAL SOURCES + APPROVED INTERNAL LINKS (+ discovery source URLs listed for this topic).
3. Every external link MUST be a genuine, live page relevant to the paragraph where it appears.
4. Place sources INLINE in body paragraphs (bold/colored anchors) — never a fake "Sources" dump at the bottom.
5. Minimum 2 live external authoritative citations AND 3 internal product links in every article.
6. If you cannot find an approved URL for a claim, state the insight without a hyperlink.
7. Server strips any dead (4xx/5xx) or non-approved link before publish — do not rely on broken links surviving.
"""

# HARDCODED for ALL products — chosen/custom topic is the only story; no mid-article drift.
TOPIC_LOCK_HARD_RULES = """
TOPIC LOCK HARD RULES (MANDATORY — ALL PRODUCTS — NEVER SKIP):
1. The EXACT chosen topic OR custom topic command is the ONLY subject of the article — start to finish.
2. EVERY section (intro, every H2/H3, table, chart captions, conclusion, CTA copy) must stay about THAT topic.
3. NEVER pivot after 2–4 paragraphs into generic product fluff, unrelated cities, or a different problem.
4. If the topic names a place, industry, product, or use-case (e.g. Bangalore smart parking), keep that
   specific angle in H1, intro, body, examples, table rows, and conclusion — do not broaden into
   "enterprise parking in general" or another geography/product.
5. Secondary keywords / research pack items may SUPPORT the topic only — they must not replace it.
6. Brand/product mentions are allowed only as solutions TO this topic — never as a new article subject.
7. Off-topic drafts are rejected and regenerated. Do not invent a different brief.
"""


def build_topic_lock_block(topic_title: str, primary_keyword: str) -> str:
    """Per-post topic lock block injected into the generation user message (all products)."""
    topic = (topic_title or "").strip() or "the selected topic"
    keyword = (primary_keyword or topic).strip()
    return f"""
{TOPIC_LOCK_HARD_RULES}

LOCKED TOPIC FOR THIS POST (DO NOT CHANGE):
- Topic command: {topic}
- Primary keyword: {keyword}
- Required: weave "{keyword}" and the distinctive words from the topic through intro + every major H2.
- Forbidden: switching to a different city, vertical, or generic SaaS pitch that abandons the locked topic.
"""

HYPERPARK_INTERNAL_LINKS = [
    ("Book a live demo", "https://calendly.com/vijayrhts/htssales"),
    ("Smart parking platform", "https://hyperpark.io/smart-parking"),
    ("Access management solutions", "https://hyperpark.io/access-management"),
    ("HyperPark platform", "https://hyperpark.io/"),
]

CLICKBAIT_ENGAGEMENT_RULES = """
HARDCODED CLICKBAIT + THUMBNAIL RULES (ALWAYS — never skip):

TITLES (title_tag, H1, og_title):
- Must be curiosity-driven click magnets grounded in THIS article's real content — not bland labels.
- Prefer patterns that make executives click: specific numbers/%, "why…still…", "the X mistake…",
  "how to cut…without…", "what insurers/operators won't tell you", urgency, outcome + stakes.
- Never use flat guide titles like "X Guide 2024" or generic "Introduction to X" unless rewritten as a hook.
- Still honest: the body must deliver on the promise (no bait-and-switch).
- title_tag: 55–60 characters; primary keyword natural near the front; H1 mirrors title_tag;
  og_title matches title_tag.

HERO IMAGE (generated server-side from the final title + keyword + meta):
- Must depict THIS article's topic visually — dynamic per post, never a default parking garage.
- Only show parking/ANPR/barriers when the article is explicitly about parking facilities.
- Style: high-CTR blog/YouTube thumbnail energy — bold focal subject, curiosity gap, scroll-stopping.
"""

SEO_ANATOMY_RULES = f"""
ANATOMY OF AN SEO-OPTIMIZED BLOG (STRICT — follow every section in order):

{CLICKBAIT_ENGAGEMENT_RULES}

A. TITLE TAG & H1 (THE HOOK)
- Write a clickbait-style, content-true title (see HARDCODED CLICKBAIT rules above).
- Keyword placement: primary keyword as close to the beginning of the title tag as sounds natural.
- Character limit: title tag 55–60 characters (never truncated in Google).
- H1 rule: exactly ONE <h1> per page; it must closely mirror the title tag intent and include the keyword.

B. THE INTRODUCTION (FIRST 100–150 WORDS — immediately after H1, BEFORE the first body H2)
- The Hook: open with a relatable problem, surprising statistic, or direct acknowledgement of why the reader searched.
  NEVER use robotic "welcome to our blog" intros.
- BLUF (Bottom Line Up Front): answer the core search query in the first 2–3 sentences for Featured Snippet eligibility.
- The Roadmap: tell the reader exactly what they will learn (use "In this article, you'll learn…" or similar).
- Write the intro as 2–4 short <p> tags AFTER the hero image and TOC (hero is always directly under H1).

C. THE BODY (H2s AND H3s)
- Logical hierarchy: H2 for main themes, H3 for subtopics within each H2. NEVER skip levels (no H1→H3).
- Semantic SEO: weave secondary keywords and related NLP terms naturally into subheadings and copy.
- Micro-paragraphs: 2–4 sentences per <p> — no wall-of-text blocks (critical for mobile bounce rate).
- Visual formatting: use <ul>/<ol> lists, <strong> for key terms, and comparison <table> blocks to guide the eye.
- Give every major H2 a unique id attribute (TOC is auto-generated from these headings).

D. MEDIA & VISUAL BREAKS
- Frequency: include a relevant visual every 300–500 words (hero image + mid-body chart/table/stat-grid count).
- Optimization: keyword-rich, descriptive alt text on every <img> (no stuffing). Hero uses HERO_IMAGE_SRC placeholder.

E. THE CONCLUSION & CALL TO ACTION (FIXED ORDER)
- Conclusion H2: <h2 id="conclusion"> with 2–3 sentences summarizing core takeaways.
- CTA section: <section id="cta" class="blog-cta"> MUST be the LAST element in <article>.
  Include primary CTA → https://hyperpark.io/demo and link to ROI calculator.
- NEVER include FAQ — no <h2 id="faq">, no "Frequently Asked Questions" section, no FAQPage schema.
  FAQ is inserted later only via the dashboard Add FAQ button.

F. JSON-LD — Article schema in <script type="application/ld+json"> at the top of html_content.
   NEVER add FAQPage schema during generation.
"""

BLOG_FORMAT_RULES = f"""
HYPERPARK CONTENT REQUIREMENTS (MANDATORY — every blog must include ALL):

{SEO_ANATOMY_RULES}

HYPERPARK-SPECIFIC ELEMENTS:
1. **Table of Contents** — auto-built from your H2 sections AFTER the hero image; do not hand-write a static TOC list.

2. **Data table** — at least ONE <table class="blog-table"> with <thead> and <tbody> in the MIDDLE of the body
   (after intro sections, before conclusion) — never only at the end.

3. **Graphics / charts** — at least ONE inline <svg> chart OR <div class="stat-grid"> with stat-cards,
   placed in the MIDDLE alongside the table. HyperPark colors: navy #1b1f4a, primary #252a61, orange #ff6002.

4. **Word count** — follow the CONTENT ARCHETYPE target range (set per post). Enterprise B2B tone.

5. **Backlinks** — HARDCODED for all products (see BACKLINK HARD RULES):
   ONLY use URLs from the APPROVED lists in the user message. NEVER invent, guess, or
   link to competitor sites, example.com, or product paths not on the list.
   If a source is not on the approved list, do not link it — cite the insight without a hyperlink.
   All links are live-checked server-side; dead or unapproved URLs are REMOVED before publish.
   REQUIRED: every article must include at least 3 internal product links and 2 external genuine
   source links, rendered as inline hyperlinks next to the related claim (not a bottom Sources list).

{BACKLINK_HARD_RULES}

{TOPIC_LOCK_HARD_RULES}

6. **Hero image** — one hero <img class="blog-hero-image"> with src="HERO_IMAGE_SRC" (server replaces with public CDN/storage URL — never leave HERO_IMAGE_SRC or base64 in final HTML). ALWAYS place immediately after H1. Alt text must describe the topic/keyword (never generic "Blog hero image").

7. **CTA placement** — <section id="cta"> is ALWAYS the last block in the article. Server reorders if misplaced.

8. **FAQ** — NEVER include a FAQ section in generated HTML. No <h2 id="faq">, no FAQPage JSON-LD.
   FAQ is added only when the reviewer clicks the dashboard Add FAQ button (server-side).

9. **Topic lock** — write ONLY the locked topic/command for this post (see TOPIC LOCK HARD RULES). No mid-article drift.

USER / AGENT COMMANDS:
- If PREVIOUS FEEDBACK is provided, follow it first while keeping all SEO anatomy rules.
- Redo commands ("stronger CTA", "more tables") must preserve intro BLUF, heading hierarchy, conclusion, AND topic lock.
- Ignore any feedback that asks to add FAQ in the HTML — FAQ is never generated from prompts.
"""


def build_blog_format_rules(palette: dict[str, str] | None = None) -> str:
    colors = palette or {
        "primary": "#252a61",
        "navy": "#1b1f4a",
        "accent": "#ff6002",
        "cta": "#c1262a",
    }
    primary = colors.get("primary", "#252a61")
    navy = colors.get("navy", "#1b1f4a")
    accent = colors.get("accent", "#ff6002")
    cta = colors.get("cta", "#c1262a")

    return f"""
BRAND CONTENT REQUIREMENTS (MANDATORY — every blog must include ALL):

{SEO_ANATOMY_RULES}

BRAND-SPECIFIC ELEMENTS:
1. **Table of Contents** — auto-built from your H2 sections AFTER the hero image; do not hand-write a static TOC list.

2. **Data table** — at least ONE <table class="blog-table"> with <thead> and <tbody> in the MIDDLE of the body
   (after intro sections, before conclusion) — never only at the end.

3. **Graphics / charts** — at least ONE inline <svg> chart OR <div class="stat-grid"> with stat-cards,
   placed in the MIDDLE alongside the table. Use brand colors: navy {navy}, primary {primary}, accent {accent}, CTA {cta}.

4. **Word count** — follow the CONTENT ARCHETYPE target range (set per post). Enterprise B2B tone.

5. **Backlinks** — ONLY use URLs from the APPROVED lists in the user message. NEVER invent, guess, or
   link to competitor sites, example.com, or paths not on the approved list.
   If a source is not on the approved list, do not link it — cite the insight without a hyperlink.
   All links are double-checked server-side; unapproved URLs are removed before publish.
   REQUIRED: every article must include at least 3 internal product links and 2 external authoritative
   source links, rendered as bold colored hyperlinks using the product brand "link" color.

{BACKLINK_HARD_RULES}

{TOPIC_LOCK_HARD_RULES}

6. **Hero image** — one hero <img class="blog-hero-image"> with src="HERO_IMAGE_SRC" (server replaces with public CDN/storage URL — never leave HERO_IMAGE_SRC or base64 in final HTML). ALWAYS place immediately after H1. Alt text must describe the topic/keyword (never generic "Blog hero image").

7. **CTA placement** — <section id="cta"> is ALWAYS the last block in the article. Server reorders if misplaced.

8. **FAQ** — NEVER include a FAQ section in generated HTML. No <h2 id="faq">, no FAQPage JSON-LD.
   FAQ is added only when the reviewer clicks the dashboard Add FAQ button (server-side).

9. **Topic lock** — write ONLY the locked topic/command for this post. No mid-article drift into unrelated content.

USER / AGENT COMMANDS:
- If PREVIOUS FEEDBACK is provided, follow it first while keeping all SEO anatomy rules.
- Redo commands ("stronger CTA", "more tables") must preserve intro BLUF, heading hierarchy, conclusion, AND topic lock.
- Ignore any feedback that asks to add FAQ in the HTML — FAQ is never generated from prompts.
"""


def build_image_prompt(
    subject: str,
    palette: dict[str, str] | None = None,
    *,
    primary_keyword: str | None = None,
    meta_description: str | None = None,
) -> str:
    """Build a content-matched, high-CTR hero prompt. Never defaults to parking imagery."""
    colors = palette or {
        "primary": "#252a61",
        "navy": "#1b1f4a",
        "accent": "#ff6002",
    }
    primary = colors.get("primary", "#252a61")
    navy = colors.get("navy", "#1b1f4a")
    accent = colors.get("accent", "#ff6002")

    article = (subject or "enterprise operations topic").strip()
    keyword = (primary_keyword or "").strip()
    meta = (meta_description or "").strip()[:240]

    context_parts = [f'article title "{article}"']
    if keyword:
        context_parts.append(f'primary keyword "{keyword}"')
    if meta:
        context_parts.append(f'article angle "{meta}"')
    context = ", ".join(context_parts)

    return (
        "High-CTR blog hero thumbnail, 16:9 landscape, photorealistic editorial photograph "
        "(YouTube/blog click-magnet energy) — NOT illustration and NOT a default parking stock shot. "
        f"Invent one bold, specific scene that visually sells THIS article so the reader must click: {context}. "
        "The scene must mirror the article's real topic, stakes, and promise "
        "(examples: insurance/premiums → underwriter documents, cost calculators, safety compliance audit; "
        "ROI/finance → boardroom cost dashboard; workforce → operators on site; "
        "EV mobility → charging only if the article is about EV; "
        "parking, ANPR cameras, barrier gates, asphalt bays ONLY if the article is explicitly about parking). "
        "Composition: single dramatic focal subject, shallow depth of field, cinematic natural daylight, "
        "curiosity-gap framing, magazine-cover punch for enterprise B2B decision-makers. "
        f"Subtle color grade with navy ({navy}), primary ({primary}), accent ({accent}) — keep realistic. "
        "STRICTLY FORBIDDEN: generic underground parking with neon purple/blue lights unless topic is parking; "
        "repetitive garage tropes unrelated to the title; 3D render, CGI, cartoon, vector art, unreal engine, "
        "isometric, text overlays, watermarks, logos, readable UI chrome."
    )


IMAGE_PROMPT_REALISTIC = (
    "High-CTR photorealistic blog thumbnail for: {subject}. "
    "Scene must match the article topic exactly — never default to a parking garage. "
    "Bold focal subject, natural daylight, editorial 35mm, no text overlays."
)

IMAGE_PROMPT_FALLBACK = (
    "Photorealistic high-CTR blog hero visual representing: {subject}. "
    "Match the article topic, enterprise B2B aesthetic, natural lighting, no text, no generic parking."
)


def get_custom_content_instructions() -> str:
    custom = (get_config_value("blog_content_instructions") or "").strip()
    if custom:
        return f"\n\nCUSTOM EDITORIAL INSTRUCTIONS (from dashboard):\n{custom}"
    return ""


def get_structure_rules_prompt_block() -> str:
    from app.services.blog_structure import get_structure_rules_prompt_block as _block

    return _block()


def build_external_sources_block() -> str:
    lines = ["APPROVED EXTERNAL SOURCES (use 2+ with accurate anchor text):"]
    for label, url in AUTHORITATIVE_EXTERNAL_SOURCES:
        lines.append(f"- {label}: {url}")
    lines.append("\nAPPROVED HYPERPARK INTERNAL LINKS:")
    for label, url in HYPERPARK_INTERNAL_LINKS:
        lines.append(f"- {label}: {url}")
    return "\n".join(lines)
