from __future__ import annotations

import io
from pathlib import Path
from typing import Any

import httpx
from loguru import logger
from PIL import Image

from app.config import settings
from app.services.blog_format import build_image_prompt
from app.services.product_context import get_brand_palette, get_core_brand_colors
from app.services.runtime_config import get_config_value, is_placeholder_value
from app.utils.retry import with_retry


@with_retry(max_attempts=3, base_delay=3.0)
def generate_hero_image(
    topic_title: str,
    slug: str,
    feedback_history: list | None = None,
    product: Any | None = None,
    custom_prompt: str | None = None,
    primary_keyword: str | None = None,
    meta_description: str | None = None,
) -> str:
    """Generate a content-matched, high-CTR hero thumbnail for this article."""
    custom = (custom_prompt or "").strip()
    palette = get_core_brand_colors(get_brand_palette(product))
    keyword = (primary_keyword or "").strip() or None
    meta = (meta_description or "").strip() or None

    if custom:
        # User-supplied subject — still force content-matched, non-parking-default builder
        prompt = build_image_prompt(
            custom[:600],
            palette,
            primary_keyword=keyword,
            meta_description=meta,
        )
    else:
        subject = (topic_title or slug or "enterprise topic").strip()
        if feedback_history:
            latest = feedback_history[-1].get("feedback", "")
            low = (latest or "").lower()
            if any(w in low for w in ("image", "visual", "photo", "realistic", "thumbnail", "banner")):
                subject = f"{subject}. Visual notes: {(latest or '')[:180]}"
        prompt = build_image_prompt(
            subject,
            palette,
            primary_keyword=keyword,
            meta_description=meta,
        )

    output_path = Path(settings.blog_images_dir) / f"{slug}.webp"
    output_path.parent.mkdir(parents=True, exist_ok=True)

    fal_key = get_config_value("fal_key")
    if not fal_key or is_placeholder_value(fal_key):
        logger.warning("Fal.ai API key not configured; creating placeholder image")
        return _create_placeholder_image(output_path, slug, topic_title, product)

    try:
        import fal_client
        import os

        os.environ["FAL_KEY"] = fal_key

        logger.info(f"Hero image prompt for '{slug}': {prompt[:220]}...")
        result = fal_client.subscribe(
            "fal-ai/flux-pro/v1.1",
            arguments={
                "prompt": prompt,
                "image_size": "landscape_16_9",
                "num_images": 1,
                "safety_tolerance": "2",
                "enable_safety_checker": True,
            },
        )

        image_url = result["images"][0]["url"]
        return _download_and_convert(image_url, output_path)
    except Exception as exc:
        logger.error(f"Fal.ai generation failed: {exc}")
        return _create_placeholder_image(output_path, slug, topic_title, product)


def _download_and_convert(url: str, output_path: Path) -> str:
    with httpx.Client(timeout=120.0) as client:
        response = client.get(url)
        response.raise_for_status()

    img = Image.open(io.BytesIO(response.content)).convert("RGB")
    # Keep source resolution when already ≥ target; only downscale, never upscale
    if img.size != (1200, 630):
        img = img.resize((1200, 630), Image.Resampling.LANCZOS)
    # Minimal processing — preserve Fal output fidelity (no contrast/sharpen boosts)
    img.save(output_path, "WEBP", quality=100, method=6)
    logger.info(f"Hero image saved: {output_path}")
    return str(output_path)


def _hex_to_rgb(hex_color: str, fallback: tuple[int, int, int]) -> tuple[int, int, int]:
    value = (hex_color or "").strip().lstrip("#")
    if len(value) != 6:
        return fallback
    try:
        return (
            int(value[0:2], 16),
            int(value[2:4], 16),
            int(value[4:6], 16),
        )
    except ValueError:
        return fallback


def _create_placeholder_image(
    output_path: Path,
    slug: str,
    title: str = "",
    product: Any | None = None,
) -> str:
    palette = get_core_brand_colors(get_brand_palette(product))
    navy = _hex_to_rgb(palette.get("navy", "#1b1f4a"), (27, 31, 74))
    primary = _hex_to_rgb(palette.get("primary", "#252a61"), (37, 42, 97))
    accent = _hex_to_rgb(palette.get("accent", "#ff6002"), (255, 96, 2))
    cta = _hex_to_rgb(palette.get("cta", "#c1262a"), (193, 38, 42))

    img = Image.new("RGB", (1200, 630), color=(244, 245, 250))
    from PIL import ImageDraw

    draw = ImageDraw.Draw(img)
    draw.rectangle([0, 420, 1200, 630], fill=navy)
    draw.rectangle([60, 80, 1140, 400], fill=primary)
    draw.rectangle([80, 260, 380, 380], fill=primary, outline=accent, width=3)
    draw.rectangle([420, 120, 1120, 360], fill=cta)
    label = (title[:52] + "…") if len(title) > 52 else (title or slug)
    draw.text((80, 430), label, fill=(255, 255, 255))
    company = getattr(product, "company_name", None) or getattr(product, "name", None) or "blog Automation"
    draw.text((80, 460), company, fill=accent)
    img.save(output_path, "WEBP", quality=100, method=6)
    logger.info(f"Placeholder image created: {output_path}")
    return str(output_path)
