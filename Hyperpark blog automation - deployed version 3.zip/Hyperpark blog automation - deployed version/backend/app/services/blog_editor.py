from __future__ import annotations

import io
import re
from pathlib import Path

from fastapi import HTTPException, UploadFile
from loguru import logger
from PIL import Image

from app.config import settings
from app.services.blog_text_editor import hero_img_tag
from app.services.runtime_config import get_config_value


def calc_reading_time(html: str) -> str:
    text = re.sub(r"<[^>]+>", " ", html)
    words = len(text.split())
    minutes = max(1, round(words / 200))
    return f"{minutes} min read"


def save_hero_upload(slug: str, upload: UploadFile) -> str:
    if not upload.content_type or not upload.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="File must be an image")

    raw = upload.file.read()
    if len(raw) > 10 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="Image must be under 10 MB")

    try:
        img = Image.open(io.BytesIO(raw)).convert("RGB")
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid image file: {exc}") from exc

    img = img.resize((1200, 630), Image.Resampling.LANCZOS)
    out_dir = Path(settings.blog_images_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{slug}.webp"
    img.save(out_path, "WEBP", quality=100, method=6)
    logger.info(f"Manual hero upload saved: {out_path}")
    return str(out_path)


def sync_hero_img_in_html(html: str, slug: str, alt: str | None = None) -> str:
    """Point the first <img> in article body to the current public hero URL (never base64)."""
    from app.services.seo_pipeline import descriptive_hero_alt

    base = get_config_value("public_base_url") or settings.public_base_url or "http://localhost:8000"
    hero_alt = alt or descriptive_hero_alt(slug.replace("-", " "), None)
    hero = hero_img_tag(slug, base, alt=hero_alt)
    if re.search(r"<img\b", html, re.I):
        return re.sub(r"<img[^>]*>", hero, html, count=1, flags=re.I)
    if re.search(r"</h1>", html, re.I):
        return re.sub(r"(</h1>)", r"\1\n" + hero, html, count=1, flags=re.I)
    return html
