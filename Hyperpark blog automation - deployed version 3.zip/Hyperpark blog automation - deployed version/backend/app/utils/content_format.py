from __future__ import annotations

import re

from loguru import logger

from app.utils.seo_structure import validate_seo_structure

_CTA_PATTERN = re.compile(r'id=["\']cta["\']|class=["\'][^"\']*blog-cta', re.I)
_TABLE_PATTERN = re.compile(r"<table[\s>]", re.I)
_SVG_PATTERN = re.compile(r"<svg[\s>]", re.I)
_STAT_GRID_PATTERN = re.compile(r'class=["\'][^"\']*stat-(grid|card)', re.I)


def validate_rich_format(html: str) -> list[str]:
    """Return list of missing format elements (empty = all present)."""
    missing: list[str] = []
    if not _TABLE_PATTERN.search(html):
        missing.append("data table")
    if not _SVG_PATTERN.search(html) and not _STAT_GRID_PATTERN.search(html):
        missing.append("chart or stat-grid graphic")
    if not _CTA_PATTERN.search(html):
        missing.append("closing CTA section")
    if len(re.findall(r'href=["\']https?://(?:www\.)?hyperpark\.io/', html, re.I)) < 3:
        missing.append("internal backlinks (min 3)")
    if len(
        re.findall(
            r'<a[^>]+href=["\']https?://(?!hyperpark\.io)[^"\']+["\'][^>]*>',
            html,
            re.I,
        )
    ) < 2:
        missing.append("external authoritative backlinks (min 2)")
    missing.extend(validate_seo_structure(html))
    return missing


def validate_word_count(html: str, content_archetype: str | None) -> list[str]:
    from app.services.content_archetypes import get_archetype, word_count_in_range
    from app.utils.word_count import count_blog_words

    arch = get_archetype(content_archetype)
    wc = count_blog_words(html)
    if not word_count_in_range(wc, arch.id):
        return [f"word count {wc} outside {arch.label} range ({arch.min_words}–{arch.max_words})"]
    return []


def log_format_warnings(html: str, post_id: int | None = None) -> None:
    missing = validate_rich_format(html)
    if missing:
        label = f"BlogPost #{post_id}" if post_id else "Blog content"
        logger.warning(f"{label} missing format elements: {', '.join(missing)}")
