import os
from contextlib import asynccontextmanager
from pathlib import Path

# Pin Playwright browsers before any Playwright import in worker threads.
# Respect PLAYWRIGHT_BROWSERS_PATH when already set (e.g. Docker image bake path).
if not os.environ.get("PLAYWRIGHT_BROWSERS_PATH"):
    _browsers_dir = (
        Path(__file__).resolve().parent.parent.parent / "storage" / "playwright-browsers"
    )
    _browsers_dir.mkdir(parents=True, exist_ok=True)
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = str(_browsers_dir)

from fastapi import BackgroundTasks, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, RedirectResponse
from loguru import logger

from app.api import (
    auth,
    brand_palettes,
    google,
    integrations,
    notifications,
    products,
    review,
    settings,
    teams,
    topics,
    ubersuggest,
    wordpress,
    workflow,
)
from app.config import settings as app_settings
from app.database import Base, SessionLocal, engine, run_sqlite_migrations
from app.services.scheduler import migrate_global_schedule_to_products, start_scheduler, stop_scheduler
from app.services.workflow import (
    complete_discovery_run,
    seed_scraper_settings,
    start_discovery_run,
)
from typing import Optional

from pydantic import BaseModel

from app.api.products import seed_default_product
from app.utils.logging_config import setup_logging
from app.utils.playwright_setup import browsers_installed, configure_playwright_browsers_path


@asynccontextmanager
async def lifespan(app: FastAPI):
    setup_logging()
    app_settings.ensure_dirs()
    configure_playwright_browsers_path()
    Path(app_settings.storage_root, "logs").mkdir(parents=True, exist_ok=True)
    Base.metadata.create_all(bind=engine)
    run_sqlite_migrations()

    db = SessionLocal()
    try:
        seed_default_product(db)
        seed_scraper_settings(db)
        migrate_global_schedule_to_products(db)
        from app.services.slugs import backfill_product_slugs

        n = backfill_product_slugs(db)
        if n:
            logger.info("Backfilled fixed slugs for {} product(s)", n)
    finally:
        db.close()

    start_scheduler()
    logger.info("blog Automation engine started")
    yield
    stop_scheduler()
    logger.info("blog Automation engine stopped")


app = FastAPI(
    title="blog Automation",
    description="Enterprise SEO blog automation with HITL review gates",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        app_settings.frontend_url,
        "https://blog-automation.app.knowerai.com",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:3001",
        "http://127.0.0.1:3001",
        "http://localhost:3002",
        "http://127.0.0.1:3002",
        "http://localhost:8080",
        "http://127.0.0.1:8080",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(integrations.router)
app.include_router(brand_palettes.router)
app.include_router(notifications.router)
app.include_router(products.router)
app.include_router(settings.router)
app.include_router(topics.router)
app.include_router(review.router)
app.include_router(teams.router)
app.include_router(ubersuggest.router)
app.include_router(wordpress.router)
app.include_router(google.router)
app.include_router(workflow.router)


@app.get("/", include_in_schema=False)
def root():
    """API has no HTML UI — send browsers to the Next.js dashboard."""
    return RedirectResponse(url=app_settings.frontend_url, status_code=307)


@app.get("/api", include_in_schema=False)
def api_root():
    return {
        "service": "hyperpark-blog-automation",
        "status": "ok",
        "dashboard": app_settings.frontend_url,
        "docs": "/docs",
        "health": "/api/health",
    }


@app.get("/api/health")
def health():
    configure_playwright_browsers_path()
    return {
        "status": "ok",
        "service": "hyperpark-blog-automation",
        "playwright": "ready" if browsers_installed() else "missing",
    }


class DiscoveryTriggerRequest(BaseModel):
    product_id: Optional[int] = None


@app.post("/api/discovery/trigger")
def trigger_discovery(
    background_tasks: BackgroundTasks,
    payload: Optional[DiscoveryTriggerRequest] = None,
):
    """Start discovery in the background; returns immediately with post_id."""
    product_id = payload.product_id if payload else None
    post_id = start_discovery_run(product_id)
    background_tasks.add_task(complete_discovery_run, post_id)
    return {
        "message": "Discovery started",
        "post_id": post_id,
    }


@app.post("/api/discovery/{post_id}/retry")
def retry_discovery(post_id: int, background_tasks: BackgroundTasks):
    """Retry a stuck or failed discovery run (same post / same stage)."""
    from app.models import BlogPost, BlogStatus

    db = SessionLocal()
    try:
        post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
        if not post:
            raise HTTPException(status_code=404, detail="Post not found")
        if post.status not in (BlogStatus.SCRAPING, BlogStatus.REJECTED):
            raise HTTPException(
                status_code=400,
                detail=f"Cannot retry discovery for post in status {post.status.value}",
            )
        post.status = BlogStatus.SCRAPING
        # Keep topics/history except clear errors so Retry reworks discovery, not a brand-new board card
        history = list(post.feedback_history or [])
        post.feedback_history = [h for h in history if h.get("type") != "error"]
        db.commit()
    finally:
        db.close()

    background_tasks.add_task(complete_discovery_run, post_id)
    return {"message": "Discovery retry started", "post_id": post_id}


@app.post("/api/generation/{post_id}/retry")
def retry_generation_endpoint(post_id: int, background_tasks: BackgroundTasks):
    """Retry failed blog generation on the same post without returning to discovery."""
    from app.models import BlogPost, BlogStatus
    from app.services.workflow import retry_generation

    db = SessionLocal()
    try:
        post = db.query(BlogPost).filter(BlogPost.id == post_id).first()
        if not post:
            raise HTTPException(status_code=404, detail="Post not found")
        if post.status not in (BlogStatus.GENERATING, BlogStatus.PENDING_REVIEW):
            raise HTTPException(
                status_code=400,
                detail=f"Cannot retry generation for post in status {post.status.value}",
            )
        if not post.selected_topic_title:
            raise HTTPException(status_code=400, detail="No selected topic on this post")
    finally:
        db.close()

    background_tasks.add_task(retry_generation, post_id)
    return {"message": "Generation retry started", "post_id": post_id}


@app.get("/api/images/{slug}.webp")
def serve_image(slug: str):
    path = Path(app_settings.blog_images_dir) / f"{slug}.webp"
    if not path.exists():
        from fastapi import HTTPException

        raise HTTPException(status_code=404, detail="Image not found")
    return FileResponse(
        path,
        media_type="image/webp",
        headers={"Cache-Control": "no-cache, must-revalidate"},
    )


def _post_summary_dict(p) -> dict:
    from app.models import Product

    history = p.feedback_history or []
    last_error = None
    for entry in reversed(history):
        if entry.get("type") == "error":
            last_error = entry.get("feedback")
            break
    topics = p.scraped_topics_json or []
    product_name = None
    if getattr(p, "product_id", None):
        db = SessionLocal()
        try:
            prod = db.query(Product).filter(Product.id == p.product_id).first()
            product_name = prod.name if prod else None
        finally:
            db.close()
    from app.services.topic_synthesis import topics_count

    minio_object = None
    for entry in reversed(history):
        if entry.get("type") == "published" and isinstance(entry.get("minio"), dict):
            minio_object = entry["minio"].get("object_name")
            break

    return {
        "id": p.id,
        "status": p.status.value,
        "title_tag": p.title_tag,
        "selected_topic_title": p.selected_topic_title,
        "slug": p.slug,
        "meta_description": p.meta_description,
        "reading_time": p.reading_time,
        "image_url": p.image_url,
        "created_at": p.created_at.isoformat() if p.created_at else None,
        "published_at": p.published_at.isoformat() if getattr(p, "published_at", None) else None,
        "publish_serial": getattr(p, "publish_serial", None),
        "topics_count": topics_count(topics),
        "comment_count": len(history),
        "last_error": last_error,
        "content_archetype": p.content_archetype,
        "product_id": getattr(p, "product_id", None),
        "product_name": product_name,
        "minio_object": minio_object,
    }


@app.get("/api/posts")
def list_all_posts(product_id: Optional[int] = None, status: Optional[str] = None):
    from sqlalchemy import or_

    from app.models import BlogPost, BlogStatus, Product

    db = SessionLocal()
    try:
        query = db.query(BlogPost)
        if product_id is not None:
            default_product = (
                db.query(Product).filter(Product.is_default.is_(True)).first()
                or db.query(Product).order_by(Product.id).first()
            )
            default_id = default_product.id if default_product else None
            if default_id and product_id == default_id:
                query = query.filter(
                    or_(BlogPost.product_id == product_id, BlogPost.product_id.is_(None))
                )
            else:
                query = query.filter(BlogPost.product_id == product_id)
        if status:
            try:
                status_enum = BlogStatus(status)
            except ValueError as exc:
                raise HTTPException(status_code=400, detail=f"Invalid status: {status}") from exc
            query = query.filter(BlogPost.status == status_enum)
        limit = 100 if status == "PUBLISHED" else 50
        if status == "PUBLISHED":
            # Serial order (#1, #2, …) with publish time as tie-breaker
            posts = (
                query.order_by(
                    BlogPost.publish_serial.asc().nullslast(),
                    BlogPost.published_at.asc().nullslast(),
                    BlogPost.id.asc(),
                )
                .limit(limit)
                .all()
            )
        else:
            posts = query.order_by(BlogPost.created_at.desc()).limit(limit).all()
        return [_post_summary_dict(p) for p in posts]
    finally:
        db.close()
