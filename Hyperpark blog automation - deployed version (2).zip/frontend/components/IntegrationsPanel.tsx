"use client";

import { useEffect, useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  Eye,
  EyeOff,
  KeyRound,
  Loader2,
  Save,
  Send,
  Trash2,
  XCircle,
} from "lucide-react";
import { api, IntegrationField, IntegrationsConfig } from "@/lib/api";
import Button from "@/components/ui/Button";
import { Skeleton } from "@/components/ui/Skeleton";
import { cn } from "@/lib/cn";

export default function IntegrationsPanel() {
  const [config, setConfig] = useState<IntegrationsConfig | null>(null);
  const [draft, setDraft] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [savingKey, setSavingKey] = useState<string | null>(null);
  const [deletingKey, setDeletingKey] = useState<string | null>(null);
  const [visibleSecrets, setVisibleSecrets] = useState<Set<string>>(new Set());
  const [message, setMessage] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  async function load() {
    try {
      const data = await api.getIntegrations();
      setConfig(data);
      setDraft({});
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  function handleChange(key: string, value: string) {
    setDraft((prev) => ({ ...prev, [key]: value }));
  }

  async function handleSaveField(key: string) {
    const value = draft[key] ?? "";
    if (!value.trim() && key !== "blog_structure_rules") {
      setMessage({ type: "error", text: "Enter a value before saving." });
      return;
    }
    setSavingKey(key);
    setMessage(null);
    try {
      await api.saveIntegrationKey(key, value.trim());
      setMessage({ type: "success", text: "Saved successfully." });
      await load();
    } catch (e) {
      setMessage({ type: "error", text: String(e) });
    } finally {
      setSavingKey(null);
    }
  }

  async function handleDeleteField(key: string, label: string) {
    if (
      !confirm(
        `Delete saved value for "${label}"?\n\nThis removes it from the database. If a placeholder still exists in backend/.env, clear that file too.`
      )
    ) {
      return;
    }
    setDeletingKey(key);
    setMessage(null);
    try {
      await api.deleteIntegrationKey(key);
      setDraft((prev) => {
        const next = { ...prev };
        delete next[key];
        return next;
      });
      setMessage({ type: "success", text: `"${label}" removed from database.` });
      await load();
    } catch (e) {
      setMessage({ type: "error", text: String(e) });
    } finally {
      setDeletingKey(null);
    }
  }

  if (loading) {
    return (
      <div className="space-y-5">
        <Skeleton className="h-24 w-full rounded-2xl" />
        <Skeleton className="h-64 w-full rounded-2xl" />
        <Skeleton className="h-48 w-full rounded-2xl" />
      </div>
    );
  }

  if (!config) {
    return <p className="text-hyper-red">Failed to load integration settings.</p>;
  }

  const placeholderCount = config.fields.filter((f) => f.is_placeholder).length;

  const grouped = config.groups.map((group) => ({
    group,
    fields: config.fields.filter((f) => f.group === group),
  }));

  return (
    <div className="settings-stack">
      <div className="settings-intro">
        <div className="relative flex items-start gap-3.5 pl-1">
          <span className="settings-intro-icon">
            <KeyRound className="h-4 w-4" />
          </span>
          <div>
            <p className="text-sm font-semibold text-hyper-navy">API keys & integrations</p>
            <p className="mt-1 max-w-2xl text-xs leading-relaxed text-text-secondary md:text-sm">
              Paste each key and save per row. Credentials are stored securely in SQLite at{" "}
              <code className="rounded bg-white px-1.5 py-0.5 font-mono text-[11px] text-hyper-primary ring-1 ring-hyper-border">
                storage/hyperpark_blog.db
              </code>
              .
            </p>
            {placeholderCount > 0 && (
              <p className="mt-3 inline-flex items-center gap-2 rounded-full border border-amber-200 bg-amber-50 px-3 py-1 text-xs font-medium text-amber-800">
                <AlertTriangle className="h-3.5 w-3.5" />
                {placeholderCount} field(s) still use .env placeholders
              </p>
            )}
          </div>
        </div>
      </div>

      {message && (
        <div
          className={cn(
            "settings-alert",
            message.type === "success"
              ? "border-emerald-200 bg-emerald-50 text-emerald-800"
              : "border-red-200 bg-red-50 text-red-800"
          )}
        >
          <span
            className={cn(
              "settings-alert-dot",
              message.type === "success" ? "bg-emerald-500" : "bg-hyper-red"
            )}
          />
          {message.text}
        </div>
      )}

      {grouped.map(({ group, fields }) => (
        <div key={group} className="settings-card">
          <div className="settings-accent-bar h-0.5" />
          <div className="settings-card-head">
            <p className="text-micro uppercase tracking-wider text-text-muted">Integration group</p>
            <h2 className="mt-0.5 text-base font-semibold text-hyper-navy md:text-lg">{group}</h2>
          </div>
          <div className="settings-card-body">
            {fields.map((field) =>
                field.key === "topic_selection_mode" ? (
                  <div key={field.key} className="settings-field-row">
                    <p className="text-sm font-medium text-hyper-navy">{field.label}</p>
                    <p className="mt-1 text-xs leading-relaxed text-text-secondary">
                      Automation mode is now set <strong>per product</strong> on the Content Board
                      (under each product) and in Settings → Products. Choose Manual, Auto, or Both
                      for each product line separately.
                    </p>
                  </div>
                ) : field.key === "anthropic_model" ? (
                  <AnthropicModelFieldRow
                    key={field.key}
                    field={field}
                    draftValue={draft[field.key]}
                    saving={savingKey === field.key}
                    onChange={(v) => handleChange(field.key, v)}
                    onSave={() => handleSaveField(field.key)}
                  />
                ) : field.key === "blog_structure_rules" ? (
                  <BlogStructureFieldRow
                    key={field.key}
                    field={field}
                    draftValue={draft[field.key]}
                    saving={savingKey === field.key}
                    onChange={(v) => handleChange(field.key, v)}
                    onSave={() => handleSaveField(field.key)}
                  />
                ) : field.key === "blog_content_instructions" ? (
                  <BlogInstructionsFieldRow
                    key={field.key}
                    field={field}
                    draftValue={draft[field.key]}
                    saving={savingKey === field.key}
                    onChange={(v) => handleChange(field.key, v)}
                    onSave={() => handleSaveField(field.key)}
                  />
                ) : field.key === "teams_notifications_enabled" ? (
                  <TeamsNotificationsToggle
                    key={field.key}
                    field={field}
                    saving={savingKey === field.key}
                    onSave={async (enabled) => {
                      setSavingKey(field.key);
                      setMessage(null);
                      try {
                        await api.saveIntegrationKey(field.key, enabled ? "true" : "false");
                        setMessage({
                          type: "success",
                          text: enabled
                            ? "Teams notifications are on."
                            : "Teams notifications turned off.",
                        });
                        await load();
                      } catch (e) {
                        setMessage({ type: "error", text: String(e) });
                      } finally {
                        setSavingKey(null);
                      }
                    }}
                  />
                ) : field.key === "teams_webhook_url" ? (
                  <TeamsWebhookFieldRow
                    key={field.key}
                    field={field}
                    draftValue={draft[field.key]}
                    showSecret={visibleSecrets.has(field.key)}
                    saving={savingKey === field.key}
                    deleting={deletingKey === field.key}
                    onToggleSecret={() =>
                      setVisibleSecrets((prev) => {
                        const next = new Set(prev);
                        if (next.has(field.key)) next.delete(field.key);
                        else next.add(field.key);
                        return next;
                      })
                    }
                    onChange={(v) => handleChange(field.key, v)}
                    onSave={() => handleSaveField(field.key)}
                    onDelete={() => handleDeleteField(field.key, field.label)}
                    onMessage={setMessage}
                  />
                ) : (
                  <IntegrationFieldRow
                    key={field.key}
                    field={field}
                    draftValue={draft[field.key]}
                    showSecret={visibleSecrets.has(field.key)}
                    saving={savingKey === field.key}
                    deleting={deletingKey === field.key}
                    onToggleSecret={() =>
                      setVisibleSecrets((prev) => {
                        const next = new Set(prev);
                        if (next.has(field.key)) next.delete(field.key);
                        else next.add(field.key);
                        return next;
                      })
                    }
                    onChange={(v) => handleChange(field.key, v)}
                    onSave={() => handleSaveField(field.key)}
                    onDelete={() => handleDeleteField(field.key, field.label)}
                  />
                )
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

function BlogStructureFieldRow({
  field,
  draftValue,
  saving,
  onChange,
  onSave,
}: {
  field: IntegrationField;
  draftValue?: string;
  saving: boolean;
  onChange: (v: string) => void;
  onSave: () => void;
}) {
  const current = draftValue ?? field.value ?? "";
  const hasDraft = draftValue !== undefined && draftValue !== (field.value || "");

  return (
    <div className="settings-field-row">
      <div className="mb-2">
        <label className="text-sm font-medium text-hyper-navy">{field.label}</label>
        <p className="text-xs text-text-secondary">{field.description}</p>
        <p className="mt-1 text-[11px] text-text-muted">
          Leave empty to use the default layout. Hero image always follows H1; CTA always comes last — enforced on every post.
        </p>
      </div>
      <textarea
        value={current}
        onChange={(e) => onChange(e.target.value)}
        rows={8}
        placeholder={`FIXED BLOG LAYOUT (default):\n1. H1 title\n2. Hero image (immediately after H1)\n3. Table of Contents\n4. Introduction paragraphs\n5. Body sections (H2/H3, tables, charts)\n6. Conclusion\n7. CTA (always last)\n\nFAQ is NOT included unless you click Add FAQ.\n\nAdd archetype-specific section rules here, e.g. listicle item count...`}
        className="mb-2 w-full rounded-xl border border-hyper-border px-3 py-2 font-mono text-xs leading-relaxed focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/20"
      />
      <div className="flex justify-end">
        <button
          type="button"
          onClick={onSave}
          disabled={saving || !hasDraft}
          className="flex items-center gap-1.5 rounded-xl bg-hyper-primary px-4 py-2 text-sm font-medium text-white hover:bg-hyper-navy disabled:cursor-not-allowed disabled:opacity-40"
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          {current.trim() ? "Save Structure Rules" : "Reset to Default Layout"}
        </button>
      </div>
    </div>
  );
}

function BlogInstructionsFieldRow({
  field,
  draftValue,
  saving,
  onChange,
  onSave,
}: {
  field: IntegrationField;
  draftValue?: string;
  saving: boolean;
  onChange: (v: string) => void;
  onSave: () => void;
}) {
  const current = draftValue ?? field.value ?? "";
  const hasDraft = draftValue !== undefined && draftValue !== (field.value || "");

  return (
    <div className="settings-field-row">
      <div className="mb-2">
        <label className="text-sm font-medium text-hyper-navy">{field.label}</label>
        <p className="text-xs text-text-secondary">{field.description}</p>
      </div>
      <textarea
        value={current}
        onChange={(e) => onChange(e.target.value)}
        rows={4}
        placeholder="Always include tables, stat graphics, genuine backlinks, photorealistic images, and a demo CTA..."
        className="mb-2 w-full rounded-xl border border-hyper-border px-3 py-2 text-sm focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/20"
      />
      <div className="flex justify-end">
        <button
          type="button"
          onClick={onSave}
          disabled={saving || !hasDraft}
          className="flex items-center gap-1.5 rounded-xl bg-hyper-primary px-4 py-2 text-sm font-medium text-white hover:bg-hyper-navy disabled:cursor-not-allowed disabled:opacity-40"
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Save Instructions
        </button>
      </div>
    </div>
  );
}

function AnthropicModelFieldRow({
  field,
  draftValue,
  saving,
  onChange,
  onSave,
}: {
  field: IntegrationField;
  draftValue?: string;
  saving: boolean;
  onChange: (v: string) => void;
  onSave: () => void;
}) {
  const MODELS: { value: string; label: string }[] = [
    { value: "claude-sonnet-5", label: "claude-sonnet-5 — recommended (balanced)" },
    { value: "claude-opus-5", label: "claude-opus-5 — highest quality" },
    { value: "claude-fable-5", label: "claude-fable-5 — top tier / hardest tasks" },
    { value: "claude-sonnet-4-6", label: "claude-sonnet-4-6" },
    { value: "claude-opus-4-8", label: "claude-opus-4-8" },
    { value: "claude-opus-4-7", label: "claude-opus-4-7" },
    { value: "claude-opus-4-6", label: "claude-opus-4-6" },
    { value: "claude-sonnet-4-5", label: "claude-sonnet-4-5" },
    { value: "claude-sonnet-4-5-20250929", label: "claude-sonnet-4-5-20250929 (pinned)" },
    { value: "claude-haiku-4-5", label: "claude-haiku-4-5 — faster / lower cost" },
    { value: "claude-haiku-4-5-20251001", label: "claude-haiku-4-5-20251001 (pinned)" },
  ];

  const saved = field.value || "claude-sonnet-5";
  const current = draftValue ?? saved;
  const hasDraft = draftValue !== undefined && draftValue !== saved;
  const known = MODELS.some((m) => m.value === current);

  return (
    <div className="settings-field-row">
      <div className="mb-2">
        <label className="text-sm font-medium text-hyper-navy">{field.label}</label>
        <p className="text-xs text-text-secondary">{field.description}</p>
      </div>
      <div className="flex flex-wrap gap-2">
        <select
          value={known ? current : "__custom__"}
          onChange={(e) => {
            if (e.target.value === "__custom__") return;
            onChange(e.target.value);
          }}
          className="settings-input w-full min-w-0 flex-1 sm:min-w-[240px]"
        >
          {!known && current ? (
            <option value="__custom__">{current} (saved)</option>
          ) : null}
          {MODELS.map((m) => (
            <option key={m.value} value={m.value}>
              {m.label}
            </option>
          ))}
        </select>
        <Button
          type="button"
          variant="primary"
          size="sm"
          onClick={onSave}
          disabled={saving || !hasDraft}
          loading={saving}
          className="settings-btn-row-primary btn-sheen relative overflow-hidden"
        >
          <Save className="h-4 w-4" />
          Save
        </Button>
      </div>
      <p className="mt-2 text-xs text-slate-500">
        Active model:{" "}
        <code className="rounded bg-slate-100 px-1.5 py-0.5 font-mono text-[11px] text-hyper-navy">
          {saved}
        </code>
        . All blogs use this after Save.
      </p>
    </div>
  );
}

function TopicModeFieldRow({
  field,
  draftValue,
  saving,
  onChange,
  onSave,
}: {
  field: IntegrationField;
  draftValue?: string;
  saving: boolean;
  onChange: (v: string) => void;
  onSave: () => void;
}) {
  const current = draftValue ?? field.value ?? "hybrid";
  const hasDraft = draftValue !== undefined && draftValue !== field.value;

  return (
    <div className="settings-field-row">
      <div className="mb-2">
        <label className="text-sm font-medium text-hyper-navy">{field.label}</label>
        <p className="text-xs text-text-secondary">{field.description}</p>
      </div>
      <div className="flex flex-wrap gap-2">
        <select
          value={current}
          onChange={(e) => onChange(e.target.value)}
          className="w-full min-w-0 flex-1 rounded-xl border border-hyper-border px-3 py-2 text-sm focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/20 sm:min-w-[200px]"
        >
          <option value="manual">Manual — you pick topics</option>
          <option value="auto">Auto — AI picks best topic</option>
          <option value="hybrid">Both — manual + auto option</option>
        </select>
        <button
          type="button"
          onClick={onSave}
          disabled={saving || !hasDraft}
          className="flex items-center gap-1.5 rounded-xl bg-hyper-primary px-4 py-2 text-sm font-medium text-white hover:bg-hyper-navy disabled:cursor-not-allowed disabled:opacity-40"
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Save
        </button>
      </div>
    </div>
  );
}

function TeamsNotificationsToggle({
  field,
  saving,
  onSave,
}: {
  field: IntegrationField;
  saving: boolean;
  onSave: (enabled: boolean) => void;
}) {
  const enabled = (field.value || "true").toLowerCase() !== "false";

  return (
    <div className="settings-field-row">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0 flex-1">
          <label className="text-sm font-medium text-hyper-navy">{field.label}</label>
          <p className="text-xs text-text-secondary">{field.description}</p>
          <p className="mt-1 text-[11px] text-text-muted">
            When off, Teams will not receive topic, review, or publish cards. The webhook URL is kept.
          </p>
        </div>
        <button
          type="button"
          role="switch"
          aria-checked={enabled}
          disabled={saving}
          onClick={() => onSave(!enabled)}
          className={cn(
            "relative inline-flex h-8 w-14 shrink-0 items-center rounded-full transition-colors disabled:opacity-50",
            enabled ? "bg-emerald-500" : "bg-slate-300"
          )}
        >
          <span
            className={cn(
              "inline-block h-6 w-6 rounded-full bg-white shadow transition-transform",
              enabled ? "translate-x-7" : "translate-x-1"
            )}
          />
        </button>
      </div>
      <p className="mt-2 text-xs font-semibold text-slate-600">
        {saving ? "Saving…" : enabled ? "Currently sending to Teams" : "Currently muted"}
      </p>
    </div>
  );
}

function TeamsWebhookFieldRow({
  field,
  draftValue,
  showSecret,
  saving,
  deleting,
  onToggleSecret,
  onChange,
  onSave,
  onDelete,
  onMessage,
}: {
  field: IntegrationField;
  draftValue?: string;
  showSecret: boolean;
  saving: boolean;
  deleting: boolean;
  onToggleSecret: () => void;
  onChange: (v: string) => void;
  onSave: () => void;
  onDelete: () => void;
  onMessage: (msg: { type: "success" | "error"; text: string }) => void;
}) {
  const [testing, setTesting] = useState(false);
  const hasDraft = draftValue !== undefined && draftValue.trim() !== "";
  const displayValue =
    draftValue !== undefined
      ? draftValue
      : field.secret
        ? ""
        : field.value || "";

  async function handleTest() {
    setTesting(true);
    try {
      const res = await api.testTeamsWebhook({
        webhook_url: draftValue?.trim() || undefined,
        channel_name: "Blog automation Chatbot",
      });
      onMessage({ type: "success", text: res.message });
    } catch (e) {
      onMessage({ type: "error", text: String(e) });
    } finally {
      setTesting(false);
    }
  }

  return (
    <div className="settings-field-row">
      <div className="mb-2 flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between sm:gap-3">
        <div className="min-w-0">
          <label className="text-sm font-medium text-hyper-navy">{field.label}</label>
          <p className="text-xs text-text-secondary">{field.description}</p>
          <p className="mt-1 text-[11px] text-text-muted">
            Your channel link is not the webhook. In <strong>Blog automation Chatbot</strong> →
            Connectors → Incoming Webhook → copy the URL starting with{" "}
            <code className="rounded bg-surface-2 px-1 font-mono text-[10px]">https://...webhook.office.com/...</code>
          </p>
        </div>
        <StatusBadge field={field} />
      </div>

      <div className="flex flex-wrap gap-2">
        <div className="relative w-full min-w-0 flex-1 sm:min-w-[200px]">
          <input
            type={showSecret ? "text" : "password"}
            value={displayValue}
            onChange={(e) => onChange(e.target.value)}
            placeholder="https://outlook.office.com/webhook/..."
            className="w-full rounded-xl border border-hyper-border px-3 py-2 pr-10 text-sm focus:border-hyper-primary focus:outline-none focus:ring-2 focus:ring-hyper-primary/20"
          />
          <button
            type="button"
            onClick={onToggleSecret}
            className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-1 text-text-muted hover:text-hyper-primary"
          >
            {showSecret ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          </button>
        </div>
        <button
          type="button"
          onClick={onSave}
          disabled={saving || !hasDraft}
          className="flex items-center gap-1.5 rounded-xl bg-hyper-primary px-4 py-2 text-sm font-medium text-white hover:bg-hyper-navy disabled:cursor-not-allowed disabled:opacity-40"
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Save
        </button>
        <button
          type="button"
          onClick={handleTest}
          disabled={testing || (!hasDraft && !field.is_set)}
          className="flex items-center gap-1.5 rounded-xl border border-hyper-primary px-4 py-2 text-sm font-medium text-hyper-primary hover:bg-hyper-primary/5 disabled:cursor-not-allowed disabled:opacity-40"
        >
          {testing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          Test Teams
        </button>
        {(field.is_set || field.source === "database") && (
          <button
            type="button"
            onClick={onDelete}
            disabled={deleting}
            className="flex items-center gap-1.5 rounded-xl border border-hyper-border px-4 py-2 text-sm font-medium text-hyper-red hover:bg-red-50 disabled:opacity-50"
          >
            {deleting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
            Delete
          </button>
        )}
      </div>
    </div>
  );
}

function IntegrationFieldRow({
  field,
  draftValue,
  showSecret,
  saving,
  deleting,
  onToggleSecret,
  onChange,
  onSave,
  onDelete,
}: {
  field: IntegrationField;
  draftValue?: string;
  showSecret: boolean;
  saving: boolean;
  deleting: boolean;
  onToggleSecret: () => void;
  onChange: (v: string) => void;
  onSave: () => void;
  onDelete: () => void;
}) {
  const hasDraft = draftValue !== undefined && draftValue.trim() !== "";
  const displayValue =
    draftValue !== undefined
      ? draftValue
      : field.secret
        ? ""
        : field.value || "";

  const placeholder = field.secret
    ? field.is_set
      ? field.masked_value || "•••••••• (saved)"
      : field.is_placeholder
        ? "Replace placeholder — paste real API key"
        : "Paste API key and click Save"
    : field.value || `Enter ${field.label.toLowerCase()}...`;

  return (
    <div className="settings-field-row">
      <div className="mb-2 flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between sm:gap-3">
        <div className="min-w-0">
          <label className="text-sm font-medium text-hyper-navy">
            {field.label}
          </label>
          <p className="text-xs text-text-secondary">{field.description}</p>
        </div>
        <StatusBadge field={field} />
      </div>

      <div className="settings-btn-row">
        <div className="relative w-full min-w-0 flex-1 sm:min-w-[200px]">
          <input
            type={field.secret && !showSecret ? "password" : "text"}
            value={displayValue}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            className="settings-input pr-10"
          />
          {field.secret && (
            <button
              type="button"
              onClick={onToggleSecret}
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-text-muted transition-colors hover:bg-slate-100 hover:text-hyper-primary"
            >
              {showSecret ? (
                <EyeOff className="h-4 w-4" />
              ) : (
                <Eye className="h-4 w-4" />
              )}
            </button>
          )}
        </div>

        <Button
          type="button"
          variant="primary"
          size="sm"
          onClick={onSave}
          disabled={saving || !hasDraft}
          loading={saving}
          className="settings-btn-row-primary btn-sheen relative overflow-hidden"
        >
          <Save className="h-4 w-4" />
          Save
        </Button>

        {(field.is_set || field.source === "database") && (
          <Button
            type="button"
            variant="danger"
            size="sm"
            onClick={onDelete}
            disabled={deleting}
            loading={deleting}
          >
            <Trash2 className="h-4 w-4" />
            Delete
          </Button>
        )}
      </div>
    </div>
  );
}

function StatusBadge({ field }: { field: IntegrationField }) {
  if (field.is_placeholder) {
    return (
      <span className="flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-[10px] font-medium text-amber-800">
        <AlertTriangle className="h-3 w-3" />
        Placeholder (.env)
      </span>
    );
  }
  if (field.is_set) {
    return (
      <span className="flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-medium text-emerald-700">
        <CheckCircle2 className="h-3 w-3" />
        {field.source === "database" ? "Saved" : "Configured"}
      </span>
    );
  }
  return (
    <span className="flex items-center gap-1 rounded-full bg-surface-2 px-2 py-0.5 text-[10px] font-medium text-text-muted">
      <XCircle className="h-3 w-3" />
      Not set
    </span>
  );
}
